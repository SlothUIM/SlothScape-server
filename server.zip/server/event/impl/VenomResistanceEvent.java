package server.event.impl;

import server.event.Events;
import server.model.Entity;
import server.model.Health;
import server.model.HealthStatus;

public class VenomResistanceEvent extends Events<Entity> {

	public VenomResistanceEvent(Entity attachment, int ticks) {
		super("venom_resistance_event", attachment, ticks);
	}

	@Override
	public void execute() {
		super.stop();
		if (attachment == null) {
			return;
		}
		Health health = attachment.getHealth();
		health.removeNonsusceptible(HealthStatus.VENOM);
	}

}
