package server.event.impl;

import server.event.Events;
import server.model.Entity;
import server.model.Health;
import server.model.HealthStatus;

public class PoisonResistanceEvent extends Events<Entity> {

	public PoisonResistanceEvent(Entity attachment, int ticks) {
		super("poison_resistance_event", attachment, ticks);
	}

	@Override
	public void execute() {
		if (attachment == null) {
			super.stop();
			return;
		}
		super.stop();

		Health health = attachment.getHealth();
		health.removeNonsusceptible(HealthStatus.POISON);
	}

}
