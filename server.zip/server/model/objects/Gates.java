package server.model.objects;

import server.Server;
import server.model.players.Client;
import server.model.items.*;
import server.model.players.*;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;

	/*
	*
	*
	* Gates made by Sloth
	*
	*
	*/
	public class Gates {
	
		private Client c;
		public Gates(Client c){
			this.c = c;
		}													  //(c, objectType, obX, obY, 
		
		
			public final int Event = 50;
				public void PassDoubleGate_with_req(int ID, int ID2, int X, int Y, int firstface, int secondFace, int direction){
					int tempX;
					int tempY;
				/****
				*	face 
				*	0 = westside
				*	1 = northside
				*	2 = east side
				*	3 = southside
				*****/
						switch(direction) {
							case 0: //south
								c.getPA().object(-1, X, Y, 0, 0);
								c.getPA().object(-1, X+1, Y, 0, 0);
								c.getPA().object(ID, X, Y-1, 0, 0);
								c.getPA().object(ID2, X, Y-2, 0, 0);
								tempX = 0;
								tempY = -1;
								break;
							case 1: //north
								c.getPA().object(-1, X, Y, 0, 0);
								c.getPA().object(-1, X-1, Y, 0, 0);
								c.getPA().object(ID, X, Y+1, 2, 0);
								c.getPA().object(ID2, X, Y+2, 2, 0);
								tempX = 0;
								tempY = +1;
								break;
							case 2: //east
								c.getPA().object(-1, X, Y, 0, 0);
								c.getPA().object(-1, X, Y+1, 0, 0);
								c.getPA().object(ID, X-1, Y, 3, 0);
								c.getPA().object(ID2, X-2, Y, 3, 0);
								tempX = -1;
								tempY = 0;
								break;
							case 3: //west
								c.getPA().object(-1, X, Y, 0, 0);
								c.getPA().object(-1, X, Y-1, 0, 0);
								c.getPA().object(ID, X+1, Y, 1, 0);
								c.getPA().object(ID2, X+2, Y, 1, 0);
								tempX = 1;
								tempY = 0;
								break;
								default:
								tempX = 0;
								tempY = 0;
								break;
						}
						CycleEventHandler.getSingleton().addEvent(Event, Event, new CycleEvent() {
							@Override
							public void execute(CycleEventContainer container) {
									container.stop();
							}

							@Override
							public void stop() {
								c.getPA().object(-1, X+tempX, Y+tempY, 0, 0);
								c.getPA().object(-1, X+tempX+tempX, Y+tempY+tempY, 0, 0);
								c.getPA().object(ID, X, Y, secondFace, 0);
								c.getPA().object(ID2, X+tempY, Y-tempX, secondFace, 0);
							}

						}, 200);
				}
				public void resetGate(int EventID){
						CycleEventHandler.getSingleton().stopEvent(Event, Event);
				}
				/****
				*	facing direction 
				*	0 = westside
				*	1 = northside
				*	2 = east side
				*	3 = southside
				*****/
				public void OpenDoor_withTimer(Client c, int ID, int X, int Y){
					int X2 = 0;
					int Y2 = 0;
					int face = 0;
					int face2 = 0;
					boolean dooropened = false;
					switch(ID){
						case 24381:
							if(X == 3079 && Y == 3497){
								X2 = 3079;
								Y2 = 3496;
								face = 1;
								face2 = -1;
								doorOpened = true;
							}
							if(X == 3079 && Y == 3496){
								doorOpened = false;
							}
							break;
						default:
							return;
					}
				if(doorOpened) {
					c.getPA().sendSound(Sound.SOUND_LIST.DOOR.getSound(), 0, 10);
					openDoor(c, ID, X, Y, X2, Y2, face, face2, dooropened);
				} else {
					c.getPA().sendSound(Sound.SOUND_LIST.DOOR.getSound(), 0, 10);
						stopEvent();
				}
				}				
				public int eventID = 45;
				public final void openDoor(Client c, int ID, int X, int Y, int X2, int Y2, int face, int face2, boolean dooropened){
					
					c.getPA().object(ID, X2, Y2, face-1, 0);
					c.getPA().object(-1, X, Y, 0, 0);
					CycleEventHandler.getSingleton().addEvent(eventID, c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {
							c.getPA().object(-1, X2, Y2, 0, 0);
							c.getPA().object(ID, X, Y, face2, 0);
						}

					}, 300);
				}	
				public void stopEvent() {
					CycleEventHandler.getSingleton().stopEvent(c, eventID);
					c.sendMessage("You close the door");
					doorOpened = false;
				}
				public boolean doorOpened = false;

				
				
	}