package server.model.content;

import server.world.map.ObjectDef;
import server.model.players.Client;

public class STASH {

    private Client c;

    public STASH(Client c) {
        this.c = c;
    }

    /* Start of STASH Units around map */
    int[][] configs = {
        {1365, 25}, // Varrock palace entrance bush
        {2202, 0},
        {1368, 14},
        {1365, 19},
        {1367, 1},
        {1366, 18},
        {1368, 8}
    };

    /* Old School RuneScape STASH Unit Item IDs */
    public int[][] STASH_ITEMS = {
        {1361, 1169, 1641}, // Example items for beginner bush
        {2583, 1079, 1704}, // Example items for easy bush
        {1127, 1201, 1712}, // Example items for medium bush
        {4131, 1333, 1725}, // Example items for hard bush
        {11840, 6585, 6737} // Example items for elite bush
    };

    public void setSTASH(int objectID, int X, int Y) {
        ObjectDef objID = ObjectDef.getObjectDef(objectID);
            c.startAnimation(898);
        if (c.getItems().playerHasItem(STASHConfig.PLANK, 3) && c.getItems().playerHasItem(STASHConfig.NAILS, 10) && c.getItems().playerHasItem(STASHConfig.HAMMER, 1)) {
            for (int i = 0; i < STASHConfig.EASY_BUSH.length; i++) {
                if (objID.type == STASHConfig.EASY_BUSH[i] && !STASHConfig.EasyStashBuilt[i]) {
                    //c.getPA().sendConfig(configs[i][0], 1 << configs[i][1]);//15943
					c.getPA().object(15943, X, Y, -1, 10);
                    STASHConfig.EasyStashBuilt[i] = true;
					c.getItems().deleteItem2(STASHConfig.PLANK, 3);
					c.getItems().deleteItem2(STASHConfig.NAILS, 10);
                }
            }
		}
        if (c.getItems().playerHasItem(STASHConfig.OAK_PLANK, 3) && c.getItems().playerHasItem(STASHConfig.IRON_NAILS, 10) && c.getItems().playerHasItem(STASHConfig.HAMMER, 1)) {
            for (int i = 0; i < STASHConfig.MEDIUM_BUSH.length; i++) {
                if (objID.type == STASHConfig.MEDIUM_BUSH[i] && !STASHConfig.MediumStashBuilt[i]) {
                    c.getPA().sendConfig(configs[i][0], 1 << configs[i][1]);
                    STASHConfig.MediumStashBuilt[i] = true;
					c.getItems().deleteItem2(STASHConfig.OAK_PLANK, 3);
					c.getItems().deleteItem2(STASHConfig.IRON_NAILS, 10);
                }
            }
		}
        if (c.getItems().playerHasItem(STASHConfig.TEAK_PLANK, 3) && c.getItems().playerHasItem(STASHConfig.STEEL_NAILS, 10) && c.getItems().playerHasItem(STASHConfig.HAMMER, 1)) {
            for (int i = 0; i < STASHConfig.HARD_BUSH.length; i++) {
                if (objID.type == STASHConfig.HARD_BUSH[i] && !STASHConfig.HardStashBuilt[i]) {
                    c.getPA().sendConfig(configs[i][0], 1 << configs[i][1]);
                    STASHConfig.HardStashBuilt[i] = true;
					c.getItems().deleteItem2(STASHConfig.TEAK_PLANK, 3);
					c.getItems().deleteItem2(STASHConfig.STEEL_NAILS, 10);
                }
            }
		}
        if (c.getItems().playerHasItem(STASHConfig.MAHOG_PLANK, 3) && c.getItems().playerHasItem(STASHConfig.STEEL_NAILS, 10) && c.getItems().playerHasItem(STASHConfig.HAMMER, 1)) {
            for (int i = 0; i < STASHConfig.ELITE_BUSH.length; i++) {
                if (objID.type == STASHConfig.ELITE_BUSH[i] && !STASHConfig.EliteStashBuilt[i]) {
                    c.getPA().sendConfig(configs[i][0], 1 << configs[i][1]);
                    STASHConfig.EliteStashBuilt[i] = true;
					c.getItems().deleteItem2(STASHConfig.MAHOG_PLANK, 3);
					c.getItems().deleteItem2(STASHConfig.STEEL_NAILS, 10);
                }
            }
		}
                c.sendMessage("You build a new STASH unit.");
    }

    public void takeSTASH(int objectID) {
        ObjectDef objID = ObjectDef.getObjectDef(objectID);
        for (int i = 0; i < STASHConfig.EASY_BUSH.length; i++) {
            if (objID.type == STASHConfig.EASY_BUSH[i] && STASHConfig.EasyStashBuilt[i] && !STASHConfig.taken[1][i] && STASHConfig.Stored[1][i]) {
                for (int item : STASH_ITEMS[0]) {
                    c.getItems().addItem(item, 1);
                }
                c.sendMessage("You take the items out of your STASH");
                STASHConfig.taken[1][i] = true;
            }
        }
        // Similarly add for other types like MEDIUM_BUSH, HARD_BUSH, etc.
    }

    public void storeSTASH(int objectID) {
        ObjectDef objID = ObjectDef.getObjectDef(objectID);
      if (c.getItems().playerHasItem(STASH_ITEMS[0][0], 1) && c.getItems().playerHasItem(STASH_ITEMS[0][1], 1) && c.getItems().playerHasItem(STASH_ITEMS[0][2], 1))
       for (int i = 0; i < STASHConfig.EASY_BUSH.length; i++) {
            if (objID.type == STASHConfig.EASY_BUSH[i] && STASHConfig.EasyStashBuilt[i] && !STASHConfig.taken[1][i]) {
                for (int item : STASH_ITEMS[0]) {
                    c.getItems().deleteItem2(item, 1);
                }
                c.sendMessage("You add the items to your STASH");
                STASHConfig.Stored[1][i] = true;
                STASHConfig.taken[1][i] = false;
            }
        }
        // Similarly add for other types like MEDIUM_BUSH, HARD_BUSH, etc.
    }

    public void handleLoginConfigs() {
        for (int i = 0; i < STASHConfig.EasyStashBuilt.length; i++) {
            if (STASHConfig.EasyStashBuilt[i]) {
                c.getPA().sendConfig(configs[i][0], 1 << configs[i][1]);
            }
        }
        // Similarly add for other levels like MEDIUM, HARD, etc.
    }

    public void useSTASHItem(int itemId, int objX, int objY, int objectID) {
        ObjectDef objID = ObjectDef.getObjectDef(objectID);
        for (int i = 0; i < STASHConfig.EASY_BUSH.length; i++) {
            if (objID.type == STASHConfig.EASY_BUSH[i]) {
                if (!STASHConfig.Stored[1][i]) {
                    takeSTASH(objectID);
                } else {
                    storeSTASH(objectID);
                }
            }
        }
        // Similarly add for other types like MEDIUM_BUSH, HARD_BUSH, etc.
    }
}
