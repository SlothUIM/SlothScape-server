package server.model.npcs;

import server.util.Misc;
import server.util.Buffer;
import server.model.items.*;
import server.model.players.Client;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.npcs.NPCDumbPathFinder;
import server.model.npcs.NPCClipping;
import server.model.Entity;

public abstract class NPC extends Entity{
	public int npcId;
	public String name;
	public int npcType;
	public int combat;
	public int absX, absY;
	public int heightLevel;
	public int makeX, makeY, maxHit, defence, attack, moveX, moveY, direction,
			walkingType, size;
	public int spawnX, spawnY;
	public int viewX, viewY;
	public int lastX, lastY;
	public boolean teleporting = false;
	
	private long lastRandomWalk;
	private long lastRandomWalkHome;

	private long randomWalkDelay;
	private long randomStopDelay;
	public long lastRandomlySelectedPlayer = System.currentTimeMillis();
	
    public int npcAttackAnimation;
    public int npcBlockAnimation;
    public int npcAttack2Animation;
    public int npcDeathAnimation;
	/**
	 * attackType: 0 = melee, 1 = range, 2 = mage
	 */
	public int attackType, projectileId, endGfx, spawnedBy, hitDelayTimer, HP,
			MaxHP, hitDiff, animNumber, actionTimer, enemyX, enemyY;
	public boolean applyDead, isDead, needRespawn, respawns;
	public boolean walkingHome, underAttack, summoner, trapNotice;
	public int freezeTimer, attackTimer, killerId, killedBy, oldIndex,
			underAttackBy, summonedBy;
	public long lastDamageTaken;
	public int impTimer;
	@Setter public boolean randomWalk;
	@Setter public boolean neverWalkHome;
	public boolean dirUpdateRequired;
	public boolean animUpdateRequired;
	public boolean hitUpdateRequired;
	public boolean updateRequired;
	public boolean forcedChatRequired;
	public boolean faceToUpdateRequired;
	public boolean randomfollow;
	public int firstAttacker;
	public String forcedText;

	public NPC(int _npcId, int _npcType, NPCDefinitions definition) {
		super(_npcId, definition.getNpcName());
		this.definition = definition;
		npcId = _npcId;
		npcType = _npcType;
		combat = -1;
		direction = -1;
		isDead = false;
		applyDead = false;
		actionTimer = 0;
		randomWalk = true;
	}

	public void updateNPCMovement(Buffer str) {
		if (direction == -1) {

			if (updateRequired) {

				str.writeBits(1, 1);
				str.writeBits(2, 0);
			} else {
				str.writeBits(1, 0);
			}
		} else {

			str.writeBits(1, 1);
			str.writeBits(2, 1);
			str.writeBits(3, Misc.xlateDirectionToClient[direction]);
			if (updateRequired) {
				str.writeBits(1, 1);
			} else {
				str.writeBits(1, 0);
			}
		}
	}
public void requestTransform(int id) {
    	transformId = id;
    	transformUpdateRequired = true;
    	updateRequired = true;
	}
	
	public boolean transformUpdateRequired = false, isTransformed = false;
	public int transformId;
	public void shearSheep(Client player, int itemNeeded, int itemGiven, int animation, final int currentId, final int newId, int transformTime) {
		if (!player.getItems().playerHasItem(itemNeeded)) {
			player.sendMessage("You need " + ItemAssistant.getItemName(itemNeeded).toLowerCase() + " to do that.");
			return;
		}
		if (transformId == newId) {
			player.sendMessage("This sheep has already been shorn.");
			return;
		}
		if (NPCHandler.npcs[npcId].isTransformed) {
			return;
		}
		if (animation > 0) {
			player.startAnimation(animation);
		}
		requestTransform(newId);
		player.getItems().addItem(itemGiven, 1);
		player.sendMessage("You get some " + ItemAssistant.getItemName(itemGiven).toLowerCase() + ".");
		CycleEventHandler.getSingleton().addEvent(player, new CycleEvent() {

			@Override
			public void execute(CycleEventContainer container) {
				requestTransform(currentId);
				container.stop();
			}

			@Override
			public void stop() {
				NPCHandler.npcs[npcId].isTransformed = false;
			}
		}, transformTime);
	}
	public void appendTransformUpdate(Buffer str) {
    	str.writeWordBigEndianA(transformId);
	}
	/**
	 * Text update
	 **/

	public void forceChat(String text) {
		forcedText = text;
		forcedChatRequired = true;
		updateRequired = true;
	}

	/**
	 * Graphics
	 **/

	public int mask80var1 = 0;
	public int mask80var2 = 0;
	protected boolean mask80update = false;

	public void appendMask80Update(Buffer str) {
		str.writeWord(mask80var1);
		str.writeDWord(mask80var2);
	}

	public void gfx100(int gfx) {
		mask80var1 = gfx;
		mask80var2 = 6553600;
		mask80update = true;
		updateRequired = true;
	}

	public void gfx0(int gfx) {
		mask80var1 = gfx;
		mask80var2 = 65536;
		mask80update = true;
		updateRequired = true;
	}

	public void appendAnimUpdate(Buffer str) {
		str.writeWordBigEndian(animNumber);
		str.writeByte(1);
	}

	public NPCDefinitions getDefinition() {
		return definition;
	}
	private NPCDefinitions definition;
	
	public int getSize() {
		if (definition == null)
			return 1;
		return definition.getSize();
	}
	/**
	 * 
	 Face
	 * 
	 **/

	public int FocusPointX = -1, FocusPointY = -1;
	public int face = 0;

	private void appendSetFocusDestination(Buffer str) {
		str.writeWordBigEndian(FocusPointX);
		str.writeWordBigEndian(FocusPointY);
	}

	public void turnNpc(int i, int j) {
		FocusPointX = 2 * i + 1;
		FocusPointY = 2 * j + 1;
		updateRequired = true;

	}

	public void appendFaceEntity(Buffer str) {
		str.writeWord(face);
	}

	public void faceEntity(int index) {
		if (!facePlayer) {
			if (face == -1) {
				return;
			}
			face = -1;
		} else {
			face = index + 32768;
		}
		dirUpdateRequired = true;
		updateRequired = true;
	}
		public boolean canFacePlayer() {
		return facePlayer;
	}
	public int getX() {
		return absX;
	}

	public void setX(int x) {
		this.absX = x;
	}

	public int getY() {
		return absY;
	}
	public int getHeight() {
		return heightLevel;
	}

	public void setY(int y) {
		this.absY = y;
	}
	public void setHeight(int h) {
		this.heightLevel = h;
	}
	public void teleport(int x, int y, int z) {
		teleporting = true;
		this.setX(x);
		this.setY(y);
		setHeight(z);
	}
	/**
	 * Makes the npcs either able or unable to face other players
	 * 
	 * @param facePlayer
	 *            {@code true} if the npc can face players
	 */
	public void setFacePlayer(boolean facePlayer) {
		this.facePlayer = facePlayer;
	}
	private boolean facePlayer = true;
	public void faceEntity(Entity entity) {
		if (!facePlayer || entity == null) {
			if (face == -1) {
				return;
			}
			face = -1;
		} else {
			face = entity.getIndex() + (entity.isPlayer() ? 32768 : 0);
		}
		dirUpdateRequired = true;
		updateRequired = true;
	}
	public void facePlayer(int player) {
		boolean face2 = true;
		if(npcType > 308 && npcType < 335)
			face2 = false;
		if(face2){
			face = player + 32768;
			dirUpdateRequired = true;
			updateRequired = true;
		}
	}

	public void appendFaceToUpdate(Buffer str) {
		str.writeWordBigEndian(viewX);
		str.writeWordBigEndian(viewY);
	}

	public void appendNPCUpdateBlock(Buffer str) {
		if (!updateRequired)
			return;
		int updateMask = 0;
		if (animUpdateRequired)
			updateMask |= 0x10;
		if (hitUpdateRequired2)
			updateMask |= 8;
		if (mask80update)
			updateMask |= 0x80;
		if (dirUpdateRequired)
			updateMask |= 0x20;
		if (forcedChatRequired)
			updateMask |= 1;
		if (hitUpdateRequired)
			updateMask |= 0x40;
		if (FocusPointX != -1)
			updateMask |= 4;
		if (transformUpdateRequired)
			updateMask |= 2;
		str.writeByte(updateMask);

		if (animUpdateRequired)
			appendAnimUpdate(str);
		if (hitUpdateRequired2)
			appendHitUpdate2(str);
		if (mask80update)
			appendMask80Update(str);
		if (dirUpdateRequired)
			appendFaceEntity(str);
		if (forcedChatRequired) {
			str.writeString(forcedText);
		}
		if (transformUpdateRequired) {	
			appendTransformUpdate(str);
		}
		if (hitUpdateRequired)
			appendHitUpdate(str);
		if (FocusPointX != -1)
			appendSetFocusDestination(str);

	}

	public void clearUpdateFlags() {
		updateRequired = false;
		forcedChatRequired = false;
		hitUpdateRequired = false;
		hitUpdateRequired2 = false;
		animUpdateRequired = false;
		dirUpdateRequired = false;
		transformUpdateRequired = false;
		mask80update = false;
		forcedText = null;
		moveX = 0;
		moveY = 0;
		direction = -1;
		FocusPointX = -1;
		FocusPointY = -1;
	}

	public int getNextWalkingDirection() {
		int dir;
		dir = Misc.direction(absX, absY, (absX + moveX), (absY + moveY));
		if (dir == -1)
			return -1;
		dir >>= 1;
		absX += moveX;
		absY += moveY;
		return dir;
	}

	public void getNextNPCMovement() {
		direction = -1;
		if (freezeTimer == 0) {
			direction = getNextWalkingDirection();
		}
	}

	public void appendHitUpdate(Buffer str) {
		if (HP <= 0) {
			isDead = true;
		}
		str.writeByteC(hitDiff);
		if (hitDiff > 0) {
			str.writeByteS(1);
		} else {
			str.writeByteS(0);
		}
		str.writeByteS(HP);
		str.writeByteC(MaxHP);
	}

	public int hitDiff2 = 0;
	public boolean hitUpdateRequired2 = false;

	public void appendHitUpdate2(Buffer str) {
		if (HP <= 0) {
			isDead = true;
		}
		str.writeByteA(hitDiff2);
		if (hitDiff2 > 0) {
			str.writeByteC(1);
		} else {
			str.writeByteC(0);
		}
		str.writeByteA(HP);
		str.writeByte(MaxHP);
	}

	public void handleHitMask(int damage) {
		if (!hitUpdateRequired) {
			hitUpdateRequired = true;
			hitDiff = damage;
		} else if (!hitUpdateRequired2) {
			hitUpdateRequired2 = true;
			hitDiff2 = damage;
		}
		updateRequired = true;
	}

	public int getX() {
		return absX;
	}

	public int getY() {
		return absY;
	}
	public int getH() {
		return heightLevel;
	}

			public boolean inMulti() {
				if((absX >= 3136 && absX <= 3327 && absY >= 3519 && absY <= 3607) || 
				(absX >= 3190 && absX <= 3327 && absY >= 3648 && absY <= 3839) ||  
				(absX >= 3200 && absX <= 3390 && absY >= 3840 && absY <= 3967) || 
				(absX >= 2992 && absX <= 3007 && absY >= 3912 && absY <= 3967) || 
				(absX >= 2946 && absX <= 2959 && absY >= 3816 && absY <= 3831) || 
				(absX >= 3008 && absX <= 3199 && absY >= 3856 && absY <= 3903) || 
				(absX >= 3008 && absX <= 3071 && absY >= 3600 && absY <= 3711) || 
				(absX >= 3072 && absX <= 3327 && absY >= 3608 && absY <= 3647) ||
				(absX >= 2624 && absX <= 2690 && absY >= 2550 && absY <= 2619) ||
				(absX >= 2371 && absX <= 2422 && absY >= 5062 && absY <= 5117) ||
				(absX >= 2896 && absX <= 2927 && absY >= 3595 && absY <= 3630) ||
				(absX >= 2892 && absX <= 2932 && absY >= 4435 && absY <= 4464) ||
				(absX >= 2256 && absX <= 2287 && absY >= 4680 && absY <= 4711) ||
				(absX >= 2862 && absX <= 2876 && absY >= 5351 && absY <= 5369) ||
				(absX >= 2918 && absX <= 2936 && absY <= 5331 && absY >= 5318) ||
				(absX >= 2842 && absX <= 2889 && absY <= 5296 && absY >= 5258) ||
				(absX >= 2907 && absX <= 2889 && absY <= 5276 && absY >= 5258) ||
				(absX <= 2943 && absX >= 2815 && absY <= 5375 && absY >= 5246) ||
				(absX <= 2959 && absX >= 2914 && absY <= 4406 && absY >= 4357) ||
				(absX <= 2434 && absX >= 2365 && absY <= 3138 && absY >= 3069)) {
					return true;
				}
				return false;
			}
public boolean inZammyGWD() {		
		if(absX <= 2918 && absX >= 2936 && absY >= 5331 && absY <= 5318) {
			return true;
		}
		return false;
	};
	public boolean inArmadylGWD() {		
		if(absX <= 2842 && absX >= 2824 && absY >= 5296 && absY <= 5308) {
			return true;
		}
		return false;
	}
	public boolean inBandosGWD() {		
		if(absX >= 2864 && absX <= 2876 && absY >= 5351 && absY <= 5369) {
			return true;
		}
		return false;
	}
	public boolean inSaraGWD() {		
		if(absX <= 2907 && absX >= 2889 && absY <= 5276 && absY >= 5258) {
			return true;
		}
		return false;
	}
	public boolean inGodWars() {		
		if(absX <= 2953 && absX >= 2816 && absY <= 5368 && absY >= 5248) {
			return true;
		}
		return false;
	}
	public boolean inWild() {
		if (absX > 2941 && absX < 3392 && absY > 3525 && absY < 3966
				|| absX > 2941 && absX < 3392 && absY > 9918 && absY < 10366) {
			return true;
		}
		return false;
	}
	
	public long getLastRandomWalk() {
		return lastRandomWalk;
	}

	public long getLastRandomWalkhome() {
		return lastRandomWalkHome;
	}

	public void setLastRandomWalkHome(long lastRandomWalkHome) {
		this.lastRandomWalkHome = lastRandomWalkHome;
	}

	public long getRandomStopDelay() {
		return randomStopDelay;
	}

	public void setRandomStopDelay(long randomStopDelay) {
		this.randomStopDelay = randomStopDelay;
	}

	public void setLastRandomWalk(long lastRandomWalk) {
		this.lastRandomWalk = lastRandomWalk;
	}

	public long getRandomWalkDelay() {
		return randomWalkDelay;
	}

	public void setRandomWalkDelay(long randomWalkDelay) {
		this.randomWalkDelay = randomWalkDelay;
	}

	public void setNoRespawn(boolean b) {
		this.noRespawn = b;
	}
	
	public boolean isNoRespawn() {
		return noRespawn;
	}

	private boolean noRespawn;
	public boolean isDragon() {
		switch (npcType) {
		case 137:
		case 139:
		case 239:
		case 241:
		case 242:
		case 243:
		case 244:
		case 245:
		case 246:
		case 247:
		case 248:
		case 249:
		case 250:
		case 251:
		case 252:
		case 253:
		case 254:
		case 255:
		case 256:
		case 257:
		case 258:
		case 259:
		case 260:
		case 261:
		case 262:
		case 263:
		case 264:
		case 265:
		case 266:
		case 267:
		case 268:
		case 269:
		case 270:
		case 271:
		case 272:
		case 273:
		case 274:
		case 275:
		case 1871:
		case 1872:
		case 2642:
		case 2918:
		case 2919:
		case 4000:
		case 4385:
		case 5194:
		case 5872:
		case 5873:
		case 5878:
		case 5879:
		case 5880:
		case 5881:
		case 5882:
		case 6500:
		case 6501:
		case 6502:
		case 6593:
		case 6636:
		case 6652:
		case 7039:
		case 7253:
		case 7254:
		case 7255:
		case 7273:
		case 7274:
		case 7275:
		case 8027:
		case 7553:
		case 7554:
		case 7555:
		case 8609:
			return true;
		}
		return false;
	}
}
