package server.model.npcs;

import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import server.clip.*;
import server.clip.PathFinder;
import server.clip.Region;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.Config;
import server.Server;
import server.model.npcs.NPCDumbPathFinder;
import server.model.npcs.NPCClipping;
import server.model.players.Client;
import server.model.players.Player;
import server.model.objects.Object;
import server.model.objects.Objects;
import server.model.items.CollectionLog;
import server.model.players.Godwars;
import server.model.players.PlayerHandler;
import server.util.Misc;
import server.world.map.VirtualWorld;
import server.world.Boundary;
import server.event.EventManager;
import server.event.Event;
import server.event.EventContainer;

public class NPCHandler {
	public static int maxNPCs = 20000;
	public static int maxListedNPCs = 20000;
	public static int maxNPCDrops = 20000;
	public static NPC npcs[] = new NPC[maxNPCs];
	public static NPCList NpcList[] = new NPCList[maxListedNPCs];


	private Client c;
	public NPCHandler(Client Client) {
		this.c = Client;
	}
	public void init() {
		for (int i = 0; i < maxNPCs; i++) {
			npcs[i] = null;
			NPCDefinitions.getDefinitions()[i] = null;
		}
		loadNPCList("./Data/CFG/npc.cfg");
		loadAutoSpawn("./Data/CFG/spawn-config.cfg");
        try {
            NPCDefinition.init();
        } catch (Exception e) {
            //System.out.println("npc def error");
        }
	}
	public void multiAttackGfx(int i, int gfx) {
		if (npcs[i].projectileId < 0)
			return;
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
				Client c = (Client) PlayerHandler.players[j];
				if (c.heightLevel != npcs[i].heightLevel)
					continue;
				if (PlayerHandler.players[j].goodDistance(c.absX,
						c.absY, npcs[i].absX, npcs[i].absY, 15)) {
					int nX = NPCHandler.npcs[i].getX() + offset(i);
					int nY = NPCHandler.npcs[i].getY() + offset(i);
					int pX = c.getX();
					int pY = c.getY();
					int offX = (nY - pY) * -1;
					int offY = (nX - pX) * -1;
					c.getPA().createPlayersProjectile(nX, nY, offX, offY, 50,
							getProjectileSpeed(i), npcs[i].projectileId, 43,
							31, -c.getId() - 1, 65);
				}
			}
		}
	}

	public boolean switchesAttackers(int i) {
		switch (npcs[i].npcType) {
		case 2551:
		case 2552:
		case 2553:
		case 2559:
		case 2560:
		case 2561:
		case 2563:
		case 2564:
		case 2565:
		case 2892:
		case 2894:
			return true;

		}

		return false;
	}

	public void multiAttackDamage(int i) {
		int max = getMaxHit(i);
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
				Client c = (Client) PlayerHandler.players[j];
				if (c.isDead || c.heightLevel != npcs[i].heightLevel)
					continue;
				if (PlayerHandler.players[j].goodDistance(c.absX,
						c.absY, npcs[i].absX, npcs[i].absY, 15)) {
					if (npcs[i].attackType == 2) {
						if (!c.prayerActive[16]) {
							if (Misc.random(500) + 200 > Misc.random(c
									.getCombat().mageDef())) {
								int dam = Misc.random(max);
								c.dealDamage(dam);
								c.handleHitMask(dam);
							} else {
								c.dealDamage(0);
								c.handleHitMask(0);
							}
						} else {
							c.dealDamage(0);
							c.handleHitMask(0);
						}
					} else if (npcs[i].attackType == 1) {
						if (!c.prayerActive[17]) {
							int dam = Misc.random(max);
							if (Misc.random(500) + 200 > Misc.random(c
									.getCombat().calculateRangeDefence())) {
								c.dealDamage(dam);
								c.handleHitMask(dam);
							} else {
								c.dealDamage(0);
								c.handleHitMask(0);
							}
						} else {
							c.dealDamage(0);
							c.handleHitMask(0);
						}
					}
					if (npcs[i].endGfx > 0) {
						c.gfx0(npcs[i].endGfx);
					}
				}
				c.getPA().refreshSkill(3);
			}
		}
	}

	public int getClosePlayer(int i) {
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
				if (j == npcs[i].spawnedBy)
					return j;
				if (goodDistance(PlayerHandler.players[j].absX,
						PlayerHandler.players[j].absY, npcs[i].absX,
						npcs[i].absY, 2 + distanceRequired(i)
								+ followDistance(i))
						|| isFightCaveNpc(i)) {
					if ((PlayerHandler.players[j].underAttackBy <= 0 && PlayerHandler.players[j].underAttackBy2 <= 0)
							|| PlayerHandler.players[j].inMulti())
						if (PlayerHandler.players[j].heightLevel == npcs[i].heightLevel)
							return j;
				}
			}
		}
		return 0;
	}

	public int getCloseRandomPlayer(int i) {
		ArrayList<Integer> players = new ArrayList<Integer>();
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
                Client c = (Client) Server.playerHandler.players[j];
				if (goodDistance(PlayerHandler.players[j].absX,
						PlayerHandler.players[j].absY, npcs[i].absX,
						npcs[i].absY, npcSize(i) + distanceRequired(i)
								+ followDistance(i))
						|| isFightCaveNpc(i)) {
					if ((PlayerHandler.players[j].underAttackBy <= 0 && PlayerHandler.players[j].underAttackBy2 <= 0)
							|| Boundary.isIn(PlayerHandler.players[j], Boundary.MULTI) || PlayerHandler.players[j].inMulti())
						if (PlayerHandler.players[j].heightLevel == npcs[i].heightLevel)
							if (isZamorakNpc(i) && Godwars.isWearingZamorakItems(c)) {
                                return 0;
                            } else if (isZamorakNpc(i) && !Godwars.isWearingZamorakItems(c)) {
                                players.add(j);
                            } else if (isSaradominNpc(i) && Godwars.isWearingSaradominItems(c)) {
                                return 0;
                            } else if (isSaradominNpc(i) && !Godwars.isWearingSaradominItems(c)) {
                                players.add(j);
                            } else if (isArmadylNpc(i) && Godwars.isWearingArmadylItems(c)) {
								return 0;
                            } else if (isArmadylNpc(i) && !Godwars.isWearingArmadylItems(c)) {
                                players.add(j);
                            } else if (isBandosNpc(i) && Godwars.isWearingBandosItems(c)) {
                                return 0;
                            } else if (isBandosNpc(i) && !Godwars.isWearingBandosItems(c)) {
                                players.add(j);
                            } else if (isBandosBossNpc(i) && !c.inBandosGWD()) {
                                return 0;
                            } else if (isBandosBossNpc(i) && c.inBandosGWD()) {
                                players.add(j);
                            } else {
							    players.add(j);
                            }
				}
			}
		}
		if (players.size() > 0)
			return players.get(Misc.random(players.size() - 1));
		else
			return 0;
	}
    public static int getNpcSize(int npcId) {
        return NPCDefinition.forId(npcId).getSize();
    }
	public static int npcSize(int i) {
		switch (npcs[i].npcType) {
			case 86:
			case 87:
			case 81:
			return 2;
		case 2883:
		case 2882:
		case 2881:
			return 3;
		}
		return 1;
	}

	public boolean isAggressive(int i) {
		switch (npcs[i].npcType) {
			case 172:
			case 174:
			case 175:
			case 180:
		case 2215:
		case 2216:
		case 2217:
		case 2218:
		case 1158:
		case 1160:
		case 2550:
		case 2551:
		case 2552:
		case 2553:
		case 2558:
		case 2559:
		case 2560:
		case 2561:
		case 2562:
		case 2563:
		case 2564:
		case 2565:
		case 2892:
		case 2894:
		case 2881:
		case 2882:
		case 2883:
			return true;
		}
		if (npcs[i].inWild() && npcs[i].MaxHP > 0)
			return true;
		if (isFightCaveNpc(i))
			return true;
		if(isBandosNpc(i) || isSaradominNpc(i) || isZamorakNpc(i) || isArmadylNpc(i))
			return true;
		return false;
	}

	public boolean isFightCaveNpc(int i) {
		switch (npcs[i].npcType) {
		case 2627:
		case 2630:
		case 2631:
		case 2741:
		case 2743:
		case 2745:
			return true;
		}
		return false;
	}
	public boolean isLogNpc(int i) {
		if(i <= 8366 && i >= 8349)
			return true;
		switch (npcs[i].npcType) {
		case 2215:
		case 6247:
		case 6222:
		case 6203:
		case 2025:
		case 2026:
		case 2027:
		case 2028:
		case 2029:
		case 2030:
		case 50:
		case 1160:
		case 3200:
		case 3340:
		case 8133:
		case 2881:
		case 2882:
		case 2883:
			return true;
		}
		return false;
	}
	/**
	 * Summon npc, barrows, etc
	 **/
	public NPC spawnNpc(final Client c, int npcType, int x, int y, int heightLevel,
			int WalkingType, int HP, int maxHit, int attack, int defence,
			boolean attackPlayer, boolean headIcon) {
		// first, search for a free slot
		int slot = -1;
		for (int i = 1; i < maxNPCs; i++) {
			if (npcs[i] == null) {
				slot = i;
				break;
			}
		}
		if (slot == -1) {
			// Misc.println("No Free Slot");
			return; // no free slot found
		}
		NPCDefinitions definition = NPCDefinitions.get(npcType);
		final NPC newNPC = new NPC(slot, npcType, definition);
		newNPC.setX(x);
		newNPC.setY(y);
		newNPC.makeX = x;
		newNPC.makeY = y;
		newNPC.setHeight(heightLevel);
		newNPC.walkingType = WalkingType;
		newNPC.getHealth().setMaximum(HP);
		newNPC.getHealth().reset();
		newNPC.maxHit = maxHit;
		newNPC.attack = attack;
		newNPC.defence = defence;
		newNPC.spawnedBy = c.getId();
		if (headIcon)
			c.getPA().drawHeadicon(1, slot, 0, 0);
		if (attackPlayer) {
			newNPC.underAttack = true;
			newNPC.killerId = c.playerId;
			c.underAttackBy = slot;
			c.underAttackBy2 = slot;
		}
		npcs[slot] = newNPC;
		if (newNPC.npcType == 1605) {
			newNPC.forceChat("You must prove yourself... now!");
			newNPC.gfx100(86);
		}
		if (newNPC.npcType == 1606) {
			newNPC.forceChat("This is only the beginning, you can't beat me!");
			newNPC.gfx100(86);
		}
		if (newNPC.npcType == 1607) {
			newNPC.forceChat("Foolish mortal, I am unstoppable.");
		}
		if (newNPC.npcType == 1608) {
			newNPC.forceChat("Now you feel it... The dark energy.");
		}
		if (newNPC.npcType == 1609) {
			newNPC.forceChat("Aaaaaaaarrgghhhh! The power!");
		}
		return newNPC;
	}
	public static NPC spawnNpc2(int npcType, int x, int y, int heightLevel,
			int WalkingType, int HP, int maxHit, int attack, int defence) {
		// first, search for a free slot
		int slot = -1;
		for (int i = 1; i < maxNPCs; i++) {
			if (npcs[i] == null) {
				slot = i;
				break;
			}
		}
		if (slot == -1) {
			return; // no free slot found
		}
		NPCDefinitions definition = NPCDefinitions.get(npcType);
		NPC newNPC = new NPC(slot, npcType, definition);
		newNPC.absX = x;
		newNPC.absY = y;
		newNPC.makeX = x;
		newNPC.makeY = y;
		newNPC.heightLevel = heightLevel;
		newNPC.walkingType = WalkingType;
		newNPC.HP = HP;
		newNPC.MaxHP = HP;
		newNPC.maxHit = maxHit;
		newNPC.attack = attack;
		newNPC.defence = defence;
		npcs[slot] = newNPC;		
	}
	public void spawnNpc3(Client c, int npcType, int x, int y, int heightLevel, int WalkingType, int HP, int maxHit, int attack, int defence, boolean attackPlayer, boolean headIcon, boolean summonFollow) {
		// first, search for a free slot
		int slot = -1;
		for (int i = 1; i < maxNPCs; i++) {
			if (npcs[i] == null) {
				slot = i;
				break;
			}
		}
		if(slot == -1) {
			//Misc.println("No Free Slot");
			return;		// no free slot found
		}
		NPCDefinitions definition = NPCDefinitions.get(npcType);
		NPC newNPC = new NPC(slot, npcType, definition);
		newNPC.setX(x);
		newNPC.setY(y);
		newNPC.makeX = x;
		newNPC.makeY = y;
		newNPC.setHeight(heightLevel);
		newNPC.walkingType = WalkingType;
		newNPC.getHealth().setMaximum(HP);
		newNPC.getHealth().reset();
		newNPC.maxHit = maxHit;
		newNPC.attack = attack;
		newNPC.defence = defence;
		newNPC.spawnedBy = c.getId();
		newNPC.facePlayer(c.getId());
		if(headIcon) 
			c.getPA().drawHeadicon(1, slot, 0, 0);
		if (summonFollow) {
			newNPC.summoner = true;
			newNPC.summonedBy = c.getId();
			c.summonId = npcType;
			c.hasNpc = true;
		}
		if(attackPlayer) {
			newNPC.underAttack = true;
			newNPC.killerId = c.getId();
		}
		npcs[slot] = newNPC;
	}
	
	public int summonItemId(int itemId) {
		if(itemId == 1555) return 761;
		if(itemId == 1556) return 762;
		if(itemId == 1557) return 763;
		if(itemId == 1558) return 764;
		if(itemId == 1559) return 765;
		if(itemId == 1560) return 766;
		if(itemId == 1561) return 768;
		if(itemId == 1562) return 769;
		if(itemId == 1563) return 770;
		if(itemId == 1564) return 771;
		if(itemId == 1565) return 772;
		if(itemId == 1566) return 773;
		if(itemId == 7585) return 3507;
		if(itemId == 7584) return 3506;
		if(itemId == 7583) return 3505;
		if(itemId == 11995) return 2055; //ele
		if(itemId == 13178) return 6637; //Callisto
		if(itemId == 13247) return 6630; //Hellpuppy
		if(itemId == 12643) return 6626; //dag sup
		if(itemId == 12644) return 6627; //dag prime
		if(itemId == 12645) return 6630; //dag rex
		if(itemId == 12646) return 6635; //baby mole
		if(itemId == 12647) return 6637; //kalphite princess
		if(itemId == 12648) return 6639; //pet smoke devil
		if(itemId == 12649) return 6631; //pet kree'arra
		if(itemId == 12650) return 6632; //bandos
		if(itemId == 12651) return 6633; //sara
		if(itemId == 12652) return 6634; //kril
		if(itemId == 12653) return 6636; //prince
		if(itemId == 12655) return 6640; //pet kraken
		if(itemId == 19730) return 6296; //bloodhound
		if(itemId == 12816) return 388; //dark core
		return 0;
	}
			public int[] zamorak = {
				6218, 6257, 6256, 6255, 6229, 6230, 6231,
				6270, 6216, 6214, 6211, 6221, 6276, 6277,
				6219
			};

			public int[] saradomin = {
				6257, 6256, 6259, 6258, 6254, 6255, 6229, 6230, 
				6231, 6221, 6276, 6277, 6219
			};

			public int[] armadyl = { 
				6246, 6233, 6257, 6256, 6255, 6229, 6230, 6231,
				6232, 6234, 6235, 6236, 6237, 6238, 6239, 6240,
				6241, 6242, 6243, 6246, 6244, 6221, 6276, 6277,
				6219
			};

			public int[] bandos = {
				6269, 6210, 6212, 6257, 6256, 6255, 6229, 6230, 
				6231, 6268, 6274, 6283, 6282, 6275, 6221, 6273,
				6276, 6272, 6213, 6277, 6219
				
			};
			public void appendKillCount(int i) {
				Client c = (Client)Server.playerHandler.players[npcs[i].killedBy];
				if(c != null) {
					for(int kl = 0; kl < zamorak.length; kl++) {
						if(npcs[i].npcType == zamorak[kl]) {
							c.zammyKC++;
						}
					}
					for(int kl = 0; kl < saradomin.length; kl++) {
						if(npcs[i].npcType == saradomin[kl]) {
							c.saraKC++;
						}
					}
					for(int kl = 0; kl < armadyl.length; kl++) {
						if(npcs[i].npcType == armadyl[kl]) {
							c.armadylKC++;
						}
					}
					for(int kl = 0; kl < bandos.length; kl++) {
						if(npcs[i].npcType == bandos[kl]) {
							c.bandosKC++;
						}
					}
				}	
			}
	
	/**
	 * Attack animations
	 * 
	 * @param i
	 *            the npc to perform the animation.
	 * @return the animation to be performed.
	 */
	public static int getAttackEmote(int i) {
		return AttackAnimation.handleEmote(i);
	}

	/**
	 * Death animations
	 * 
	 * @param i
	 *            the npc to perform the animation.
	 * @return the animation to be performed.
	 */
	public int getDeadEmote(int i) {
		return DeathAnimation.handleEmote(i);
	}
	/**
	 * Attack delays
	 **/
	public int getNpcDelay(int i) {
		switch (npcs[i].npcType) {
		case 499:
			return 4;
		case 498:
			return 7;
		case 6611:
		case 6612:
			return npcs[i].attackType == 2 ? 6 : 5;
		case 319:
			return npcs[i].attackType == 2 ? 7 : 6;
		case 7554:
			return npcs[i].attackType == 2 ? 4 : 6;
		case 2025:
		case 2028:
		case 963:
		case 965:
			return 7;
		case 6475:
		case 6477:
			return 4;
		case 8030:
		case 8031:
			return 5;
		case 3127:
			case 7700:
			return 8;
		case 2205:
			return 4;
		/*case Brother.AHRIM:
			return 6;
		case Brother.DHAROK:
			return 7;
		case Brother.GUTHAN:
			return 5;
		case Brother.KARIL:
			return 4;
		case Brother.TORAG:
			return 5;
		case Brother.VERAC:
			return 5;*/
		case 3167:
		case 2558:
		case 2559:
		case 2560:
		case 2561:
			return 6;
		// saradomin gw boss
		case 2562:
		case 7597:
		case 7547:
			return 2;
		case 3162:
			return 7;
		default:
			return 5;
		}
	}

	/**
	 * Hit delays
	 **/
	public int getHitDelay(int i) {
		switch (npcs[i].npcType) {
		case 2881:
		case 2882:
		case 3200:
		case 2892:
		case 2894:
			return 3;

		case 2743:
		case 2631:
		case 2558:
		case 2559:
		case 2560:
			return 3;

		case 2745:
			if (npcs[i].attackType == 1 || npcs[i].attackType == 2)
				return 5;
			else
				return 2;

		case 2025:
			return 4;
		case 2028:
			return 3;

		default:
			return 2;
		}
	}

	/**
	 * Npc respawn time
	 **/
		public int getRespawnTime(int i) {
		switch (npcs[i].npcType) {
		case 6600:
		case 6601:
		case 6602:
		case 320:
		case 1049:
		case 6617:
		case 3118:
		case 3120:
		case 6768:
		case 5862:
		case 5054:
		case 2402:
		case 2401:
		case 2400:
		case 2399:
		case 5916:
		case 7604:
		case 7605:
		case 7606:
		case 7585:
		case 5129:
		case 4922:
		case 7563:
		case 7573:
		case 7544:
		case 7566:
		case 7559:
			case 7553:
			case 7554:
			case 7555:
		case 7560://Trials of Xeric
		case 7527:
		case 7528:
		case 7529:
		case 8679://Colossal Chicken
		case 6014://Void Knight Champion
			return -1;
		case 5001://anti-santa
		case 6477:
		case 5462:
		case 7858:
		case 7859:
		case 7860:
		case 3383:
			return -1;
			
		case 3833:
		case 3845:
			return 300;
			
		case 3407:
			return 600;
			
		case 3842:
			return 180;

		case 963:
		case 965:
			return 10;
			
		case 6475:
			return 25;
			
			/* hydra */
		case 8609:
			return 40;

		case 6618:
		case 6619:
		case 319:
		case 5890:
			return 30;

		case 1046:
		case 465:
			return 60;

		case 6609:
		case 2265:
		case 2266:
		case 2267:
			return 70;

		case 6611:
		case 6612:
		case 492:
			return 90;

		case 2558:
		case 2559:
		case 2560:
		case 2561:
		case 2562:
		case 2563:
		case 2564:
		case 2205:
		case 2206:
		case 2207:
		case 2208:
		case 2215:
		case 2216:
		case 2217:
		case 2218:
		case 3129:
		case 3130:
		case 3131:
		case 3132:
		case 3162:
		case 3163:
		case 3164:
		case 3165:
		case 1641:
		case 1642:
			return 100;

		case 1643:
			return 180;

		case 1654:
			return 250;

		case 3777:
		case 3778:
		case 3779:
		case 3780:
		case 7302:
			return 500;
		default:
			return 25;
		}
	}
	public void newNPC(int npcType, int x, int y, int heightLevel,
			int WalkingType, int HP, int maxHit, int attack, int defence, int attackAnimation, int blockAnimation, int attack2Animation, int deathAnimation) {
		// first, search for a free slot
		int slot = -1;
		for (int i = 1; i < maxNPCs; i++) {
			if (npcs[i] == null) {
				slot = i;
				break;
			}
		}

		if (slot == -1)
			return; // no free slot found

		NPCDefinitions definition = NPCDefinitions.get(npcType);
		NPC newNPC = new NPC(slot, npcType, definition);
		newNPC.setX(x);
		newNPC.setY(y);
		newNPC.makeX = x;
		newNPC.makeY = y;
		newNPC.heightLevel = heightLevel;
		newNPC.walkingType = WalkingType;
		newNPC.getHealth().setMaximum(HP);
		newNPC.getHealth().reset();
		newNPC.maxHit = maxHit;
		newNPC.attack = attack;
		newNPC.defence = defence;
		newNPC.resetDamageTaken();
		npcs[slot] = newNPC;
	}

	public void newNPCList(int npcType, String npcName, int combat, int HP) {
		NPCDefinitions newNPCList = new NPCDefinitions(npcType);
		newNPCList.setNpcName(npcName);// = npcName;
		newNPCList.setNpcCombat(combat); //= combat;
		newNPCList.setNpcHealth(HP);// = HP;   
		NPCDefinitions.getDefinitions()[npcType] = newNPCList;
	}

	public void process() {
		for (int i = 0; i < maxNPCs; i++) {
			if (npcs[i] == null)
				continue;
			npcs[i].clearUpdateFlags();

		}

		for (int i = 0; i < maxNPCs; i++) {
			if (npcs[i] != null) {
				
				Client slaveOwner = (Client) Server.playerHandler.players[npcs[i].summonedBy]; 
				
				if (slaveOwner == null && npcs[i].summoner) {
					npcs[i].absX = 0;
					npcs[i].absY = 0;
				}
				if (slaveOwner != null && slaveOwner.hasNpc && !slaveOwner.goodDistance(npcs[i].getX(), npcs[i].getY(), slaveOwner.absX, slaveOwner.absY, 15) && npcs[i].summoner) {
					npcs[i].absX = slaveOwner.absX;
					npcs[i].absY = slaveOwner.absY - 1;
				}
				
				if (npcs[i].actionTimer > 0) {
					npcs[i].actionTimer--;
				}
				if (npcs[i].lastX != npcs[i].getX()
						|| npcs[i].lastY != npcs[i].getY()) {
					npcs[i].lastX = npcs[i].getX();
					npcs[i].lastY = npcs[i].getY();
				}
				if (npcs[i].freezeTimer > 0) {
					npcs[i].freezeTimer--;
				}

				if (npcs[i].hitDelayTimer > 0) {
					npcs[i].hitDelayTimer--;
				}

				if (npcs[i].hitDelayTimer == 1) {
					npcs[i].hitDelayTimer = 0;
					applyDamage(i);
				}

				if (npcs[i].attackTimer > 0) {
					npcs[i].attackTimer--;
				}
		if (npcs[i].npcType == 2215 && npcs[i].killerId != 0) {
				int randomspeech = Misc.random(100);
				if(randomspeech == 1)
					npcs[i].forceChat("Split their skulls");
				if(randomspeech == 20)
					npcs[i].forceChat("Crush them underfoot!");
				if(randomspeech == 30)
					npcs[i].forceChat("For the glory of the Big High War God!");
				if(randomspeech == 40)
					npcs[i].forceChat("Brargh!");
				if(randomspeech == 50)
					npcs[i].forceChat("CHAAARGE!");
				if(randomspeech == 60)
					npcs[i].forceChat("All glory to Bandos!");
				if(randomspeech == 70)
					npcs[i].forceChat("We feast on the bones of our enemies tonight!");
				if(randomspeech == 80)
					npcs[i].forceChat("Death to our enemies!");
				if(randomspeech == 90)
					npcs[i].forceChat("Break their bones!");
				if(randomspeech == 100)
					npcs[i].forceChat("GRRRAAAAAR!");
		}
		if (npcs[i].npcType == 180 && npcs[i].killerId > 0) {
				int randomspeech = Misc.random(100);
				if(randomspeech == 1){
					npcs[i].forceChat("Stand an deliver!");
				}
		}
				
                if (npcs[i].npcType == 162) {
                    if (npcs[i].getX() == 2475 && npcs[i].getY() == 3438) {
                        npcs[i].forceChat("Okay get over that log, quick quick!");
                    } else if (npcs[i].getX() == 2471 && npcs[i].getY() == 3427) {
                        npcs[i].forceChat("Move it, move it, move it!");
                    } else if (npcs[i].getX() == 2476 && npcs[i].getY() == 3423) {
                        npcs[i].forceChat("That's it - straight up");
                    } else if (npcs[i].getX() == 2475 && npcs[i].getY() == 3421) {
                        if (Misc.random(1) == 0) {
                            npcs[i].forceChat("Terrorbirds could climb faster than that!");
                        } else {
                            npcs[i].forceChat("Come on scaredy cat, get across that rope!");
                        }
                    } else if (npcs[i].getX() == 2481 && npcs[i].getY() == 3424) {
                        npcs[i].forceChat("My Granny can move faster than you.");
                    }
                }
                if (npcs[i].npcType == 43 || npcs[i].npcType == 1765) {
                    if (Misc.random(20) == 4) {
                        npcs[i].forceChat("Baa!");
                    }
                }
				String name = getNpcListName(npcs[i].npcType);
                if (name.equalsIgnoreCase("Cow") || npcs[i].npcType == 81 || npcs[i].npcType == 397 || npcs[i].npcType == 1766 || npcs[i].npcType == 1767 || npcs[i].npcType == 1768) {
                    if (Misc.random(30) == 4) {
                        npcs[i].forceChat("Moo");
                    }
                }
                if (npcs[i].npcType == 45) {
                    if (Misc.random(30) == 6) {
                        npcs[i].forceChat("Quack!");
                    }
                }
				if (npcs[i].spawnedBy > 0) { // delete summons npc
					if (PlayerHandler.players[npcs[i].spawnedBy] == null
							|| PlayerHandler.players[npcs[i].spawnedBy].heightLevel != npcs[i].heightLevel
							|| PlayerHandler.players[npcs[i].spawnedBy].respawnTimer > 0
							|| !PlayerHandler.players[npcs[i].spawnedBy]
									.goodDistance(
											npcs[i].getX(),
											npcs[i].getY(),
											PlayerHandler.players[npcs[i].spawnedBy]
													.getX(),
											PlayerHandler.players[npcs[i].spawnedBy]
													.getY(), 20)) {

						if (PlayerHandler.players[npcs[i].spawnedBy] != null) {
							for (int o = 0; o < PlayerHandler.players[npcs[i].spawnedBy].barrowsNpcs.length; o++) {
								if (npcs[i].npcType == PlayerHandler.players[npcs[i].spawnedBy].barrowsNpcs[o][0]) {
									if (PlayerHandler.players[npcs[i].spawnedBy].barrowsNpcs[o][1] == 1)
										PlayerHandler.players[npcs[i].spawnedBy].barrowsNpcs[o][1] = 0;
								}
							}
						}
						npcs[i] = null;
					}
				}
				if (npcs[i] == null)
					continue;
				/**
				 * Attacking player
				 **/
                Client client = (Client) PlayerHandler.players[getCloseRandomPlayer(i)];
				if (client != null) {
                    boolean aggressive = (isAggressive(i) && getNpcListCombat(npcs[i].npcType) * 2 > client.combatLevel);
						if (aggressive && !npcs[i].underAttack && !npcs[i].isDead
							&& !switchesAttackers(i)) {
							npcs[i].killerId = getCloseRandomPlayer(i);
						} else if (aggressive && !npcs[i].underAttack
								&& !npcs[i].isDead && switchesAttackers(i)) {
							npcs[i].killerId = getCloseRandomPlayer(i);
						}
				}
				if (System.currentTimeMillis() - npcs[i].lastDamageTaken > 5000 && !npcs[i].underAttack) {
                    npcs[i].underAttackBy = 0;
                    npcs[i].lastRandomlySelectedPlayer = 0;
                    npcs[i].underAttack = false;
                    npcs[i].randomWalk = true;
                }
                if (System.currentTimeMillis() - npcs[i].lastDamageTaken > 10000) {
                    npcs[i].underAttackBy = 0;
                    npcs[i].lastRandomlySelectedPlayer = 0;
                    npcs[i].underAttack = false;
                    npcs[i].randomWalk = true;
                }        
				int p = npcs[i].killerId;
				
				if ((npcs[i].killerId > 0 || npcs[i].underAttack)
						&& !npcs[i].walkingHome && retaliates(npcs[i].npcType) && npcs[i].npcType != 7891 && npcs[i].npcType != 4474) {
					if (!npcs[i].isDead) {
						if (PlayerHandler.players[p] != null) {
							if (!npcs[i].summoner) {
								Client c = (Client) PlayerHandler.players[p];
									if(c == null)
										followPlayer(i, c.playerId);
									if (npcs[i].attackTimer == 0) {
										attackPlayer(c, c.playerId);
									}
							} else {
								Client c = (Client) Server.playerHandler.players[p];
								if (c.getX() == npcs[i].getX() && c.getY() == npcs[i].getY()) {
									stepAway(i);
									npcs[i].randomWalk = false;
									npcs[i].facePlayer(c.playerId);
								} else {
									followPlayer(i, c.playerId);
								}
							}
						} else {
							npcs[i].killerId = 0;
							npcs[i].lastRandomlySelectedPlayer = 0;
							npcs[i].underAttack = false;
							npcs[i].facePlayer(0);
						}
					}
				}
				catchNpc(i);
				catchNpc2(i);
				catchNpc3(i);
				catchNpc4(i);
				catchNpc5(i);
				catchNetTrap(i);
				catchNetTrap2(i);
				catchNetTrap3(i);
				catchNetTrap4(i);     
				/**
				 * Random walking and walking home
				 **/
				if (npcs[i] == null)
					continue;
				if ((!npcs[i].underAttack || npcs[i].walkingHome)
						&& npcs[i].randomWalk && !npcs[i].isDead) {
					npcs[i].facePlayer(0);
					npcs[i].killerId = 0;
					if (npcs[i].spawnedBy == 0) {
						if ((npcs[i].getX() > npcs[i].makeX + Config.NPC_RANDOM_WALK_DISTANCE)
								|| (npcs[i].getX() < npcs[i].makeX - Config.NPC_RANDOM_WALK_DISTANCE)
								|| (npcs[i].getY() > npcs[i].makeY + Config.NPC_RANDOM_WALK_DISTANCE)
								|| (npcs[i].getY() < npcs[i].makeY - Config.NPC_RANDOM_WALK_DISTANCE)
										&& npcs[i].npcType != 1635 && npcs[i].npcType != 1636 && npcs[i].npcType != 1637
										&& npcs[i].npcType != 1638 && npcs[i].npcType != 1639 && npcs[i].npcType != 1640
										&& npcs[i].npcType != 1641 && npcs[i].npcType != 1642 && npcs[i].npcType != 1643
										&& npcs[i].npcType != 1654 && npcs[i].npcType != 7302) {
							npcs[i].walkingHome = true;
						}
					}
					if (npcs[i].walkingType >= 0) {
						switch(npcs[i].walkingType) {
							//Directions/Movments: 1-Walk, 2-North, 3-South, 4-East, 5-West
							case 5:
								npcs[i].turnNpc(npcs[i].absX-1, npcs[i].absY);
								break;
							case 4:
								npcs[i].turnNpc(npcs[i].absX+1, npcs[i].absY);
								break;
							case 3:
								npcs[i].turnNpc(npcs[i].absX, npcs[i].absY-1);
								break;
							case 2:
								npcs[i].turnNpc(npcs[i].absX, npcs[i].absY+1);
								break;
						}
					} 

					if (npcs[i].walkingType == 1 && (!npcs[i].underAttack) && !npcs[i].walkingHome) {
						if (System.currentTimeMillis() - npcs[i].getLastRandomWalk() > npcs[i].getRandomWalkDelay()) {
							int direction = Misc.random3(8);
							int movingToX = npcs[i].getX() + NPCClipping.DIR[direction][0];
							int movingToY = npcs[i].getY() + NPCClipping.DIR[direction][1];
							if (npcs[i].npcType >= 1635 && npcs[i].npcType <= 1643 || npcs[i].npcType == 1654
									|| npcs[i].npcType == 7302) {
								NPCDumbPathFinder.walkTowards(npcs[i], npcs[i].getX() - 1 + Misc.random(8),
										npcs[i].getY() - 1 + Misc.random(8));
							} else {
								if (Math.abs(npcs[i].makeX - movingToX) <= 1 && Math.abs(npcs[i].makeY - movingToY) <= 1
										&& NPCDumbPathFinder.canMoveTo(npcs[i], direction)) {
									NPCDumbPathFinder.walkTowards(npcs[i], movingToX, movingToY);
								}
							}
							npcs[i].setRandomWalkDelay(TimeUnit.SECONDS.toMillis(1 + Misc.random(2)));
							npcs[i].setLastRandomWalk(System.currentTimeMillis());
						}
					}
				}

				if (!npcs[i].neverWalkHome && npcs[i].walkingHome) {
					if (!npcs[i].isDead) {
						NPCDumbPathFinder.walkTowards(npcs[i], npcs[i].makeX, npcs[i].makeY);
						if (npcs[i].moveX == 0 && npcs[i].moveY == 0) {
							npcs[i].teleport(npcs[i].makeX, npcs[i].makeY, npcs[i].getHeight());
						}
						if (npcs[i].getX() == npcs[i].makeX && npcs[i].getY() == npcs[i].makeY) {
							npcs[i].walkingHome = false;
						}
					} else {
						npcs[i].walkingHome = false;
					}
				}
				if (npcs[i].isDead == true && (npcs[i].npcType != 7891 && npcs[i].npcType != 4474)) {
					if (npcs[i].actionTimer == 0 && npcs[i].applyDead == false
							&& npcs[i].needRespawn == false) {
						npcs[i].updateRequired = true;
						npcs[i].facePlayer(0);
						npcs[i].killedBy = getNpcKillerId(i);
						npcs[i].actionTimer = 4; // delete time
						if(npcs[i].npcDeathAnimation <= 0){
							npcs[i].animNumber = getDeadEmote(i);
						} else if(npcs[i].npcDeathAnimation > 0){
							npcs[i].animNumber = npcs[i].npcDeathAnimation; 
						}// dead emote
						npcs[i].animUpdateRequired = true;
						npcs[i].freezeTimer = 0;
						npcs[i].applyDead = true;
						if(npcs[i].npcType != 1158)
							resetPlayersInCombat(i);
						killedBarrow(i);
						killedBarrowsMonsters(i);
						if (isFightCaveNpc(i))
							killedTzhaar(i);
						if(isLogNpc(i))
							UpdateLogKC(i);
					} else if (npcs[i].actionTimer == 0
							&& npcs[i].applyDead == true
							&& npcs[i].needRespawn == false) {
						if(isLogNpc(i))
							UpdateLogKC(i);
						dropItems(i); // npc drops items!
						npcs[i].absX = npcs[i].makeX;
						npcs[i].absY = npcs[i].makeY;
						npcs[i].HP = npcs[i].MaxHP;
						if(npcs[i].npcDeathAnimation <= -1)
							npcs[i].animNumber = getDeadEmote(i);
						else						// dead emote
							npcs[i].animNumber = npcs[i].npcDeathAnimation; // dead emote
						npcs[i].updateRequired = true;
						npcs[i].animUpdateRequired = true;
						if (npcs[i].npcType >= 2440 && npcs[i].npcType <= 2446) {
							Server.objectManager.removeObject(npcs[i].absX,
									npcs[i].absY);
						}
						if (npcs[i].npcType == 2745) {
							handleJadDeath(i);
						}
						npcs[i].needRespawn = true;
						npcs[i].actionTimer = getRespawnTime(i); // respawn time
						appendSlayerExperience(i);
						appendKillCount(i);
						 Client player = (Client) PlayerHandler.players[npcs[i].killedBy];
                        if (player != null) {
                            if (player.tutorialProgress == 24) {
                                handleratdeath(i);
                            } else if (player.tutorialProgress == 25
                                    && player.ratdied2) {
                                handleratdeath2(i);
                            }
                        }
					} else if (npcs[i].actionTimer == 0 && npcs[i].needRespawn && npcs[i].npcType != 1158) {
						if (npcs[i].spawnedBy > 0) {
							npcs[i] = null;
						} else {
							int old1 = npcs[i].npcType;
							int old2 = npcs[i].makeX;
							int old3 = npcs[i].makeY;
							int old4 = npcs[i].heightLevel;
							int old5 = npcs[i].walkingType;
							int old6 = npcs[i].MaxHP;
							int old7 = npcs[i].maxHit;
							int old8 = npcs[i].attack;
							int old9 = npcs[i].defence;
							int npcAttackAnimation = npcs[i].npcAttackAnimation;
							int npcBlockAnimation = npcs[i].npcBlockAnimation;
							int npcAttack2Animation = npcs[i].npcAttack2Animation;
							int npcDeathAnimation = getDeadEmote(i);
							npcs[i] = null;
							newNPC(old1, old2, old3, old4, old5, old6, old7,
									old8, old9, npcAttackAnimation, npcBlockAnimation, npcAttack2Animation, npcDeathAnimation);
						}
					}
				} else if(npcs[i].isDead == true && (npcs[i].npcType == 7891 || npcs[i].npcType == 4474)){
					
						npcs[i].actionTimer = getRespawnTime(i);
						npcs[i].killedBy = getNpcKillerId(i);
						if (PlayerHandler.players[npcs[i].killedBy] != null){
							Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
							c.getCombat().resetPlayerAttack();
						}
						npcs[i].applyDead = true;
						resetPlayersInCombat(i);
						npcs[i].HP = npcs[i].MaxHP;
						npcs[i].absX = npcs[i].makeX;
						npcs[i].absY = npcs[i].makeY;
						npcs[i].isDead = false; 
						npcs[i].updateRequired = true;
				}
			}
		}
	}
   private void handleratdeath(int i) {
        final Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
        if (c != null) {
            c.getPA().chatbox(6180);
            c.getDH().chatboxText( "",
                            "Pass through the gate and talk to the Combat Instructor, he",
                            "will give you your next task.", "",
                            "Well done, you've made your first kill!");
            c.getPA().chatbox(6179);
            c.getPA().drawHeadicon(1, 6, 0, 0); // draws
            // headicon to
            // combat ude
            c.tutorialProgress = 25;
        }
    }

    private void handleratdeath2(int i) {
        Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
        if (c != null) {
            c.getPA().chatbox(6180);
            c.getDH().chatboxText( "You have completed the tasks here. To move on, click on the",
                            "ladder shown. If you need to go over any of what you learnt",
                            "here, just talk to the Combat Instructor and he'll tell you what",
                            "he can.", "Moving on");
            c.getPA().chatbox(6179);
            c.tutorialProgress = 26;
            c.getPA().createObjectHints(3111, 9525, c.getH(), 2); // send
            // hint
            // to
            // furnace
        }
    }
	public boolean getsPulled(int i) {
		switch (npcs[i].npcType) {
		case 2550:
			if (npcs[i].firstAttacker > 0)
				return false;
			break;
		}
		return true;
	}

	public boolean multiAttacks(int i) {
		switch (npcs[i].npcType) {
			case 2215:
			if (npcs[i].attackType == 1)
				return true;
		default:
			return false;
		}

	}

	/**
	 * Npc killer id?
	 **/

	public int getNpcKillerId(int npcId) {
		int oldDamage = 0;
		int killerId = 0;
		for (int p = 1; p < Config.MAX_PLAYERS; p++) {
			if (PlayerHandler.players[p] != null) {
				if (PlayerHandler.players[p].lastNpcAttacked == npcId) {
					if (PlayerHandler.players[p].totalDamageDealt > oldDamage) {
						oldDamage = PlayerHandler.players[p].totalDamageDealt;
						killerId = p;
					}
					PlayerHandler.players[p].totalDamageDealt = 0;
				}
			}
		}
		return killerId;
	}

	/**
	 * 
	 */
	private void killedBarrow(int i) {
		Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
		if (c != null) {
			for (int o = 0; o < c.barrowsNpcs.length; o++) {
				if (npcs[i].npcType == c.barrowsNpcs[o][0]) {
					c.barrowsNpcs[o][1] = 2; // 2 for dead
					c.barrowsKillCount++;
					if(c.BarrowsRewardPotential < 1000)
					c.BarrowsRewardPotential += 50;
					else if(c.BarrowsRewardPotential > 1000)
						c.BarrowsRewardPotential = 1000+(c.barrowsKillCount*2);
				}
			}
		}
	}	
	/**
	 * 
	 */
	private void killedBarrowsMonsters(int i) {
		Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
		if (c != null) {
			for (int o = 0; o < c.barrowsNpcs.length; o++) {
				if (npcs[i].npcType == c.barrowsMonsterNpcs[o]) {
					if(c.BarrowsRewardPotential < 1000)
					c.BarrowsRewardPotential += 50;
					else if(c.BarrowsRewardPotential > 1000)
						c.BarrowsRewardPotential = 1000+(c.barrowsKillCount*2);
				}
			}
		}
	}
	
		public void UpdateLogKC(int NPCId) {
		Client c = (Client) PlayerHandler.players[npcs[NPCId].killedBy];
			if (c != null) {
				for (int i = 0; i < c.CollLog.length; i++) {
					if (npcs[NPCId].npcType == c.CollLog[i][0]) { // Check if itemID matches the itemId parameter
						c.CollLog[i][1] += 1; // Update the KC amount in the collection log array
						break; // Exit the loop once the item is found and updated
					}		
				}
			}
		}
	private void killedTzhaar(int i) {
		final Client c2 = (Client) PlayerHandler.players[npcs[i].spawnedBy];
		c2.tzhaarKilled++;
		if (c2.tzhaarKilled == c2.tzhaarToKill) {
			c2.waveId++;
			EventManager.getSingleton().addEvent(new Event() {
				public void execute(EventContainer c) {
					if (c2 != null) {
						Server.fightCaves.spawnNextWave(c2);
					}
					c.stop();
				}
			}, 7500);
		}
	}	
	public void handleJadDeath(int i) {
		Client c = (Client) PlayerHandler.players[npcs[i].spawnedBy];
		c.getItems().addItem(6570, 1);
		c.sendMessage("Congratulations on completing the fight caves minigame!");
		c.getPA().resetTzhaar();
		c.waveId = 300;
	}

	/**
	 * Dropping Items!
	 **/

	public boolean rareDrops(int i) {
		int rarity = NPCDrops.dropRarity.get(npcs[i].npcType);
		return Misc.random(rarity) == 0;
	}
	public boolean rareDropsTable(int i) {
		int[][] rareDropsTable = NPCDrops.rareDropsTable.get(npcs[i].npcType);
		int lastItemIndex = rareDropsTable.length - 1;
		int rarity = rareDropsTable[lastItemIndex][2];
		return Misc.random(rarity) == 0;
	}
	public void dropItems(int i) {
		Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
		if (c != null) {
			if (npcs[i].npcType == 912 || npcs[i].npcType == 913
					|| npcs[i].npcType == 914)
				c.magePoints += 1;
			if (NPCDrops.constantDrops.get(npcs[i].npcType) != null) {
				for (int item : NPCDrops.constantDrops.get(npcs[i].npcType)) {
						Server.itemHandler.createGroundItem(c, item, npcs[i].absX,
							npcs[i].absY, npcs[i].heightLevel, 1, c.playerId);
				} 
			} else {
				Server.itemHandler.createGroundItem(c, boneDrop(i), npcs[i].absX, npcs[i].absY, npcs[i].heightLevel,1, c.playerId);
			}
			if (NPCDrops.dropRarity.get(npcs[i].npcType) != null) {
				if (rareDrops(i)) {
					int random = Misc.random(NPCDrops.rareDrops
							.get(npcs[i].npcType).length - 1);
					int itemId = NPCDrops.rareDrops.get(npcs[i].npcType)[random][0];
					Server.itemHandler.createGroundItem(c,
							NPCDrops.rareDrops.get(npcs[i].npcType)[random][0],
							npcs[i].absX, npcs[i].absY, npcs[i].heightLevel,
							NPCDrops.rareDrops.get(npcs[i].npcType)[random][1],
							c.playerId);
					for(int o = 0; o < c.getCollectionLog().bandosCollectionLog.length; o++)
						if(itemId == c.getCollectionLog().bandosCollectionLog[o][0])
							c.getPA().CollLogPopUp(c.getCollectionLog().bandosCollectionLog, itemId, 1);
					if (c.clanId >= 0)
						Server.clanChat.handleLootShare(c, NPCDrops.rareDrops.get(npcs[i].npcType)[random][0], NPCDrops.rareDrops.get(npcs[i].npcType)[random][1]);
				} else {
					int npcType = npcs[i].npcType;
					int[][] normalDropsList = NPCDrops.normalDrops.get(npcType);

					// Calculate the total rarity of all items in the drop list
					int totalRarity = 0;
					for (int[] drop : normalDropsList) {
						totalRarity += drop[2]; // The rarity is at index 2 in each drop array.
					}

					// Generate a random number from 0 to the totalRarity exclusive.
					int randomRarity = Misc.random(totalRarity);

					// Iterate through the drop list to find the item based on the rarity
					int itemId = -1;
					int amount = 0;
					int accumulatedRarity = 0;
					for (int[] drop : normalDropsList) {
						accumulatedRarity += drop[2];
						if (randomRarity < accumulatedRarity) {
							itemId = drop[0];
							amount = drop[1];
							break;
						}
					}

									c.sendMessage("randomRarity: "+ randomRarity+" accumulatedRarity: "+ accumulatedRarity);
					// If itemId remains -1 (no item selected), drop coins as the fallback item.
					if (itemId == -1) {
						// Set the rarity for coins to 4 (1 out of 4 chance).
						int coinsRarity = 4;

						// Generate a random number from 0 to coinsRarity - 1.
						int randomCoins = Misc.random(coinsRarity);

						if (randomCoins == 0) {
							itemId = 995; // Coins item ID
							amount = 19500+Misc.random(5000);   // Adjust the amount of coins as needed.
						}
					}

					//new Object(26291, npcs[i].absX-2, npcs[i].absY-2, npcs[i].heightLevel, 0, 10, -1, 100);
						Server.itemHandler.createGroundItem(c, itemId, npcs[i].absX, npcs[i].absY,npcs[i].heightLevel, amount, c.playerId);


				}
				if (rareDropsTable(i)) {
					int random = Misc.random(NPCDrops.rareDropsTable.get(npcs[i].npcType).length - 1);
					int itemId = NPCDrops.rareDropsTable.get(npcs[i].npcType)[random][0];
					int random2 = Misc.random(NPCDrops.rareDropsTable.get(npcs[i].npcType)[random][2]);
					if(random2 == 0){
						Server.itemHandler.createGroundItem(c, NPCDrops.rareDropsTable.get(npcs[i].npcType)[random][0], npcs[i].absX, npcs[i].absY, npcs[i].heightLevel, NPCDrops.rareDropsTable.get(npcs[i].npcType)[random][1], c.playerId);
						new Object(26291, npcs[i].absX-2, npcs[i].absY-2, npcs[i].heightLevel, 0, 10, -1, 100);
						for(int o = 0; o < c.getCollectionLog().MiscCollectionLog.length; o++){
							if(itemId == c.getCollectionLog().MiscCollectionLog[o][0])
								c.getPA().CollLogPopUp(c.getCollectionLog().MiscCollectionLog, itemId, NPCDrops.rareDropsTable.get(npcs[i].npcType)[random][1]);
								}
					}
				} 
			}

		}
		// System.out.println("Took: " + (System.currentTimeMillis() - start));
	}



	// id of bones dropped by npcs
	public int boneDrop(int type) {
		switch (type) {
		case 1:// normal bones
		case 9:
		case 100:
		case 1770:
		case 12:
		case 17:
		case 803:
		case 18:
		case 81:
		case 101:
		case 41:
		case 19:
		case 90:
		case 75:
		case 86:
		case 78:
		case 912:
		case 913:
		case 914:
		case 1648:
		case 1643:
		case 1618:
		case 1624:
		case 181:
		case 119:
		case 49:
		case 26:
		case 1341:
			return 526;
		case 117:
			return 532;// big bones
		case 50:// drags
		case 53:
		case 54:
		case 55:
		case 941:
		case 1590:
		case 1591:
		case 1592:
			return 536;
		case 84:
		case 1615:
		case 1613:
		case 82:
		case 3200:
			return 592;
			
		case 2215:
		return 4834;
		default:
			return 526;
		}
	}

	public int getStackedDropAmount(int itemId, int npcId) {
		switch (itemId) {
		case 995:
			switch (npcId) {
			case 1:
				return 50 + Misc.random(50);
			case 9:
				return 133 + Misc.random(100);
			case 1624:
				return 1000 + Misc.random(300);
			case 1618:
				return 1000 + Misc.random(300);
			case 1643:
				return 1000 + Misc.random(300);
			case 1610:
				return 1000 + Misc.random(1000);
			case 1613:
				return 1500 + Misc.random(1250);
			case 1615:
				return 3000;
			case 18:
				return 500;
			case 101:
				return 60;
			case 913:
			case 912:
			case 914:
				return 750 + Misc.random(500);
			case 1612:
				return 250 + Misc.random(500);
			case 1648:
				return 250 + Misc.random(250);
			case 90:
				return 200;
			case 82:
				return 1000 + Misc.random(455);
			case 52:
				return 400 + Misc.random(200);
			case 49:
				return 1500 + Misc.random(2000);
			case 1341:
				return 1500 + Misc.random(500);
			case 26:
				return 500 + Misc.random(100);
			case 20:
				return 750 + Misc.random(100);
			case 21:
				return 890 + Misc.random(125);
			case 117:
				return 500 + Misc.random(250);
			case 2607:
				return 500 + Misc.random(350);
			}
			break;
		case 11212:
			return 10 + Misc.random(4);
		case 565:
		case 561:
			return 10;
		case 560:
		case 563:
		case 562:
			return 15;
		case 555:
		case 554:
		case 556:
		case 557:
			return 20;
		case 892:
			return 40;
		case 886:
			return 100;
		case 6522:
			return 6 + Misc.random(5);

		}

		return 1;
	}

	/**
	 * Slayer Experience
	 **/
	public void appendSlayerExperience(int i) {
		Client c = (Client) PlayerHandler.players[npcs[i].killedBy];
		if (c != null) {
			if (c.slayerTask == npcs[i].npcType) {
				c.taskAmount--;
				c.getPA().addSkillXP(npcs[i].MaxHP * Config.SLAYER_EXPERIENCE,
						18);
				if (c.taskAmount <= 0) {
					c.getPA().addSkillXP(
							(npcs[i].MaxHP * 8) * Config.SLAYER_EXPERIENCE, 18);
					c.slayerTask = -1;
					c.sendMessage("You completed your slayer task. Please see a slayer master to get a new one.");
				}
			}
		}
	}

	/**
	 * Resets players in combat
	 */

	public void resetPlayersInCombat(int i) {
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null)
				if (PlayerHandler.players[j].underAttackBy2 == i)
					PlayerHandler.players[j].underAttackBy2 = 0;
		}
	}

	/**
	 * Npc Follow Player
	 **/

	public int GetMove(int Place1, int Place2) {
		if ((Place1 - Place2) == 0) {
			return 0;
		} else if ((Place1 - Place2) < 0) {
			return 1;
		} else if ((Place1 - Place2) > 0) {
			return -1;
		}
		return 0;
	}

		public boolean NetTrap = false;	
		public void catchNetTrap(int i) {
			if (NetTrap == false)
				return;
			for (int j = 0; j < Server.playerHandler.players.length; j++) {
				if (Server.playerHandler.players[j] != null) {	
					Client c = (Client) Server.playerHandler.players[j];
					
					if (c.playerLevel[22] >= 30) {
						if (c.getHunter().netX > 0 && c.getHunter().netY > 0) {
							if((npcs[i].npcType == 7311) && npcs[i].absX == c.getHunter().netX && npcs[i].absY == c.getHunter().netY) {
								if (c.success == false) {
									npcs[i].absX = 0;
									npcs[i].absY = 0;
									npcs[i].isDead = true;
									npcs[i].facePlayer(0);
									npcs[i].killerId = 0;	
									npcs[i] = null;
									c.getHunter().catchSquirrel(12758);
								}
								break;
							}
						}		
					}
					
					if (c.playerLevel[22] >= 29) {
						if((npcs[i].npcType == 5117) && npcs[i].absX == c.getHunter().netX && npcs[i].absY == c.getHunter().netY) {
							if (c.success == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchSWLizard(10149);
							}
							break;
						}
					}
					if (c.playerLevel[22] >= 47) {
						if((npcs[i].npcType == 5114) && npcs[i].absX == c.getHunter().netX && npcs[i].absY == c.getHunter().netY) {
							if (c.success == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchORLizard(10146);
							}
							break;
						}
					}
				}	
			}	
		}
		public boolean NetTrap2 = false;	
		public void catchNetTrap2(int i) {
			if (NetTrap == false)
				return;
			for (int j = 0; j < Server.playerHandler.players.length; j++) {
				if (Server.playerHandler.players[j] != null) {	
					Client c = (Client) Server.playerHandler.players[j];
					
					if (c.playerLevel[22] >= 30) {
						if (c.getHunter().netX2 > 0 && c.getHunter().netY2 > 0) {
							if((npcs[i].npcType == 7311) && npcs[i].absX == c.getHunter().netX2 && npcs[i].absY == c.getHunter().netY2) {
								if (c.success2 == false) {
									npcs[i].absX = 0;
									npcs[i].absY = 0;
									npcs[i].isDead = true;
									npcs[i].facePlayer(0);
									npcs[i].killerId = 0;	
									npcs[i] = null;
									c.getHunter().catchSquirrel2(12758);
								}
								break;
							}
						}		
					}
					
					if (c.playerLevel[22] >= 29) {
						if((npcs[i].npcType == 5117) && npcs[i].absX == c.getHunter().netX2 && npcs[i].absY == c.getHunter().netY2) {
							if (c.success2 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchSWLizard2(10149);
							}
							break;
						}
					}
					if (c.playerLevel[22] >= 47) {
						if((npcs[i].npcType == 5114) && npcs[i].absX == c.getHunter().netX2 && npcs[i].absY == c.getHunter().netY2) {
							if (c.success2 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchORLizard2(10146);
							}
							break;
						}
					}
				}	
			}	
		}
		
		public boolean NetTrap3 = false;	
		public void catchNetTrap3(int i) {
			if (NetTrap3 == false)
				return;
			for (int j = 0; j < Server.playerHandler.players.length; j++) {
				if (Server.playerHandler.players[j] != null) {	
					Client c = (Client) Server.playerHandler.players[j];
					
					if (c.playerLevel[22] >= 30) {
						if (c.getHunter().netX3 > 0 && c.getHunter().netY3 > 0) {
							if((npcs[i].npcType == 7311) && npcs[i].absX == c.getHunter().netX3 && npcs[i].absY == c.getHunter().netY3) {
								if (c.success3 == false) {
									npcs[i].absX = 0;
									npcs[i].absY = 0;
									npcs[i].isDead = true;
									npcs[i].facePlayer(0);
									npcs[i].killerId = 0;	
									npcs[i] = null;
									c.getHunter().catchSquirrel3(12758);
								}
								break;
							}
						}		
					}
					
					if (c.playerLevel[22] >= 29) {
						if((npcs[i].npcType == 5117) && npcs[i].absX == c.getHunter().netX3 && npcs[i].absY == c.getHunter().netY3) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchSWLizard3(10149);
							}
							break;
						}
					}
					if (c.playerLevel[22] >= 47) {
						if((npcs[i].npcType == 5114) && npcs[i].absX == c.getHunter().netX3 && npcs[i].absY == c.getHunter().netY3) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchORLizard3(10146);
							}
							break;
						}
					}
				}	
			}	
		}
		public boolean NetTrap4 = false;	
		public void catchNetTrap4(int i) {
			if (NetTrap4 == false)
				return;
			for (int j = 0; j < Server.playerHandler.players.length; j++) {
				if (Server.playerHandler.players[j] != null) {	
					Client c = (Client) Server.playerHandler.players[j];
					
					if (c.playerLevel[22] >= 30) {
						if (c.getHunter().netX4 > 0 && c.getHunter().netY4 > 0) {
							if((npcs[i].npcType == 7311) && npcs[i].absX == c.getHunter().netX4 && npcs[i].absY == c.getHunter().netY4) {
								if (c.success4 == false) {
									npcs[i].absX = 0;
									npcs[i].absY = 0;
									npcs[i].isDead = true;
									npcs[i].facePlayer(0);
									npcs[i].killerId = 0;	
									npcs[i] = null;
									c.getHunter().catchSquirrel4(12758);
								}
								break;
							}
						}		
					}
					
					if (c.playerLevel[22] >= 29) {
						if((npcs[i].npcType == 5117) && npcs[i].absX == c.getHunter().netX4 && npcs[i].absY == c.getHunter().netY4) {
							if (c.success4 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchSWLizard4(10149);
							}
							break;
						}
					}
					if (c.playerLevel[22] >= 47) {
						if((npcs[i].npcType == 5114) && npcs[i].absX == c.getHunter().netX4 && npcs[i].absY == c.getHunter().netY4) {
							if (c.success4 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchORLizard4(10146);
							}
							break;
						}
					}
				}	
			}	
		}
	public boolean snareTrap = false;
	public boolean trapBox = false;
	public void catchNpc(int i) {
		if (trapBox == false)
		return;
		for (int j = 0; j < Server.playerHandler.players.length; j++) {
			if (Server.playerHandler.players[j] != null) {	
				Client c = (Client) Server.playerHandler.players[j];
				

			if (c.playerLevel[22] >= 30) {
				if (c.getHunter().trapX > 0 && c.getHunter().trapY > 0) {
					if(npcs[i].npcType == 5079){
						if(npcs[i].getX() == c.getHunter().trapX + 1 || 
							npcs[i].getX() == c.getHunter().trapX - 1 ||
							npcs[i].getY() == c.getHunter().trapY + 1 ||
							npcs[i].getY() == c.getHunter().trapY - 1) {
								int noticeChance = Misc.random(5);
								if (noticeChance == 1){
										npcs[i].turnNpc(c.getHunter().trapX, c.getHunter().trapY);
							
										if(npcs[i].absX == c.getHunter().trapX + 1)
											npcs[i].moveX = -1;
										if(npcs[i].absX == c.getHunter().trapX - 1)
											npcs[i].moveX = 1;
										if(npcs[i].absY == c.getHunter().trapY + 1)
											npcs[i].moveY = -1;
										if(npcs[i].absY == c.getHunter().trapY - 1)
											npcs[i].moveY = 1;
								}
							}
					if(npcs[i].absX == c.getHunter().trapX && npcs[i].absY == c.getHunter().trapY){
						if (c.success == false) {
							npcs[i].absX = 0;
							npcs[i].absY = 0;
							npcs[i].isDead = true;
							npcs[i].facePlayer(0);
							npcs[i].killerId = 0;	
							npcs[i] = null;
							//npcs[i].trapNotice = false;
							c.getPA().object(19193, c.getHunter().trapX, c.getHunter().trapY, 0, 10);
							c.getHunter().catchNormalChin(10033);
						}
					}
						break;
					} 
				}	
			 } 
			if (c.playerLevel[22] >= 60) {
					if (c.getHunter().trapX > 0 && c.getHunter().trapY > 0) {
						if((npcs[i].npcType == 5080) && npcs[i].absX == c.getHunter().trapX && npcs[i].absY == c.getHunter().trapY) {
							if (c.success == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchRedChin(10034);
							}
							break;
						} 
					} 
			}
			if (c.playerLevel[22] >= 20) {
					if (c.getHunter().trapX > 0 && c.getHunter().trapY > 0) {
						if((npcs[i].npcType == 5081) && npcs[i].absX == c.getHunter().trapX && npcs[i].absY == c.getHunter().trapY) {
							if (c.success == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchFerret(10092);
							}
							break;
						}
					} 
				}
			}
		}
	}
	public boolean trapBox2 = false;
	public void catchNpc2(int i) {
		if (trapBox2 == false)
		return;
		for (int j = 0; j < Server.playerHandler.players.length; j++) {
			if (Server.playerHandler.players[j] != null) {	
				Client c = (Client) Server.playerHandler.players[j];
				
				if (c.playerLevel[22] >= 30) {
					if (c.getHunter().trapX2 > 0 && c.getHunter().trapY2 > 0) {
						if((npcs[i].npcType == 5079) && npcs[i].absX == c.getHunter().trapX2 && npcs[i].absY == c.getHunter().trapY2) {
							if (c.success2 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchNormalChin2(10033);
							}
							break;
						} 
					}	
				} 
				if (c.playerLevel[22] >= 60) {
					if (c.getHunter().trapX2 > 0 && c.getHunter().trapY2 > 0) {
						if((npcs[i].npcType == 5080) && npcs[i].absX == c.getHunter().trapX2 && npcs[i].absY == c.getHunter().trapY2) {
							if (c.success2 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchRedChin2(10034);
							}
							break;
						} 
					} 
				} 
				if (c.playerLevel[22] >= 20) {
					if (c.getHunter().trapX2 > 0 && c.getHunter().trapY2 > 0) {
						if((npcs[i].npcType == 5081) && npcs[i].absX == c.getHunter().trapX2 && npcs[i].absY == c.getHunter().trapY2) {
							if (c.success2 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchFerret2(10092);
							}
							break;
						}
					} 
				}
			}
		}
	}
	public boolean trapBox3 = false;
	public void catchNpc3(int i) {
		if (trapBox3 == false)
		return;
		for (int j = 0; j < Server.playerHandler.players.length; j++) {
			if (Server.playerHandler.players[j] != null) {	
				Client c = (Client) Server.playerHandler.players[j];
				
				if (c.playerLevel[22] >= 30) {
					if (c.getHunter().trapX3 > 0 && c.getHunter().trapY3 > 0) {
						if((npcs[i].npcType == 5079) && npcs[i].absX == c.getHunter().trapX3 && npcs[i].absY == c.getHunter().trapY3) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchNormalChin3(10033);
							}
							break;
						} 
					}	
				 } 
				if (c.playerLevel[22] >= 60) {
					if (c.getHunter().trapX3 > 0 && c.getHunter().trapY3 > 0) {
						if((npcs[i].npcType == 5080) && npcs[i].absX == c.getHunter().trapX3 && npcs[i].absY == c.getHunter().trapY3) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchRedChin3(10034);
							}
							break;
						} 
					} 
				} 
				if (c.playerLevel[22] >= 20) {
					if (c.getHunter().trapX3 > 0 && c.getHunter().trapY3 > 0) {
						if((npcs[i].npcType == 5081) && npcs[i].absX == c.getHunter().trapX2 && npcs[i].absY == c.getHunter().trapY3) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchFerret3(10092);
							}
							break;
						}
					} 
				}
			}
		}
	}
	public boolean trapBox4 = false;
	public void catchNpc4(int i) {
		if (trapBox4 == false)
		return;
		for (int j = 0; j < Server.playerHandler.players.length; j++) {
			if (Server.playerHandler.players[j] != null) {	
				Client c = (Client) Server.playerHandler.players[j];
				
				if (c.playerLevel[22] >= 30) {
					if (c.getHunter().trapX4 > 0 && c.getHunter().trapY4 > 0) {
						if((npcs[i].npcType == 5079) && npcs[i].absX == c.getHunter().trapX4 && npcs[i].absY == c.getHunter().trapY4) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchNormalChin3(10033);
							}
							break;
						} 
					}	
				 } 
				if (c.playerLevel[22] >= 60) {
					if (c.getHunter().trapX4 > 0 && c.getHunter().trapY4 > 0) {
						if((npcs[i].npcType == 5080) && npcs[i].absX == c.getHunter().trapX4 && npcs[i].absY == c.getHunter().trapY4) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchRedChin3(10034);
							}
							break;
						} 
					} 
				} 
				if (c.playerLevel[22] >= 20) {
					if (c.getHunter().trapX4 > 0 && c.getHunter().trapY4 > 0) {
						if((npcs[i].npcType == 5081) && npcs[i].absX == c.getHunter().trapX4 && npcs[i].absY == c.getHunter().trapY4) {
							if (c.success3 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchFerret3(10092);
							}
							break;
						}
					} 
				}
			}
		}
	}
	public boolean trapBox5 = false;
	public void catchNpc5(int i) {
		if (trapBox5 == false)
		return;
		for (int j = 0; j < Server.playerHandler.players.length; j++) {
			if (Server.playerHandler.players[j] != null) {	
				Client c = (Client) Server.playerHandler.players[j];
				
			if (c.playerLevel[22] >= 30) {
				if (c.getHunter().trapX5 > 0 && c.getHunter().trapY5 > 0) {
					if((npcs[i].npcType == 5079) && npcs[i].absX == c.getHunter().trapX5 && npcs[i].absY == c.getHunter().trapY5) {
						if (c.success5 == false) {
							npcs[i].absX = 0;
							npcs[i].absY = 0;
							npcs[i].isDead = true;
							npcs[i].facePlayer(0);
							npcs[i].killerId = 0;	
							npcs[i] = null;
							c.getHunter().catchNormalChin5(10033);
						}
						break;
					} 
				}	
			 } 
			if (c.playerLevel[22] >= 60) {
					if (c.getHunter().trapX5 > 0 && c.getHunter().trapY5 > 0) {
						if((npcs[i].npcType == 5080) && npcs[i].absX == c.getHunter().trapX5 && npcs[i].absY == c.getHunter().trapY5) {
							if (c.success5 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchRedChin5(10034);
							}
							break;
						} 
					} 
			}
			if (c.playerLevel[22] >= 20) {
					if (c.getHunter().trapX5 > 0 && c.getHunter().trapY5 > 0) {
						if((npcs[i].npcType == 5081) && npcs[i].absX == c.getHunter().trapX5 && npcs[i].absY == c.getHunter().trapY5) {
							if (c.success5 == false) {
								npcs[i].absX = 0;
								npcs[i].absY = 0;
								npcs[i].isDead = true;
								npcs[i].facePlayer(0);
								npcs[i].killerId = 0;	
								npcs[i] = null;
								c.getHunter().catchFerret5(10092);
							}
							break;
						}
					} 
				}
			}
		}
	}
	public void dismissImpling(Client c, int Type) {
	for (int i = 0; i < maxNPCs; i++) {
		if (npcs[i] == null) 
		continue;	
	}       
	for (int i = 0; i < maxNPCs; i++) {
			if (npcs[i] != null) {
				if (npcs[i].npcType == Type) {
						npcs[i].absX = 0;
						npcs[i].absY = 0;
						npcs[i] = null;
						break;
					//dismissReset();
				}
			}	
		}
	}

	public boolean followPlayer(int i) {
		switch (npcs[i].npcType) {
			case 309:
			case 310:
			case 311:
			case 312:
			case 313:
			case 314:
			case 315:
			case 316:
			case 317:
			case 318:
			case 319:
			case 320:
			case 321:
			case 322:
			case 323:
			case 324:
			case 325:
			case 326:
			case 327:
			case 328:
			case 329:
			case 330:
			case 331:
			case 332:
			case 333:
			case 334:
		case 2892:
		case 2894:
			return false;
		}
		return true;
	}

	public void followPlayer(int i, int playerId) {
    if (PlayerHandler.players[playerId] == null) {
        return;
    }
    boolean face = true;
    if (PlayerHandler.players[playerId].respawnTimer > 0) {
        npcs[i].facePlayer(0);
        npcs[i].randomWalk = true;
        npcs[i].underAttack = false;
        return;
    }

    if (!followPlayer(i)) {
        if(npcs[i].npcType > 308 && npcs[i].npcType < 335)
            face = false;
        if(face)
            npcs[i].facePlayer(playerId);
        return;
    }

    int playerX = PlayerHandler.players[playerId].absX;
    int playerY = PlayerHandler.players[playerId].absY;
    npcs[i].randomWalk = false;
    if (goodDistance(npcs[i].getX(), npcs[i].getY(), playerX, playerY, distanceRequired(i))) {
        return;
    }

    NPC npc = npcs[i];
    int x = npc.absX;
    int y = npc.absY;
    Player player = PlayerHandler.players[playerId];
    if ((npcs[i].spawnedBy > 0)
            || ((x < npc.makeX + Config.NPC_FOLLOW_DISTANCE)
            && (x > npc.makeX - Config.NPC_FOLLOW_DISTANCE)
            && (y < npc.makeY + Config.NPC_FOLLOW_DISTANCE)
            && (y > npc.makeY - Config.NPC_FOLLOW_DISTANCE))) {
        if (npc.heightLevel == player.heightLevel) {
            if (player != null && npc != null) {
                if (playerX > x && playerY < y) {
                    npc.moveX = GetMove(x, playerX);
                    npc.moveY = GetMove(y, playerY);
                } else if (playerX < x && playerY < y) {
                    npc.moveX = GetMove(x, playerX);
                    npc.moveY = GetMove(y, playerY);
                } else if (playerX < x && playerY > y) {
                    npc.moveX = GetMove(x, playerX);
                    npc.moveY = GetMove(y, playerY);
                } else if (playerX > x && playerY > y) {
                    npc.moveX = GetMove(x, playerX);
                    npc.moveY = GetMove(y, playerY);
                } else if (playerY < y) {
                    npc.moveY = GetMove(y, playerY);
                } else if (playerY > y) {
                    npc.moveY = GetMove(y, playerY);
                } else if (playerX < x) {
                    npc.moveX = GetMove(x, playerX);
                } else if (playerX > x) {
                    npc.moveX = GetMove(x, playerX);
                }
                if (npc.npcType > 308 && npc.npcType < 335)
                    face = false;
                if (face)
                    npc.facePlayer(playerId);
                handleClipping(i);
                npc.getNextNPCMovement();
                npc.updateRequired = true;
            }
        }
    } else {
        npc.facePlayer(0);
        npc.randomWalk = true;
        npc.underAttack = false;
    }
}

	public void stepAway(int i) {
		int[][] points = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

		for (int[] k : points) {
			int dir = NPCClipping.getDirection(k[0], k[1]);
			if (NPCDumbPathFinder.canMoveTo(npcs[i], dir)) {
				NPCDumbPathFinder.walkTowards(npcs[i], npcs[i].getX() + NPCClipping.DIR[dir][0],
						npcs[i].getY() + NPCClipping.DIR[dir][1]);
				break;
			}
		}
	}
public void handleClipping(int i) {
    NPC npc = npcs[i];

    // Check for diagonal movement
    if (npc.moveX == 1 && npc.moveY == 1) {
        if ((Region.getClipping(npc.absX + 1, npc.absY + 1, npc.heightLevel) & Region.BLOCKED_NORTH_EAST) != 0) {
            npc.moveX = 0; npc.moveY = 0;
            if ((Region.getClipping(npc.absX, npc.absY + 1, npc.heightLevel) & Region.BLOCKED_NORTH) == 0)
                npc.moveY = 1;
            else if ((Region.getClipping(npc.absX + 1, npc.absY, npc.heightLevel) & Region.BLOCKED_EAST) == 0)
                npc.moveX = 1;
        }
    } else if (npc.moveX == -1 && npc.moveY == -1) {
        if ((Region.getClipping(npc.absX - 1, npc.absY - 1, npc.heightLevel) & Region.BLOCKED_SOUTH_WEST) != 0) {
            npc.moveX = 0; npc.moveY = 0;
            if ((Region.getClipping(npc.absX, npc.absY - 1, npc.heightLevel) & Region.BLOCKED_SOUTH) == 0)
                npc.moveY = -1;
            else if ((Region.getClipping(npc.absX - 1, npc.absY, npc.heightLevel) & Region.BLOCKED_WEST) == 0)
                npc.moveX = -1;
        }
    } else if (npc.moveX == 1 && npc.moveY == -1) {
        if ((Region.getClipping(npc.absX + 1, npc.absY - 1, npc.heightLevel) & Region.BLOCKED_SOUTH_EAST) != 0) {
            npc.moveX = 0; npc.moveY = 0;
            if ((Region.getClipping(npc.absX, npc.absY - 1, npc.heightLevel) & Region.BLOCKED_SOUTH) == 0)
                npc.moveY = -1;
            else if ((Region.getClipping(npc.absX + 1, npc.absY, npc.heightLevel) & Region.BLOCKED_EAST) == 0)
                npc.moveX = 1;
        }
    } else if (npc.moveX == -1 && npc.moveY == 1) {
        if ((Region.getClipping(npc.absX - 1, npc.absY + 1, npc.heightLevel) & Region.BLOCKED_NORTH_WEST) != 0) {
            npc.moveX = 0; npc.moveY = 0;
            if ((Region.getClipping(npc.absX, npc.absY + 1, npc.heightLevel) & Region.BLOCKED_NORTH) == 0)
                npc.moveY = 1;
            else if ((Region.getClipping(npc.absX - 1, npc.absY, npc.heightLevel) & Region.BLOCKED_WEST) == 0)
                npc.moveX = -1;
        }
    } // Checking diagonal movement.

    // Check for straight movement
    if (npc.moveY == -1) {
        if ((Region.getClipping(npc.absX, npc.absY - 1, npc.heightLevel) & Region.BLOCKED_SOUTH) != 0)
            npc.moveY = 0;
    } else if (npc.moveY == 1) {
        if ((Region.getClipping(npc.absX, npc.absY + 1, npc.heightLevel) & Region.BLOCKED_NORTH) != 0)
            npc.moveY = 0;
    } // Checking Y movement.

    if (npc.moveX == 1) {
        if ((Region.getClipping(npc.absX + 1, npc.absY, npc.heightLevel) & Region.BLOCKED_EAST) != 0)
            npc.moveX = 0;
    } else if (npc.moveX == -1) {
        if ((Region.getClipping(npc.absX - 1, npc.absY, npc.heightLevel) & Region.BLOCKED_WEST) != 0)
            npc.moveX = 0;
    } // Checking X movement.
}



	/**
	 * load spell
	 **/
	public void loadSpell2(int i) {
		npcs[i].attackType = 3;
		int random = Misc.random(3);
		if (random == 0) {
			npcs[i].projectileId = 393; // red
			npcs[i].endGfx = 430;
		} else if (random == 1) {
			npcs[i].projectileId = 394; // green
			npcs[i].endGfx = 429;
		} else if (random == 2) {
			npcs[i].projectileId = 395; // white
			npcs[i].endGfx = 431;
		} else if (random == 3) {
			npcs[i].projectileId = 396; // blue
			npcs[i].endGfx = 428;
		}
	}

	public void loadSpell(Client c,int i) {
		switch (npcs[i].npcType) {
		case 2208:
			if (goodDistance(npcs[i].absX, npcs[i].absY,
					Server.playerHandler.players[npcs[i].killerId].absX,
					Server.playerHandler.players[npcs[i].killerId].absY, 4)){
						npcs[i].gfx0(1185);
				npcs[i].projectileId = 1190; // red
				npcs[i].endGfx = 430;
				npcs[i].attackType = 1;
					}
		break;
		case 50:
			int random = Misc.random(4);
			if (random == 0) {
				npcs[i].projectileId = 393; // red
				npcs[i].endGfx = 430;
				npcs[i].attackType = 3;
			} else if (random == 1) {
				npcs[i].projectileId = 394; // green
				npcs[i].endGfx = 429;
				npcs[i].attackType = 3;
			} else if (random == 2) {
				npcs[i].projectileId = 395; // white
				npcs[i].endGfx = 431;
				npcs[i].attackType = 3;
			} else if (random == 3) {
				npcs[i].projectileId = 396; // blue
				npcs[i].endGfx = 428;
				npcs[i].attackType = 3;
			} else if (random == 4) {
				npcs[i].projectileId = -1; // melee
				npcs[i].endGfx = -1;
				npcs[i].attackType = 0;
			}
			break;
			case 55:
			case 54:
			case 53:
			case 56:
			if (goodDistance(npcs[i].absX, npcs[i].absY,
					Server.playerHandler.players[npcs[i].killerId].absX,
					Server.playerHandler.players[npcs[i].killerId].absY, 4)){
					npcs[i].projectileId = -1;
					npcs[i].attackType = 0;
					npcs[i].endGfx = -1;
				} else { 
						npcs[i].projectileId = 393;
						npcs[i].attackType = 3;
						npcs[i].endGfx = 430;
				}
		break;
			case 3229:
						npcs[i].projectileId = 27;
						npcs[i].attackType = 1;
			break;
			case 688:
			case 689:
			case 690:
			case 691:
						npcs[i].gfx100(18);
						npcs[i].projectileId = 10;
						npcs[i].attackType = 1;
						npcs[i].endGfx = 10;
						npcs[i].maxHit = 2;
			break;
		//bandos npcs
		case 2215:
			if (goodDistance(npcs[i].absX, npcs[i].absY,
					Server.playerHandler.players[npcs[i].killerId].absX,
					Server.playerHandler.players[npcs[i].killerId].absY, 2)){//melee
					npcs[i].projectileId = -1;
					npcs[i].attackType = 0;
					npcs[i].endGfx = -1;
					npcs[i].maxHit = 60;
				} else { 
						npcs[i].gfx0(1219);
						npcs[i].projectileId = 1202;
						npcs[i].attackType = 1;
						npcs[i].endGfx = 1218;
						npcs[i].maxHit = 35;
				}
		break;
		case 2217:
		npcs[i].attackType = 0;
		break;
		case 174:
		case 172:
			int confuse = Misc.random(10);
			if (confuse != 1) {
				npcs[i].gfx100(129);
				npcs[i].projectileId = 130;
				npcs[i].endGfx = 131;
				npcs[i].attackType = 2;
			}
			else if (confuse == 1 && Server.playerHandler.players[npcs[i].killerId].playerLevel[0] == Server.playerHandler.players[npcs[i].killerId].getLevelForXP(Server.playerHandler.players[npcs[i].killerId].playerXP[0])) {
				npcs[i].gfx100(102);
				npcs[i].projectileId = 103;
				npcs[i].endGfx = 104;
				Server.playerHandler.players[npcs[i].killerId].playerLevel[0] -= 5;
				npcs[i].attackType = 2;
			}
		break;
		case 2216:
		npcs[i].attackType = 2;
		npcs[i].gfx0(1202);
		npcs[i].projectileId = 1203;
		break;
		case 2218:
		npcs[i].attackType = 1;
		npcs[i].gfx0(1205);
		npcs[i].projectileId = 1206;
		break;
		case 2025:
			npcs[i].attackType = 2;
			int r = Misc.random(3);
			if (r == 0) {
				npcs[i].gfx100(158);
				npcs[i].projectileId = 159;
				npcs[i].endGfx = 160;
			}
			if (r == 1) {
				npcs[i].gfx100(161);
				npcs[i].projectileId = 162;
				npcs[i].endGfx = 163;
			}
			if (r == 2) {
				npcs[i].gfx100(164);
				npcs[i].projectileId = 165;
				npcs[i].endGfx = 166;
			}
			if (r == 3) {
				npcs[i].gfx100(155);
				npcs[i].projectileId = 156;
			}
			break;
		case 2881:// supreme
			npcs[i].attackType = 1;
			npcs[i].projectileId = 298;
			break;

		case 2882:// prime
			npcs[i].attackType = 2;
			npcs[i].projectileId = 162;
			npcs[i].endGfx = 477;
			break;

		case 2028:
			npcs[i].attackType = 1;
			npcs[i].projectileId = 27;
			break;

		case 3200:
			int r2 = Misc.random(1);
			if (r2 == 0) {
				npcs[i].attackType = 1;
				npcs[i].gfx100(550);
				npcs[i].projectileId = 551;
				npcs[i].endGfx = 552;
			} else {
				npcs[i].attackType = 2;
				npcs[i].gfx100(553);
				npcs[i].projectileId = 554;
				npcs[i].endGfx = 555;
			}
			break;
		case 2745:
			int r3 = 0;
			if (goodDistance(npcs[i].absX, npcs[i].absY,
					PlayerHandler.players[npcs[i].spawnedBy].absX,
					PlayerHandler.players[npcs[i].spawnedBy].absY, 1))
				r3 = Misc.random(2);
			else
				r3 = Misc.random(1);
			if (r3 == 0) {
				npcs[i].attackType = 2;
				npcs[i].endGfx = 157;
				npcs[i].projectileId = 448;
			} else if (r3 == 1) {
				npcs[i].attackType = 1;
				npcs[i].endGfx = 451;
				npcs[i].projectileId = -1;
			} else if (r3 == 2) {
				npcs[i].attackType = 0;
				npcs[i].projectileId = -1;
			}
			break;
			case 6278:
			break;
		case 2743:
			npcs[i].attackType = 2;
			npcs[i].projectileId = 445;
			npcs[i].endGfx = 446;
			break;
		
		case 2631:
			npcs[i].attackType = 1;
			npcs[i].projectileId = 443;
			break;
		}
	}

	private boolean isZamorakNpc(int i) {
		switch (npcs[i].npcType) {
            case 6203:
            case 6204:
            case 6206:
            case 6208:
            case 6219:
            case 6218:
            case 6212:
            case 3248:
            case 6220:
            case 6221:
			return true;
		}
		return false;
	}
	
	private boolean isSaradominNpc(int i) {
		switch(npcs[i].npcType) {
            case 6247:
            case 6248:
            case 6250:
            case 6254:
            case 6252:
            case 6257:
            case 6255:
            case 6256:
            case 6258:
			return true;
		}
		return false;
	}

    private boolean isBandosNpc(int i) {
        switch(npcs[i].npcType) {
            case 6277:
            case 6269:
            case 6270:
            case 3247:
            case 6276:
            case 6272:
            case 6274:
            case 6278:
                return true;
        }
        return false;
    }   
	private boolean isBandosBossNpc(int i) {
        switch(npcs[i].npcType) {
            case 2215:
            case 2216:
            case 2217:
            case 2218:
                return true;
        }
        return false;
    }

    private boolean isArmadylNpc(int i) {
        switch(npcs[i].npcType) {
            case 6222:
            case 6223:
            case 6225:
            case 6230:
            case 6239: // Aviansie
            case 6227:
            case 6232:
            case 6229:
            case 6233:
            case 6231:
                return true;
        }
        return false;
    }
	/**
	 * Distanced required to attack
	 **/
	public int distanceRequired(int i) {
int distanceNeeded = 1;
		if (npcs[i].attackType == 1) {
			return distanceNeeded += 7;
		} else if (npcs[i].attackType == 2) {
			return distanceNeeded += 9;
		} else if (npcs[i].attackType > 2) {
			return distanceNeeded += 4;
		}
		switch (npcs[i].npcType) {		
		case 3229:
		case 172:
		case 174:
		case 688:
		case 689:
		case 690:
		case 691:
				return distanceNeeded += 5;
		case 2215:
				return distanceNeeded += 10;
		case 6263:
		case 6265:
				return distanceNeeded += 10;
			case 941 : // Green drag
			case 50 : // Kbd
				return distanceNeeded += 5;
		case 2562:
				return distanceNeeded += 1;
		case 2881:// dag kings
		case 2882:
		case 3200:// chaos ele
				return distanceNeeded += 7;
		case 2883:// rex
				return distanceNeeded += 0;
		case 2552:
		case 2553:
		case 2556:
		case 2557:
		case 2558:
		case 2559:
		case 2560:
		case 2564:
		case 2565:
				return distanceNeeded += 8;
			// things around dags
		case 2892:
		case 2894:
				return distanceNeeded += 9;
			case 907 : // Kolodian
			case 908 :
			case 909 :
			case 910 :
			case 911 :
			case 912 : // Zammy battlemage
			case 913 : // Sara battlemage
			case 914 : // Guthix battlemage
			case 2591 : // TzHaar-Mej (Tzhaar mage guy)
			case 2743 : // Ket-Zek (Tzhaar mage guy)
			case 2745 : // TzTok-Jad
			case 1158 : // Kalphite queen form 1
			case 1160 : // Kalphite queen form 2
			case 2025 : // Ahrim
				return distanceNeeded += 9;
			case 2028 : // Karil
			case 2631 : // Tok-Xil (Tzhaar ranging guy)
			case 1183 : // Elf ranger
				return distanceNeeded += 7;
		}
			return distanceNeeded;
	}

	public int followDistance(int i) {
		switch (npcs[i].npcType) {
		case 2550:
		case 2551:
		case 2562:
		case 2563:
			return 8;
		case 2883:
			return 4;
		case 2881:
		case 2882:
			return 1;
		case 2215:
		case 2216:
		case 2217:
		case 2218:
		return 5;
		}
		return 0;

	}

	public int getProjectileSpeed(int i) {
		//lower number = faster, higher = slower
		switch (npcs[i].npcType) {
		case 2881:
		case 2882:
		case 3200:
			return 85;

		case 2745:
			return 130;

		case 50:
			return 90;

		case 2025:
			return 85;

		case 172:
		case 174:
				return 110;
		case 2028:
			return 80;
		case 6263:
		case 6265:
		case 2215:
		return 120;
		default:
			return 85;
		}
	}

	/**
	 * NPC Attacking Player
	 **/
	public boolean goodDistanceNpc(int i, int x2, int y2, int distance) {
		for (int x = npcs[i].getX(); x <= npcs[i].getX() + npcSize(i); x++) {
			for (int y = npcs[i].getY(); y <= npcs[i].getY() + npcSize(i); y++) {
				if (Misc.goodDistance(x, y, x2, y2, distance)) {
					return true;
				}
			}
		}
		return false;
	}
	public void attackPlayer(Client c, int i) {
		boolean face = true;
		if (npcs[i] != null) {
		if (NPCHandler.npcs[i].HP <= 0) {
			return;
		}
			if (npcs[i].isDead)
				return;
			if (!npcs[i].inMulti() && npcs[i].underAttackBy > 0
					&& npcs[i].underAttackBy != c.playerId) {
				npcs[i].killerId = 0;
				return;
			}
			if (npcs[i].absY == 3228 && c.absY == 3227
				|| npcs[i].absY == 3224 && c.absY == 3225
				|| npcs[i].absY == 3226 && c.absY == 3227
				|| npcs[i].isDead) {
				return;
			}
			if (npcs[i].npcType == 1532
					|| npcs[i].npcType == 1534
					|| npcs[i].npcType == 6145
					|| npcs[i].npcType == 6144
					|| npcs[i].npcType == 6143
					|| npcs[i].npcType == 6142
					|| npcs[i].npcType == 752) {
				return;
			}
			
			if (npcs[i].lastX != npcs[i].getX()
					|| npcs[i].lastY != npcs[i].getY()) {
				return;
			}
			if (!npcs[i].inMulti()
					&& (c.underAttackBy > 0 || (c.underAttackBy2 > 0 && c.underAttackBy2 != i))) {
				npcs[i].killerId = 0;
				return;
			}
			if (npcs[i].heightLevel != c.heightLevel) {
				npcs[i].killerId = 0;
				return;
			}
			if (!goodDistanceNpc(npcs[i].npcId, c.getX(), c.getY(), distanceRequired(npcs[i].npcId))) {
				return;
			}
			if (!goodDistanceNpc(npcs[i].npcId, c.getX(), c.getY(), distanceRequired(npcs[i].npcId)) || inNpc(npcs[i].npcId, c.getX(), c.getY())) {
				stepAway(i);
				//return;
			}
				if (!PathFinder.isProjectilePathClear(npcs[i].getX(), npcs[i].getY(), npcs[i].heightLevel, c.getX(), c.getY())) {
					return;
				}
				if(npcs[i].npcType > 308 && npcs[i].npcType < 335)
					face = false;
					if(face)
					npcs[i].facePlayer(c.playerId);
			boolean special = false;// specialCase(c,i);
			if (checkClip(i) || special) {
				if (c.respawnTimer <= 0) {
					if(face)
					npcs[i].facePlayer(c.playerId);
					npcs[i].attackTimer = getNpcDelay(i);
					npcs[i].hitDelayTimer = getHitDelay(i);
					npcs[i].attackType = 0;
					if (special)
						loadSpell2(i);
					else
						loadSpell(c, i);
					if (npcs[i].attackType == 3)
						npcs[i].hitDelayTimer += 2;
					if (multiAttacks(i)) {
						multiAttackGfx(i, npcs[i].projectileId);
					if (npcs[i].npcAttackAnimation <= -1)
						startAnimation(getAttackEmote(i), i);
					else
						startAnimation(npcs[i].npcAttack2Animation, i);
						npcs[i].oldIndex = c.playerId;
						return;
					}
					if (npcs[i].projectileId > 0) {
						int nX = NPCHandler.npcs[i].getX() + npcSize(i);
						int nY = NPCHandler.npcs[i].getY() + npcSize(i);
						int pX = c.getX();
						int pY = c.getY();
						int offX = (nY - pY) * -1;
						int offY = (nX - pX) * -1;
						c.getPA().createPlayersProjectile(nX, nY, offX, offY,
								50, getProjectileSpeed(i),
								npcs[i].projectileId, 53, 21, -c.getId() - 1,
								65);
					}
					c.underAttackBy2 = i;
					c.singleCombatDelay2 = System.currentTimeMillis();
					npcs[i].oldIndex = c.playerId;
					if (npcs[i].npcAttackAnimation <= -1)
						startAnimation(getAttackEmote(i), i);
					else 
						startAnimation(npcs[i].npcAttackAnimation, i);
					c.getPA().removeAllWindows();
				}
			}
		}
	}

	public int offset(int i) {
		switch (npcs[i].npcType) {
			case 2215:
			return 2;
		case 50:
			return 2;
		
		}
		return 0;
	}

	public boolean specialCase(Client c, int i) { // responsible for npcs that
													// much
		if (goodDistance(npcs[i].getX(), npcs[i].getY(), c.getX(), c.getY(), 8)
				&& !goodDistance(npcs[i].getX(), npcs[i].getY(), c.getX(),
						c.getY(), distanceRequired(i)))
			return true;
		return false;
	}

	public boolean retaliates(int npcType) {
		return npcType < 3777 || npcType > 3780
				&& !(npcType >= 2440 && npcType <= 2446);
	}

	public void applyDamage(int i) {
		if (npcs[i] != null) {
			if (PlayerHandler.players[npcs[i].oldIndex] == null) {
				return;
			}
			if (npcs[i].isDead)
				return;
			Client c = (Client) PlayerHandler.players[npcs[i].oldIndex];
			if (multiAttacks(i)) {
				multiAttackDamage(i);
				return;
			}
			if (c.playerIndex <= 0 && c.npcIndex <= 0)
				if (c.autoRet == 1)
					c.npcIndex = i;
			if (c.attackTimer <= 3 || c.attackTimer == 0 && c.npcIndex == 0
					&& c.oldNpcIndex == 0) {
				c.startAnimation(c.getCombat().getBlockEmote());
				//startAnimation(getBlockEmote(i), i);
			}
			if (c.respawnTimer <= 0) {
				int damage = 0;
				if (npcs[i].attackType == 0) {
					damage = Misc.random(npcs[i].maxHit);
					if (10 + Misc.random(c.getCombat().calculateMeleeDefence()) > Misc
							.random(NPCHandler.npcs[i].attack)) {
						damage = 0;
					}
					if (c.prayerActive[18]) { // protect from melee
						damage = 0;
					}
					if (c.playerLevel[3] - damage < 0) {
						damage = c.playerLevel[3];
					}
				}

				if (npcs[i].attackType == 1) { // range
					damage = Misc.random(npcs[i].maxHit);
					if (10 + Misc.random(c.getCombat().calculateRangeDefence()) > Misc
							.random(NPCHandler.npcs[i].attack)) {
						damage = 0;
					}
					if (c.prayerActive[17]) { // protect from range
						damage = 0;
					}
					if (c.playerLevel[3] - damage < 0) {
						damage = c.playerLevel[3];
					}
				}

				if (npcs[i].attackType == 2) { // magic
					damage = Misc.random(npcs[i].maxHit);
					boolean magicFailed = false;
					if (10 + Misc.random(c.getCombat().mageDef()) > Misc
							.random(NPCHandler.npcs[i].attack)) {
						damage = 0;
						magicFailed = true;
					}
					if (c.prayerActive[16]) { // protect from magic
						damage = 0;
						magicFailed = true;
					}
					if (c.playerLevel[3] - damage < 0) {
						damage = c.playerLevel[3];
					}
					if (npcs[i].endGfx > 0
							&& (!magicFailed || isFightCaveNpc(i))) {
						c.gfx100(npcs[i].endGfx);
					} else {
						c.gfx100(85);
					}
				}

				if (npcs[i].attackType == 3) { // fire breath
					int anti = c.getPA().antiFire();
					if (anti == 0) {
						damage = Misc.random(30) + 10;
						c.sendMessage("You are badly burnt by the dragon fire!");
					} else if (anti == 1)
						damage = Misc.random(20);
					else if (anti == 2)
						damage = Misc.random(5);
					if (c.playerLevel[3] - damage < 0)
						damage = c.playerLevel[3];
					c.gfx100(npcs[i].endGfx);
				}
				handleSpecialEffects(c, i, damage);
				c.logoutDelay = System.currentTimeMillis(); // logout delay
				// c.setHitDiff(damage);
				c.handleHitMask(damage);
				c.playerLevel[3] -= damage;
				c.getPA().refreshSkill(3);
				c.updateRequired = true;
				// c.setHitUpdateRequired(true);
			}
		}
	}

	public void handleSpecialEffects(Client c, int i, int damage) {
		if (npcs[i].npcType == 2892 || npcs[i].npcType == 2894 || npcs[i].npcType == 1158
                || npcs[i].npcType == 116) {
			if (damage > 0) {
				if (c != null) {
					if (c.playerLevel[5] > 0) {
						c.playerLevel[5]--;
						c.getPA().refreshSkill(5);
						c.getPA().appendPoison(12);
					}
				}
			}
		}

	}

	public static void startAnimation(int animId, int i) {
		npcs[i].animNumber = animId;
		npcs[i].animUpdateRequired = true;
		npcs[i].updateRequired = true;
	}

	public boolean goodDistance(int objectX, int objectY, int playerX,
			int playerY, int distance) {
		for (int i = 0; i <= distance; i++) {
			for (int j = 0; j <= distance; j++) {
				if ((objectX + i) == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				} else if ((objectX - i) == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				} else if (objectX == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				}
			}
		}

		return false;
	}
	
	public boolean checkClip(int i) {
		NPC n = npcs[i];
		int x2 = 0, y2 = 0, x3 = 0, y3 = 0;
		if (n.killerId > 0) {
			if (PlayerHandler.players[n.killerId] == null) {
				return false;
			}
			x2 = PlayerHandler.players[n.killerId].getX();
			y2 = PlayerHandler.players[n.killerId].getY();
		} else if (n.summonedBy > 0) {
			if (PlayerHandler.players[n.summonedBy] == null) {
				return false;
			}
			x2 = PlayerHandler.players[n.summonedBy].getX();
			y2 = PlayerHandler.players[n.summonedBy].getY();
		} else {
			return false;
		}
		int x = n.getX(); // -1
		int y = n.getY(); // 1
		final int dis = distanceRequired(i) + npcSize(i);
		int dis2 = 0;
		final boolean melee = distanceRequired(i) < 2;
		if (npcSize(i) < 1 && x != x2 && y != y2) {
			return false;
		}
		// Algorithm starts here
		int w = x2 - x;
		int h = y2 - y;
		int dx1 = 0, dy1 = 0, dx2 = 0, dy2 = 0;
		if (w < 0) {
			dx1 = -1;
		} else if (w > 0) {
			dx1 = 1;
		}
		if (h < 0) {
			dy1 = -1;
		} else if (h > 0) {
			dy1 = 1;
		}
		if (w < 0) {
			dx2 = -1;
		} else if (w > 0) {
			dx2 = 1;
		}
		int longest = Math.abs(w);
		int shortest = Math.abs(h);
		if (!(longest > shortest)) {
			longest = Math.abs(h);
			shortest = Math.abs(w);
			if (h < 0) {
				dy2 = -1;
			} else if (h > 0) {
				dy2 = 1;
			}
			dx2 = 0;
		}
		int numerator = longest >> 1;
		boolean firstCheck = false;
		for (int j = 0; j <= longest; j++) {
			if (dis2 > dis) {
				return false;
			}
			dis2++;
			x3 = x;
			y3 = y;
			numerator += shortest;
			if (!(numerator < longest)) {
				numerator -= longest;
				x += dx1;
				y += dy1;
			} else {
				x += dx2;
				y += dy2;
			}
			if (!firstCheck) {
				if (melee) {
					if (!Region.getClipping(x, y, n.heightLevel, x - x3, y - y3)) {
						return false;
					}
				}
				if (x == x2 && y == y2) {
					break;
				}
				firstCheck = true;
			}
			if (melee) {
				if (!Region.getClipping(x, y, n.heightLevel, x - x3, y - y3)) {
					return false;
				}
			}
			if (x == x2 && y == y2) {
				return true;
			}
		}
		return true;
	}

	public boolean inNpc(int i, int x2, int y2) {
		if (offset(i) < 1) {
			if (x2 == NPCHandler.npcs[i].getX() && y2 == NPCHandler.npcs[i].getY()) {
				return true;
			}
		} else {
			for (int x = NPCHandler.npcs[i].getX(); x <= NPCHandler.npcs[i].getX() + npcSize(i); x++) {
				for (int y = NPCHandler.npcs[i].getY(); y <= NPCHandler.npcs[i].getY() + npcSize(i); y++) {
					if (x2 == x && y2 == y) {
						return true;
					}
				}
			}
		}
		return false;
	}
	public int getMaxHit(int i) {
		switch (npcs[i].npcType) {
		case 2558:
			if (npcs[i].attackType == 2)
				return 28;
			else
				return 68;
		case 2562:
			return 31;
		case 2550:
			return 36;
		}
		return 1;
	}

	public boolean loadAutoSpawn(String FileName) {
		String line = "";
		String token = "";
		String token2 = "";
		String token2_2 = "";
		String[] token3 = new String[10];
		boolean EndOfFile = false;
		BufferedReader characterfile = null;
		try {
			characterfile = new BufferedReader(new FileReader("./" + FileName));
		} catch (FileNotFoundException fileex) {
			Misc.println(FileName + ": file not found.");
			return false;
		}
		try {
			line = characterfile.readLine();
		} catch (IOException ioexception) {
			Misc.println(FileName + ": error loading file.");
			return false;
		}
		while (EndOfFile == false && line != null) {
			line = line.trim();
			int spot = line.indexOf("=");
			if (spot > -1) {
				token = line.substring(0, spot);
				token = token.trim();
				token2 = line.substring(spot + 1);
				token2 = token2.trim();
				token2_2 = token2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token3 = token2_2.split("\t");
				if (token.equals("spawn")) {
					int attackAnimation = -1;
							int blockAnimation = -1;
							int attack2Animation = -1;
							int deathAnimation = -1;

            if (token3.length > 8) {
                attackAnimation = Integer.parseInt(token3[8]);
            }

            if (token3.length > 9) {
                blockAnimation = Integer.parseInt(token3[9]);
            }

            if (token3.length > 10) {
                attack2Animation = Integer.parseInt(token3[10]);
            }

            if (token3.length > 11) {
                deathAnimation = Integer.parseInt(token3[11]);
            }

           // newNPCList(Integer.parseInt(token3[0]), token3[1], Integer.parseInt(token3[2]), Integer.parseInt(token3[3]));
        
					newNPC(Integer.parseInt(token3[0]),
							Integer.parseInt(token3[1]),
							Integer.parseInt(token3[2]),
							Integer.parseInt(token3[3]),
							Integer.parseInt(token3[4]),
							getNpcListHP(Integer.parseInt(token3[0])),
							Integer.parseInt(token3[5]),
							Integer.parseInt(token3[6]),
							Integer.parseInt(token3[7]), attackAnimation, blockAnimation, attack2Animation, deathAnimation);
							
				}
			} else {
				if (line.equals("[ENDOFSPAWNLIST]")) {
					try {
						characterfile.close();
					} catch (IOException ioexception) {
					}
					return true;
				}
			}
			try {
				line = characterfile.readLine();
			} catch (IOException ioexception1) {
				EndOfFile = true;
			}
		}
		try {
			characterfile.close();
		} catch (IOException ioexception) {
		}
		return false;
	}

	public int getNpcListHP(int npcId) {
		for (int i = 0; i < maxListedNPCs; i++) {
			if (NpcList[i] != null) {
				if (NpcList[i].npcId == npcId) {
					return NpcList[i].npcHealth;
				}
			}
		}
		return 0;
	}	
	public int getNpcListCombat(int npcId) {
		for (int i = 0; i < maxListedNPCs; i++) {
			if (NpcList[i] != null) {
				if (NpcList[i].npcId == npcId) {
					return NpcList[i].npcCombat;
				}
			}
		}
		return 0;
	}

public static String getNpcListName(int npcId) {
    for (int i = 0; i < maxListedNPCs; i++) {
        if (NpcList[i] != null) {
            if (NpcList[i].npcId == npcId) {
                String npcName = NpcList[i].npcName;
                npcName = npcName.replace("_", " "); // Replace underscores with spaces
                return npcName;
            }
        }
    }
    return "nothing";
}
	/*public int getNpcListAttackAnimation(int npcId) {
		for (int i = 0; i < maxListedNPCs; i++) {
			if (NpcList[i] != null) {
				if (NpcList[i].npcId == npcId) {
					return NpcList[i].npcAttackAnimation;
				}
			}
		}
		return -1;
	}*/

	public boolean loadNPCList(String FileName) {
		String line = "";
		String token = "";
		String token2 = "";
		String token2_2 = "";
		String[] token3 = new String[10];
		boolean EndOfFile = false;
		BufferedReader characterfile = null;
		try {
			characterfile = new BufferedReader(new FileReader("./" + FileName));
		} catch (FileNotFoundException fileex) {
			Misc.println(FileName + ": file not found.");
			return false;
		}
		try {
			line = characterfile.readLine();
		} catch (IOException ioexception) {
			Misc.println(FileName + ": error loading file.");
			return false;
		}
		while (EndOfFile == false && line != null) {
			line = line.trim();
			int spot = line.indexOf("=");
			if (spot > -1) {
				token = line.substring(0, spot);
				token = token.trim();
				token2 = line.substring(spot + 1);
				token2 = token2.trim();
				token2_2 = token2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token2_2 = token2_2.replaceAll("\t\t", "\t");
				token3 = token2_2.split("\t");
				  if (token.equals("npc")) {
				newNPCList(Integer.parseInt(token3[0]), token3[1], Integer.parseInt(token3[2]), Integer.parseInt(token3[3]));
				}
			} else {
				if (line.equals("[ENDOFNPCLIST]")) {
					try {
						characterfile.close();
					} catch (IOException ioexception) {
					}
					return true;
				}
			}
			try {
				line = characterfile.readLine();
			} catch (IOException ioexception1) {
				EndOfFile = true;
			}
		}
		try {
			characterfile.close();
		} catch (IOException ioexception) {
		}
		return false;
	}

}
