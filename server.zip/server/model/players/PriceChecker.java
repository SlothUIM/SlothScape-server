package server.model.players;

import java.io.*;
import java.util.*;
import java.awt.*;
import server.Config;
import server.model.players.Client;
import server.util.Misc;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;
import server.model.players.packets.GeValuesCache;
import server.model.players.packets.Pair;


public class PriceChecker {

	private static int getFramesForSlot[][] = { { 0, 62550 }, { 1, 62553 },
			{ 2, 62556 }, { 3, 62559 }, { 4, 62562 }, { 5, 62565 },
			{ 6, 62568 }, { 7, 62571 }, { 8, 62574 }, { 9, 62577 },
			{ 10, 62580 }, { 11, 62583 }, { 12, 62586 }, { 13, 62589 },
			{ 14, 62592 }, { 15, 62595 }, { 16, 62598 }, { 17, 62601 },
			{ 18, 62604 }, { 19, 62607 }, { 20, 62610 }, { 21, 62613 },
			{ 22, 62616 }, { 23, 62619 }, { 24, 62622 }, { 25, 62625 },
			{ 26, 62628 }, { 27, 62631 }};

	public static int arraySlot(Client c, int[] array, int target) {
		int spare = -1;
		for (int x = 0; x < array.length; x++) {
			if (array[x] == target && c.getItems().isStackable(target)) {
				return x;
			} else if (spare == -1 && array[x] <= 0) {
				spare = x;
			}
		}
		return spare;
	}

	public static void clearConfig(Client c) {
		for (int x = 0; x < c.price.length; x++) {
			if (c.price[x] > 0)
				withdrawItem(c, c.price[x], x, c.priceN[x]);
		}
		c.getItems().updateInventory = true;
		c.isChecking = false;
		c.getItems().resetItems(5064);
	}

	public static void depositItem(Client c, int id, int amount) {
		int slot = arraySlot(c, c.price, id);
		for (int j = 0; j < Config.ITEM_TRADEABLE.length; j++) {
			if (id == Config.ITEM_TRADEABLE[j]) {
				c.sendMessage("This item is untrade-able.");
				return;
			}
		}
		if (c.getItems().getItemAmount(id) < amount) {
			amount = c.getItems().getItemAmount(id);
		}
		if (slot == -1) {
			c.sendMessage("The price-checker is currently full.");
			return;
		}
		if (!c.getItems().isStackable(id)) {
			amount = 1;
		}
		if (!c.getItems().playerHasItem(id, amount)) {
			return;
		}
		c.getItems().deleteItem2(id, amount);
		if (c.price[slot] != id) {
			c.price[slot] = id;
			c.priceN[slot] = amount;
		} else {
			c.price[slot] = id;
			c.priceN[slot] += amount;
		}
		c.total += loadvalues(id) * amount;
		updateChecker(c);
	}

public static void loadcache() {
	GeValuesCache.loadGePricesCache();
}
public static int loadvalues(int i1){
	 Pair<Integer, Integer> values = GeValuesCache.geValues.get(i1);
	                int GeValue = 0;
	                
	                if (values != null) {
	                    GeValue = values.getFirst();
						return GeValue;
	                } else {
	                    GeValue = 0;
						return GeValue;
	                }
}
	public static void itemOnInterface(Client c, int frame, int slot, int id,
			int amount) {
		c.outStream.createFrameVarSizeWord(34);
		c.outStream.writeWord(frame);
		c.outStream.writeByte(slot);
		c.outStream.writeWord(id + 1);
		c.outStream.writeByte(255);
		c.outStream.writeDWord(amount);
		c.outStream.endFrameVarSizeWord();
	}

	public static void open(Client c) {
		openUpChecker(c);
	}

	/**
	 * Open bank
	 **/
	public static void openUpChecker(Client c) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getItems().resetItems(5064);
		c.isChecking = true;
		c.total = 0;
		c.getPA().sendFrame126("" + Misc.insertCommasToNumber(Integer.toString(c.total)) + "", 62548); 
		c.getPA().sendFrame126("Click on items in your inventory to check their values", 62549);
		updateChecker(c);
		resetFrames(c);
			c.getOutStream().createFrame(248);
			c.getOutStream().writeWordA(43933);
			c.getOutStream().writeWord(5063);
			c.flushOutStream();
		}
	}
	public static void resetFrames(Client c) {
		for (int x = 0; x < 20; x++) {
			if (c.price[x] <= 1) {
				setFrame(c, x, getFramesForSlot[x][1], c.price[x], c.priceN[x],
						false);
			}
		}
	}

	private static void setFrame(Client player, int slotId, int frameId,
			int itemId, int amount, boolean store) {
		int totalAmount = player.getShops().getItemShopValue(itemId) * amount;
		String total = Misc.insertCommasToNumber(Integer.toString(totalAmount));
		if (!store) {
			player.getPA().sendFrame126("", frameId);
			player.getPA().sendFrame126("", frameId + 1);
			player.getPA().sendFrame126("", frameId + 2);
			return;
		}
		if (player.getItems().isStackable(itemId)) {
			player.getPA().sendFrame126("" + amount + " x", frameId);
			player.getPA().sendFrame126("" + Misc.insertCommasToNumber(Integer.toString(loadvalues(itemId)))
							+ " =", frameId + 1);
			if(totalAmount > Integer.MAX_VALUE || totalAmount < 0)
				player.getPA().sendFrame126("Lots!", frameId + 2);
			else
				player.getPA().sendFrame126("" + total + "", frameId + 2);
		} else {
			player.getPA().sendFrame126(""+ Misc.insertCommasToNumber(Integer.toString(loadvalues(itemId))) + "", frameId);
			player.getPA().sendFrame126("", frameId + 1);
			player.getPA().sendFrame126("", frameId + 2);
		}
	}

	public static void updateChecker(Client c) {
		c.getItems().resetItems(5064);
		for (int x = 0; x < 28; x++) {
			if (c.priceN[x] <= 0) {
				itemOnInterface(c, 18246, x, -1, 0);
			} else {
				itemOnInterface(c, 18246, x, c.price[x], c.priceN[x]);
				c.getPA().sendFrame126("", 62549);
				for (int frames = 0; frames < getFramesForSlot.length; frames++) {
					if (x == getFramesForSlot[frames][0]) {
						setFrame(c, x, getFramesForSlot[frames][1], c.price[x],
								c.priceN[x], true);
					}
				}
			}
		}
			if(c.total > Integer.MAX_VALUE || c.total < 0)
				c.getPA().sendFrame126("Lots!", 62548);
			else
				c.getPA().sendFrame126(""+ Misc.insertCommasToNumber(Integer.toString(c.total < 0 ? 0 : c.total)) + "",62548);
	}

	public static void withdrawItem(Client c, int removeId, int slot, int amount) {
		if (!c.isChecking)
			return;
		if (c.price[slot] != removeId) {
			return;
		}
		if (!c.getItems().isStackable(c.price[slot]))
			amount = amount;
		if (amount > c.priceN[slot] && c.getItems().isStackable(c.price[slot]))
			amount = c.priceN[slot];
		if (c.price[slot] >= 0 && c.getItems().freeSlots() > 0) {
			c.getItems().addItem(c.price[slot], amount);
			if (c.getItems().isStackable(c.price[slot])
					&& c.getItems().playerHasItem(c.price[slot], amount)) {
				c.priceN[slot] -= amount;
				c.price[slot] = c.priceN[slot] <= 0 ? 0 : c.price[slot];
			} else {
				c.priceN[slot] = 0;
				c.price[slot] = 0;
			}
		}
		c.total -= c.getShops().getItemShopValue(removeId) * amount;
		for (int frames = 0; frames < getFramesForSlot.length; frames++) {
			if (slot == getFramesForSlot[frames][0]) {
				if (c.priceN[slot] >= 1) {
					setFrame(c, slot, getFramesForSlot[frames][1],
							c.price[slot], c.priceN[slot], true);
				} else {
					setFrame(c, slot, getFramesForSlot[frames][1],
							c.price[slot], c.priceN[slot], false);
				}
			}
		}
		updateChecker(c);
	}

}