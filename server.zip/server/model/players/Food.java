package server.model.players;

import java.util.HashMap;
import server.util.Misc;

/**
 * @author Sanity
 */

public class Food {

	private Client c;

	public Food(Client c) {
		this.c = c;
	}

	public static enum FoodToEat {
		MANTA(391, 22, "Manta Ray"), 
		SHARK(385, 20, "Shark"), 
		LOBSTER(379, 12,"Lobster"), 
		TROUT(333, 7, "Trout"), 
		COD(339, 6, "Cod"), 
		HERRING(347, 5, "herring"), 
		PIKE(351, 8, "Pike"), 
		MACKEREL(355, 7, "Mackerel"), 
		BASS(365, 13, "Bass"), 
		SARDINE(325, 4, "Sardine"), 
		ANCHOVIES(319, 4, "Anchovy"), 
		SHRIMPS(315, 3, "Shrimp"), 
		SALMON(329, 9, "Salmon"), 
		SWORDFISH(373, 14, "Swordfish"), 
		TUNA(361, 10, "Tuna"), 
		MONKFISH(7946,16, "Monkfish"),
		SEA_TURTLE(397, 22, "Sea Turtle"), 
		BAKED_POTATO(6701, 4, "Baked Potato"),
		BUTTER_POTATO(6703, 14, "Potato with butter"),
		CHEESE_POTATO(6705, 16, "Potato with cheese"),
		CHILLI_POTATO(7054, 14, "Chilli Potato"),
		EGG_POTATO(7056, 16, "Egg Potato"),
		MUSHROOM_POTATO(7058, 20, "Mushroom Potato"),
		TUNA_POTATO(7060, 22, "Tuna Potato"), 
		CAKE(1891, 4, "Cake"), 
		TWO_THIRDS_CAKE(1893, 4, "2/3 Cake "), 
		CAKE_SLICE(1895, 4, "Slice of Cake "), 
		CHOC_CAKE(1897, 5, "Chocolate Cake"), 
		TWO_THIRDS_CHOC_CAKE(1899, 5, "2/3 Chocolate Cake"), 
		CHOC_SLICE(1901, 5, "Slice of Chocolate Cake"), 
		PITTA_BREAD(1865, 3, "Pitta Bread"), 
		UGTHANKI_MEAT(1861, 3, "Ugthanki Meat"), 
		UGTHANKI_KEBAB(1885, 5, "Ugthanki Kebab"), 
		BANANA(1963, 2, "Banana"), 
		CABBAGE(1965, 1, "Cabbage"), 
		SPINACH_ROLL(1969, 1, "Spinach Roll"), 
		KEBAB(1971, Misc.random(10), "Kebab"), 
		CHOCO_BAR(1973, 2, "Chocolate Bar"), 
		CHEESE(1985, 2, "Cheese"), 
		STEW(2003, 11, "Stew"), 
		CURRY(2011, 19, "Curry"), 
		CHICKEN(2140, 3, "Chicken"), 
		MEAT(2142, 3, "Meat"), 
		TOADS_LEGS(2152, 3, "Toads Legs"), 
		CHOCO_BOMB(2185, 15, "Choco Bomb"), 
		ODD_CRUNCHIES(2197, 8, "Odd Crunchies"), 
		PLAIN_PIZZA(2289, 7, "Plain Pizza"), 
		HALF_PLAIN_PIZZA(2291, 7, "1/2 a Plain Pizza"), 
		MEAT_PIZZA(2293, 8, "Meat Pizza"), 
		HALF_MEAT_PIZZA(2295, 8, "1/2 a Meat Pizza"), 
		ANCHOVY_PIZZA(2297, 9, "Anchovy Pizza"), 
		HALF_ANCHOVY_PIZZA(2299, 9, "1/2 an Anchovy Pizza"), 
		PINEAPPLE_PIZZA(2301, 11, "Pineapple Pizza"), 
		HALF_PINEAPPLE_PIZZA(2303, 11, "1/2 a Pineapple Pizza"), 
		BREAD(2309, 22, "Bread"), 
		APPLE_PIE(2323, 7, "Apple Pie"), 
		HALF_APPLE_PIE(2335, 7, "1/2 an Apple pie"),
		REDBERRY_PIE(2325, 5, "Redberry Pie"), 
		HALF_REDBERRY_PIE(2333, 5, "1/2 a Redberry pie"),
		MEAT_PIE(2327, 6, "Meat pie"), 
		HALF_MEAT_PIE(2331, 6, "1/2 a Meat Pie"),
		OOMLIE_WRAP(2343, 22, "Oomlie Wrap"), 
		MONKEY_NUTS(4012, 4, "Monkey Nuts"), 
		BANANA_STEW(4016, 11, "Banana Stew");

		private int id;
		private int heal;
		private String name;

		private FoodToEat(int id, int heal, String name) {
			this.id = id;
			this.heal = heal;
			this.name = name;
		}

		public int getId() {
			return id;
		}

		public int getHeal() {
			return heal;
		}

		public String getName() {
			return name;
		}

		public static HashMap<Integer, FoodToEat> food = new HashMap<Integer, FoodToEat>();

		public static FoodToEat forId(int id) {
			return food.get(id);
		}

		static {
			for (FoodToEat f : FoodToEat.values())
				food.put(f.getId(), f);
		}
	}

	public void eat(int id, int slot) {
		if (c.duelRule[6]) {
			c.sendMessage("You may not eat in this duel.");
			return;
		}
		if (System.currentTimeMillis() - c.foodDelay >= 1500
				&& c.playerLevel[3] > 0) {
			c.getCombat().resetPlayerAttack();
			c.attackTimer += 2;
			c.startAnimation(829);
			c.getItems().deleteItem(id, slot, 1);
			FoodToEat f = FoodToEat.food.get(id);
			if (c.playerLevel[3] < c.getLevelForXP(c.playerXP[3])) {
				c.playerLevel[3] += f.getHeal();
				if (c.playerLevel[3] > c.getLevelForXP(c.playerXP[3]))
					c.playerLevel[3] = c.getLevelForXP(c.playerXP[3]);
			}
			c.foodDelay = System.currentTimeMillis();
			c.getPA().sendSound(317, 0, 8);
				c.getPA().refreshSkill(3);
			c.sendMessage("You eat the " + f.getName() + ".");
		}
	}

	public boolean isFood(int id) {
		return FoodToEat.food.containsKey(id);
	}

}