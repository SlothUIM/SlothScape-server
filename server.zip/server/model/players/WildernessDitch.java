package server.model.players;

import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.players.Client;

/**
 * Class WildernessDitch Handles Crossing the wilderness ditch
 * 
 * @author Organic 5-4-2012
 */

public class WildernessDitch {

	private static final int EMOTE = 6132;
	private static int AMOUNT_TO_MOVE = 3;

	private static void setAnimationBack(Client c) {
	  c.isRunning2 = isRunning;
	  c.getPA().sendFrame36(173, c.isRunning2 ? 0 : 1);
		c.playerStandIndex = 0x328;
		c.playerWalkIndex = 0x333;
		c.playerTurn180Index = 0x334;
		c.playerTurn90CWIndex = 0x335;
		c.playerTurn90CCWIndex = 0x336;
		c.playerTurnIndex = 0x337;
		c.playerRunIndex = 0x338;
		c.getCombat().getPlayerAnimIndex(c.getItems().getItemName(c.playerEquipment[c.playerWeapon]).toLowerCase());
		c.resetWalkingQueue();
		c.getPA().requestUpdates();
	}

	public static void movePlayer(Client c, int x, int y) {
		c.resetWalkingQueue();
		c.setX(x);
		c.setY(y);
		//c.setNeedsPlacement(true);
		c.getPA().requestUpdates();
	}

	public static boolean isRunning;
	public static void wildernessDitchEnter(final Client c) {
		isRunning = c.isRunning2;
		c.isRunning2 = true;
		c.setForceMovement(c.getX(), 3523, 0, 10, "NORTH", EMOTE);
		if (c.stopPlayerPacket) {
			return;
		}
		c.stopPlayerPacket = true;
		//c.startAnimation(EMOTE);
		CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				if (c.getY() >= 3523) {
					container.stop();
				} else if (c.getX() <= 2998) {
					container.stop();
				}
			}

			@Override
			public void stop() {
				setAnimationBack(c);
				c.turnPlayerTo(c.objectX, c.objectY);
				c.stopPlayerPacket = false;
			}
		}, 1);
		/*CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				//movePlayer(c, c.getX(), c.getY() + AMOUNT_TO_MOVE);
				if (c.getY() <= 3523) {
					container.stop();
				} else if (c.getX() <= 2998) {
					container.stop();
				}
			}

			@Override
			public void stop() {
				setAnimationBack(c);
				c.stopPlayerPacket = false;
			}
		}, 2);*/
	}

	public static void wildernessDitchLeave(final Client c) {
		isRunning = c.isRunning2;
		c.setForceMovement(c.getX(), 3520, 0, 10, "SOUTH", EMOTE);
		if (c.stopPlayerPacket) {
			return;
		}
		c.stopPlayerPacket = true;
		//c.startAnimation(EMOTE);
		CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				if (c.getY() <= 3520) {
					container.stop();
				} else if (c.getX() <= 2995) {
					container.stop();
				}
			}

			@Override
			public void stop() {
				setAnimationBack(c);
				c.turnPlayerTo(c.objectX, c.objectY);
				c.stopPlayerPacket = false;
			}
		}, 1);
		/*CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				//movePlayer(c, c.getX(), c.getY() - AMOUNT_TO_MOVE);
				if (c.getY() <= 3523) {
					container.stop();
				} else if (c.getX() <= 2995) {
					container.stop();
				}
			}

			@Override
			public void stop() {
				setAnimationBack(c);
				c.stopPlayerPacket = false;
			}
		}, 2);*/
	}
}