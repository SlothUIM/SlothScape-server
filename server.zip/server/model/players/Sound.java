package server.model.players;

public class Sound {

	//TODO : Implement more sounds...
	public static enum SOUND_LIST {
		/**
		 * Objects
		 */
		TREE_CUT_BEGIN(471),
		TREE_CUTTING(472),
		TREE_EMPTY(473),
		DOOR(324),
		GATE(325),
		DOUBLEDOOR(326),
		CHESTOPEN(319),
		RAKE_WEEDS(1323),
		SMITHING_ANVIL(468),
		MINING_ORE(1331),
		SMELTING_ORE(469),
		PROSPECTING(431),
		RUNECRAFTING(481),
		FILLCONTAINER(371),
		COOK_ITEM(357),
		SLASH_WEB(237),
		JUMPING_STONES(455),
		 
		/*
		 * Miscellaneous sounds.
		 */
		FOOD_EAT(317),
		TWOHAND_SLASH(425),
		TWOHAND_STAB(426),
		TWOHAND_CRUSH(427),
		TWOHAND_BLOCK(428),
		GEM_CUT(464),
		ITEM_DROP(376),
		ITEM_COOK(357),
		ITEM_PICKUP(358),
		ARROW_SHOOT(370),
		TELEPORT(202),
		HERBMIX(372),
		PESTLE_MOTAR(373),
		BONE_BURY(380),
		POTION_DRINK(334),
		FIRE_LIGHT(375),
		FIRE_SUCCESSFUL(608),
		FIRST_ATTEMPT(2584),
		LOG_FLETCH(375),
		DEATH(373),
		STUNNED(458),
		/**
		 * Prayer
		 */
		 
		PROTECT_MELEE(433),
		PROTECT_MAGIC(438),
		PROTECT_RANGE(444),
		NO_PRAY(435),
		PRAYER_TO_LOW(447),
		/**
		 * Magic
		 */
		TELEGRAB(200),
		EARTH_BOLT(1002),
		EARTH_STRIKE(1003),
		EARTH_BOLT_HIT(1004),
		EARTH_BLAST_HIT(1005),
		EARTH_STRIKE_HIT(1006),
		EARTH_WAVE_HIT(1008),
		WEAKEN(1011),
		BIND(996),
		SNARE(1012),
		ENTANGLE(1013),
		ALCHEMY_LOW(224),
		ALCHEMY_HIGH(223),
		BLITZ_ICE(1110),
		
		/*
		 * Weapons
		 */
		ATTACK_WHIP(4151, 1080),
		SPECIAL_WHIP(4151, 1081),
		ATTACK_FLAIL(4755, 1059),
		ATTACK_GMAUL(4153, 1079),
		ATTACK_DDS(5698, 793),
		SPECIAL_DDS(5698, 385),
		ATTACK_DLONG(1305, 396),
		SPECIAL_DLONG(390),
		SPEAR_ATTACK(394),
		SPEAR_ATTACK2(395),
		ATTACK_SCIMITAR(396),
		ATTACK_SCIMITAR2(397),
		ATTACK_LUNGE(398),
		ATTACK_BAXE(399),
		ATTACK_BAXE2(400),
		ATTACK_DAGGER(401),
		ATTACK_DAGGER2(402),
		ATTACK_DAGGER3(403),
		ATTACK_HALBERD(420),
		ATTACK_HAMMERS(4747, 1062),
		ATTACK_GREATAXE_SLASH(4718, 1057),
		SPECIAL_BOW(386),
		SHOOT_BOW(370),
		SPECIAL_DBA(1377, 389),
		SPECIAL_DSPEAR(1249, 388),
		SPECIAL_MACE(1434, 387),
		SPECIAL_MAUL(4153, 1082),
		EXCALIBUR_SPECIAL(384),
		SHIELD_BLOCK(791);
		public int weapon, weaponSound, sound;
		
		SOUND_LIST(int weapon, int weaponSound) {
			this.weapon = weapon;
			this.weaponSound = weaponSound;
		}

		SOUND_LIST(int sound) {
			this.sound = sound;
		}

		public int getSound() {
			return sound;
		}

		public int getWeaponSound(int weapon) {
			if (weapon == this.weapon)
				return weaponSound;
			else
				return sound;
		}
	}

}