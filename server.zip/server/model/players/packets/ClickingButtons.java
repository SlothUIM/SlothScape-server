package server.model.players.packets;

import server.Config;
import server.Server;
import server.model.items.GameItem;
import server.model.players.Client;
import server.model.players.Music;
import server.model.players.skills.*;
import server.model.players.skills.cooking.*;
import server.model.players.quests.*;
import server.model.players.*;
import server.model.players.PacketType;
import server.model.players.PlayerHandler;
import server.util.Misc;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.players.PriceChecker;
import server.model.minigames.GnomeGlider;
/**
 * Clicking most buttons
 **/
public class ClickingButtons implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int actionButtonId = Misc.hexToInt(c.getInStream().buffer, 0,
				packetSize);
		// int actionButtonId = c.getInStream().readShort();
		int currentConfigValue = 0; // Initialize with a default value of 0
		int currentConfigValue1 = 0; // Initialize with a default value of 0
		GnomeGlider.flightButtons(c, actionButtonId);
		QuestAssistant.questButtons(c, actionButtonId);
		DialogueOptions.handleDialogueOptions(c, actionButtonId);
		//Smelting.getBar(c, actionButtonId);
			 int actionButtonId2 = c.getInStream().readUnsignedWord();
		if (c.isDead)
			return;
		if (c.playerRights == 3){
			Misc.println(c.playerName + " - actionbutton: " + actionButtonId);
			Misc.println(c.playerName + " - actionbutton2: " + actionButtonId2);
			c.sendMessage("actionbutton: " + actionButtonId);
			c.sendMessage("actionbutton-realID: " + actionButtonId2);
		}
		/*if(actionButtonId >= 16196 && actionButtonId <= 16254) {
			int songId = actionButtonId - 16186;
				c.MusicOn = true;
				c.RegionMusicOn = false;
				c.lastSong = songId;
				c.getPA().sendSong(songId);
		}*/
		/**if(actionButtonId >= 195079 && actionButtonId <= 195182) {
				int favedSongId = actionButtonId - 195078;
				for(int p = 0; p < songNames.length; p++){
					c.favedSong[0] = favedSongId;
					c.songName[p] = c.songNames[p];
				}
		}*/
		//favorite buttons for each song
		if (actionButtonId >= 195180 && actionButtonId <= 195255) {
			int songId = actionButtonId - 195175;
			int songId2 = actionButtonId - 195180;
				int FavSongId = 0;
			if (Music.favoriteSongIds.contains(songId) && songId2 <= Music.favoriteSongIds.size())
				FavSongId = Music.favoriteSongIds.get(songId2);
			int configId = 799+(actionButtonId-195179);
			// Toggle the config value between 1 and 0
			String songName = Music.CITY_MUSIC.getSongNameById(songId);
			String formatSongName = Music.CITY_MUSIC.formatSongName(songName);
			String songName2 = Music.CITY_MUSIC.getSongNameById(FavSongId);
			String formatSongName2 = Music.CITY_MUSIC.formatSongName(songName2); // Get the song name from the enum
			if(!c.onPlaylist && (Music.isSongUnlocked(songId) || c.playerRights >= 3)){
				if (!Music.favoriteSongIds.contains(songId)) {
					c.sendMessage("You have added: "+ formatSongName + " to your favourites playlist.");
					Music.addToFavorites(songId, formatSongName); // Add the song name to the favorites if it doesn't exist
					currentConfigValue = 1;
				} else {
					c.sendMessage("You have removed: "+ formatSongName + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName); // Add the song name to the favorites if it doesn't exist
					currentConfigValue = 0;
				}
			} else if(c.onPlaylist){ 
				if (Music.favoriteSongIds.contains(songId)) {
					currentConfigValue = 0;
					c.sendMessage("You have removed: "+ formatSongName2 + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName2); // Add the song name to the favorites if it doesn't exist
					Music.refreshPlaylist(c, true);
				}	
			} else if(!Music.isSongUnlocked(songId)){
					currentConfigValue = 0;
					c.sendMessage("You have not unlocked " + formatSongName + ".");
					c.getPA().sendFrame36(configId, 0);//currentConfigValue = 1 for - sprite, 0 for + sprite
					return;
			}
				//Music.refreshConfigs(c, configId);
					c.getPA().sendFrame36(configId, currentConfigValue);
		}		
		if (actionButtonId >= 196000 && actionButtonId <= 196255) {
			int SongId = actionButtonId - 195919;
			//int FavSongId = Music.favoriteSongIds.get(SongId);
			int configId = 799+(actionButtonId-195923);
			// Toggle the config value between 1 and 0
			String songName = Music.CITY_MUSIC.getSongNameById(SongId);
			String formatSongName = Music.CITY_MUSIC.formatSongName(songName); // Get the song name from the enum
			if(!c.onPlaylist){
				if (!Music.favoriteSongNames.contains(formatSongName)) {
					c.sendMessage("You have added: "+ formatSongName + " to your favourites playlist.");
					Music.addToFavorites(SongId, formatSongName); // Add the song name to the favorites if it doesn't exist
					currentConfigValue = 1;
				} else {
					c.sendMessage("You have removed: "+ formatSongName + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName); // Add the song name to the favorites if it doesn't exist
					currentConfigValue = 0;
				}		
			} else {
				if (Music.favoriteSongNames.contains(formatSongName)) {
					currentConfigValue = 0;
					c.sendMessage("You have removed: "+ formatSongName + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName); // Add the song name to the favorites if it doesn't exist
					Music.refreshPlaylist(c, c.onPlaylist);
				}	
			}
					c.getPA().sendFrame36(configId, currentConfigValue);
				//Music.refreshConfigs(c, configId);
			//c.getPA().sendFrame36(configId, currentConfigValue);//currentConfigValue = 1 for - sprite, 0 for + sprite
		}
		if (actionButtonId >= 197000 && actionButtonId <= 197035) {
			int songId = actionButtonId - 196780;
			int configId = 799+(actionButtonId-196923);
			// Toggle the config value between 1 and 0
			String songName = Music.CITY_MUSIC.getSongNameById(songId);
			String formatSongName = Music.CITY_MUSIC.formatSongName(songName); // Get the song name from the enum
			if(!c.onPlaylist){
				if (!Music.favoriteSongNames.contains(formatSongName)) {
					currentConfigValue = 1;
					c.sendMessage("You have added: "+ formatSongName + " to your favourites playlist.");
					Music.addToFavorites(songId, formatSongName); // Add the song name to the favorites if it doesn't exist
				} else {
					currentConfigValue = 0;
					c.sendMessage("You have removed: "+ formatSongName + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName); // Add the song name to the favorites if it doesn't exist
				}
				} else {
			if (Music.favoriteSongNames.contains(formatSongName)) {
					currentConfigValue = 0;
					c.sendMessage("You have removed: "+ formatSongName + " to your favourites playlist.");
					Music.removeFromFavorites(formatSongName); // Add the song name to the favorites if it doesn't exist
					Music.refreshPlaylist(c, c.onPlaylist);
				}	
			}
					c.getPA().sendFrame36(configId, currentConfigValue);
		}
					boolean someCondition = true; // Replace this with your actual condition
			if (actionButtonId >= 197041 && actionButtonId <= 197255) {
				Music.CITY_MUSIC selectedCityMusic = Music.CITY_MUSIC.getByActionButtonId(actionButtonId-5);

				if (selectedCityMusic != null) {
					if (c.onPlaylist && Music.favoriteSongIds.contains(selectedCityMusic.getMusic())) {
						int favSongId = selectedCityMusic.getMusic();
						Music.playSong(c, favSongId, true, false);
					} else {
						Music.playSong(c, selectedCityMusic.getMusic(), true, false);
					}
				}
			}

		if (actionButtonId >= 198000 && actionButtonId <= 198152) {
					Music.playSong(c, actionButtonId-197785, true, false);
		}
		if (actionButtonId > 97000 && actionButtonId <= 97231) {
			int maxVolume = 100;  // Maximum volume percentage
			int minId = 96999;    // Minimum actionButtonId in the range
			int maxId = 97231;    // Maximum actionButtonId in the range
			
			// Calculate the volume as a percentage based on the actionButtonId
			int volume = (actionButtonId - minId) * maxVolume / (maxId - minId);
			
			c.getPA().sendFrame36(168, 0);
			c.getPA().sendFrame126("Music volume: " + volume + "%", 25819);
		} else if(actionButtonId == 97000) {
			c.getPA().sendFrame36(168, 1);
			c.getPA().sendFrame126("Music volume: Muted", 25819);
		}

		if (actionButtonId2 > 23765 && actionButtonId2 <= 24134) {
			int maxVolume = 100;  // Maximum volume percentage
			int minId = 23765;    // Minimum actionButtonId in the range
			int maxId = 24134;    // Maximum actionButtonId in the range
			
			// Calculate the volume as a percentage based on the actionButtonId
			int volume2 = (actionButtonId2 - minId) * maxVolume / (maxId - minId);
			
			c.getPA().sendFrame36(169, 0);
			c.getPA().sendFrame126("Effect volume: " + volume2 + "%", 25820);
		} else if(actionButtonId2 == 23765) {
			c.getPA().sendFrame36(169, 1);
			c.getPA().sendFrame126("Effect volume: Muted", 25820);
		}
		switch(actionButtonId2) {
			/*case 28960:
				c.attackOptions = false;
				c.getPA().sendFrame36(134, 0);
			break;
			case 28961:
				c.attackOptions = true;
				c.getPA().sendFrame36(134, 1);
			break;*/
			case 55814:
			boolean toggle = true;
				toggle = !toggle;
				c.getPA().sendFrame36(195, toggle ? 2 : 0);
			break;
			case 37853:
				c.hideRoofs = !c.hideRoofs;
				//c.getPA().sendFrame36(356, c.hideRoofs ? 1 : 0); // Display + sprite for songs not in the playlist
			break;
			case 37854:
			c.ScrollWheel = !c.ScrollWheel;
				//c.getPA().sendFrame36(213, c.ScrollWheel ? 1 : 0); // Display + sprite for songs not in the playlist
			break;
			case 28932:
			c.transChat = !c.transChat;
				//c.getPA().sendFrame36(214, c.transChat ? 1 : 0); 
			break;
			case 28946:
			c.smoothshading = !c.smoothshading;
				//c.getPA().sendFrame36(215, c.smoothshading ? 1 : 0); 
			break;
			case 29000:
			c.fogToggle = !c.fogToggle;
				//c.getPA().sendFrame36(216, c.fogToggle ? 0 : 1); 
			break;
			case 29001:
			c.dataorbs = !c.dataorbs;
				//c.getPA().sendFrame36(217, c.dataorbs ? 1 : 0); 
			break;
			case 37855:
				c.toggle = !c.toggle;
				c.getPA().sendFrame126("Show @whi@" + (c.toggle ? "less": "more") + " @or1@information", 29891);
			break;
		}
		switch (actionButtonId) {
			case 71071:// closebutton
			c.getPA().removeAllWindows();
			if (c.xInterfaceId == 43933 || c.isChecking) {
				PriceChecker.clearConfig(c);
			}
			break;
			case 59141:// Price checker
			if (System.currentTimeMillis() - c.logoutDelay > 10000) {
				PriceChecker.open(c);
				c.isBanking = false;
				} else {
				c.sendMessage("I can't open this in combat..");
			}
			break;
						case 24130://pause
							c.MusicOn = false;
							c.RegionMusicOn = false;
							c.lastSong = -1;//load favorites playlist button
							Music.refreshPlaylist(c, false);
							c.getPA().musicManager("STOP", -1);
							break;
							case 24128://play
							if(c.lastSong > 0){
								Music.playSong(c, c.lastSong, true, false);
							}else{
							int songId = Misc.random(372);
								Music.playSong(c, songId, false, true);
							}
							Music.refreshPlaylist(c, false);
							break;
						case 24125://shuffle
							c.MusicOn = true;
							c.RegionMusicOn = false;
							c.lastSong = Misc.random(372);
							Music.refreshPlaylist(c, false);
							break;
					case 24126://load favorites playlist button//also could be search in future
							c.onPlaylist = !c.onPlaylist;
							//for (int i = 0; i < 373; i++) {
								//c.getPA().sendFrame126("", 50473 + i);
							//}
					if(!c.onPlaylist) {
						if (Music.favoriteSongIds.size() != 0) {
							c.MusicOn = true;
							c.RegionMusicOn = false;
							c.lastSong = Music.favoriteSongIds.get(0);//load favorites playlist button
						}
						Music.setText(c, Music.favoriteSongIds.size());
					} else if(c.onPlaylist) {
						if (Music.unlockedSongIds.size() != 0) {
							c.MusicOn = false;
							c.RegionMusicOn = true;
							c.lastSong = -1;//load favorites playlist button
						}
						Music.setText(c, Music.unlockedSongIds.size());
					}
							Music.refreshPlaylist(c, c.onPlaylist);
					break;
			//Slayer rewards buttons
			//Extend buttons
		case 185247://need more darkness
					if(c.slayerPoints >= 100 && !c.extend[0]){
					c.getPA().sendFrame126("Need more Darkness" , 47907);
					c.getPA().sendFrame126("Whenever you get a Dark Beast" , 47908);
					c.getPA().sendFrame126("task, it will be a bigger task." , 47909);
					c.getPA().sendFrame126("" , 47910);
					c.getPA().sendFrame126("@red@Cost: 100 points" , 47917);
					c.getPA().sendFrame126("If you turn this off in the future, you" , 47911);
					c.getPA().sendFrame126("will not get your points back." , 47912);
					c.getPA().showInterface(47900);
					c.dialogueId = 47600;
					c.dialogueAction = 185247;
					} else if(c.extend[0]){
						c.extend[0] = false;
					}
			break;
			case 225176:
					c.getPA().sendFrame126("General shop" , 18085);
					c.getPA().sendFrame126("Sword shop" , 17650);
					c.getPA().sendFrame126("Magic shop" , 17651);
					c.getPA().sendFrame126("Battle-axe shop" , 17652);
					c.getPA().sendFrame126("Helmet shop" , 17653);
					c.getPA().sendFrame126("Bank" , 17654);
					c.getPA().sendFrame126("Quest start" , 17655);
					c.getPA().sendFrame126("Amulet shop" , 17656);
					c.getPA().sendFrame126("Mine" , 17657);
					c.getPA().sendFrame126("Furnace" , 17658);
					c.getPA().sendFrame126("Anvil" , 17659);
					c.getPA().sendFrame126("Combat training" , 17660);
					c.getPA().sendFrame126("Dungeon entrance" , 17661);
					c.getPA().sendFrame126("Staff shop" , 17662);
					c.getPA().sendFrame126("Platebody shop" , 17663);
					c.getPA().sendFrame126("Platelegs shop" , 17664);
					c.getPA().sendFrame126("Scimitar shop" , 17665);
					c.getPA().sendFrame126("Range shop" , 17666);
					c.getPA().sendFrame126("Shield shop" , 17667);
					c.getPA().sendFrame126("Altar" , 17668);
					c.getPA().sendFrame126("Herblore shop" , 17669);
					c.getPA().sendFrame126("Jewelry shop" , 17670);
					c.getPA().sendFrame126("Gem shop" , 17671);
					c.getPA().sendFrame126("Crafting shop" , 17672);
					c.getPA().sendFrame126("Candle shop" , 17673);
					c.getPA().sendFrame126("Fishing shop" , 17674);
					c.getPA().sendFrame126("Fishing Spot" , 47675);
					c.getPA().sendFrame126("Clothes shop" , 47676);
					c.getPA().sendFrame126("Apothecary" , 47677);
					c.getPA().sendFrame126("Silk trader" , 47678);
					c.getPA().sendFrame126("shop" , 47679);
					c.getPA().sendFrame126("Pub/Bar" , 47680);
					c.getPA().sendFrame126("Mace shop" , 47681);
					c.getPA().sendFrame126("Tannery" , 47682);
					c.getPA().sendFrame126("Rare trees" , 47683);
					c.getPA().sendFrame126("Spinning wheel" , 47684);
					c.getPA().sendFrame126("Food shop" , 47685);
					c.getPA().sendFrame126("Cookery shop" , 47686);
					c.getPA().sendFrame126("Minigame" , 47687);
					c.getPA().sendFrame126("Water source" , 47688);
					c.getPA().sendFrame126("Cooking range" , 47689);
					c.getPA().sendFrame126("Plateskirt shop" , 47690);
					c.getPA().sendFrame126("Potters wheel" , 47691);
					c.getPA().sendFrame126("Windmill" , 47692);
					c.getPA().sendFrame126("Crossbow shop" , 47693);
					c.getPA().sendFrame126("Chainbody shop" , 47694);
					c.getPA().sendFrame126("Silver shop" , 47695);
					/*c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);
					c.getPA().sendFrame126("Silver shop" , 67695);*/
					c.getPA().showInterface(18070);
					//c.getPA().walkableInterface(18070);
											
			break;
			case 190170:
			if(c.slayerPoints >= 30 && c.slayerTask > 0){
								c.slayerPoints -= 30;
								c.slayerTask = 0;
								c.taskAmount = 0;
			}
			break;
			
			case 218009:
					c.CollectionLog = 1;
					c.getCollectionLog().openCollectionLog(c.getCollectionLog().sireCollectionLog);
					c.getPA().sendFrame126("Abyssal Sire" , 35703);
					c.getPA().sendFrame126("Obtained: @whi@0/2", 35705);
					c.getPA().sendFrame126("Abyssal Sire kills: 0" , 35706);
					c.getPA().sendFrame126("" , 35704);
					c.getPA().sendFrame126("" , 35707);
					c.getCollectionLog().openLog(0);
					c.getPA().showInterface(35700);
			break;
			case 139130:
					c.CollectionLog = 1;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().sireCollectionLog);
						c.getPA().sendFrame126("Abyssal Sire" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Sire")+ "/2", 35705);
						c.getPA().sendFrame126("Abyssal Sire kills: 0" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().BeginnerCollectionLog);
						c.getPA().sendFrame126("Beginner Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("BeginnerClue")+ "/"+c.getCollectionLog().BeginnerCollectionLog.length, 35705);
						c.getPA().sendFrame126("Beginner clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						//c.getCollectionLog().openCollectionLog(c.getCollectionLog().EasyClueCollectionLog);
						c.getPA().sendFrame126("Aerial Fishing" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@0/85", 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
			break;
			case 139131:
					c.CollectionLog = 2;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().barrowsCollectionLog);
						c.getPA().sendFrame126("Barrows Chests" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Barrows")+ "/"+c.getCollectionLog().barrowsCollectionLog.length, 35705);
						c.getPA().sendFrame126("Barrows Chests opened: "+c.BarrowsKC , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().EasyClueCollectionLog);
						c.getPA().sendFrame126("Easy Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("EasyClue")+ "/"+c.getCollectionLog().EasyClueCollectionLog.length, 35705);
						c.getPA().sendFrame126("Easy clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().PetCollectionLog);
						c.getPA().sendFrame126("All pets" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("pets")+ "/18", 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
					
					case 105222:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(0, 0, true);
					break;
					case 105223:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(8, 0, true);
					break;
					case 105225:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(1, 0, true);
					break;
					case 105228:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(2, 0, true);
					break;
					case 105233:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(19, 0, true);
					break;
					case 105234:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(4, 0, true);
					break;
					case 105237:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(5, 0, true);
					break;
					case 105240:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(6, 0, true);
					break;
					case 105243:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(7, 0, true);
					break;
					case 105231:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(3, 0, true);
					break;
					case 105229:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(10, 0, true);
					break;
					case 105238:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(13, 0, true);
					break;
					case 105242:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(22, 0, true);
					break;
					case 34014:
					c.getSkillGuide().clearInterface();
					c.getPA().closeAllWindows();
					break;
					case 34119:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 0, true);
					break;
					case 34120:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 1, true);
					break;
					case 34121:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 2, true);
					break;
					case 34122:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 3, true);
					break;
					case 34123:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 4, true);
					break;
					case 34124:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 5, true);
					break;
					case 34125:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 6, true);
					break;
					case 34126:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 7, true);
					break;
					case 34127:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 8, true);
					break;
					case 34128:
					c.getSkillGuide().clearInterface();
					c.getSkillGuide().LoadMainInterface(c.getSkillGuide().skillid, 9, true);
					break;
			case 139132:
					c.CollectionLog = 3;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().bryophytaCollectionLog);
						c.getPA().sendFrame126("Bryophyta Chests" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@", 35705);
						c.getPA().sendFrame126("Bryophyta Chests opened: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().MediumClueCollectionLog);
						c.getPA().sendFrame126("Medium Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("MediumClue")+ "/69", 35705);
						c.getPA().sendFrame126("Medium clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139133:
					c.CollectionLog = 4;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().callistoCollectionLog);
						c.getPA().sendFrame126("Callisto" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"/*+ c.getCollectionLog().getCollectionTotalAmount("Callisto")+ "/25"*/, 35705);
						c.getPA().sendFrame126("Callisto kills: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().HardClueCollectionLog);
						c.getPA().sendFrame126("Hard Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("HardClue")+ "/74", 35705);
						c.getPA().sendFrame126("Hard clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139134:
					c.CollectionLog = 5;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().cerberusCollectionLog);
						c.getPA().sendFrame126("Cerberus" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Cerberus")+ "/4", 35705);
						c.getPA().sendFrame126("Cerberus kills: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().EliteClueCollectionLog);
						c.getPA().sendFrame126("Elite Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("EliteClue")+ "/"+c.getCollectionLog().EliteClueCollectionLog.length, 35705);
						c.getPA().sendFrame126("Elite clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().ChompyCollectionLog);
						c.getPA().sendFrame126("Chompy Bird Hunting" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("chompy")+ "/18", 35705);
						c.getPA().sendFrame126("Chompy's killed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139135:
					c.CollectionLog = 6;
					if(c.CollLogOpen == 0) {
					c.getCollectionLog().openCollectionLog(c.getCollectionLog().eleCollectionLog);
					c.getPA().sendFrame126("Chaos Elemental" , 35703);
					c.getPA().sendFrame126("Obtained: @whi@0/3", 35705);
					c.getPA().sendFrame126("Chaos Elemental kills: 0" , 35706);
					c.getPA().sendFrame126("" , 35704);
					c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().EliteClueCollectionLog);
						c.getPA().sendFrame126("Master Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("MasterClue")+ "/14", 35705);
						c.getPA().sendFrame126("Master clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().CreatureCreationCollectionLog);
						c.getPA().sendFrame126("Creature Creation" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("creation")+ "/18", 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
			break;
			
			case 3071:
			if(c.bookPage == 2){
				c.getPA().sendFrame126("Book of the elemental shield", 903);
				c.getPA().sendFrame126("Within the pages of this", 843);
				c.getPA().sendFrame126("book you will find the", 844);
				c.getPA().sendFrame126("secret to working the", 845);
				c.getPA().sendFrame126("very elements themselves.", 846);
				c.getPA().sendFrame126("Early in the fifth age, a", 847);
				c.getPA().sendFrame126("new ore was discovered.", 848);
				c.getPA().sendFrame126("This ore has a unique", 849);
				c.getPA().sendFrame126("property of absorbing,", 850);
				c.getPA().sendFrame126("transforming or focusing ", 851);
				c.getPA().sendFrame126("elemental energy. A", 852);
				c.getPA().sendFrame126("workshop was erected", 853);
				c.getPA().sendFrame126("close by to work this new", 854);
				c.getPA().sendFrame126("material. The workshop", 855);
				c.getPA().sendFrame126("was set up for artisans", 856);
				c.getPA().sendFrame126("and inventors to be able", 857);
				c.getPA().sendFrame126("to come and create", 858);
				c.getPA().sendFrame126("devices made from the", 859);
				c.getPA().sendFrame126("unique ore, found only in.", 860);
				c.getPA().sendFrame126("the village of the Seers.", 861);
				c.getPA().sendFrame126("", 862);
				c.getPA().sendFrame126("", 863);
				c.getPA().sendFrame126("", 864);
				c.getPA().sendFrame126("", 14165);
				c.getPA().sendFrame126("", 14166);
				c.getPA().sendFrame126("", 839);
				c.getPA().sendFrame126("", 841);
				c.getPA().showInterface(837);
				c.sendMessage("You flip the page.");
				//c.EleWorkShop = 2;
				c.bookPage = 1;
			}
			break;
			case 39178:
				c.getPA().removeAllWindows();
				c.bookPage = 0;
				for(int i = 843; i < 841; i++)
					c.getPA().sendFrame126("", i);
			break;	
			case 3073:
			if(c.bookPage == 1){
				c.getPA().sendFrame126("Book of the elemental shield", 903);
				c.getPA().sendFrame126("After some time of", 843);
				c.getPA().sendFrame126("successful industry the", 844);
				c.getPA().sendFrame126("true power of this ore", 845);
				c.getPA().sendFrame126("became apparent, as", 846);
				c.getPA().sendFrame126("greater and more", 847);
				c.getPA().sendFrame126("powerful weapons were", 848);
				c.getPA().sendFrame126("created. realising the", 849);
				c.getPA().sendFrame126("threat this posed, the magi", 850);
				c.getPA().sendFrame126("of the time closed down", 851);
				c.getPA().sendFrame126("the workshop and bound", 852);
				c.getPA().sendFrame126("it under lock and key,", 853);
				c.getPA().sendFrame126("also trying to destroy all", 854);
				c.getPA().sendFrame126("Knowledge of", 855);
				c.getPA().sendFrame126("manufacturing processes.", 856);
				c.getPA().sendFrame126("Yet this book remains and", 857);
				c.getPA().sendFrame126("you may still find a way", 858);
				c.getPA().sendFrame126("to enter the workshop", 859);
				c.getPA().sendFrame126("within this leather bound", 860);
				c.getPA().sendFrame126("volume.", 861);
				c.getPA().sendFrame126("", 862);
				c.getPA().sendFrame126("", 863);
				c.getPA().sendFrame126("", 864);
				c.getPA().sendFrame126("", 14165);
				c.getPA().sendFrame126("", 14166);
				c.getPA().sendFrame126("", 839);
				c.getPA().sendFrame126("", 841);
				c.getPA().showInterface(837);
				c.sendMessage("You flip the page.");
				c.EleWorkShop = 2;
				c.bookPage = 2;
			}
			break;
			case 139136:
					c.CollectionLog = 7;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().fanaticCollectionLog);
						c.getPA().sendFrame126("Chaos Fanatic" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Fanatic")+ "/3", 35705);
						c.getPA().sendFrame126("Chaos Fanatic kills: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().EliteClueCollectionLog);
						c.getPA().sendFrame126("Hard Treasure Trails(Rare)" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("EliteRareClue")+ "/74", 35705);
						c.getPA().sendFrame126("Hard clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().CyclopesCollectionLog);
						c.getPA().sendFrame126("Cyclopes" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Cyclopes")+ "/8", 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139137:
					c.CollectionLog = 8;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().saraCollectionLog);
						c.getPA().sendFrame126("Commander Zilyana" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Sara")+ "/"+c.getCollectionLog().saraCollectionLog.length, 35705);
						c.getPA().sendFrame126("Commander Zilyana kills: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().EliteClueCollectionLog);
						c.getPA().sendFrame126("Elite Treasure Trails(Rare)" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("EliteRareClue")+ "/"+c.getCollectionLog().EliteClueCollectionLog.length, 35705);
						c.getPA().sendFrame126("Elite clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().MiscCollectionLog);
						c.getPA().sendFrame126("Miscellaneous" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Misc")+ "/74", 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
					case 213173:
						c.getAD().updateAchievementInterface("Ardougne");
						break;
					case 213183:
						c.getAD().updateAchievementInterface("Desert");
						break;
					case 213193:
						c.getAD().updateAchievementInterface("Falador");
						break;
					case 213203:
						c.getAD().updateAchievementInterface("Fremennik");
						break;
					case 213213:
						c.getAD().updateAchievementInterface("Kandarin");
						break;
					case 213223:
						c.getAD().updateAchievementInterface("Karamja");
						break;
					case 213233:
						c.getAD().updateAchievementInterface("Kourend");
						break;
					case 213243:
						c.getAD().updateAchievementInterface("Lumbridge&Draynor");
						break;
					case 213253:
						c.getAD().updateAchievementInterface("Morytania");
						break;
					case 214007:
						c.getAD().updateAchievementInterface("Varrock");
						break;
					case 214017:
						c.getAD().updateAchievementInterface("WesternProvinces");
						break;
					case 214027:
						c.getAD().updateAchievementInterface("Wilderness");
						break;
						/*case 218008:
						c.getPA().sendSong(169);
						break;*/
			case 139138:
					c.CollectionLog = 9;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().corpCollectionLog);
						c.getPA().sendFrame126("Corporeal Beast" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Corp")+ "/"+c.getCollectionLog().corpCollectionLog.length, 35705);
						c.getPA().sendFrame126("Corporeal Beast kills: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().MasterRareClueCollectionLog);
						c.getPA().sendFrame126("Master Treasure Trails(Rare)" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("MasterRareClue")+ "/24", 35705);
						c.getPA().sendFrame126("Master clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 4) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().RandomEventCollectionLog);
						c.getPA().sendFrame126("Random Events" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("RandomEvent")+ "/"+c.getCollectionLog().RandomEventCollectionLog.length, 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139139:
					c.CollectionLog = 10;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().DGKCollectionLog);
						c.getPA().sendFrame126("Dagannoth Kings" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("DGK")+ "/"+c.getCollectionLog().DGKCollectionLog.length, 35704);
						c.getPA().sendFrame126("Dagannoth Prime kills: " , 35705);
						c.getPA().sendFrame126("Dagannoth Rex kills: " , 35706);
						c.getPA().sendFrame126("Dagannoth Supreme kills: " , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().SharedClueCollectionLog);
						c.getPA().sendFrame126("Shared Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("SharedClue")+ "/24", 35705);
						c.getPA().sendFrame126("Total clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139140:
					c.CollectionLog = 11;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().fightCavesCollectionLog);
						c.getPA().sendFrame126("The Fight Caves" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("fightCaves")+ "/3", 35704);
						c.getPA().sendFrame126("Fight Caves Completions: " , 35705);
						c.getPA().sendFrame126("" , 35706);
						c.getPA().sendFrame126("" , 35707);
					} else if(c.CollLogOpen == 2) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().SharedClueCollectionLog);
						c.getPA().sendFrame126("Shared Treasure Trails" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("SharedClue")+ "/24", 35705);
						c.getPA().sendFrame126("Total clues completed: " , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139141:
					c.CollectionLog = 12;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().bandosCollectionLog);
						c.getPA().sendFrame126("General Graardor" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("General Graardor")+ "/"+c.getCollectionLog().bandosCollectionLog.length, 35705);
						c.getPA().sendFrame126("General Graardor kills: "+c.CollLog[0][1] , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139144:
					c.CollectionLog = 15;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().KBDCollectionLog);
						c.getPA().sendFrame126("King Black Dragon" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("King Black Dragon")+ "/"+c.getCollectionLog().KBDCollectionLog.length, 35705);
						c.getPA().sendFrame126("King Black Dragon kills: "+c.CollLog[0][1] , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139145:
					c.CollectionLog = 16;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().krakenCollectionLog);
						c.getPA().sendFrame126("Kraken" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Kraken")+ "/"+c.getCollectionLog().krakenCollectionLog.length, 35705);
						c.getPA().sendFrame126("Kraken kills: "+c.CollLog[0][1] , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139146:
					c.CollectionLog = 17;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().armadylCollectionLog);
						c.getPA().sendFrame126("Kree'arra" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("Kree'arra")+ "/"+c.getCollectionLog().armadylCollectionLog.length, 35705);
						c.getPA().sendFrame126("Kree'arra kills: "+c.CollLog[0][1] , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139147:
					c.CollectionLog = 18;
					if(c.CollLogOpen == 0) {
						c.getCollectionLog().openCollectionLog(c.getCollectionLog().zammyCollectionLog);
						c.getPA().sendFrame126("K'ril Tsutsaroth" , 35703);
						c.getPA().sendFrame126("Obtained: @whi@"+ c.getCollectionLog().getCollectionTotalAmount("K'ril Tsutsaroth")+ "/"+c.getCollectionLog().zammyCollectionLog.length, 35705);
						c.getPA().sendFrame126("K'ril Tsutsaroth kills: "+c.CollLog[0][1] , 35706);
						c.getPA().sendFrame126("" , 35704);
						c.getPA().sendFrame126("" , 35707);
					}
					break;
			case 139124: 
					c.getCollectionLog().openLog(0);
					break;
			case 139126: 
					c.getCollectionLog().openLog(2);
			break;
			case 139128: 
					c.getCollectionLog().openLog(4);
			break;
			case 190171:
					c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.slayerTask)+"" , 47907);
					c.getPA().sendFrame126("Your current task will be cancelled, and the" , 47908);
					c.getPA().sendFrame126("Slayer Masters will be blocked from" , 47909);
					c.getPA().sendFrame126("assigning this category to you again." , 47910);
					c.getPA().sendFrame126("@red@Cost: 100 points" , 47917);
					c.getPA().sendFrame126("If you unblock this creature in the future, you" , 47911);
					c.getPA().sendFrame126("will not get your points back." , 47912);
					c.getPA().showInterface(47900);
					c.dialogueId = 47800;
					c.dialogueAction = 190171;
					break;
					case 190172:
					if(c.BlockID[0] > 0) {
								c.alreadyBlocked[0] = false;
								c.BlockID[0] = -1;
					}
					break;
					case 190173:
					if(c.BlockID[1] > 0) {
								c.alreadyBlocked[1] = false;
								c.BlockID[1] = -1;
					}
					break;
					case 190174:
					if(c.BlockID[2] > 0) {
								c.alreadyBlocked[2] = false;
								c.BlockID[2] = -1;
					}
					break;
					case 190175:
					if(c.BlockID[3] > 0) {
								c.alreadyBlocked[3] = false;
								c.BlockID[3] = -1;
					}
					break;
					case 190176:
					if(c.BlockID[4] > 0) {
								c.alreadyBlocked[4] = false;
								c.BlockID[4] = -1;
					}
					break;
					case 190177:
					if(c.BlockID[5] > 0) {
								c.alreadyBlocked[5] = false;
								c.BlockID[5] = -1;
					}
					break;
			case 187033:
					if(c.dialogueId == 47600)
						c.getPA().showInterface(47600);
					if(c.dialogueId == 47700)
						c.getPA().showInterface(47700);
					if(c.dialogueId == 47800)
						c.getPA().showInterface(47800);
					break;
					case 187034://slayer rewards confirm
					if(c.slayerPoints >= 100 && !c.extend[0] && c.dialogueAction == 185247){
						c.extend[0] = true;
						c.getPA().sendFrame36(899, 1);
						c.slayerPoints -= 100;
					}	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && c.slayerTask != 0){
						for(int i = 0; i < 6; i++) {
							if(c.BlockID[i] != c.slayerTask && !c.alreadyBlocked[i]){
								c.alreadyBlocked[i] = true;
								c.BlockID[i] = c.slayerTask;
								c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[i]), 48818+i);
								c.slayerPoints -= 100;
								c.slayerTask = 0;
								c.taskAmount = 0;
							}
						}
					}
					
					if(c.dialogueId == 47800)
						c.getPA().showInterface(47800);/* else 	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && c.alreadyBlocked[1] && c.slayerTask != 0){
						c.alreadyBlocked[1] = true;
						c.BlockID[1] = c.slayerTask;
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[1]), 48819);
						c.slayerPoints -= 100;
						c.slayerTask = 0;
						c.taskAmount = 0;
					}	 else 	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && !c.alreadyBlocked[2] && c.slayerTask != 0){
						c.alreadyBlocked[2] = true;
						c.BlockID[2] = c.slayerTask;
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[2]), 48820);
						c.slayerPoints -= 100;
						c.slayerTask = 0;
						c.taskAmount = 0;
					}	 else 	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && !c.alreadyBlocked[3] && c.slayerTask != 0){
						c.alreadyBlocked[3] = true;
						c.BlockID[3] = c.slayerTask;
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[3]), 48821);
						c.slayerPoints -= 100;
						c.slayerTask = 0;
						c.taskAmount = 0;
					}	 else 	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && !c.alreadyBlocked[4] && c.slayerTask != 0){
						c.alreadyBlocked[4] = true;
						c.BlockID[4] = c.slayerTask;
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[4]), 48822);
						c.slayerPoints -= 100;
						c.slayerTask = 0;
						c.taskAmount = 0;
					}	 else 	
					if(c.slayerPoints >= 100 && c.dialogueAction == 190171 && !c.alreadyBlocked[4] && c.slayerTask != 0){
						c.alreadyBlocked[4] = true;
						c.BlockID[4] = c.slayerTask;
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[4]), 48823);
						c.slayerPoints -= 100;
						c.slayerTask = 0;
						c.taskAmount = 0;
					}	*/
					if(c.dialogueId == 47600)
						c.getPA().showInterface(47600);
					break;
	case 185249://Ankou very much
			if(c.slayerPoints >= 100){
				c.extend[1] = true;
				c.getPA().sendFrame36(900, 1);
				c.slayerPoints -= 100;
			}	
			break;
		case 185251://suq-a-nother one
			if(c.slayerPoints >= 100){
				c.extend[3] = true;
				c.getPA().sendFrame36(901, 1);
				c.slayerPoints -= 100;
			}	
			break;
		case 185253://fire and darkness
			if(c.slayerPoints >= 50 && !c.extend[4]){
				c.extend[4] = true;
				c.getPA().sendFrame36(902, 1);
				c.slayerPoints -= 50;
			}	
			break;
		case 185255://pedal to the metals
			if(c.slayerPoints >= 100){
				c.extend[5] = true;
				c.getPA().sendFrame36(903, 1);
				c.slayerPoints -= 100;
			}	
			break;
		case 185257://need more darkness
			if(c.slayerPoints >= 120){
				c.extend[6] = true;
				c.getPA().sendFrame36(904, 1);
				c.slayerPoints -= 120;
			}	
			break;
			
		case 166206:
			c.setSidebarInterface(3, 3213);
		break;
			case 2048:
				c.getPA().closeAllWindows();
			break;
			case 108201:
			
				c.getPA().showInterface(100);
				break;
				case 107013:
				c.getPA().showInterface(47500);
					break;
				case 107014:
				c.getPA().showInterface(47600);
					break;
				case 107015:
					c.getPA().sendFrame34a(47706, 554, 0, 100);
					c.getPA().sendFrame34a(47706, 554, 1, 100);
					c.getPA().sendFrame34a(47706, 554, 2, 100);
					c.getPA().sendFrame34a(47706, 554, 3, 100);
					c.getPA().sendFrame34a(47706, 554, 4, 100);
				c.getPA().showInterface(47700);
					break;
				case 107016:
				c.getPA().showInterface(47800);
					break;
			case 108184:
			
				c.getPA().showInterface(27841);
				break;
			case 80023:
				c.getPA().showInterface(100);
			break;
		case 118098:
			c.getPA().castVeng();
			break;
		// crafting + fletching interface:
		case 150:
			if (c.autoRet == 0)
				c.autoRet = 1;
			else
				c.autoRet = 0;
			break;

		case 71074:
			if (c.clanId >= 0) {
				if (Server.clanChat.clans[c.clanId].owner
						.equalsIgnoreCase(c.playerName)) {
					Server.clanChat
							.sendLootShareMessage(
									c.clanId,
									"Lootshare has been toggled to "
											+ (!Server.clanChat.clans[c.clanId].lootshare ? "on"
													: "off")
											+ " by the clan leader.");
					Server.clanChat.clans[c.clanId].lootshare = !Server.clanChat.clans[c.clanId].lootshare;
				} else
					c.sendMessage("Only the owner of the clan has the power to do that.");
			}
			break;
		case 34185:
		case 34184:
		case 34183:
		case 34182:
		case 34189:
		case 34188:
		case 34187:
		case 34186:
		case 34193:
		case 34192:
		case 34191:
		case 34190:
		
		case 34205:
		case 34209:
		case 34213:
		case 34217:
		case 34170:
		case 34174:
			if (c.getFletching().fletching)
				c.getFletching().handleFletchingClick(actionButtonId, 1);
			break;
		case 34204:
		case 34208:
		case 34212:
		case 34216:
		case 34169:
		case 34173:
			if (c.getFletching().fletching)
				c.getFletching().handleFletchingClick(actionButtonId, 5);
			break;
		case 34203:
		case 34207:
		case 34211:
		case 34215:
		case 34168:
		case 34172:
			if (c.getFletching().fletching)
				c.getFletching().handleFletchingClick(actionButtonId, 10);
			break;

	
			case 59203:
				c.StartBestItemScan(c);
				c.EquipStatus = 0;
				for (int k = 0; k < 4; k++)
					c.getPA().sendFrame34a(10494, -1, k, 1);
				for (int k = 0; k < 39; k++)
					c.getPA().sendFrame34a(10600, -1, k, 1);
				if(c.WillKeepItem1 > 0)
					c.getPA().sendFrame34a(10494, c.WillKeepItem1, 0, c.WillKeepAmt1);
				if(c.WillKeepItem2 > 0)
					c.getPA().sendFrame34a(10494, c.WillKeepItem2, 1, c.WillKeepAmt2);
				if(c.WillKeepItem3 > 0)
					c.getPA().sendFrame34a(10494, c.WillKeepItem3, 2, c.WillKeepAmt3);
				if(c.WillKeepItem4 > 0 && c.prayerActive[10])
					c.getPA().sendFrame34a(10494, c.WillKeepItem4, 3, 1);
				for(int ITEM = 0; ITEM < 28; ITEM++){
					if(c.playerItems[ITEM]-1 > 0 && !(c.playerItems[ITEM]-1 == c.WillKeepItem1 && ITEM == c.WillKeepItem1Slot)
		 			&& !(c.playerItems[ITEM]-1 == c.WillKeepItem2 && ITEM == c.WillKeepItem2Slot)
		 			&& !(c.playerItems[ITEM]-1 == c.WillKeepItem3 && ITEM == c.WillKeepItem3Slot)
		 			&& !(c.playerItems[ITEM]-1 == c.WillKeepItem4 && ITEM == c.WillKeepItem4Slot)){
						c.getPA().sendFrame34a(10600, c.playerItems[ITEM]-1, c.EquipStatus, c.playerItemsN[ITEM]);
						c.EquipStatus += 1;
					} else if(c.playerItems[ITEM]-1 > 0 && (c.playerItems[ITEM]-1 == c.WillKeepItem1 && ITEM == c.WillKeepItem1Slot) && c.playerItemsN[ITEM] > c.WillKeepAmt1){
						c.getPA().sendFrame34a(10600, c.playerItems[ITEM]-1, c.EquipStatus, c.playerItemsN[ITEM]-c.WillKeepAmt1);
						c.EquipStatus += 1;
					} else if(c.playerItems[ITEM]-1 > 0 && (c.playerItems[ITEM]-1 == c.WillKeepItem2 && ITEM == c.WillKeepItem2Slot) && c.playerItemsN[ITEM] > c.WillKeepAmt2){
						c.getPA().sendFrame34a(10600, c.playerItems[ITEM]-1, c.EquipStatus, c.playerItemsN[ITEM]-c.WillKeepAmt2);
						c.EquipStatus += 1;
					} else if(c.playerItems[ITEM]-1 > 0 && (c.playerItems[ITEM]-1 == c.WillKeepItem3 && ITEM == c.WillKeepItem3Slot) && c.playerItemsN[ITEM] > c.WillKeepAmt3){
						c.getPA().sendFrame34a(10600, c.playerItems[ITEM]-1, c.EquipStatus, c.playerItemsN[ITEM]-c.WillKeepAmt3);
						c.EquipStatus += 1;
					} else if(c.playerItems[ITEM]-1 > 0 && (c.playerItems[ITEM]-1 == c.WillKeepItem4 && ITEM == c.WillKeepItem4Slot) && c.playerItemsN[ITEM] > 1){
						c.getPA().sendFrame34a(10600, c.playerItems[ITEM]-1, c.EquipStatus, c.playerItemsN[ITEM]-1);
						c.EquipStatus += 1;
					}
					}
					for(int EQUIP = 0; EQUIP < 14; EQUIP++){
						if(c.playerEquipment[EQUIP] > 0 && !(c.playerEquipment[EQUIP] == c.WillKeepItem1 && EQUIP+28 == c.WillKeepItem1Slot)
							&& !(c.playerEquipment[EQUIP] == c.WillKeepItem2 && EQUIP+28 == c.WillKeepItem2Slot)
							&& !(c.playerEquipment[EQUIP] == c.WillKeepItem3 && EQUIP+28 == c.WillKeepItem3Slot)
							&& !(c.playerEquipment[EQUIP] == c.WillKeepItem4 && EQUIP+28 == c.WillKeepItem4Slot)){
								c.getPA().sendFrame34a(10600, c.playerEquipment[EQUIP], c.EquipStatus, c.playerEquipmentN[EQUIP]);
								c.EquipStatus += 1;
							} else if(c.playerEquipment[EQUIP] > 0 && (c.playerEquipment[EQUIP] == c.WillKeepItem1 && EQUIP+28 == c.WillKeepItem1Slot) && c.playerEquipmentN[EQUIP] > 1 && c.playerEquipmentN[EQUIP]-c.WillKeepAmt1 > 0){
								c.getPA().sendFrame34a(10600, c.playerEquipment[EQUIP], c.EquipStatus, c.playerEquipmentN[EQUIP]-c.WillKeepAmt1);
								c.EquipStatus += 1;
							} else if(c.playerEquipment[EQUIP] > 0 && (c.playerEquipment[EQUIP] == c.WillKeepItem2 && EQUIP+28 == c.WillKeepItem2Slot) && c.playerEquipmentN[EQUIP] > 1 && c.playerEquipmentN[EQUIP]-c.WillKeepAmt2 > 0){
								c.getPA().sendFrame34a(10600, c.playerEquipment[EQUIP], c.EquipStatus, c.playerEquipmentN[EQUIP]-c.WillKeepAmt2);
								c.EquipStatus += 1;
							} else if(c.playerEquipment[EQUIP] > 0 && (c.playerEquipment[EQUIP] == c.WillKeepItem3 && EQUIP+28 == c.WillKeepItem3Slot) && c.playerEquipmentN[EQUIP] > 1 && c.playerEquipmentN[EQUIP]-c.WillKeepAmt3 > 0){
								c.getPA().sendFrame34a(10600, c.playerEquipment[EQUIP], c.EquipStatus, c.playerEquipmentN[EQUIP]-c.WillKeepAmt3);
								c.EquipStatus += 1;
							} else if(c.playerEquipment[EQUIP] > 0 && (c.playerEquipment[EQUIP] == c.WillKeepItem4 && EQUIP+28 == c.WillKeepItem4Slot) && c.playerEquipmentN[EQUIP] > 1 && c.playerEquipmentN[EQUIP]-1 > 0){
								c.getPA().sendFrame34a(10600, c.playerEquipment[EQUIP], c.EquipStatus, c.playerEquipmentN[EQUIP]-1);
								c.EquipStatus += 1;
						}
					}
			          	c.ResetKeepItems();
						c.getCarriedWealth();
						c.getRiskedWealth();
					c.getPA().showInterface(34400);
					break;
		
		case 59100:
			c.getPA().showInterface(36106);
			c.getItems().writeBonus();
			break;
		case 1204:
			c.setSidebarInterface(11, 904);
			c.getPA().removeAllWindows();
				c.addingToRP = false;
				for (int k = 0; k < 28; k++)
					c.getPA().sendFrame34a(41711, -1, k, 1);
			break;
		
		case 59004:
			c.getPA().removeAllWindows();
			break;

		case 70212:
			if (c.clanId > -1)
				Server.clanChat.leaveClan(c.playerId, c.clanId);
			else
				c.sendMessage("You are not in a clan.");
			break;
		case 62137:
			if (c.clanId >= 0) {
				c.sendMessage("You are already in a clan.");
				break;
			}
			if (c.getOutStream() != null) {
				c.getOutStream().createFrame(187);
				c.flushOutStream();
			}
			break;
			case 147221:
				c.getPA().requestUpdates();
			break;
			case 213144:
				c.setSidebarInterface(14, 55790);
			break;
			/*
			 *
			 * Options tab 
			 *
			 */
			case 3145://control settings
				c.setSidebarInterface(11, 20600);
			break;
			 case 3147://chat options
			 return;
			case 16213://graphics
				c.setSidebarInterface(11, 904);
			break;
			case 16214://audio
				c.setSidebarInterface(11, 4301);
			break;
			case 48176:
			if (!c.acceptAid) {
				c.acceptAid = true;
				c.getPA().sendFrame36(503, 1);
				c.getPA().sendFrame36(427, 1);
			} else {
				c.acceptAid = false;
				c.getPA().sendFrame36(503, 0);
				c.getPA().sendFrame36(427, 0);
			}
			break;
			
		case 153:
			c.getPA().sendConfig(173, !c.isRunning2 ? 0 : 1);
			c.isRunning2 = !c.isRunning2;
			if (c.tutorialProgress == 11) {
				c.getDH().sendDialogues(3041, 0);
			}
			break;

		case 152://run
			if (c.tutorialProgress == 11) {
				c.getDH().sendDialogues(3041, 0);
			}
			c.isRunning2 = !c.isRunning2;
			c.getPA().sendConfig(173, !c.isRunning2 ? 0 : 1);
			break;
			case 100244:
			
			//End//
			case 213145:
				c.setSidebarInterface(14, 638);
			break;
			case 213146:
				c.setSidebarInterface(14, 54670);
			break;
		case 1093:
		case 1094:
		case 1097:
			if (c.autocastId > 0) {
				c.getPA().resetAutocast();
			} else {
				if (c.playerMagicBook == 1) {
					if (c.playerEquipment[c.playerWeapon] == 4675)
						c.setSidebarInterface(0, 1689);
					else
						c.sendMessage("You can't autocast ancients without an ancient staff.");
				} else if (c.playerMagicBook == 0) {
					if (c.playerEquipment[c.playerWeapon] == 4170) {
						c.setSidebarInterface(0, 12050);
					} else {
						c.setSidebarInterface(0, 1829);
					}
				}

			}
			break;
		/** Specials **/
		case 29188:
			c.specBarId = 7636; // the special attack text - sendframe126(S P E
								// C I A L A T T A C K, c.specBarId);
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 29163:
			c.specBarId = 7611;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 33033:
			c.specBarId = 8505;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 29038:
			c.specBarId = 7486;
			/*
			 * if (c.specAmount >= 5) { c.attackTimer = 0;
			 * c.getCombat().attackPlayer(c.playerIndex); c.usingSpecial = true;
			 * c.specAmount -= 5; }
			 */
			c.getCombat().handleGmaulPlayer();
			c.getItems().updateSpecialBar();
			break;

		case 29063:
			if (c.getCombat()
					.checkSpecAmount(c.playerEquipment[c.playerWeapon])) {
				c.gfx0(246);
				c.forcedChat("Raarrrrrgggggghhhhhhh!");
				c.startAnimation(1056);
				c.playerLevel[2] = c.getLevelForXP(c.playerXP[2])
						+ (c.getLevelForXP(c.playerXP[2]) * 15 / 100);
				c.getPA().refreshSkill(2);
				c.getItems().updateSpecialBar();
			} else {
				c.sendMessage("You don't have the required special energy to use this attack.");
			}
			break;

		case 48023:
			c.specBarId = 12335;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 29138:
			c.specBarId = 7586;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 29113:
			c.specBarId = 7561;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		case 29238:
			c.specBarId = 7686;
			c.usingSpecial = !c.usingSpecial;
			c.getItems().updateSpecialBar();
			break;

		/** Dueling **/
		case 26065: // no forfeit
		case 26040:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(0);
			break;

		case 26066: // no movement
		case 26048:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(1);
			break;

		case 26069: // no range
		case 26042:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(2);
			break;

		case 26070: // no melee
		case 26043:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(3);
			break;

		case 26071: // no mage
		case 26041:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(4);
			break;

		case 26072: // no drinks
		case 26045:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(5);
			break;

		case 26073: // no food
		case 26046:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(6);
			break;

		case 26074: // no prayer
		case 26047:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(7);
			break;

		case 26076: // obsticals
		case 26075:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(8);
			break;

		case 2158: // fun weapons
		case 2157:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(9);
			break;

		case 30136: // sp attack
		case 30137:
			c.duelSlot = -1;
			c.getTradeAndDuel().selectRule(10);
			break;

		case 53245: // no helm
			c.duelSlot = 0;
			c.getTradeAndDuel().selectRule(11);
			break;

		case 53246: // no cape
			c.duelSlot = 1;
			c.getTradeAndDuel().selectRule(12);
			break;

		case 53247: // no ammy
			c.duelSlot = 2;
			c.getTradeAndDuel().selectRule(13);
			break;

		case 53249: // no weapon.
			c.duelSlot = 3;
			c.getTradeAndDuel().selectRule(14);
			break;

		case 53250: // no body
			c.duelSlot = 4;
			c.getTradeAndDuel().selectRule(15);
			break;

		case 53251: // no shield
			c.duelSlot = 5;
			c.getTradeAndDuel().selectRule(16);
			break;

		case 53252: // no legs
			c.duelSlot = 7;
			c.getTradeAndDuel().selectRule(17);
			break;

		case 53255: // no gloves
			c.duelSlot = 9;
			c.getTradeAndDuel().selectRule(18);
			break;

		case 53254: // no boots
			c.duelSlot = 10;
			c.getTradeAndDuel().selectRule(19);
			break;

		case 53253: // no rings
			c.duelSlot = 12;
			c.getTradeAndDuel().selectRule(20);
			break;

		case 53248: // no arrows
			c.duelSlot = 13;
			c.getTradeAndDuel().selectRule(21);
			break;

		case 26018:
			Client o = (Client) PlayerHandler.players[c.duelingWith];
			if (o == null) {
				c.getTradeAndDuel().declineDuel();
				return;
			}

			if (c.duelRule[2] && c.duelRule[3] && c.duelRule[4]) {
				c.sendMessage("You won't be able to attack the player with the rules you have set.");
				break;
			}
			c.duelStatus = 2;
			if (c.duelStatus == 2) {
				c.getPA().sendFrame126("Waiting for other player...", 6684);
				o.getPA().sendFrame126("Other player has accepted.", 6684);
			}
			if (o.duelStatus == 2) {
				o.getPA().sendFrame126("Waiting for other player...", 6684);
				c.getPA().sendFrame126("Other player has accepted.", 6684);
			}

			if (c.duelStatus == 2 && o.duelStatus == 2) {
				c.canOffer = false;
				o.canOffer = false;
				c.duelStatus = 3;
				o.duelStatus = 3;
				c.getTradeAndDuel().confirmDuel();
				o.getTradeAndDuel().confirmDuel();
			}
			break;

		case 25120:
			if (c.duelStatus == 5) {
				break;
			}
			Client o1 = (Client) PlayerHandler.players[c.duelingWith];
			if (o1 == null) {
				c.getTradeAndDuel().declineDuel();
				return;
			}

			c.duelStatus = 4;
			if (o1.duelStatus == 4 && c.duelStatus == 4) {
				c.getTradeAndDuel().startDuel();
				o1.getTradeAndDuel().startDuel();
				o1.duelCount = 4;
				c.duelCount = 4;
				c.duelDelay = System.currentTimeMillis();
				o1.duelDelay = System.currentTimeMillis();
			} else {
				c.getPA().sendFrame126("Waiting for other player...", 6571);
				o1.getPA().sendFrame126("Other player has accepted", 6571);
			}
			break;

		case 4169: // god spell charge
			c.usingMagic = true;
			if (!c.getCombat().checkMagicReqs(48)) {
				break;
			}

			if (System.currentTimeMillis() - c.godSpellDelay < Config.GOD_SPELL_CHARGE) {
				c.sendMessage("You still feel the charge in your body!");
				break;
			}
			c.godSpellDelay = System.currentTimeMillis();
			c.sendMessage("You feel charged with a magical power!");
			c.gfx100(c.MAGIC_SPELLS[48][3]);
			c.startAnimation(c.MAGIC_SPELLS[48][2]);
			c.usingMagic = false;
			break;


			

		case 9154:
			c.logout();
			break;

		case 58025:
		case 58026:
		case 58027:
		case 58028:
		case 58029:
		case 58030:
		case 58031:
		case 58032:
		case 58033:
		case 58034:
			c.getBankPin().bankPinEnter(actionButtonId);
			break;
		case 58230:
			if (!c.hasBankpin) {
				c.getBankPin().openPin();
			} else if (c.hasBankpin && c.enterdBankpin) {
				c.getBankPin().resetBankPin();
				c.sendMessage(
						"Your PIN has been deleted as requested.");
			} else {
				c.sendMessage("Please enter your Bank Pin before requesting a delete.");
				c.sendMessage("You can do this by simply opening your bank. This is to verify it's really you.");
				c.getPA().closeAllWindows();
			}
			break;
		case 20174:
			c.getBankPin().bankPinSettings();
			break;
			
		case 58074:
			c.getBankPin().closeBankPin();
			break;

		case 58073:
			if (c.hasBankpin && !c.requestPinDelete) {
				c.requestPinDelete = true;
				c.getBankPin().dateRequested();
				c.getBankPin().dateExpired();
				c.getDH().sendDialogues(1017, 1);
				c.sendMessage(
								"[Notice] A PIN delete has been requested. Your PIN will be deleted in "
										+ c.getBankPin().recovery_Delay
										+ " days.");
				c.sendMessage(
						"To cancel this change just type in the correct PIN.");
			} else {
				c.sendMessage(
								"[Notice] Your PIN is already pending deletion. Please wait the entire 2 days.");
				c.getPA().closeAllWindows();
			}
			break;
	/* Bank tabs buttons */
	case 40084: c.getPA().openUpBank(0); break;
	case 40085: if(c.bankItems1[0] > 0) c.getPA().openUpBank(1); break;
	case 40086: if(c.bankItems2[0] > 0) c.getPA().openUpBank(2); break;
	case 40087: if(c.bankItems3[0] > 0) c.getPA().openUpBank(3); break;
	case 40088: if(c.bankItems4[0] > 0) c.getPA().openUpBank(4); break;
	case 40089: if(c.bankItems5[0] > 0) c.getPA().openUpBank(5); break;
	case 40090: if(c.bankItems6[0] > 0) c.getPA().openUpBank(6); break;
	case 40091: if(c.bankItems7[0] > 0) c.getPA().openUpBank(7); break;
	case 40092: if(c.bankItems8[0] > 0) c.getPA().openUpBank(8); break;
	case 82016:
	if (!c.takeAsNote) {
	c.takeAsNote = true;
	} else if (c.takeAsNote){
	c.takeAsNote = false;
	}
	break;

	case 113084:
	for(int i = 0; i < c.playerItems.length; i++) {
	c.getItems().bankItem(28, i, 1000000000);
	}
	break;		
	case 82024://Deposit Worn items
	for (int i = 0; i < c.playerEquipment.length; i++) {
	int itemId = c.playerEquipment[i];
	int itemAmount = c.playerEquipmentN[i];
	c.getItems().removeItem(itemId, i);
	c.getItems().bankItem(itemId, c.getItems().getItemSlot(itemId), itemAmount);
	}
	break;
		// home teleports
		case 4171:
			String type = c.playerMagicBook == 0 ? "modern" : "ancient";
			c.getPA().startTeleport(Config.EDGEVILLE_X, Config.EDGEVILLE_Y, 0,
					type);
			break;

		case 4140:
			c.handleTeleportRunes(556, 554, 563, 3, 1, 1, Config.VARROCK_X+Misc.random(5), Config.VARROCK_Y+Misc.random(5));
			break;

		case 4143:
			c.handleTeleportRunes(556, 557, 563, 3, 1, 1, Config.LUMBY_X+Misc.random(5), Config.LUMBY_Y+Misc.random(5));
			break;

		case 4146:
			c.handleTeleportRunes(556, 555, 563, 3, 1, 1, 2965+Misc.random(5), 3381+Misc.random(5));
			break;

		case 4150:
			c.handleTeleportRunes(556, 563, -1, 5, 1, -1, Config.CAMELOT_X+Misc.random(5), Config.CAMELOT_Y+Misc.random(5));
			break;

		case 6004:
			c.getAD().completeAchievement("ArdougneMedium", "Cast the Ardougne Teleport spell", 0, 1, 4);
			c.handleTeleportRunes(555, 563, -1, 2, 2, -1, Config.ARDOUGNE_X+Misc.random(5), Config.ARDOUGNE_Y+Misc.random(5));
			break;

		case 6005:
			c.getAD().completeAchievement("ArdougneHard", "Teleport to the Watchtower", 0, 2, 5);
			c.handleTeleportRunes(557, 563, -1, 2, 2, -1, Config.WATCHTOWER_X+Misc.random(5), Config.WATCHTOWER_Y+Misc.random(5));
			break;

		case 51031:
		case 29031:
			c.handleTeleportRunes(554, 563, -1, 2, 2, -1, Config.TROLLHEIM_X+Misc.random(1), Config.TROLLHEIM_Y+Misc.random(1));
			break;

		case 72038:
		case 51039:
			// c.getDH().sendOption5("Option 18", "Option 2", "Option 3",
			// "Option 4", "Option 5");
			// c.teleAction = 8;
			break;
case 53152:
			if (c.tutorialProgress < 36) {
				CookingTutorialIsland.getAmount(c, 1);
			} else {
				Cooking.cookItem(c, c.cookingItem, 1, c.cookingObject);
			}
			break;

		case 53151:
			if (c.tutorialProgress < 36) {
				CookingTutorialIsland.getAmount(c, 5);
			} else {
				Cooking.cookItem(c, c.cookingItem, 5, c.cookingObject);
			}
			break;

		case 53150:
			if (c.tutorialProgress < 36) {
				CookingTutorialIsland.getAmount(c, 10);
			} else {
				c.playerIsCooking = true;
				c.getOutStream().createFrame(27);
			}
			break;

		case 53149:
			if (c.tutorialProgress < 36) {
				CookingTutorialIsland.getAmount(c, 28);
			} else {
				Cooking.cookItem(c, c.cookingItem, 28, c.cookingObject);
			}
			break;

		case 9125: // Accurate
		case 6221: // range accurate
		case 22230: // punch (unarmed)
		case 48010: // flick (whip)
		case 21200: // spike (pickaxe)
		case 1080: // bash (staff)
		case 6168: // chop (axe)
		case 6236: // accurate (long bow)
		case 17102: // accurate (darts)
		case 8234: // stab (dagger)
			c.fightMode = 0;
			if (c.autocasting)
				c.getPA().resetAutocast();
			break;

		case 9126: // Defensive
		case 48008: // deflect (whip)
		case 22228: // kick (unarmed)
		case 21201: // block (pickaxe)
		case 1078: // focus - block (staff)
		case 6169: // block (axe)
		case 33019: // fend (hally)
		case 18078: // block (spear)
		case 8235: // block (dagger)
			c.fightMode = 1;
			if (c.autocasting)
				c.getPA().resetAutocast();
			break;

		case 9127: // Controlled
		case 48009: // lash (whip)
		case 33018: // jab (hally)
		case 6234: // longrange (long bow)
		case 6219: // longrange
		case 18077: // lunge (spear)
		case 18080: // swipe (spear)
		case 18079: // pound (spear)
		case 17100: // longrange (darts)
			c.fightMode = 3;
			if (c.autocasting)
				c.getPA().resetAutocast();
			break;

		case 9128: // Aggressive
		case 6220: // range rapid
		case 22229: // kick (unarmed)
		case 21203: // impale (pickaxe)
		case 21202: // smash (pickaxe)
		case 1079: // pound (staff)
		case 6171: // hack (axe)
		case 6170: // smash (axe)
		case 33020: // swipe (hally)
		case 6235: // rapid (long bow)
		case 17101: // repid (darts)
		case 8237: // lunge (dagger)
		case 8236: // slash (dagger)
			c.fightMode = 2;
			if (c.autocasting)
				c.getPA().resetAutocast();
			break;

/** Prayers **/
		case 21233: // thick skin
			c.getCombat().activatePrayer(0);
			break;
		case 21234: // burst of str
			c.getCombat().activatePrayer(1);
			break;
		case 21235: // charity of thought
			c.getCombat().activatePrayer(2);
			break;
		case 70080: // range
			c.getCombat().activatePrayer(3);
			break;
		case 70082: // mage
			c.getCombat().activatePrayer(4);
			break;
		case 21236: // rockskin
			c.getCombat().activatePrayer(5);
			break;
		case 21237: // super human
			c.getCombat().activatePrayer(6);
			break;
		case 21238: // improved reflexes
			c.getCombat().activatePrayer(7);
			break;
		case 21239: // hawk eye
			c.getCombat().activatePrayer(8);
			break;
		case 21240:
			c.getCombat().activatePrayer(9);
			break;
		case 21241: // protect Item
			c.getCombat().activatePrayer(10);
			break;
		case 70084: // 26 range
			c.getCombat().activatePrayer(11);
			break;
		case 70086: // 27 mage
			c.getCombat().activatePrayer(12);
			break;
		case 21242: // steel skin
			c.getCombat().activatePrayer(13);
			break;
		case 21243: // ultimate str
			c.getCombat().activatePrayer(14);
			break;
		case 21244: // incredible reflex
			c.getCombat().activatePrayer(15);
			break;
		case 21245: // protect from magic
			c.getCombat().activatePrayer(16);
			break;
		case 21246: // protect from range
			c.getCombat().activatePrayer(17);
			break;
		case 21247: // protect from melee
			c.getCombat().activatePrayer(18);
			break;
		case 70088: // 44 range
			c.getCombat().activatePrayer(19);
			break;
		case 70090: // 45 mystic
			c.getCombat().activatePrayer(20);
			break;
		case 2171: // retrui
			c.getCombat().activatePrayer(21);
			break;
		case 2172: // redem
			c.getCombat().activatePrayer(22);
			break;
		case 2173: // smite
			c.getCombat().activatePrayer(23);
			break;
		case 70092: // chiv
			c.getCombat().activatePrayer(24);
			break;
		case 70094: // piety
			c.getCombat().activatePrayer(25);
			break;

		case 13092:
			if (System.currentTimeMillis() - c.lastButton < 400) {

				c.lastButton = System.currentTimeMillis();

				break;

			} else {

				c.lastButton = System.currentTimeMillis();

			}
			Client ot = (Client) PlayerHandler.players[c.tradeWith];
			if (ot == null) {
				c.getTradeAndDuel().declineTrade();
				c.sendMessage("Trade declined as the other player has disconnected.");
				break;
			}
			c.getPA().sendFrame126("Waiting for other player...", 3431);
			ot.getPA().sendFrame126("Other player has accepted", 3431);
			c.goodTrade = true;
			ot.goodTrade = true;

			for (GameItem item : c.getTradeAndDuel().offeredItems) {
				if (item.id > 0) {
					if (ot.getItems().freeSlots() < c.getTradeAndDuel().offeredItems
							.size()) {
						c.sendMessage(ot.playerName
								+ " only has "
								+ ot.getItems().freeSlots()
								+ " free slots, please remove "
								+ (c.getTradeAndDuel().offeredItems.size() - ot
										.getItems().freeSlots()) + " items.");
						ot.sendMessage(c.playerName
								+ " has to remove "
								+ (c.getTradeAndDuel().offeredItems.size() - ot
										.getItems().freeSlots())
								+ " items or you could offer them "
								+ (c.getTradeAndDuel().offeredItems.size() - ot
										.getItems().freeSlots()) + " items.");
						c.goodTrade = false;
						ot.goodTrade = false;
						c.getPA().sendFrame126("Not enough inventory space...",
								3431);
						ot.getPA().sendFrame126(
								"Not enough inventory space...", 3431);
						break;
					} else {
						c.getPA().sendFrame126("Waiting for other player...",
								3431);
						ot.getPA().sendFrame126("Other player has accepted",
								3431);
						c.goodTrade = true;
						ot.goodTrade = true;
					}
				}
			}
			if (c.inTrade && !c.tradeConfirmed && ot.goodTrade && c.goodTrade) {
				c.tradeConfirmed = true;
				if (ot.tradeConfirmed) {
					c.getTradeAndDuel().confirmScreen();
					ot.getTradeAndDuel().confirmScreen();
					break;
				}

			}

			break;

		case 13218:
			if (System.currentTimeMillis() - c.lastButton < 400) {

				c.lastButton = System.currentTimeMillis();

				break;

			} else {

				c.lastButton = System.currentTimeMillis();

			}
			c.tradeAccepted = true;
			Client ot1 = (Client) PlayerHandler.players[c.tradeWith];
			if (ot1 == null) {
				c.getTradeAndDuel().declineTrade();
				c.sendMessage("Trade declined as the other player has disconnected.");
				break;
			}

			if (c.inTrade && c.tradeConfirmed && ot1.tradeConfirmed
					&& !c.tradeConfirmed2) {
				c.tradeConfirmed2 = true;
				if (ot1.tradeConfirmed2) {
					c.acceptedTrade = true;
					ot1.acceptedTrade = true;
					c.getTradeAndDuel().giveItems();
					ot1.getTradeAndDuel().giveItems();
					break;
				}
				ot1.getPA().sendFrame126("Other player has accepted.", 3535);
				c.getPA().sendFrame126("Waiting for other player...", 3535);
			}

			break;
		/*
		 *
		 *Player Emotes 
		 *
		 */
		
		case 168:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(855);
			break;
		case 169:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(856);
			break;
		case 162:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(857);
			break;
		case 164:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(858);
			break;
		case 165:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(859);
			break;
		case 161:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(860);
			break;
		case 170:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(861);
			break;
		case 171:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(862);
			break;
		case 163:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(863);
			break;
		case 167:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(864);
			break;
		case 172:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(865);
			break;
		case 166:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(866);
			break;
		case 52050:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2105);
			break;
		case 52051:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2106);
			break;
		case 52052:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2107);
			break;
		case 52053:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2108);
			break;
		case 52054:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2109);
			break;
		case 52055:
			if (c.tutorialProgress == 10) {
				c.getDH().sendDialogues(3039, 0);
			}
			c.startAnimation(2110);
			break;
		case 52056:
			c.startAnimation(2111);
			break;
		case 52057:
			c.startAnimation(2112);
			break;
		case 52058:
			c.startAnimation(2113);
			break;
		case 43092:
			c.startAnimation(0x558);
			break;
		case 2155:
			c.startAnimation(0x46B);
			break;
		case 25103:
			c.startAnimation(0x46A);
			break;
		case 25106:
			c.startAnimation(0x469);
			break;
		case 2154:
			c.startAnimation(0x468);
			break;
		case 52071:
			c.startAnimation(0x84F);
			break;
		case 52072:
			c.startAnimation(0x850);
			break;
		case 59062:
			c.startAnimation(2836);
			break;
		case 72032:
			c.startAnimation(3544);
			break;
		case 72033:
			c.startAnimation(3543);
			break;
		case 72254:
			c.startAnimation(3866);
			break;
		/* END OF EMOTES */

		case 24017:
			c.getPA().resetAutocast();
			// c.sendFrame246(329, 200, c.playerEquipment[c.playerWeapon]);
			c.getItems()
					.sendWeapon(
							c.playerEquipment[c.playerWeapon],
							c.getItems().getItemName(
									c.playerEquipment[c.playerWeapon]));
			// c.setSidebarInterface(0, 328);
			// c.setSidebarInterface(6, c.playerMagicBook == 0 ? 1151 :
			// c.playerMagicBook == 1 ? 12855 : 1151);
			break;
		}
		if (c.isAutoButton(actionButtonId))
			c.assignAutocast(actionButtonId);
	}

}
