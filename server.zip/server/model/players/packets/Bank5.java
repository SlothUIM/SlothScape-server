package server.model.players.packets;

import server.model.players.Client;
import server.Config;
import server.model.players.PacketType;
import server.model.players.PriceChecker;

/**
 * Bank 5 Items
 **/
public class Bank5 implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int interfaceId = c.getInStream().readSignedWordBigEndianA();
		int removeId = c.getInStream().readSignedWordBigEndianA();
		int removeSlot = c.getInStream().readSignedWordBigEndian();

				System.out.println("Bank5 "+interfaceId+"]: "+removeId);
		switch (interfaceId) {

		case 3900:
			c.getShops().buyItem(removeId, removeSlot, 1);
			break;

		case 3823:
			c.getShops().sellItem(removeId, removeSlot, 1);
			break;
		case -23826:
			if(removeId == c.PouchRune1){
				c.getItems().addItem(removeId, c.PouchRune1Amt);
				c.PouchRune1Amt = 0;
				c.PouchRune1 = 0;
			} else 
			if(removeId == c.PouchRune2){
				c.getItems().addItem(removeId, c.PouchRune2Amt);
				c.PouchRune2Amt = 0;
				c.PouchRune2 = 0;
			} else 
			if(removeId == c.PouchRune3){
				c.getItems().addItem(removeId, c.PouchRune3Amt);
				c.PouchRune3Amt = 0;
				c.PouchRune3 = 0;
			}
				c.openRunePouch();
				c.getPA().sendRuneTypes(c.PouchRune1, c.PouchRune2, c.PouchRune3, c.PouchRune1Amt,c.PouchRune2Amt,c.PouchRune3Amt);
			
		break;
		case -23825:
		//if(c.addingToRP){
			//int[] RuneIDS = {554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566};
		for(int i = 0; i < 20; i++){
			if(removeId == c.RuneIDS[i]){
				c.getCharges().addRunes(removeId, removeSlot, 5);
				//c.openRunePouch();
			break;
			}
			}
		//}
		break;
		case 7423:
				c.getItems().bankItem(c.playerItems[removeSlot] , removeSlot, 5);
		break;
		case 5064:
			if (c.inTrade) {
				c.sendMessage("You can't store items while trading!");
				return;
			}
			if(removeId == 11941){
				for (int i = 0; i < c.playerLootItems.length; i++) {
					int itemId = c.playerLootItems[i];
					int itemAmount = c.playerLootItemsN[i];
					c.getItems().bankLootItem(c.playerLootItems[i], i, c.playerLootItemsN[i]);
				}
			} else if(c.isBanking){
					c.getItems().bankItem(c.playerItems[removeSlot] , removeSlot, 5);
					//c.getPA().searchBank(c, c.searchTerm);
			} else if (c.isChecking) {
				PriceChecker.depositItem(c, removeId, 5);
			}
			break;
			case -21826:
				for (int i : Config.DESTROYABLE_ITEMS) {
					if (i == removeId) {
					c.sendMessage("You can't put untradable items in your looting bag.");
					return;
					} else
						c.getItems().addtoLootbagFromDeposit(removeId, removeSlot, 5);
				}
			break;
		case 43933:
			PriceChecker.withdrawItem(c, removeId, removeSlot, 5);
			break;
		case -29722:
				int ItemAmount = 0;
		if(c.CollectionLog == 2)
				ItemAmount = c.getCollectionLog().getCollectionLogItemAmount(c.getCollectionLog().barrowsCollectionLog, removeId);
		else if(c.CollectionLog == 12)
				ItemAmount = c.getCollectionLog().getCollectionLogItemAmount(c.getCollectionLog().bandosCollectionLog, removeId);

					c.sendMessage("You have recieved "+ItemAmount+ " "+c.getItems().getItemName(removeId));
			break;
			case 5382:
			if (c.inTrade) {
				c.getTradeAndDuel().declineTrade(true);
			}
				c.getItems().fromBank(removeId, removeSlot, 5);
			break;
		case 3322:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().tradeItem(removeId, removeSlot, 5);
			} else {
				c.getTradeAndDuel().stakeItem(removeId, removeSlot, 5);
			}
			break;

		case 3415:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().fromTrade(removeId, removeSlot, 5);
			}
			break;

		case 6669:
			c.getTradeAndDuel().fromDuel(removeId, removeSlot, 5);
			break;

		case 1119:
		case 1120:
		case 1121:
		case 1122:
		case 1123:
			c.getSmithing().readInput(c, c.playerLevel[c.playerSmithing], removeId, 5);
			break;

		}
	}

}
