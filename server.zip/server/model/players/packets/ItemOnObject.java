package server.model.players.packets;

/**
 * @author Ryan / Lmctruck30
 */

import server.model.items.UseItem;
import server.model.players.Client;
import server.model.players.PacketType;
import server.model.items.*;

public class ItemOnObject implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		/*
		 * a = ? b = ?
		 */

		c.getInStream().readUnsignedWord();
		int objectId = c.getInStream().readSignedWordBigEndian();
		int objectY = c.getInStream().readSignedWordBigEndianA();
		c.getInStream().readUnsignedWord();
		int objectX = c.getInStream().readSignedWordBigEndianA();
		int itemId = c.getInStream().readUnsignedWord();
		//int objectType = c.getInStream().readUnsignedWord();
		c.objectX = objectX;
		c.objectY = objectY;
		if (!c.getItems().playerHasItem(itemId, 1)) {
			return;
		}
		UseItem.ItemonObject(c, objectId, objectX, objectY, itemId);
		switch(objectId){
			
		case 3044:
			if (itemId == 438 || itemId == 436) {
				if (c.getItems().playerHasItem(438) && c.getItems().playerHasItem(436)) {
					if (c.tutorialProgress == 19) {
						c.startAnimation(899);
						c.getPA().sendSound(352, 100, 1);
						c.sendMessage("You smelt the copper and tin together in the furnace.");
						c.getItems().deleteItem(438, 1);
						c.getItems().deleteItem(436, 1);
						c.sendMessage("You retrieve a bar of bronze.");
						c.getItems().addItem(2349, 1);
						c.getDH().sendDialogues(3062, -1);
					} else if (c.tutorialProgress > 19) {
						c.startAnimation(899);
						c.getPA().sendSound(352, 100, 1);
						c.sendMessage("You smelt the copper and tin together in the furnace.");
						c.getItems().deleteItem(438, 1);
						c.getItems().deleteItem(436, 1);
						c.sendMessage("You retrieve a bar of bronze.");
						c.getItems().addItem(2349, 1);
					}
				}
			}
		break;
		}
	}

}
