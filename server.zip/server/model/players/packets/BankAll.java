package server.model.players.packets;

import server.model.items.GameItem;
import server.model.items.Item;
import server.model.players.Client;
import server.model.players.PacketType;
import server.model.players.PriceChecker;

/**
 * Bank All Items
 **/
public class BankAll implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int removeSlot = c.getInStream().readUnsignedWordA();
		int interfaceId = c.getInStream().readUnsignedWord();
		int removeId = c.getInStream().readUnsignedWordA();

				System.out.println("BankAll "+interfaceId+"]: "+removeId);
		switch (interfaceId) {
		case 3900:
			c.getShops().buyItem(removeId, removeSlot, 10);
			break;
			
		case 41711:
		//if(c.addingToRP){
		for(int i = 0; i < 20; i++){
			if(removeId == c.RuneIDS[i]){
				c.getCharges().addRunes(removeId, removeSlot, c.getItems().itemAmount(c.playerItems[removeSlot]));
				//c.openRunePouch();
				break;
			}
		}
		break;
		
			case -21826:
		case 43710:
		c.getItems().addtoLootbagFromDeposit(removeId, removeSlot, c.getItems().itemAmount(c.playerItems[removeSlot]));
		break;
		case 3823:
			c.getShops().sellItem(removeId, removeSlot, 10);
			break;
		case 5064:
			if (c.inTrade) {
				c.sendMessage("You can't store items while trading!");
				return;
			}
			if (c.isChecking) {
				PriceChecker.depositItem(c, removeId,
						c.playerItemsN[removeSlot]);
				return;
			}
			if (Item.itemStackable[removeId]) {
				c.getItems().bankItem(c.playerItems[removeSlot], removeSlot,
						c.playerItemsN[removeSlot]);
			} else {
				c.getItems().bankItem(c.playerItems[removeSlot], removeSlot,
						c.getItems().itemAmount(c.playerItems[removeSlot]));
			}
			break;

		case 5382:
			c.getItems().fromBank(c.bankingItems[removeSlot], removeSlot,
					c.bankingItemsN[removeSlot]);
			break;

		case 7423:
				c.getItems().bankItem(c.playerItems[removeSlot] , removeSlot, c.getItems().itemAmount(c.playerItems[removeSlot]));
		break;
		case 3322:
			if (c.duelStatus <= 0) {
				if (Item.itemStackable[removeId]) {
					c.getTradeAndDuel().tradeItem(removeId, removeSlot,
							c.playerItemsN[removeSlot]);
				} else {
					c.getTradeAndDuel().tradeItem(removeId, removeSlot, 28);
				}
			} else {
				if (Item.itemStackable[removeId] || Item.itemIsNote[removeId]) {
					c.getTradeAndDuel().stakeItem(removeId, removeSlot,
							c.playerItemsN[removeSlot]);
				} else {
					c.getTradeAndDuel().stakeItem(removeId, removeSlot, 28);
				}
			}
			break;

		case 43933:
			PriceChecker.withdrawItem(c, removeId, removeSlot,
					c.priceN[removeSlot]);
		break;
		case 3415:
			if (c.duelStatus <= 0) {
				if (Item.itemStackable[removeId]) {
					for (GameItem item : c.getTradeAndDuel().offeredItems) {
						if (item.id == removeId) {
							c.getTradeAndDuel().fromTrade(
									removeId,
									removeSlot,
									c.getTradeAndDuel().offeredItems
											.get(removeSlot).amount);
						}
					}
				} else {
					for (GameItem item : c.getTradeAndDuel().offeredItems) {
						if (item.id == removeId) {
							c.getTradeAndDuel().fromTrade(removeId, removeSlot,
									28);
						}
					}
				}
			}
			break;

		case 6669:
			if (Item.itemStackable[removeId] || Item.itemIsNote[removeId]) {
				for (GameItem item : c.getTradeAndDuel().stakedItems) {
					if (item.id == removeId) {
						c.getTradeAndDuel()
								.fromDuel(
										removeId,
										removeSlot,
										c.getTradeAndDuel().stakedItems
												.get(removeSlot).amount);
					}
				}

			} else {
				c.getTradeAndDuel().fromDuel(removeId, removeSlot, 28);
			}
			break;

		}
	}

}
