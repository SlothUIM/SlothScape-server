package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;
import server.Server;

/**
 * Clicking an item, bury bone, eat food etc
 **/
public class ClickItem implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		c.getInStream().readSignedWordBigEndianA();
		int itemSlot = c.getInStream().readUnsignedWordA();
		int itemId = c.getInStream().readUnsignedWordBigEndian();
		if (itemId != c.playerItems[itemSlot] - 1) {
			return;
		}
		switch(itemId){
			case 10008: // box trap
			for (int i = 0; i < Server.npcHandler.maxNPCs; i++) {
				if (Server.npcHandler.npcs[i] != null) {
					if (c.absX == Server.npcHandler.npcs[i].absX && c.absY == Server.npcHandler.npcs[i].absY) {
						c.sendMessage("you can't set up a trap here!");
						return;
					} else if (c.absX == c.getHunter().trapX && c.absY == c.getHunter().trapY) {
						c.sendMessage("you can't set up a trap here!");
						return;
					} else if (c.absX == c.getHunter().trapX2 && c.absY == c.getHunter().trapY2) {
						c.sendMessage("you can't set up a trap here!");
						return;
					} else if (c.absX == c.getHunter().trapX3 && c.absY == c.getHunter().trapY3) {
						c.sendMessage("you can't set up a trap here!");
						return;
					} else if (c.absX == c.getHunter().trapX4 && c.absY == c.getHunter().trapY4) {
						c.sendMessage("you can't set up a trap here!");
						return;
					} else if (c.absX == c.getHunter().trapX5 && c.absY == c.getHunter().trapY5) {
						c.sendMessage("you can't set up a trap here!");
						return;
					}
				}
			}
			
			if (c.getHunter().trapX == 0 && c.getHunter().trapY == 0) {
				c.getHunter().setTrap();
			} else if (c.getHunter().trapX2 == 0 && c.getHunter().trapY2 == 0) {
				c.getHunter().setTrap2();
			} else if (c.getHunter().trapX3 == 0 && c.getHunter().trapY3 == 0) {
				c.getHunter().setTrap3();
			} else if (c.getHunter().trapX4 == 0 && c.getHunter().trapY4 == 0) {
				c.getHunter().setTrap4();
			} else if (c.getHunter().trapX5 == 0 && c.getHunter().trapY5 == 0) {
				c.getHunter().setTrap5();
			}
		break;
			case 11941:
			case 11942:
				for (int ITEM = 0; ITEM < 28; ITEM++) {
					c.getPA().sendFrame34a(42710, c.playerLootItems[ITEM] - 1, ITEM, c.playerLootItemsN[ITEM]);
				}
				c.getPA().sendFrame126("Value: " + String.format("%,d", c.getLootBagWealth()), 42720);

					//c.getPA().sendFrame126("Value: "+c.getLootBagWealth(), 42720);
			c.setSidebarInterface(3, 42700);
			break;
			case 2886:
				c.getPA().sendFrame126("Book of the elemental shield", 903);
				c.getPA().sendFrame126("Within the pages of this", 843);
				c.getPA().sendFrame126("book you will find the", 844);
				c.getPA().sendFrame126("secret to working the", 845);
				c.getPA().sendFrame126("very elements themselves.", 846);
				c.getPA().sendFrame126("Early in the fifth age, a", 847);
				c.getPA().sendFrame126("new ore was discovered.", 848);
				c.getPA().sendFrame126("This ore has a unique", 849);
				c.getPA().sendFrame126("property of absorbing,", 850);
				c.getPA().sendFrame126("transforming or focusing ", 851);
				c.getPA().sendFrame126("elemental energy. A", 852);
				c.getPA().sendFrame126("workshop was erected", 853);
				c.getPA().sendFrame126("close by to work this new", 854);
				c.getPA().sendFrame126("material. The workshop", 855);
				c.getPA().sendFrame126("was set up for artisans", 856);
				c.getPA().sendFrame126("and inventors to be able", 857);
				c.getPA().sendFrame126("to come and create", 858);
				c.getPA().sendFrame126("devices made from the", 859);
				c.getPA().sendFrame126("unique ore, found only in.", 860);
				c.getPA().sendFrame126("the village of the Seers.", 861);
				c.getPA().sendFrame126("", 862);
				c.getPA().sendFrame126("", 863);
				c.getPA().sendFrame126("", 864);
				c.getPA().sendFrame126("", 14165);
				c.getPA().sendFrame126("", 14166);
				c.getPA().sendFrame126("", 839);
				c.getPA().sendFrame126("", 841);
				c.getPA().showInterface(837);
				c.bookPage = 1;
				c.sendMessage("The book has two parts: an introduction and an instruction section.");
				c.sendMessage("You flip the book open to the introduction and start reading.");
			break;
			/*case 11942:
				c.openLootBag = true;
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(11941, 100);
				break;*/
				case 8007:
				case 8008:
				case 8009:
				case 8010:
				case 8011:
				case 8012:
				case 8013:
				c.getTabs().breakTablet(itemId);
				break;
			case 12791:
				c.addingToRP = true;
				c.openRunePouch();
			break;
			case 12728:
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(556, 100);
				break;
			case 12730://water
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(555, 100);
				break;
			case 12732://earth
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(557, 100);
				break;
			case 12734://fire
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(554, 100);
				break;
			case 12736://mind
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(558, 100);
				break;
			case 12738://chaos
				c.getItems().deleteItem(itemId, c.getItems().getItemSlot(itemId), 1);
				c.getItems().addItem(562, 100);
				break;
		}
		if (itemId >= 5509 && itemId <= 5514) {
			int pouch = -1;
			int a = itemId;
			if (a == 5509)
				pouch = 0;
			if (a == 5510)
				pouch = 1;
			if (a == 5512)
				pouch = 2;
			if (a == 5514)
				pouch = 3;
			c.getPA().fillPouch(pouch);
			return;
		}
		if (c.getHerblore().isUnidHerb(itemId))
			c.getHerblore().handleHerbClick(itemId);
		if (c.getFood().isFood(itemId))
			c.getFood().eat(itemId, itemSlot);
		// ScriptManager.callFunc("itemClick_"+itemId, c, itemId, itemSlot);
		if (c.getPotions().isPotion(itemId))
			c.getPotions().handlePotion(itemId, itemSlot);
		if (c.getPrayer().isBone(itemId))
			c.getPrayer().buryBone(itemId, itemSlot);
		if (itemId == 952) {
			if (c.inArea(3553, 3301, 3561, 3294)) {
				c.teleTimer = 3;
				c.newLocation = 1;
			} else if (c.inArea(3550, 3287, 3557, 3278)) {
				c.teleTimer = 3;
				c.newLocation = 2;
			} else if (c.inArea(3561, 3292, 3568, 3285)) {
				c.teleTimer = 3;
				c.newLocation = 3;
			} else if (c.inArea(3570, 3302, 3579, 3293)) {
				c.teleTimer = 3;
				c.newLocation = 4;
			} else if (c.inArea(3571, 3285, 3582, 3278)) {
				c.teleTimer = 3;
				c.newLocation = 5;
			} else if (c.inArea(3562, 3279, 3569, 3273)) {
				c.teleTimer = 3;
				c.newLocation = 6;
			}
		}
	}

}
