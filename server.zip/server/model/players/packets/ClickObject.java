package server.model.players.packets;

import java.util.function.Consumer;
import server.model.players.*;
import server.model.players.skills.*;
import server.clip.*;
import server.util.Misc;
import server.world.map.*;
import server.model.objects.Doors;
import server.model.objects.DoubleDoors;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.objects.Objects;

public class ClickObject implements PacketType {

	public static final int FIRST_CLICK = 132;
	public static final int SECOND_CLICK = 252;
	public static final int THIRD_CLICK = 70;

	public ClickObject() {
	}
	public void onObjectReached(Client player, Consumer<Client> consumer) {
		if (System.currentTimeMillis() - player.clickDelay < 300)
			return;
		player.clickDelay = System.currentTimeMillis();

		final int objectX = player.objectX;
		final int objectY = player.objectY;
		final int objectId = player.objectId;
		final int objectDistance = player.objectDistance;
		final int objectYOffset = player.objectYOffset;
		final int objectXOffset = player.objectXOffset;

		Objects object = Region.getObject(objectId, objectX, objectY, player.heightLevel);
		if (object == null) {
			// Since most content is coded poorly we will have to assume the object is valid
			// but we won't know the face direction, so some objects will behave incorrectly
			// if the object size is not equal on both axes and the face
			// is not set to zero. The proper fix would be when an object is removed or added
			// they are added into the region configuration properly so we can retrieve
			// the object at runtime. This will suffice for now.
			object = new Objects(objectId, objectX, objectY, player.heightLevel, 0, 10, 0);
		}

		int[] size = object.getObjectSize();

		CycleEvent objectWalkToEvent = new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				if (objectX != player.objectX || objectY != player.objectY || objectId != player.objectId) {
					container.stop();
					return;
				}

				int x = player.absX;
				int y = player.absY;
				int xMin = objectX - objectDistance;
				int xMax = xMin + size[0] + objectDistance;
				int yMin = objectY - objectDistance;
				int yMax = yMin + size[1] + objectDistance;

				if ((x >= xMin && y >= yMin && x <= xMax && y <= yMax)/* || (player.getRangersGuild().isInTargetArea() && player.objectId == 2513)*/) {
					consumer.accept(player);
					container.stop();
				}
			}

			@Override
			public void stop() {
				
			}
		};

		player.startCurrentTask(1, objectWalkToEvent);
		objectWalkToEvent.execute(player.getCurrentTask()); // cheap hax for instant event execution, since we don't support it
	}
	public void processPacket(Client client, int i, int j) {
		client.clickObjectType = client.objectX = client.objectId = client.objectY = 0;
		int objectid = client.objectId;
		client.getPA().resetFollow();
		client.getCombat().resetPlayerAttack();
		client.getPA().requestUpdates();
		switch (i) {
		default:
			break;

		case FIRST_CLICK:
			client.objectX = client.getInStream().readSignedWordBigEndianA();
			client.objectId = client.getInStream().readUnsignedWord();
			client.objectY = client.getInStream().readUnsignedWordA();
			client.objectDistance = 1;
			//client.sendMessage("Object type 1: " + objectid);
			
			if (Math.abs(client.getX() - client.objectX) > 25
					|| Math.abs(client.getY() - client.objectY) > 25) {
				client.resetWalkingQueue();
			} else {
				for (int k = 0; k < client.getRunecrafting().altarID.length; k++) {
					if (client.objectId == client.getRunecrafting().altarID[k]) {
						client.getRunecrafting().craftRunes(client.objectId);
					}
				}

				switch (client.objectId) {
					case 10832:
					client.objectDistance = 2;
					client.objectYOffset = -1;
					client.objectXOffset = 1;
					break;
					case 10355:
					client.objectDistance = 1;
					client.objectXOffset = 2;
					client.objectYOffset = 0;
					break;
			
				default:
					//client.objectDistance = 2;
					break;
				}
			}
			onObjectReached(client, (p) -> completeObjectClick(p, 1));
			break;

		case 252:
			client.objectId = client.getInStream().readUnsignedWordBigEndianA();
			client.objectY = client.getInStream().readSignedWordBigEndian();
			client.objectX = client.getInStream().readUnsignedWordA();
			onObjectReached(client, (p) -> completeObjectClick(p, 2));
			//client.objectDistance = 1;
			switch (client.objectId) {
			

			default:
				break;
			}
			break;

		case 70: // 'F'
			client.objectX = client.getInStream().readSignedWordBigEndian();
			client.objectY = client.getInStream().readUnsignedWord();
			client.objectId = client.getInStream().readUnsignedWordBigEndianA();
			onObjectReached(client, (p) -> completeObjectClick(p, 3));
			switch (client.objectId) {
				
			default:
				break;
			}
			break;
		}
	}
	public void completeObjectClick(final Client player, int objectOption) {
		player.turnPlayerTo(player.objectX, player.objectY);

		switch (objectOption) {
		case 1:
			if (player.playerRights == 3) {
				player.sendMessage("object click 1: ObjectId: " + player.objectId + " ObjectX: " + player.objectX + " ObjectY: " + player.objectY + " Objectclick = 1, Xoff: " + (player.getX() - player.objectX) + " Yoff: " + (player.getY() - player.objectY));
			}

			//todo: check if it's a door before fire handle
			if (player.teleTimer > 0) {
				player.sendMessage("You cannot use objects while teleporting.");
				return;
			}
			if (Math.abs(player.getX() - player.objectX) > 25 || Math.abs(player.getY() - player.objectY) > 25) {
				player.resetWalkingQueue();
				break;
			}
			Doors.getSingleton().handleDoor(player.objectId, player.objectX, player.objectY, player.heightLevel);
			DoubleDoors.getSingleton().handleDoor(player.objectId, player.objectX, player.objectY, player.heightLevel);	
			player.getActions().firstClickObject(player.objectId, player.objectX, player.objectY);
			break;
		case 2:
			if (player.playerRights == 3) {
				player.sendMessage("object click 2: ObjectId: " + player.objectId + " ObjectX: " + player.objectX + " ObjectY: " + player.objectY + " Objectclick = 2, Xoff: " + (player.getX() - player.objectX) + " Yoff: " + (player.getY() - player.objectY));
			}
			player.getActions().secondClickObject(player.objectId, player.objectX, player.objectY);
			break;
		case 3: // 'F'
			if (player.playerRights == 3) {
				player.sendMessage("object click 3: ObjectId: " + player.objectId + " ObjectX: " + player.objectX + " ObjectY: " + player.objectY + " Objectclick = 3, Xoff: " + (player.getX() - player.objectX) + " Yoff: " + (player.getY() - player.objectY));
			}

			player.getActions().thirdClickObject(player.objectId, player.objectX, player.objectY);
			break;
		}
	}
	public void handleSpecialCase(Client client, int i, int j, int k) {
	}
}
