package server.model.players.packets;

import server.Server;
import server.model.players.Client;
import server.model.players.PacketType;
import server.model.players.Sound;
import server.model.players.Music;
import server.model.players.skills.*;

/**
 * Pickup Item
 **/
public class PickupItem implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		c.pItemY = c.getInStream().readSignedWordBigEndian();
		c.pItemId = c.getInStream().readUnsignedWord();
		c.pItemX = c.getInStream().readSignedWordBigEndian();
		if (Math.abs(c.getX() - c.pItemX) > 25
				|| Math.abs(c.getY() - c.pItemY) > 25) {
			c.resetWalkingQueue();
			return;
		}
		for (LogData logData : LogData.values()) {
			if (c.isFiremaking && c.pItemId == logData.getLogId()) {
				c.sendMessage("You can't do that!");
				c.stopFiremaking = true;
				return;
			}
		}
		for (LogData logData : LogData.values()) {
			if (c.pItemId == logData.getLogId()) {
				c.pickedUpFiremakingLog = true;
			}
		}
		SkillHandler.resetSkills(c);
		c.getCombat().resetPlayerAttack();
		if (c.getX() == c.pItemX && c.getY() == c.pItemY) {
			Server.itemHandler.removeGroundItem(c, c.pItemId, c.pItemX,
					c.pItemY, true);
		} else {
			c.walkingToItem = true;
		}
			c.getPA().sendSound(Sound.SOUND_LIST.DOOR.getSound(), 0, 8);

	}

}
