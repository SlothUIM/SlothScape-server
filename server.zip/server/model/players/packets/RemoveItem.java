package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;
import server.model.players.PriceChecker;

/**
 * Remove Item
 **/
public class RemoveItem implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int interfaceId = c.getInStream().readUnsignedWordA();
		int removeSlot = c.getInStream().readUnsignedWordA();
		int removeId = c.getInStream().readUnsignedWordA();
		switch (interfaceId) {

		case 1688:
			c.getItems().removeItem(removeId, removeSlot);
			break;

			case 5064:
			if(c.inTrade) {
				c.getTradeAndDuel().declineTrade(true);
			}
		if (removeId != -1){
			if(c.isBanking){
			c.getItems().bankItem(removeId, removeSlot, 1);
			//c.getPA().searchBank(c, c.searchTerm);
			} else if (c.isChecking)
				PriceChecker.depositItem(c, removeId, 1);
		}
			break;

		case 41711:
		//if(c.addingToRP){
			//int[] RuneIDS = {554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566};
		for(int i = 0; i < 20; i++){
			if(removeId == c.RuneIDS[i]){
				c.getCharges().addRunes(removeId, removeSlot, 1);
				//c.openRunePouch();
			}
		}
			break;
			case 43933:
			PriceChecker.withdrawItem(c, removeId, removeSlot, 1);
			break;
		case 5382:
			c.getItems().fromBank(removeId, removeSlot, 1);
			break;

		case 3900:
			c.getShops().buyFromShopPrice(removeId, removeSlot);
			break;

		case 3823:
			c.getShops().sellToShopPrice(removeId, removeSlot);
			break;

		case 3322:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().tradeItem(removeId, removeSlot, 1);
			} else {
				c.getTradeAndDuel().stakeItem(removeId, removeSlot, 1);
			}
			break;

		case 3415:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().fromTrade(removeId, removeSlot, 1);
			}
			break;

		case 6669:
			c.getTradeAndDuel().fromDuel(removeId, removeSlot, 1);
			break;

		case 1119:
		case 1120:
		case 1121:
		case 1122:
		case 1123:
			c.getSmithing().readInput(c, c.playerLevel[c.playerSmithing], removeId, 1);
			break;
		}
	}

}
