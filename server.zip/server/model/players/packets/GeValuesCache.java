package server.model.players.packets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.awt.*;


public class GeValuesCache {
	
	               public static Map<Integer, Pair<Integer, Integer>> geValues = new HashMap<>();
					public static long lastPriceUpdate;
	                static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	               public static String dropboxFileURL = "https://www.dropbox.com/scl/fi/tgeb3lv0x9q7im4x2d4hf/GeValues.txt?rlkey=lrshs5fcfa0b7d3q2rfnowrj8&dl=1";
	                public static void loadGePricesCache() {
	                    try {
	                        URL url = new URL(dropboxFileURL);
	                        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	                        try  {
	                            connection.setRequestMethod("GET");
	                            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
	                                String line;
	                                
	                                while ((line = reader.readLine()) != null) {
	                                    String[] parts = line.split(",");
	                                    if (parts.length == 2) {
	                                        int itemId = Integer.parseInt(parts[0]);
	                                        int geValue = Integer.parseInt(parts[1]);
	                                        int haValue = 0;
	                                        geValues.put(itemId, new Pair<>(geValue, haValue));
	                                    }
	                                }
	                                lastPriceUpdate = System.currentTimeMillis();
	                                String formattedTime = dateFormat.format(new Date(lastPriceUpdate));
	                                System.out.println("Prices updated at " + formattedTime);
	                            } catch (IOException e) {
	                                // Handle exceptions when working with the reader
	                            }
	                        } catch (IOException e) {
	                            // Handle exceptions when working with the connection
	                        } finally {
	                            if (connection != null) {
	                                connection.disconnect();
	                            }
	                        }
	                    } catch (IOException e) {
	                        e.printStackTrace();
	                    }
	                }

}