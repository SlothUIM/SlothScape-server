package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;
import server.model.players.PriceChecker;

/**
 * Bank X Items
 **/
public class BankX2 implements PacketType {
	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int Xamount = c.getInStream().readDWord();
		if (Xamount == 0)
			Xamount = 1;
		switch (c.xInterfaceId) {
		case 5064:
			if(c.inTrade) {
				c.sendMessage("You can't store items while trading!");
				return;
			}
			if(c.isBanking){
			c.getItems().bankItem(c.playerItems[c.xRemoveSlot] , c.xRemoveSlot, Xamount);
			} else if (c.isChecking)
				PriceChecker.depositItem(c, c.playerItems[c.xRemoveSlot] - 1,
						Xamount);
			break;
		
			case 43933:
			PriceChecker.withdrawItem(c, c.price[c.xRemoveSlot], c.xRemoveSlot,
					Xamount);
			break;
			case -21826:
		case 43710:
		c.getItems().addtoLootbagFromDeposit(c.xRemoveSlot, c.xRemoveSlot, Xamount);
		break;
		case 5382:
			c.getItems().fromBank(c.bankItems[c.xRemoveSlot], c.xRemoveSlot,
					Xamount);
			break;
		case 3900:
			c.getShops().buyItem(c.xRemoveId, c.xRemoveSlot, Xamount);
			break;
				
		case 3823:
			c.getShops().sellItem(c.xRemoveId , c.xRemoveSlot, Xamount);
			break;
		case 3322:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().tradeItem(c.xRemoveId, c.xRemoveSlot,
						Xamount);
			} else {
				c.getTradeAndDuel().stakeItem(c.xRemoveId, c.xRemoveSlot,
						Xamount);
			}
			break;
		
		case 3415:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().fromTrade(c.xRemoveId, c.xRemoveSlot,
						Xamount);
			}
			break;

		case 6669:
			c.getTradeAndDuel().fromDuel(c.xRemoveId, c.xRemoveSlot, Xamount);
			break;
		}
		if(c.addingCharges || c.addingDarts)
			c.getCharges().addCharges(c.xRemoveId, c.xRemoveSlot, Xamount);
		if(c.addingToRP && c.xInterfaceId == 41711)
			c.getCharges().addRunes(c.xRemoveId, c.xRemoveSlot, Xamount);
	}
}