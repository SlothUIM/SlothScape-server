package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;
import server.util.Misc;

/**
 * Item Click 2 Or Alternative Item Option 1
 * 
 * @author Ryan / Lmctruck30
 * 
 *         Proper Streams
 */

public class ItemClick2 implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int itemId = c.getInStream().readSignedWordA();

		if (!c.getItems().playerHasItem(itemId, 1))
			return;

		switch (itemId) {
			case 12926:
			if(c.DartType == 809)
				c.sendMessage("Your Toxic Blowpipe has "+ c.BlowpipeCharges + " scales and there are " + c.BlowpipeDarts + " Mithril Darts loaded into it.");
			if(c.DartType == 810)
				c.sendMessage("Your Toxic Blowpipe has "+ c.BlowpipeCharges + " scales and there are " + c.BlowpipeDarts + " Adamant Darts loaded into it.");
			if(c.DartType == 811)
				c.sendMessage("Your Toxic Blowpipe has "+ c.BlowpipeCharges + " scales and there are " + c.BlowpipeDarts + " Runite Darts loaded into it.");
			//if(c.DartType == 809)
				//c.sendMessage("Your Toxic Blowpipe has "+ c.BlowpipeCharges + " scales and there are " + c.BlowpipeDarts + " loaded into it.");
			break;
		case 11694:
			c.getItems().deleteItem(itemId, 1);
			c.getItems().addItem(11690, 1);
			c.getItems().addItem(11702, 1);
			c.sendMessage("You dismantle the godsword blade from the hilt.");
			break;
		case 11696:
			c.getItems().deleteItem(itemId, 1);
			c.getItems().addItem(11690, 1);
			c.getItems().addItem(11704, 1);
			c.sendMessage("You dismantle the godsword blade from the hilt.");
			break;
		case 11698:
			c.getItems().deleteItem(itemId, 1);
			c.getItems().addItem(11690, 1);
			c.getItems().addItem(11706, 1);
			c.sendMessage("You dismantle the godsword blade from the hilt.");
			break;
		case 11700:
			c.getItems().deleteItem(itemId, 1);
			c.getItems().addItem(11690, 1);
			c.getItems().addItem(11708, 1);
			c.sendMessage("You dismantle the godsword blade from the hilt.");
			break;
			
			case 11941:
			
				for (int ITEM = 0; ITEM < 28; ITEM++) {
					c.getPA().sendFrame34a(43710, c.playerItems[ITEM] - 1, ITEM, c.playerItemsN[ITEM]);
				}
			c.setSidebarInterface(3, 43700);
			break;
		case 13121:
		case 13122:
		case 13123:
		case 13124:
			c.getPA().handleArdyCloak(itemId);
			break;
		default:
			if (c.playerRights == 3)
				Misc.println(c.playerName + " - Item2ndOption: " + itemId);
			break;
		}

	}

}
