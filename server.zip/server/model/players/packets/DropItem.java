package server.model.players.packets;

import server.Config;
import server.Server;
import server.model.players.Client;
import server.model.players.Sound;
import server.model.players.skills.*;
import server.model.players.PacketType;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;

/**
 * Drop Item
 **/
public class DropItem implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int itemId = c.getInStream().readUnsignedWordA();
		c.getInStream().readUnsignedByte();
		c.getInStream().readUnsignedByte();
		int slot = c.getInStream().readUnsignedWordA();
		//c.getPA().sendSound(Sound.SOUND_LIST.ITEM_DROP.getSound(), 0, 10);
		if (System.currentTimeMillis() - c.alchDelay < 1800) {
			return;
		}
		if (c.arenas()) {
			c.sendMessage("You can't drop items inside the arena!");
			return;
		}
		if (c.inTrade) {
			c.sendMessage("You can't drop items while trading!");
			return;
		}
		SkillHandler.resetSkills(c);
		if (c.tutorialProgress < 36 && Config.TUTORIAL_ISLAND) {
			c.sendMessage("You can't drop items on tutorial island!");
			return;
		}
		/*if(itemId == 11941){
			c.getDH().sendDestroy("Looting Bag", "You will have to buy another", itemId);
			return;
		}*/
		boolean droppable = true;
		for (int i : Config.UNDROPPABLE_ITEMS) {
			if (i == itemId) {
				droppable = false;
				break;
			}
		}
		for (int p : Config.CAT_ITEMS) {
				if (p == itemId) {
				if(c.hasNpc == true) {
					droppable = false;
					break;
				}
			}
		}		
		switch(itemId) {
			
			case 11995:
			case 13178:
			case 13247:
			case 12643:
			case 12644:
			case 12645:
			case 12646:
			case 12647:
			case 12648:
			case 12649:
			case 12650:
			case 12651:
			case 12652:
			case 12653:
			case 12654:
			case 12655:
			case 19730:
			case 7583:
			case 7584:
			case 7585:
			case 1555:
			case 1556:
			case 1557:
			case 1558:
			case 1559:
			case 1560:
			case 1561:
			case 1562:
			case 1563:
			case 1564:
			case 1565:
			case 1566:
			case 12816:
						if (!c.hasNpc) {
							Server.npcHandler.spawnNpc3(c, Server.npcHandler.summonItemId(itemId), c.absX, c.absY-1, c.heightLevel, 0, 120, 25, 200, 200, true, false, true);
							c.getPA().followPlayer();
							c.getItems().deleteItem(itemId, slot, c.playerItemsN[slot]);
							c.hasNpc = true;
							//c.summonId = 2;
						} else
							return;
			break;
			
		}
		for (int i : Config.DESTROYABLE_ITEMS) {
			if (i == itemId) {
				c.DestroyID = itemId;
					c.getDH().sendDestroy(c.getItems().getItemName(itemId), c.getDH().sendDestroyDialogue(itemId), itemId);
				return;
			}
		}
		if (c.playerItemsN[slot] != 0 && itemId != -1
				&& c.playerItems[slot] == itemId + 1) {
			if (droppable) {
				Server.itemHandler.createGroundItem(c, itemId, c.getX(),
						c.getY(), c.getH(), c.playerItemsN[slot], c.getId());
				c.getItems().deleteItem(itemId, slot, c.playerItemsN[slot]);
				c.getPA().sendSound(Sound.SOUND_LIST.ITEM_DROP.getSound(), 0, 8);
		} else {
				c.sendMessage("This items cannot be dropped.");
			}
		}

	}
}
