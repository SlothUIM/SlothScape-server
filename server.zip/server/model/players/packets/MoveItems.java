package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;

/**
 * Move Items
 **/
public class MoveItems implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int somejunk = c.getInStream().readSignedWordBigEndianA(); // junk
		boolean insertMode = c.getInStream().readSignedByteC() == 1;
		int itemFrom = c.getInStream().readSignedWordBigEndianA();// slot1
		int itemTo = c.getInStream().readSignedWordBigEndian();// slot2
		// c.sendMessage("junk: " + somejunk);
		if (c.inTrade) {
			c.getTradeAndDuel().declineTrade();
			return;
		}
		if (c.tradeStatus == 1) {
			c.getTradeAndDuel().declineTrade();
			return;
		}
		if (c.duelStatus == 1) {
			c.getTradeAndDuel().declineDuel();
			return;
		}
		if(somejunk == 5)
			c.getItems().toTab(0, itemFrom);
		else if(somejunk == 13)
			c.getItems().toTab(1, itemFrom);
		else if(somejunk == 26)
			c.getItems().toTab(2, itemFrom);
		else if(somejunk == 39)
			c.getItems().toTab(3, itemFrom);
		else if(somejunk == 52)
			c.getItems().toTab(4, itemFrom);
		else if(somejunk == 65)
			c.getItems().toTab(5, itemFrom);
		else if(somejunk == 78)
			c.getItems().toTab(6, itemFrom);
		else if(somejunk == 91)
			c.getItems().toTab(7, itemFrom);
		else if(somejunk == 104)
			c.getItems().toTab(8, itemFrom);
		else 
		c.getItems().moveItems(itemFrom, itemTo, somejunk, insertMode);	
	}
}
