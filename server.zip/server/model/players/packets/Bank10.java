package server.model.players.packets;

import server.model.players.Client;
import server.model.players.PacketType;
import server.model.players.PriceChecker;

/**
 * Bank 10 Items
 **/
public class Bank10 implements PacketType {

	@Override
	public void processPacket(Client c, int packetType, int packetSize) {
		int interfaceId = c.getInStream().readUnsignedWordBigEndian();
		int removeId = c.getInStream().readUnsignedWordA();
		int removeSlot = c.getInStream().readUnsignedWordA();

				System.out.println("Bank10 "+interfaceId+"]: "+removeId);
		switch (interfaceId) {
		case 1688:
			c.getPA().useOperate(removeId);
			break;
			
			case -21826:
		case 43710:
		c.getItems().addtoLootbagFromDeposit(removeId, removeSlot, 10);
		break;
		case 41711:
		//if(c.addingToRP){
		for(int i = 0; i < 20; i++){
			if(removeId == c.RuneIDS[i]){
				c.getCharges().addRunes(removeId, removeSlot, 10);
				//c.openRunePouch();
			break;
			}
		}
		//}
		break;
		
		case 7423:
				c.getItems().bankItem(c.playerItems[removeSlot] , removeSlot, 10);
		break;
			case 43933:
			PriceChecker.withdrawItem(c, removeId, removeSlot, 1);
			break;
		case 3900:
			c.getShops().buyItem(removeId, removeSlot, 5);
			break;

		case 3823:
			c.getShops().sellItem(removeId, removeSlot, 5);
			break;

		case 5064:
			if (c.inTrade) {
				c.sendMessage("You can't store items while trading!");
				return;
			}
			if (removeId != -1){
				if(c.isBanking){
					c.getItems().bankItem(removeId, removeSlot, 10);
					//c.getPA().searchBank(c, c.searchTerm);
				} else if (c.isChecking) {
					PriceChecker.depositItem(c, removeId, 10);
				}	
			}
			break;

		case 5382:
			c.getItems().fromBank(removeId, removeSlot, 10);
			break;

		case 3322:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().tradeItem(removeId, removeSlot, 10);
			} else {
				c.getTradeAndDuel().stakeItem(removeId, removeSlot, 10);
			}
			break;

		case 3415:
			if (c.duelStatus <= 0) {
				c.getTradeAndDuel().fromTrade(removeId, removeSlot, 10);
			}
			break;

		case 6669:
			c.getTradeAndDuel().fromDuel(removeId, removeSlot, 10);
			break;

		case 1119:
		case 1120:
		case 1121:
		case 1122:
		case 1123:
			c.getSmithing().readInput(c, c.playerLevel[c.playerSmithing], removeId, 10);
			break;
		}
	}

}
