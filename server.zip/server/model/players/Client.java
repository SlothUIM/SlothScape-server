package server.model.players;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Future;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.text.DecimalFormat;
import server.model.players.packets.GeValuesCache;
import server.model.players.packets.Pair;

import org.apache.mina.common.IoSession;
import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;

import server.Config;
import server.Server;
import server.world.Boundary;
import server.model.items.ItemAssistant;
import server.model.shops.ShopAssistant;
import server.net.HostList;
import server.net.Packet;
import server.net.StaticPacketBuilder;
import server.util.Misc;
import server.util.Buffer;
import server.model.npcs.NPCHandler;
import server.model.content.STASH;
import server.model.players.skills.*;
import server.model.players.quests.*;
import server.model.objects.Gates;
import server.model.players.skills.mining.*;
import server.model.players.skills.smithing.*;
import server.model.players.skills.farming.*;
import server.model.players.skills.ProcessSkillGuides;
import server.model.players.skills.farming.Allotments;
import server.model.players.skills.farming.Bushes;
import server.model.players.skills.farming.Compost;
import server.model.players.skills.farming.Flowers;
import server.model.players.skills.farming.FruitTree;
import server.model.players.skills.farming.Herbs;
import server.model.players.skills.farming.Hops;
import server.model.players.skills.farming.ToolLeprechaun;
import server.model.players.skills.farming.SpecialPlantOne;
import server.model.players.skills.farming.SpecialPlantTwo;
import server.model.players.skills.farming.WoodTrees;
import server.model.players.skills.runecraft.Abyss;
import server.model.players.packets.ItemCharge;
import server.model.players.BankPin;
import server.model.players.packets.*;
import server.model.players.movements.ladders;
//import server.model.players.movements.GateHandler;
import server.event.EventManager;
import server.event.Event;
import server.event.EventHandler;
import server.event.EventContainer;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.items.CollectionLog;
import server.model.players.skills.agility.impl.*;
import server.model.players.skills.agility.*;
import server.model.players.skills.agility.impl.rooftop.*;

public class Client extends Player {

	public byte buffer[] = null;
	public Buffer inStream = null, outStream = null;
	private Channel session;
	private ItemAssistant itemAssistant = new ItemAssistant(this);
	//private GateHandler gateHandler = new GateHandler();
	private CycleEventContainer currentTask;
	private EventHandler currentEvent;
	private ShopAssistant shopAssistant = new ShopAssistant(this);
	private TradeAndDuel tradeAndDuel = new TradeAndDuel(this);
	private PlayerAssistant playerAssistant = new PlayerAssistant(this);
	private CombatAssistant combatAssistant = new CombatAssistant(this);
	private ActionHandler actionHandler = new ActionHandler(this);
	private Compost compost = new Compost(this);
	private Allotments allotment = new Allotments(this);
	private Flowers flower = new Flowers(this);
	private Herbs herb = new Herbs(this);
	private Hops hops = new Hops(this);
	private final BankPin bankPin = new BankPin(this);
	private Bushes bushes = new Bushes(this);
	private WoodTrees trees = new WoodTrees(this);
	private FruitTree fruitTrees = new FruitTree(this);
	private SpecialPlantOne specialPlantOne = new SpecialPlantOne(this);
	private SpecialPlantTwo specialPlantTwo = new SpecialPlantTwo(this);
	private ToolLeprechaun toolLeprechaun = new ToolLeprechaun(this);
	private DialogueHandler dialogueHandler = new DialogueHandler(this);
	private CollectionLog collectionLog = new CollectionLog(this);
	private ProcessSkillGuides SkillGuides = new ProcessSkillGuides(this);
	private NPCHandler npcHandler = new NPCHandler(this);
	private Gates gates = new Gates(this);
	private AchievementDiary achievementDiary = new AchievementDiary(this);
	private TeleTabs TeleTab = new TeleTabs(this);
	private ItemCharge itemcharge = new ItemCharge(this);
	private ladders ladder = new ladders(this);
	private Abyss abyss = new Abyss(this);
	private Queue<Packet> queuedPackets = new LinkedList<Packet>();
	private Potions potions = new Potions(this);
	private PotionMixing potionMixing = new PotionMixing(this);
	private Pets pets = new Pets();
	private Food food = new Food(this);
	/**
	 * Skill instances
	 */
	 
	 private AgilityHandler agilityHandler = new AgilityHandler();
	private GnomeAgility gnomeAgility = new GnomeAgility();
	private WildernessAgility wildernessAgility = new WildernessAgility();
	private Shortcuts shortcuts = new Shortcuts();
	private RooftopSeers rooftopSeers = new RooftopSeers();
	private RooftopFalador rooftopFalador = new RooftopFalador();
	private RooftopVarrock rooftopVarrock = new RooftopVarrock();
	private RooftopArdougne rooftopArdougne = new RooftopArdougne();
	private BarbarianAgility barbarianAgility = new BarbarianAgility();
	private Lighthouse lighthouse = new Lighthouse();
	private Agility agility = new Agility(this);
	
	private Slayer slayer = new Slayer(this);
	private Runecrafting runecrafting = new Runecrafting(this);
	private Woodcutting woodcutting = new Woodcutting(this);
	private Hunter hunt = new Hunter(this);
	private STASH stash = new STASH(this);
	private Cooking cooking = new Cooking(this);
	private Crafting crafting = new Crafting(this);
	private Prayer prayer = new Prayer(this);
	private Fletching fletching = new Fletching(this);
	private SmithingInterface smithInt = new SmithingInterface(this);
	private Thieving thieving = new Thieving(this);
	private Firemaking firemaking = new Firemaking(this);
	private Herblore herblore = new Herblore(this);
	private Mining mining = new Mining();
	private final Smithing smithing = new Smithing();
	public int lowMemoryVersion = 0;
	public int timeOutCounter = 0;
	public int returnCode = 2;
	//private Future<?> currentTask;

	public Client(Channel s, int _playerId, String name) {
		super(_playerId, name);
		this.session = s;
		synchronized (this) {
			outStream = new Buffer(new byte[Config.BUFFER_SIZE]);
			outStream.currentOffset = 0;
		}
		inStream = new Buffer(new byte[Config.BUFFER_SIZE]);
		inStream.currentOffset = 0;
		buffer = new byte[Config.BUFFER_SIZE];
	}

	public void flushOutStream() {
		if (disconnected || outStream.currentOffset == 0)
			return;
		synchronized (this) {
			StaticPacketBuilder out = new StaticPacketBuilder().setBare(true);
			byte[] temp = new byte[outStream.currentOffset];
			System.arraycopy(outStream.buffer, 0, temp, 0, temp.length);
			out.addBytes(temp);
			session.write(out.toPacket());
			outStream.currentOffset = 0;
		}
	}
	/**
	 * Outputs a send packet which is built from the data
	 * params provided towards a connected user client channel.
	 * @param id The identification number of the sound.
	 * @param volume The volume amount of the sound (1-100)
	 * @param delay The delay (0 = immediately 30 = 1/2cycle 60=full cycle) before
	 * the sound plays.
	 */

	/**
	 * Outputs a send packet which is built from the data
	 * params provided towards a connected user client channel.
	 * @param id The identification number of the sound.
	 * @param volume The volume amount of the sound (1-100)
	 */
	public void sendSound(int id, int volume) {
		c.getPA().sendSound(id, 6, 0, volume);
		
	}

	/**
	 * Outputs a send packet which is built from the data
	 * params provided towards a connected user client channel.
	 * @param id The identification number of the sound.
	 */
	public void sendSound(int id) {
		sendSound(id, 10);//pretty sure it's 100 just double check
		// otherwise it will be 1
	}

	public void sendClan(String name, String message, String clan, int rights) {
		outStream.createFrameVarSizeWord(217);
		outStream.writeString(name);
		outStream.writeString(message);
		outStream.writeString(clan);
		outStream.writeWord(rights);
		outStream.endFrameVarSize();
	}

	public static final int PACKET_SIZES[] = { 
			0, 0, 0, 1, -1, 0, 0, 0, 0, 0, // 0
			0, 0, 0, 0, 8, 0, 6, 2, 2, 0, // 10
			0, 2, 0, 6, 0, 12, 0, 0, 0, 0, // 20
			0, 0, 0, 0, 0, 8, 4, 0, 0, 2, // 30
			2, 6, 0, 6, 0, -1, 0, 0, 0, 0, // 40
			0, 0, 0, 12, 0, 0, 0, 8, 8, 12, // 50
			8, 8, 0, 0, 0, 0, 0, 0, 0, 0, // 60
			6, 0, 2, 2, 8, 6, 0, -1, 0, 6, // 70
			0, 0, 0, 0, 0, 1, 4, 6, 0, 0, // 80
			0, 0, 0, 0, 0, 3, 0, 0, -1, 0, // 90
			0, 13, 0, -1, 0, 0, 0, 0, 0, 0,// 100
			0, 0, 0, 0, 0, 0, 0, 6, 0, 0, // 110
			1, 0, 6, 0, 0, 0, -1, 0, 2, 6, // 120
			0, 4, 6, 8, 4, 6, 0, 0, 6, 2, // 130
			0, 0, 0, 0, 0, 6, 0, 0, 0, 0, // 140
			0, 0, 1, 2, 0, 2, 6, 0, 0, 0, // 150
			0, 0, 0, 0, -1, -1, 0, 0, 0, 0,// 160
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 170
			0, 8, 0, 3, 0, 2, 0, 0, 8, 1, // 180
			0, 0, 12, 0, 0, 0, 0, 0, 0, 0, // 190
			2, 0, 0, 0, 0, 0, 0, 0, 4, 0, // 200
			4, 0, 0, 0, 7, 8, 0, 0, 10, 0, // 210
			0, 0, 0, 0, 0, 0, -1, 0, 6, 0, // 220
			1, 0, 0, 0, 6, 0, 6, 8, 1, 0, // 230
			0, 4, 0, 0, 0, 0, -1, 0, -1, 4,// 240
			0, 0, 6, 6, 0, 0, 0 // 250
	};

	public void destruct() {
		if (session == null)
			return;
		// PlayerSaving.getSingleton().requestSave(playerId);
		
		getPA().removeFromCW();
		if (inPits)
			Server.fightPits.removePlayerFromPits(playerId);
		if (clanId >= 0)
			Server.clanChat.leaveClan(playerId, clanId);
		Misc.println("[DEREGISTERED]: " + playerName + "");
		HostList.getHostList().remove(session);
		CycleEventHandler.getSingleton().stopEvents(this);
		PriceChecker.clearConfig(this);
		disconnected = true;
		session.close();
		session = null;
		inStream = null;
		outStream = null;
		isActive = false;
		buffer = null;
		super.destruct();
	}

	public void sendMessage(String s) {
		synchronized (this) {
			if (getOutStream() != null) {
				outStream.createFrameVarSize(253);
				outStream.writeString(s);
				outStream.endFrameVarSize();
			}
		}
	}

		public static int THICK_SKIN = 0, BURST_OF_STRENGTH = 1, CLARITY_OF_THOUGHT = 2, SHARP_EYE = 3, MYSTIC_WILL = 4, ROCK_SKIN = 5,
		SUPERHUMAN_STRENGTH = 6, IMPROVED_REFLEXES = 7, RAPID_RESTORE = 8, RAPID_HEAL = 9, PROTECT_ITEM = 10, HAWK_EYE = 11,
		MYSTIC_LORE = 12, STEEL_SKIN = 13, ULTIMATE_STRENGTH = 14, INCREDIBLE_REFLEXES = 15, PROTECT_FROM_MAGIC = 16,
		PROTECT_FROM_MISSLES = 17, PROTECT_FROM_MELEE = 18, EAGLE_EYE = 19, MYSTIC_MIGHT = 20, RETRIBUTION = 21, REDEMPTION = 22,
		SMITE = 23, CHIVALRY = 24, PIETY = 25, RAPID_RENEWAL = 26, RIGOUR = 27, AUGURY = 28;
	public void setSidebarInterface(int menuId, int form) {
		synchronized (this) {
			if (getOutStream() != null) {
				outStream.createFrame(71);
				outStream.writeWord(form);
				outStream.writeByteA(menuId);
			}
		}
	}
	public boolean hideRoofs;
	public boolean ScrollWheel;
	public boolean transChat;
	public boolean fogToggle;
	public boolean smoothshading;
	public boolean dataorbs;
	public int CollLogOpen = 0;
	public void initialize() {
		synchronized (this) {
			accountFlagged = getPA().checkForFlags();
		if (getOutStream() != null) {
			outStream.createFrame(249);
			outStream.writeByteA(1); // 1 for members, zero for free
			outStream.writeWordBigEndianA(playerId);
			for (int j = 0; j < PlayerHandler.players.length; j++) {
				if (j == playerId)
					continue;
				if (PlayerHandler.players[j] != null) {
					if (PlayerHandler.players[j].playerName.equalsIgnoreCase(playerName)){
						disconnected = true;
					}
				}
			}
		}
				
			
		if (hasNpc == true || this.summonId > 0) {
			if (summonId > 0) {
				Server.npcHandler.spawnNpc3(this, summonId, absX, absY-1, heightLevel, 0, 120, 25, 200, 200, true, false, true);
				this.sendMessage("Your pet is now following you");
			}
		}
		if (tutorialProgress > 0 && tutorialProgress < 36 && Config.TUTORIAL_ISLAND) {
			sendMessage("@blu@Continue the tutorial from the last step you were on.@bla@");
		}
		if (tutorialProgress > 35) {
			sendSidebars();
			//Weight.updateWeight(player);
			sendMessage("Welcome to @blu@" + Config.SERVER_NAME + "@bla@ - we are currently on v@blu@" + Config.CLIENT_VERSION + "@bla@.");
			/*if (!hasBankpin) { //Kind of annoying. Maybe add Random % 10 or something.
				getActionSender().sendMessage("You do not have a bank pin it is highly recommended you set one.");
			}*/
			getAD().loadAchievementProgress();
		}
		
							c.getPA().sendConfig(299, EleWorkshopWater_stage << 3);
			getPA().firstTimeTutorial();
			QuestAssistant.sendStages(c);
			getItems().sendWeapon(playerEquipment[playerWeapon], getItems().getItemName(playerEquipment[playerWeapon]));
			for (int i = 0; i < 25; i++) {
				getPA().setSkillLevel(i, playerLevel[i], playerXP[i]);
				getPA().refreshSkill(i);
			}
			for (int p = 0; p < PRAYER.length; p++) { // reset prayer glows
				prayerActive[p] = false;
				getPA().sendFrame36(PRAYER_GLOW[p], 0);
			}
			if (inWild()) {
				wildernessWarning = true;
			}
			if (isRunning2) {
				getPA().sendConfig(504, 1);
				getPA().sendConfig(173, 1);
			} else {
				getPA().sendConfig(504, 0);
				getPA().sendConfig(173, 0);
			}
			
			getPA().sendRuneTypes(PouchRune1, PouchRune2, PouchRune3, PouchRune1Amt,PouchRune2Amt,PouchRune3Amt);
			if(PouchRune1 > 0)
				c.getPA().sendFrame34a(41710, PouchRune1, 0, PouchRune1Amt);
			if(PouchRune2 > 0)
				c.getPA().sendFrame34a(41710, PouchRune2, 1, PouchRune2Amt);
			if(PouchRune3 > 0)
				c.getPA().sendFrame34a(41710, PouchRune3, 2, PouchRune3Amt);
			getPA().LoginInfo(15, 14, 1, 1, 1, PlayerHandler.getPlayerCount());
			getPA().sendCrashFrame();
			getPA().sendFrame126(getCollectionLog().getAllLogsTotal() +"/447" , 55810);
			loadSlayerInterfaceText();
			getPA().handleWeaponStyle();
			getPA().sendFrame36(108, 0);// resets autocast button
			getPA().sendFrame107(); // reset screen
			getPA().setChatOptions(0, 0, 0); // reset private messaging options
			getPA().showOption(4, 0,"Follow", 4);
			getPA().showOption(5, 0,"Trade With", 3);
			getItems().resetItems(3214);
			getItems().resetBonus();
			getItems().getBonus();
			getItems().writeBonus();
			getItems().setEquipment(playerEquipment[playerHat], 1, playerHat);
			getItems().setEquipment(playerEquipment[playerCape], 1, playerCape);
			getItems().setEquipment(playerEquipment[playerAmulet], 1, playerAmulet);
			getItems().setEquipment(playerEquipment[playerArrows], playerEquipmentN[playerArrows], playerArrows);
			getItems().setEquipment(playerEquipment[playerChest], 1, playerChest);
			getItems().setEquipment(playerEquipment[playerShield], 1, playerShield);
			getItems().setEquipment(playerEquipment[playerLegs], 1, playerLegs);
			getItems().setEquipment(playerEquipment[playerHands], 1, playerHands);
			getItems().setEquipment(playerEquipment[playerFeet], 1, playerFeet);
			getItems().setEquipment(playerEquipment[playerRing], 1, playerRing);
			getItems().setEquipment(playerEquipment[playerWeapon], playerEquipmentN[playerWeapon], playerWeapon);
			getCombat().getPlayerAnimIndex(getItems().getItemName(playerEquipment[playerWeapon]).toLowerCase());
			getPA().logIntoPM();
			getItems().addSpecialBar(playerEquipment[playerWeapon]);
			saveTimer = Config.SAVE_TIMER;
			saveCharacter = true;
			Misc.println("[REGISTERED]: " + playerName + "");
			handler.updatePlayer(this, outStream);
			handler.updateNPC(this, outStream);
			flushOutStream();
			getPA().clearClanChat();
			getPA().resetFollow();
			getPA().sendAutoRetalitate();
		}
	}

	public void update() {
		synchronized (this) {
			handler.updatePlayer(this, outStream);
			handler.updateNPC(this, outStream);
			flushOutStream();
		}
	}
		public void sendSidebars(){
			setSidebarInterface(0, 2423);
			setSidebarInterface(1, -1);
			setSidebarInterface(2, 27101);
			setSidebarInterface(3, 3213);
			setSidebarInterface(4, 1644);
			setSidebarInterface(5, 5608);
			if (playerMagicBook == 0) {
				setSidebarInterface(6, 1151); // modern
			} else {
				if (playerMagicBook == 2) {
					setSidebarInterface(6, 29999); // lunar
				} else {
					setSidebarInterface(6, 12855); // ancient
				}
			}
			correctCoordinates();
			setSidebarInterface(7, 18128);
			setSidebarInterface(8, 5065);
			setSidebarInterface(9, 5715);
			setSidebarInterface(10, 2449);//logout
			setSidebarInterface(11, 904); // settings tab
			setSidebarInterface(12, 147); // emote tab
			setSidebarInterface(13, 50020); //music
			Music.refreshPlaylist(this, false);
			if(characterSummaryTab == 0)
				setSidebarInterface(14, 55790);
			else if(characterSummaryTab == 1)
				setSidebarInterface(14, 638);
			else if(characterSummaryTab == 2)
				setSidebarInterface(14, 54670);
			else
				setSidebarInterface(14, 54670);
			getPA().sendFrame36(208, characterSummaryTab);
			//getPA().sendFrame36(287, isFixed);
			setSidebarInterface(15, -1);
		}
	public void logout() {
		synchronized (this) {
			CycleEventHandler.getSingleton().stopEvents(this);
				if (hasNpc == true)
					getPets().pickUpClean(this, summonId);
			if (System.currentTimeMillis() - logoutDelay > 10000) {
				PriceChecker.clearConfig(this);
				outStream.createFrame(109);
				properLogout = true;
			} else {
				sendMessage("You must wait a few seconds from being out of combat to logout.");
			}
		}
	}	
	public static void deleteTime(Client c) {
		c.doAmount--;
	}
public void homeTeleport(int x, int y, int h) {
			if (homeTele == 18) {
				startAnimation(1722);
			} else if (homeTele == 17) {
				startAnimation(1723);gfx0(800);				
			} else if (homeTele == 16) {
				startAnimation(1724);gfx0(801);	
			} else if (homeTele == 15) {
				startAnimation(1725);gfx0(802);		
			} else if (homeTele == 14) {
				startAnimation(2798);gfx0(1703);	
			} else if (homeTele == 13) {
				startAnimation(2799);gfx0(1704);				
			} else if (homeTele == 12) {
				startAnimation(2800);gfx0(1704);				
			} else if (homeTele == 11) {
				startAnimation(3195);gfx0(1704);			
			} else if (homeTele == 10) {
				startAnimation(4643);gfx0(1705);			
			} else if (homeTele == 9) {
				startAnimation(4645);gfx0(1706);
			} else if (homeTele == 8) {
				startAnimation(4646);gfx0(1707);			
			} else if (homeTele == 7) {
				startAnimation(4847);gfx0(1708);		
			} else if (homeTele == 6) {
				startAnimation(4848);gfx0(1709);		
			} else if (homeTele == 5) {
				startAnimation(4849);gfx0(1710);
			} else if (homeTele == 4) {
				startAnimation(4850);gfx0(1711);
			} else if (homeTele == 3) {
				startAnimation(4851);gfx0(1712);
			} else if (homeTele == 2) {
				startAnimation(4852);gfx0(1713);
			} else if (homeTele == 1) {
				homeTeleWaitTimer = 30000;
				LasthomeTele = System.currentTimeMillis();
				homeTele = 0;
				teleportToX = x;
				teleportToY = y;
				heightLevel = h;
			}
		}
			public int packetSize = 0, packetType = -1;
			public int donatorPoints = 0;
			public int[] RuneIDS = {554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 9075, 4694, 4695, 4696, 4697, 4698, 4699, 7936};
			public void openRunePouch(){
								c.getPA().sendFrame34a(41710, -1, 0, 1);
						c.getPA().sendFrame34a(41710, -1, 1, 1);
						c.getPA().sendFrame34a(41710, -1, 2, 1);
				if(c.PouchRune1 > 0)
					c.getPA().sendFrame34a(41710, c.PouchRune1, 0, c.PouchRune1Amt);
				if(c.PouchRune2 > 0)
					c.getPA().sendFrame34a(41710, c.PouchRune2, 1, c.PouchRune2Amt);
				if(c.PouchRune3 > 0)
					c.getPA().sendFrame34a(41710, c.PouchRune3, 2, c.PouchRune3Amt);
				int[] shiftedItems = new int[28];
				int[] shiftedItemsN = new int[28];
				int emptySlot = -1;

				for (int ITEM = 0; ITEM < 28; ITEM++) {
					if (c.playerItems[ITEM] - 1 > 0) {
							shiftedItems[ITEM] = c.playerItems[ITEM];
							shiftedItemsN[ITEM] = c.playerItemsN[ITEM];
					c.getPA().sendFrame34a(41711, -1, ITEM, 1);
					}/* else {
							shiftedItems[ITEM] = c.playerItems[ITEM];
							shiftedItemsN[ITEM] = c.playerItemsN[ITEM];
					}*/
					
					c.getPA().sendFrame34a(41711, shiftedItems[ITEM] - 1, ITEM, shiftedItemsN[ITEM]);
					c.getPA().sendFrame34a(42710, shiftedItems[ITEM] - 1, ITEM, shiftedItemsN[ITEM]);
				}
				c.getPA().showInterface(41700);
			}
			public void handleTeleportRunes(int RuneId1, int RuneId2, int RuneId3, int amt1, int amt2, int amt3, int TeleX, int TeleY) {
				if (hasRuneInPouch(RuneId1, RuneId2, RuneId3)) {
					updatePouchRuneCount(RuneId1, amt1, RuneId2, amt2, RuneId3, amt3);
					c.getPA().startTeleport(TeleX, TeleY, 0, "modern");
				} else if (c.getItems().playerHasItem(RuneId1, amt1) && c.getItems().playerHasItem(RuneId2, amt2) && c.getItems().playerHasItem(RuneId3, amt3)) {
					c.getItems().deleteItem(RuneId1, c.getItems().getItemSlot(RuneId1), amt1);
					c.getItems().deleteItem(RuneId2, c.getItems().getItemSlot(RuneId2), amt2);
					c.getItems().deleteItem(RuneId3, c.getItems().getItemSlot(RuneId3), amt3);
					c.getPA().startTeleport(TeleX, TeleY, 0, "modern");
				}
			}

			private boolean hasRuneInPouch(int... runeIds) {
				return PouchRune1 > 0 && (PouchRune1 == runeIds[0] || PouchRune1 == runeIds[1] || PouchRune1 == runeIds[2])
					|| PouchRune2 > 0 && (PouchRune2 == runeIds[0] || PouchRune2 == runeIds[1] || PouchRune2 == runeIds[2])
					|| PouchRune3 > 0 && (PouchRune3 == runeIds[0] || PouchRune3 == runeIds[1] || PouchRune3 == runeIds[2]);
			}

			private void updatePouchRuneCount(int RuneId1, int amt1, int RuneId2, int amt2, int RuneId3, int amt3) {
				int[] pouchRunes = {PouchRune1, PouchRune2, PouchRune3};
				int[] pouchRuneAmts = {PouchRune1Amt, PouchRune2Amt, PouchRune3Amt};

				for (int i = 0; i < pouchRunes.length; i++) {
					if (pouchRunes[i] == RuneId1) {
						pouchRuneAmts[i] -= amt1;
						break;
					} else if (pouchRunes[i] == RuneId2) {
						pouchRuneAmts[i] -= amt2;
						break;
					} else if (pouchRunes[i] == RuneId3) {
						pouchRuneAmts[i] -= amt3;
						break;
					}
				}

				// Update the pouch rune amounts
				PouchRune1Amt = pouchRuneAmts[0];
				PouchRune2Amt = pouchRuneAmts[1];
				PouchRune3Amt = pouchRuneAmts[2];
			}
	public static int totalEXP;
	public static long CollLogTimer;
	public static boolean newCollItem = false;
	private long cacheExpirationTime = 4 * 60 * 60 * 1000; // 4 hours in milliseconds
	public long remainingTime;
	public void loadSlayerInterfaceText(){
				if(c.slayerTask > 0)
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.slayerTask)+"  x"+c.taskAmount, 48809);
					else
						c.getPA().sendFrame126("You have no task to block", 48809);
					for(int i = 0; i < 6; i++)
						c.getPA().sendFrame126(Server.npcHandler.getNpcListName(c.BlockID[i]), 48818+i);
				if(c.slayerPoints >= 50){
					c.getPA().sendFrame126("will be a bigger task @gre@(50 points)" , 57718);
				} 
				if(c.slayerPoints >= 75){
					c.getPA().sendFrame126("be a bigger task @gre@(75 points)" , 57732);
				} 
				if(c.slayerPoints >= 120){
					c.getPA().sendFrame126("will be a bigger task @gre@(120 points)" , 57722);
				} 
				if(c.slayerPoints >= 100){
					c.getPA().sendFrame126("will be a bigger task @gre@(100 points)" , 57712);
					c.getPA().sendFrame126("a bigger task @gre@(100 points)" , 57714);
					c.getPA().sendFrame126("a bigger task @gre@(100 points)" , 57716);
					c.getPA().sendFrame126("Dragon task, it will be bigger. @gre@(100 points)" , 57720);
					c.getPA().sendFrame126("task, it will a bigger task @gre@(100 points)" , 57724);
					c.getPA().sendFrame126("be a bigger task @gre@(100 points)" , 57726);
					c.getPA().sendFrame126("it will be a bigger task @gre@(100 points)" , 57728);
					c.getPA().sendFrame126("will be a bigger task @gre@(100 points)" , 57730);
					c.getPA().sendFrame126("task, it will be a bigger task @gre@(100 points)" , 57734);
					c.getPA().sendFrame126("will be a bigger task @gre@(100 points)" , 57736);
					c.getPA().sendFrame126("a bigger task @gre@(100 points)" , 57738);
					c.getPA().sendFrame126("it will be a bigger task @gre@(100 points)" , 57740);
					c.getPA().sendFrame126("be a bigger task @gre@(100 points)" , 57742);
					c.getPA().sendFrame126("be a bigger task @gre@(100 points)" , 57744);
					c.getPA().sendFrame126("it will be a bigger task @gre@(100 points)" , 57746);
				} else if(c.slayerPoints < 100){
					c.getPA().sendFrame126("will be a bigger task @red@(100 points)" , 57712);
					c.getPA().sendFrame126("a bigger task @red@(100 points)" , 57714);
					c.getPA().sendFrame126("a bigger task @red@(100 points)" , 57716);
					c.getPA().sendFrame126("Dragon task, it will be bigger. @red@(100 points)" , 57720);
					c.getPA().sendFrame126("task, it will a bigger task @red@(100 points)" , 57724);
					c.getPA().sendFrame126("be a bigger task @red@(100 points)" , 57726);
					c.getPA().sendFrame126("it will be a bigger task @red@(100 points)" , 57728);
					c.getPA().sendFrame126("will be a bigger task @red@(100 points)" , 57730);
					c.getPA().sendFrame126("task, it will be a bigger task @red@(100 points)" , 57734);
					c.getPA().sendFrame126("will be a bigger task @red@(100 points)" , 57736);
					c.getPA().sendFrame126("a bigger task @red@(100 points)" , 57738);
					c.getPA().sendFrame126("it will be a bigger task @red@(100 points)" , 57740);
					c.getPA().sendFrame126("be a bigger task @red@(100 points)" , 57742);
					c.getPA().sendFrame126("be a bigger task @red@(100 points)" , 57744);
					c.getPA().sendFrame126("it will be a bigger task @red@(100 points)" , 57746);
				} 
				if(c.slayerPoints < 50){
					c.getPA().sendFrame126("will be a bigger task @red@(50 points)" , 57718);
				} 
				if(c.slayerPoints < 120){
					c.getPA().sendFrame126("will be a bigger task @red@(120 points)" , 57722);
				} 
				if(c.slayerPoints < 75){
					c.getPA().sendFrame126("be a bigger task @red@(75 points)" , 57732);
				}
					c.getPA().sendFrame126("Whenever you get an Ankou task, it will be" , 57713);
					c.getPA().sendFrame126("Whenever you get a Suqah task, it will be" , 57715);
					c.getPA().sendFrame126("Whenever you get a Black Dragon task, it" , 57717);
					c.getPA().sendFrame126("Whenever you get a Bronze, Iron or steel" , 57719);
					c.getPA().sendFrame126("Whenever you get a Mithril Dragon task, it" , 57721);
					c.getPA().sendFrame126("Whenever you get a Spiritual Creature" , 57723);
					c.getPA().sendFrame126("Whenever you get an Aviansie task, it will" , 57725);
					c.getPA().sendFrame126("Whenever you get a Greater Demon task," , 57727);
					c.getPA().sendFrame126("Whenever you get a Black Demon task, it" , 57729);
					c.getPA().sendFrame126("Whenever you get a Bloodveld task, it will" , 57731);
					c.getPA().sendFrame126("Whenever you get an Aberrant Spectre" , 57733);
					c.getPA().sendFrame126("Whenever you get a Cave Horror task, it" , 57735);
					c.getPA().sendFrame126("Whenever you get a Dusk Devil task, it will" , 57737);
					c.getPA().sendFrame126("Whenever you get a Skeletal Wyvern task," , 57739);
					c.getPA().sendFrame126("Whenever you get a Gargoyle task, it will" , 57741);
					c.getPA().sendFrame126("Whenever you get a Nechryael task, it will" , 57743);
					c.getPA().sendFrame126("Whenever you get an Abyssal Demon task," , 57745);
					c.getPA().sendFrame126("Whenever you get a Cave Kraken task, it" , 57747);
					c.getPA().sendFrame126(""+c.slayerPoints, 48505);
	}
	public void open(){
			//for (int ITEM = 0; ITEM < 28; ITEM++) {
					
					//c.getPA().sendFrame34a(41711, c.playerItems[ITEM] - 1, ITEM, c.playerItemsN[ITEM]);
				//}
	}
	public static void test() {
		//anIntArray1019 = new int[99];
		int i = 0;
		//for(int j = 0; j < 99; j++) {
			//int l = j + 1;
			//int i1 = (int)((double)l + 300D * Math.pow(2D, (double)l / 7D));
			//i += i1;
			//anIntArray1019[j] = i / 4;
		//}
		anIntArray1232 = new int[32];
		i = 2;
		for(int k = 0; k < 32; k++) {
			anIntArray1232[k] = i - 1;
			i += i;
		}
	}
	public static int variousSettings[];
	public static int anIntArray1232[];
	public void process() {
			if(System.currentTimeMillis() - GeValuesCache.lastPriceUpdate > cacheExpirationTime) {
				GeValuesCache.loadGePricesCache();
			}
			Farming.processCalc(c);
		if(MeleeTutorClaimed) {	
			if(LastMeleeTutorClaimed > 0) {
				LastMeleeTutorClaimed--;
			}
			if(System.currentTimeMillis() - LastMeleeTutorClaimed > 1000){
				LastMeleeTutorClaimed = 0;
				MeleeTutorClaimed = false;
			}
		}
		//if(absX == 3080 && absY == 3490)
			//c.getPA().sendAreaSound(int id, 0, 10);
		if(MagicTutorClaimed) {
			if(LastMagicTutorClaimed > 0) {
				LastMagicTutorClaimed--;
			}
			if(System.currentTimeMillis() - LastMagicTutorClaimed > 1000){
				LastMagicTutorClaimed = 0;
				MagicTutorClaimed = false;
			}
		}
		if(RangedTutorClaimed) {
			if(LastRangedTutorClaimed > 0) {
				LastRangedTutorClaimed--;
			}
			if(System.currentTimeMillis() - LastRangedTutorClaimed > 1000){
				LastRangedTutorClaimed = 0;
				RangedTutorClaimed = false;
			}	
		}
		if(CollLogTimer > 0 && newCollItem){
				getPA().CollLogPopUp();
		}
		if (isRunning2 == true){
			isRunning = true;
		}
		if (isRunning2 == false){
			isRunning = false;
		}
			if (homeTeleWaitTimer > 0){			
				long currentTime = System.currentTimeMillis();
				long elapsedTime = currentTime - LasthomeTele;
		
					while (elapsedTime >= 1000) {
						homeTeleWaitTimer -= 1000;
						elapsedTime -= 1000;
						LasthomeTele += 1000;
					}
					getPA().sendAreaSound(202, 0, 8);
					int Minutes = (int) (homeTeleWaitTimer / (60 * 1000));
					int Seconds = (int) ((homeTeleWaitTimer / 1000) % 60);
					String timerString = String.format("%02d:%02d", Minutes, Seconds);
					getPA().sendFrame126(timerString, 48658);
			}
			if (homeTele > 0 && homeTeleWaitTimer <= 0){
				homeTeleport(3087,3496, 0);
				homeTele--;
			}
		if (System.currentTimeMillis() - lastPoison > 20000 && poisonDamage > 0) {
			int damage = poisonDamage / 2;
			if (damage > 0) {
				sendMessage("Applying poison damage.");

				if (!getHitUpdateRequired()) {
					setHitUpdateRequired(true);
					setHitDiff(damage);
					updateRequired = true;
					poisonMask = 1;
				} else if (!getHitUpdateRequired2()) {
					setHitUpdateRequired2(true);
					setHitDiff2(damage);
					updateRequired = true;
					poisonMask = 2;
				}
						
				lastPoison = System.currentTimeMillis();		
				poisonDamage--;
				dealDamage(damage);
			} else {
				poisonDamage = -1;
				sendMessage("You are no longer poisoned.");
			}
		}	
			
		if(c.poisonImmunity > 0){
			long currentTime = System.currentTimeMillis();
			long elapsedTime = currentTime - lastUpdateTime;
    
				while (elapsedTime >= 1000) {
					poisonImmunity -= 1000;
					elapsedTime -= 1000;
					lastUpdateTime += 1000;
				}
				remainingMinutes = (int) (poisonImmunity / (60 * 1000));
				remainingSeconds = (int) ((poisonImmunity / 1000) % 60);
				timerString = String.format("%02d:%02d", remainingMinutes, remainingSeconds);
				if(remainingMinutes > 1 && remainingSeconds >= 0)
						getPA().sendFrame126(timerString, 48654);
				if(remainingMinutes == 0 && remainingSeconds > 30)
						getPA().sendFrame126("@yel@"+timerString, 48654);
				if(remainingMinutes == 0 && remainingSeconds <= 30)
						getPA().sendFrame126("@red@"+timerString, 48654);
				if(remainingMinutes == 1 && remainingSeconds == 0){
						sendMessage("Your poison immunity is going to expire in 1 minute.");
				} else if(remainingMinutes == 0 && remainingSeconds == 30){
						sendMessage("Your poison immunity is going to expire in 30 seconds.");
				} else if(remainingMinutes == 0 && remainingSeconds == 0){
						getPA().sendFrame126("0", 48654);
						sendMessage("Your poison immunity has expired.");
						poisonImmunity = 0;
				}
		} else
			c.getPA().sendFrame126("0", 48654);
		if(vengOn){
			if(VengTimer > 0){
			long currentTime = System.currentTimeMillis();
			long elapsedTime = currentTime - lastVeng;
    
				while (elapsedTime >= 1000) {
					VengTimer -= 1000;
					elapsedTime -= 1000;
					lastVeng += 1000;
				}
				int VengMinutes = (int) (VengTimer / (60 * 1000));
				int VengSeconds = (int) ((VengTimer / 1000) % 60);
				String VengtimerString = String.format("%02d:%02d", VengMinutes, VengSeconds);
				getPA().sendFrame126(VengtimerString, 48656);
				if(VengMinutes == 0 && VengSeconds == 0){
						c.getPA().sendFrame126("0", 48656);
						sendMessage("Your poison immunity has expired.");
						c.VengTimer = 0;
				}
			}
		} else 
			getPA().sendFrame126("0", 48656);
		if (System.currentTimeMillis() - duelDelay > 800 && duelCount > 0) {
			if (duelCount != 1) {
				forcedChat("" + (--duelCount));
				duelDelay = System.currentTimeMillis();
			} else {
				damageTaken = new int[Config.MAX_PLAYERS];
				forcedChat("FIGHT!");
				duelCount = 0;
			}
		}

		if (System.currentTimeMillis() - specDelay > Config.INCREASE_SPECIAL_AMOUNT) {
			specDelay = System.currentTimeMillis();
			if (specAmount < 10) {
				specAmount += .5;
				if (specAmount > 10)
					specAmount = 10;
				getItems().addSpecialBar(playerEquipment[playerWeapon]);
			}
		}

		if (clickObjectType > 0
				&& goodDistance(objectX + objectXOffset, objectY
						+ objectYOffset, getX(), getY(), objectDistance)) {
			if (clickObjectType == 1) {
				getActions().firstClickObject(objectId, objectX, objectY);
			}
			if (clickObjectType == 2) {
				getActions().secondClickObject(objectId, objectX, objectY);
			}
			if (clickObjectType == 3) {
				getActions().thirdClickObject(objectId, objectX, objectY);
			}
		}

		if ((clickNpcType > 0) && NPCHandler.npcs[npcClickIndex] != null) {
			if (goodDistance(getX(), getY(),
					NPCHandler.npcs[npcClickIndex].getX(),
					NPCHandler.npcs[npcClickIndex].getY(), 1)) {
				if (clickNpcType == 1) {
					turnPlayerTo(NPCHandler.npcs[npcClickIndex].getX(),
							NPCHandler.npcs[npcClickIndex].getY());
					NPCHandler.npcs[npcClickIndex].facePlayer(playerId);
					getActions().firstClickNpc(npcType);
				}
				if (clickNpcType == 2) {
					turnPlayerTo(NPCHandler.npcs[npcClickIndex].getX(),
							NPCHandler.npcs[npcClickIndex].getY());
					NPCHandler.npcs[npcClickIndex].facePlayer(playerId);
					getActions().secondClickNpc(npcType);
				}
				if (clickNpcType == 3) {
					turnPlayerTo(NPCHandler.npcs[npcClickIndex].getX(),
							NPCHandler.npcs[npcClickIndex].getY());
					NPCHandler.npcs[npcClickIndex].facePlayer(playerId);
					getActions().thirdClickNpc(npcType);
				}
			}
		}

		if (walkingToItem) {
			if (getX() == pItemX && getY() == pItemY
					|| goodDistance(getX(), getY(), pItemX, pItemY, 1)) {
				walkingToItem = false;
				Server.itemHandler.removeGroundItem(this, pItemId, pItemX,
						pItemY, true);
			}
		}

		if (followId > 0) {
			getPA().followPlayer();
		} else if (followId2 > 0) {
			getPA().followNpc();
		}

	if (PlayerHandler.players[playerId] != null) { 
		final Client c = (Client)PlayerHandler.players[playerId];
		getCombat();
		CombatAssistant.handlePrayerDrain(c);
	}
		if (System.currentTimeMillis() - singleCombatDelay > 3300) {
			underAttackBy = 0;
		}
		if (System.currentTimeMillis() - singleCombatDelay2 > 3300) {
			underAttackBy2 = 0;
		}
			long lastRestore = System.currentTimeMillis();
			
		if (System.currentTimeMillis() - restoreStatsDelay > 60000) {
			restoreStatsDelay = lastRestore;
			
			for (int level = 0; level < playerLevel.length; level++) {
				if (playerLevel[level] < getLevelForXP(playerXP[level])) {
					if (level != 5) { // prayer doesn't restore
						playerLevel[level] += 1;
						getPA().setSkillLevel(level, playerLevel[level],
								playerXP[level]);
						getPA().refreshSkill(level);
					}
				} else if (playerLevel[level] > getLevelForXP(playerXP[level])) {
					playerLevel[level] -= 1;
					getPA().setSkillLevel(level, playerLevel[level],
							playerXP[level]);
					getPA().refreshSkill(level);
				}
			}
		}
			long remainingTime1 = (60000 - (lastRestore - restoreStatsDelay)) / 1000;
			String restoreDelay = String.format("%02d", remainingTime1);
			c.getPA().sendFrame126(restoreDelay, 48668);
		if (System.currentTimeMillis() - teleGrabDelay > 1550 && usingMagic) {
			usingMagic = false;
			if (Server.itemHandler.itemExists(teleGrabItem, teleGrabX,
					teleGrabY)) {
				Server.itemHandler.removeGroundItem(this, teleGrabItem,
						teleGrabX, teleGrabY, true);
			}
		}

		
		if (!hasMultiSign && (Boundary.isIn(this, Boundary.MULTI) || inMulti())) {
			hasMultiSign = true;
			getPA().multiWay(1);
		}

		if (hasMultiSign  && (!Boundary.isIn(this, Boundary.MULTI) || !inMulti())) {
			hasMultiSign = false;
			getPA().multiWay(-1);
		}

		if (skullTimer > 0) {
			skullTimer--;
			if (skullTimer == 1) {
				isSkulled = false;
				attackedPlayers.clear();
				headIconPk = -1;
				skullTimer = -1;
				getPA().requestUpdates();
			}
		}

		if (isDead && respawnTimer == -6) {
			getPA().applyDead();
		}

		if (respawnTimer == 7) {
			respawnTimer = -6;
			getPA().giveLife();
		} else if (respawnTimer == 12) {
			respawnTimer--;
			startAnimation(0x900);
			poisonDamage = -1;
		}

		if (respawnTimer > -6) {
			respawnTimer--;
		}
		if (freezeTimer > -6) {
			freezeTimer--;
			c.getPA().sendFrame126("00:"+freezeTimer, 48662);
			if (frozenBy > 0) {
				if (PlayerHandler.players[frozenBy] == null) {
					freezeTimer = -1;
					frozenBy = -1;
				} else if (!goodDistance(absX, absY,
						PlayerHandler.players[frozenBy].absX,
						PlayerHandler.players[frozenBy].absY, 20)) {
					freezeTimer = -1;
					frozenBy = -1;
				}
			}
		}  

		if (hitDelay > 0) {
			hitDelay--;
		}

		Music.RegionMusicLocations(c);
		if (teleTimer > 0) {
			teleTimer--;
			if (!isDead) {
				if (teleTimer == 1 && newLocation > 0) {
					teleTimer = 0;
					getPA().changeLocation();
				}
				if (teleTimer == 5) {
					teleTimer--;
					getPA().processTeleport();
				}
				if (teleTimer == 9 && teleGfx > 0) {
					teleTimer--;
					gfx100(teleGfx);
				}
			} else {
				teleTimer = 0;
			}
		}

		if (hitDelay == 1) {
			if (oldNpcIndex > 0) {
				getCombat().delayedHit(oldNpcIndex);
			}
			if (oldPlayerIndex > 0) {
				getCombat().playerDelayedHit(oldPlayerIndex);
			}
		}

		if (attackTimer > 0) {
			attackTimer--;
		}

		if (attackTimer == 1) {
			if (npcIndex > 0 && clickNpcType == 0) {
				getCombat().attackNpc(npcIndex);
			}
			if (playerIndex > 0) {
				getCombat().attackPlayer(playerIndex);
			}
		} else if (attackTimer <= 0 && (npcIndex > 0 || playerIndex > 0)) {
			if (npcIndex > 0) {
				attackTimer = 0;
				getCombat().attackNpc(npcIndex);
			} else if (playerIndex > 0) {
				attackTimer = 0;
				getCombat().attackPlayer(playerIndex);
			}
		}

		

		if (inTrade && tradeResetNeeded) {
			Client o = (Client) PlayerHandler.players[tradeWith];
			if (o != null) {
				if (o.tradeResetNeeded) {
					getTradeAndDuel().resetTrade();
					o.getTradeAndDuel().resetTrade();
				}
			}
		}
		if (timeOutCounter > Config.TIMEOUT) {
			disconnected = true;
		}

		timeOutCounter++;
	}
	public void updateWalkEntities() {
		if (Boundary.isIn(this, Boundary.WILDERNESS)) {
				int modY = absY > 6400 ? absY - 6400 : absY;
			wildLevel = (((modY - 3520) / 8) + 1);
			getPA().walkableInterface(197);
			if (Config.SINGLE_AND_MULTI_ZONES) {
				if (Boundary.isIn(this, Boundary.MULTI)) {
					getPA().sendFrame126("@yel@Level: " + wildLevel, 199);
				} else {
					getPA().sendFrame126("@yel@Level: " + wildLevel, 199);
				}
			} else {
				getPA().multiWay(-1);
				getPA().sendFrame126("@yel@Level: " + wildLevel, 199);
			}
			if(attackOptions)
				getPA().showOption(3, 0, "Attack", 1);
		} else if (Boundary.isIn(this, Boundary.DUEL_ARENA)) {
			getPA().walkableInterface(201);
			if (duelStatus == 5) {
				getPA().showOption(3, 0, "Attack", 1);
			} else {
				getPA().showOption(3, 0, "Challenge", 1);
			}
		}  else if (Boundary.isIn(this, Boundary.BANDOS_GODWARS) || Boundary.isIn(this, Boundary.ARMADYL_GODWARS)
			 || Boundary.isIn(this, Boundary.ZAMORAK_GODWARS) || Boundary.isIn(this, Boundary.SARADOMIN_GODWARS)) {
			getPA().sendFrame126(""+armadylKC, 18056);//Armadyl Kills
			getPA().sendFrame126(""+bandosKC, 18057);//bandos Kills:
			getPA().sendFrame126(""+saraKC, 18058);//sara kills
			getPA().sendFrame126(""+zammyKC, 18059);//zam kills
			getPA().walkableInterface(18050);
		} else if (Boundary.isIn(this, Boundary.CANIFIS_BOUNDARY) || Boundary.isIn(this, Boundary.CANIFIS_BOUNDARY)) {
			getPA().sendFrame99(2);
			getPA().sendFrame126("Kill Count: " + BarrowsRewardPotential, 4536);
			getPA().walkableInterface(4535);
		} else if (inCwGame || inPits) {
			getPA().showOption(3, 0, "Attack", 1);
		} else if (getPA().inPitsWait()) {
			getPA().showOption(3, 0, "Null", 1);
		}  else {
			getPA().sendFrame99(0);
			getPA().walkableInterface(-1);
			getPA().showOption(3, 0, "Null", 1);
			getPA().walkableInterface2(18050);
		}
	}
	private boolean wearingGrace() {
		return getItems().isWearingAnyItem(GRACEFUL);
	}

	public ItemAssistant getItems() {
		return itemAssistant;
	}
	public int graceSum = 0;

	public void graceSum() {
		graceSum = 0;
		for (int grace : GRACEFUL) {
			if (getItems().isWearingItem(grace)) {
				graceSum++;
			}
		}
		//if (SkillcapePerks.AGILITY.isWearing(this) || SkillcapePerks.isWearingMaxCape(this)) {
			//graceSum++;
		//}
	}
	public synchronized Buffer getInStream() {
		return inStream;
	}

	public synchronized int getPacketType() {
		return packetType;
	}

	public synchronized int getPacketSize() {
		return packetSize;
	}

	public synchronized Buffer getOutStream() {
		return outStream;
	}
	public Mining getMining() {
		return mining;
	}
	public ItemAssistant getItems() {
		return itemAssistant;
	}
	//public GateHandler getGateHandler() {
		//return gateHandler;
	//}
	public void startCurrentTask(int ticksBetweenExecution, CycleEvent event) {
		endCurrentTask();
		currentTask = CycleEventHandler.getSingleton().addEvent(this, event, ticksBetweenExecution);
	}

	public CycleEventContainer getCurrentTask() {
		return currentTask;
	}
	public EventHandler getEventHandler() {
		return currentEvent;
	}

	public void endCurrentTask() {
		if (currentTask != null && currentTask.isRunning()) {
			currentTask.stop();
			currentTask = null;
		}
	}
	public PlayerAssistant getPA() {
		return playerAssistant;
	}

	public CollectionLog getCollectionLog() {
		return collectionLog;
	}
	public ProcessSkillGuides getSkillGuide() {
		return SkillGuides;
	}
	
	public BankPin getBankPin() {
		return bankPin;
	}
	public DialogueHandler getDH() {
		return dialogueHandler;
	}
	public Gates getGates() {
		return gates;
	}
	public NPCHandler getNH() {
		return npcHandler;
	}
	public AchievementDiary getAD() {
		return achievementDiary;
	}
	public TeleTabs getTabs() {
		return TeleTab;
	}
	public Abyss getAbyss() {
		return abyss;
	}
	public ItemCharge getCharges() {
		return itemcharge;
	}
	public ladders getLaddersAndStairs() {
		return ladder;
	}

	public ShopAssistant getShops() {
		return shopAssistant;
	}

	public TradeAndDuel getTradeAndDuel() {
		return tradeAndDuel;
	}

	public CombatAssistant getCombat() {
		return combatAssistant;
	}
	public ActionHandler getActions() {
		return actionHandler;
	}

	public Channel getSession() {
		return session;
	}

	public Potions getPotions() {
		return potions;
	}

	public PotionMixing getPotMixing() {
		return potionMixing;
	}
	public Pets getPets() {
		return pets;
	}

	public Food getFood() {
		return food;
	}

	/**
	 * Skill Constructors
	 */
	public Slayer getSlayer() {
		return slayer;
	}

	public Runecrafting getRunecrafting() {
		return runecrafting;
	}
	public GnomeAgility getGnomeAgility() {
		return gnomeAgility;
	}
	public WildernessAgility getWildernessAgility() {
		return wildernessAgility;
	}

	public Shortcuts getAgilityShortcuts() {
		return shortcuts;
	}

	public RooftopSeers getRoofTopSeers() {
		return rooftopSeers;
	}

	public RooftopFalador getRoofTopFalador() {
		return rooftopFalador;
	}

	public RooftopVarrock getRoofTopVarrock() {
		return rooftopVarrock;
	}

	public RooftopArdougne getRoofTopArdougne() {
		return rooftopArdougne;
	}

	public Lighthouse getLighthouse() {
		return lighthouse;
	}

	public BarbarianAgility getBarbarianAgility() {
		return barbarianAgility;
	}

	public AgilityHandler getAgilityHandler() {
		return agilityHandler;
	}
	public Woodcutting getWoodcutting() {
		return woodcutting;
	}
	public Cooking getCooking() {
		return cooking;
	}
	public Agility getAgility() {
		return agility;
	}
	public Hunter getHunter() {
		return hunt;
	}
	public STASH getSTASH() {
		return stash;
	}
	public Crafting getCrafting() {
		return crafting;
	}
	public Compost getCompost() {
		return compost;
	}
	public Allotments getAllotment() {
		return allotment;
	}
	public Flowers getFlowers() {
		return flower;
	}
	public Herbs getHerbs() {
		return herb;
	}
	public Hops getHops() {
		return hops;
	}
	public ToolLeprechaun getFarmingTools() {
		return toolLeprechaun;
	}
	public Bushes getBushes() {
		return bushes;
	}


	public WoodTrees getTrees() {
		return trees;
	}

	public FruitTree getFruitTrees() {
		return fruitTrees;
	}

	public SpecialPlantOne getSpecialPlantOne() {
		return specialPlantOne;
	}

	public SpecialPlantTwo getSpecialPlantTwo() {
		return specialPlantTwo;
	}

	public Thieving getThieving() {
		return thieving;
	}

	public Herblore getHerblore() {
		return herblore;
	}

	public Firemaking getFiremaking() {
		return firemaking;
	}

	public SmithingInterface getSmithingInt() {
		return smithInt;
	}

	public Smithing getSmithing() {
		return smithing;
	}
	public Prayer getPrayer() {
		return prayer;
	}

	public Fletching getFletching() {
		return fletching;
	}

	/**
	 * End of Skill Constructors
	 */

	public void queueMessage(Packet arg1) {
		queuedPackets.add(arg1);
		packetsReceived++;
	}
	protected int packetsReceived;
	public synchronized boolean processQueuedPackets() {
		Packet p = null;
		int processed = 0;
		packetsReceived = 0;
		synchronized (queuedPackets) {
			p = queuedPackets.poll();
		}
			if (processed > Config.MAX_INCOMING_PACKETS_PER_CYCLE) {
				return false;
			}
		if (p == null) {
			return false;
		}
		inStream.currentOffset = 0;
		packetType = p.getId();
		packetSize = p.getLength();
		inStream.buffer = p.getData();
		if (packetType > 0) {
			// sendMessage("PacketType: " + packetType);
			PacketHandler.processPacket(this, packetType, packetSize);
				processed++;
		}
		timeOutCounter = 0;
		return true;
	}

	public synchronized boolean processPacket(Packet p) {
		synchronized (this) {
			if (p == null) {
				return false;
			}
			inStream.currentOffset = 0;
			packetType = p.getId();
			packetSize = p.getLength();
			inStream.buffer = p.getData();
			if (packetType > 0) {
				// sendMessage("PacketType: " + packetType);
				PacketHandler.processPacket(this, packetType, packetSize);
			}
			timeOutCounter = 0;
			return true;
		}
	}

	public void correctCoordinates() {
		if (inPcGame()) {
			getPA().movePlayer(2657, 2639, 0);
		}
		if (inFightCaves()) {
			getPA().movePlayer(absX, absY, playerId * 4);
			sendMessage("Your wave will start in 10 seconds.");
			EventManager.getSingleton().addEvent(new Event() {
				public void execute(EventContainer c) {
					Server.fightCaves.spawnNextWave((Client) PlayerHandler.players[playerId]);
					c.stop();
				}
			}, 10000);

		}

	}

}
