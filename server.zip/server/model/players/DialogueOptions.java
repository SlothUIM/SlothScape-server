package server.model.players;

//import server.model.players.skills.crafting;
//import server.model.items.impl.Flowers;
//import server.model.items.impl.Teles;
import server.model.players.Client;
import server.Config;

/**
 * Dialogue Options
 * @author Andrew (Mr Extremez)
 */

public class DialogueOptions {
	
	public static void handleDialogueOptions(Client player, int buttonId) {
		switch (buttonId) {
			/*
			 *
			 * Destroy item options
			 *
			 */
		case 174160:
		case 174164:
		if(player.getItems().playerHasItem(player.DestroyID, 1)){
			player.getItems().deleteItem(player.DestroyID, player.getItems().getItemSlot(player.DestroyID), 1);
			player.DestroyID = -1;
			player.getPA().removeAllWindows();
		}
		break;
		case 174161:
		case 174165:
			player.getPA().removeAllWindows();
		break;
			/*
			 *
			 * 2 option dialogue
			 *
			 */
		case 9157://1st option
			
			switch (player.dialogueAction) {
				case 55:
				player.getDH().sendDialogues(91, player.talkingNpc);
				return;
			case 56:
				player.getDH().sendDialogues(96, player.talkingNpc);
				return;
				case 17:
					player.getDH().sendDialogues(18, player.talkingNpc);
				return;
				case 20:
					player.getDH().sendDialogues(21, player.talkingNpc);
				return;
				case 24:
					if(player.getItems().playerHasItem(995, 2)){
							player.getItems().deleteItem(995, player.getItems().getItemSlot(995), 2);
							player.getItems().addItem(950, 1);
									player.nextChat = 0;
									player.dialogueAction = 0;
									player.getPA().closeAllWindows();
					} else 
						player.getDH().sendDialogues(25, player.talkingNpc);
				return;
				case 106:
					player.getDH().sendDialogues(107, 463);
				return;
				case 127:
					player.getDH().sendDialogues(128, 463);
				return;
				case 3111:
					player.getDH().sendDialogues(3112, 946);
				return;
				case 57:
					player.getDH().sendDialogues(57, player.talkingNpc);
				return;
				/*Black Knights' Fortress Dialogue options*/
				case 1000://I seek a quest
					player.getDH().sendDialogues(3533, player.talkingNpc);
				return;
				case 3505://I laugh in the face of danger
					player.getDH().sendDialogues(3506, player.talkingNpc);
				return;
				case 3519://accept quest
					player.getDH().sendDialogues(3520, player.talkingNpc);
				return;
				case 4011:
				player.getDH().sendDialogues(4012, player.talkingNpc);
				return;
				case 4021:
				player.getDH().sendDialogues(4022, player.talkingNpc);
				return;
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;

		case 9158:
			switch (player.dialogueAction) {
				case 55:
				player.getDH().sendDialogues(92, player.talkingNpc);
				return;
				case 56:
				player.getDH().sendDialogues(95, player.talkingNpc);
				return;
				case 106:
					player.getDH().sendDialogues(109, 463);
				return;
				case 127:
					player.getDH().sendDialogues(130, 463);
				return;
				case 17:
					player.getDH().sendDialogues(31, player.talkingNpc);
				return;
				case 20:
					player.getDH().sendDialogues(29, player.talkingNpc);
				return;
				case 24:
					player.getDH().sendDialogues(27, player.talkingNpc);
				return;
				case 3111:
					player.getDH().sendDialogues(3117, 946);
				return;
				case 57:
					player.getDH().sendDialogues(58, player.talkingNpc);
				return;
				/*Black Knights' Fortress Dialogue options*/
				case 3504:
				case 1000://I don't im just looking around
					player.getDH().sendDialogues(3531, player.talkingNpc);
				return;
				case 3505://I cower in danger
					player.getDH().sendDialogues(3525, player.talkingNpc);
				return;
				case 3519://decline quest
					player.getDH().sendDialogues(3523, player.talkingNpc);
				return;
				case 4011:
				player.getDH().sendDialogues(4913, player.talkingNpc);
				return;
			
			}			
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
			/*End*/
		
			/*
			 *
			 * 3 option dialogue
			 *
			 */
		case 9167:
			switch (player.dialogueAction) {
				case 774:
					player.getLaddersAndStairs().climbLadderorStair(player.objectX, player.objectY, 3205, 3209, 2, false, false);
				return;
				case 251:
					player.getPA().openUpBank(0);
					player.nextChat = 0;
				return;
				case 4001:
					player.getDH().sendDialogues(4002, player.talkingNpc);
				return;
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;

		case 9168:
			switch (player.dialogueAction) {
				
				case 4001:
					player.getDH().sendDialogues(4003, -1);
				return;
				case 774:
					player.getLaddersAndStairs().climbLadderorStair(player.objectX, player.objectY, 3205, 3209, 0, false, false);
				return;
				case 251:
					player.getBankPin().bankPinSettings();
					player.nextChat = 0;
				return;
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;

		case 9169:
			switch (player.dialogueAction) {
				case 4001:
					player.getDH().sendDialogues(4004, player.talkingNpc);
				return;
				case 251:
					player.getDH().sendDialogues(1015, 494);
				return;
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
			/*End*/

		
			/*
			 *
			 * 4 option dialogue
			 *
			 */
		case 9178:
			if(player.usingCloak){
				player.getPA().startTeleport(Config.MONASTERYX, Config.MONASTERYY, 0, "modern");
				return;
			}
			if (player.usingGlory){
				player.getPA().startTeleport(Config.EDGEVILLE_X, Config.EDGEVILLE_Y, 0, "modern");
				return;
			}
			switch (player.dialogueAction) {
				case 420:
					player.getItems().addtoLootbagFromDeposit(player.xRemoveId, player.xRemoveSlot, 1);
					player.getPA().removeAllWindows();
				return;
				case 3:
					player.getPA().startTeleport(Config.EDGEVILLE_X, Config.EDGEVILLE_Y, 0, "modern");
				return;
				case 52:
				return;
			
			}		
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();	
			break;

		case 9179:
			if (player.usingGlory){
				player.getPA().startTeleport(Config.AL_KHARID_X, Config.AL_KHARID_Y, 0, "modern");
				return;
			}
			switch (player.dialogueAction) {
				case 420:
					player.getItems().addtoLootbagFromDeposit(player.xRemoveId, player.xRemoveSlot, 5);
					player.getPA().removeAllWindows();
				return;
			
			}	
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();		
			break;

		case 9180:
			if (player.usingGlory){
				player.getPA().startTeleport(Config.KARAMJA_X, Config.KARAMJA_Y, 0,"modern");
				return;
			}
			switch (player.dialogueAction) {
				case 420:
					player.getItems().addtoLootbagFromDeposit(player.xRemoveId, player.xRemoveSlot, 10);
					player.getPA().removeAllWindows();
				return;
				case 52:
					player.getDH().sendDialogues(65, player.talkingNpc);
				return;
			
			}	
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();		
			break;

		case 9181:
			if (player.usingGlory){
				player.getPA().startTeleport(Config.MAGEBANK_X, Config.MAGEBANK_Y,0, "modern");
				return;
			}
			switch (player.dialogueAction) {
				case 420:
					player.getItems().addtoLootbagFromDeposit(player.xRemoveId, player.xRemoveSlot, player.Xamount);
					//player.getPA().removeAllWindows();
				return;
				case 52:
					player.getDH().sendDialogues(63, player.talkingNpc);
				return;
			
			}	
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();		
			break;
			/*End*/
						/*
			 *
			 * 5 option dialogue
			 *
			 */
		case 9190:
			switch (player.dialogueAction) {
				case 505:
					player.getDH().sendDialogues(506, 705);
				return;
				
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
		case 9191:
			switch (player.dialogueAction) {
			
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
		case 9192:
			switch (player.dialogueAction) {
			
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
		case 9193:
			switch (player.dialogueAction) {
			
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
		case 9194:
			switch (player.dialogueAction) {
			
			}
			player.dialogueAction = 0;
			player.getPA().closeAllWindows();
			break;
			/*End*/
		}
	}

}
