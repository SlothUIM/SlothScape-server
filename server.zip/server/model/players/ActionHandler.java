package server.model.players;

import server.Config;
import server.Server;
import server.model.objects.Object;
import server.util.Misc;
import server.util.ScriptManager;
import server.model.minigames.Sailing;
import server.event.*;
import server.model.content.STASHConfig;
import server.model.content.STASH;
import server.model.npcs.NPCHandler;
import server.model.npcs.NPC;
import server.event.EventManager;
import server.model.objects.Doors;
import server.model.objects.DoubleDoors;
import server.event.Event;
import server.event.EventContainer;
import server.world.map.ObjectDef;
import server.model.players.skills.farming.*;
import server.model.players.skills.smithing.*;
import server.model.players.skills.*;
import server.model.players.skills.agility.*;
import server.model.players.skills.agility.impl.*;
import server.model.players.skills.agility.impl.rooftop.*;
import server.model.players.skills.mining.*;
import server.model.players.movements.ladders;
import server.model.players.Position;
import server.model.players.packets.AttackPlayer;

public class ActionHandler {

	private Client c;

	public ActionHandler(Client Client) {
		this.c = Client;
	}
				private void handleRandomEventOptionA(Client c) {
					c.getPA().walkTo(4, 0);
					c.getPA().addSkillXP(5, c.playerAgility);
					c.getPA().requestUpdates();

					c.sendMessage("You make your way across.");
					// Schedule a delayed action to reset the jump
					scheduleDelayedAction(c, 4, null);
				}

				private void handleRandomEventOptionB(Client c) {
					c.playerTurnIndex = 762;
					c.sendMessage("You begin to cross..");
					c.getPA().walkTo(2, 0);
					c.postProcessing();
					c.getPA().addSkillXP(5, c.playerAgility);
					c.getPA().requestUpdates();

					// Schedule a series of actions
					scheduleOptionBActions(c);
				}

				private void scheduleOptionBActions(Client c) {
					// Schedule the animation change
					scheduleDelayedAction(c, 4, () -> { c.startAnimation(771);
														c.sendMessage("..you slip..");
					});

					// Schedule the movement and final adjustments
					scheduleDelayedAction(c, 5, () -> {
						c.sendMessage("..and fall off the log.");
						c.turnPlayerTo(c.getX(), c.getY() + 1);
						c.getPA().movePlayer(c.getX(), c.getY() - 1, 0);
						c.getPA().requestUpdates();

						// Schedule additional actions
						scheduleDelayedAction(c, 2, () -> {
							c.playerStandIndex = 773;
							c.playerWalkIndex = 772;
							c.playerRunIndex = 772;
							c.playerTurnIndex = 772;
							c.getPA().requestUpdates();
							c.postProcessing();

							// Schedule further actions
							scheduleDelayedAction(c, 2, () -> {
								c.turnPlayerTo(c.getX(), c.getY() - 1);

								// Schedule the final actions
								scheduleDelayedAction(c, 4, () -> {
									c.getPA().walkTo(0, -6);
									c.postProcessing();

									// Schedule the last set of actions
									scheduleDelayedAction(c, 4, () -> {
										// Reset the log crossing
										c.sendMessage("You barely swim your way to shore");
										c.getPA().walkTo(-2, 0);
										c.postProcessing();
										c.getPA().resetlogCross(c);

									});
								});
							});
						});
					});
				}
				public void PassDoor(Client c, int ID, int X, int Y, int X2, int Y2, int moveX, int moveY, int face){
					c.getPA().object(ID, X2, Y2, face, 0);
					c.getPA().object(-1, X, Y, 0, 0);
							c.getPA().walkTo(moveX, moveY);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {

						c.getPA().object(-1, X2, Y2, face, 0);
						c.getPA().object(ID, X, Y, 0, 0);
						}

					}, 2);
				}	
				public void PassDoubleDoor(Client c, int ID, int ID2, int X, int Y, int X2, int Y2, int X3, int Y3, int X4, int Y4, int moveX, int moveY, int face, int face2){
					c.getPA().object(ID, X3, Y3, face, 0);
					c.getPA().object(ID2, X4, Y4, face2, 0);
					c.getPA().object(-1, X, Y, 0, 0);
					c.getPA().object(-1, X2, Y2, 0, 0);
							c.getPA().walkTo(moveX, moveY);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {

					c.getPA().object(-1, X3, Y3, face, 0);
					c.getPA().object(-1, X4, Y4, face, 0);
					c.getPA().object(ID, X, Y, 0, 0);
					c.getPA().object(ID2, X2, Y2, 0, 0);
						}

					}, 2);
				}
				public void PassDoubleGate(Client c, int ID, int X, int Y, int X2, int Y2, int ID2, int face, int face2, int moveX, int moveY, int lastX, int lastY, int lastX2, int lastY2){
					
					c.getPA().object(-1, lastX, lastY, 0, 0);
					c.getPA().object(-1, lastX2, lastY2, 0, 0);
					c.getPA().object(ID, X, Y, face, 0);
					c.getPA().object(ID2, X2, Y2, face, 0);
					c.getPA().walkTo(moveX, moveY);
						//PassDoubleGate(c, 3015, 3090, 3092, 3091, 3092, 3016, 1, 2, -1, 0);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {

						c.getPA().object(-1, X, Y, 0, 0);
						c.getPA().object(-1, X2, Y2, 0, 0);
						c.getPA().object(ID, lastX, lastY, face2, 0);
						c.getPA().object(ID2, lastX2, lastY2, face2, 0);
						}

					}, 2);
				}
		private void scheduleDelayedAction(Client c, int cycles, Runnable action) {
			CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
				@Override
				public void execute(CycleEventContainer container) {
					if(action != null)
					action.run();
					container.stop();
				}

				@Override
				public void stop() {
				}
			}, cycles);
		}

						int test = 0;
	public void firstClickObject(int objectType, int obX, int obY) {
        c.faceUpdate(0);
		c.clickObjectType = 0;
		ObjectDef def = ObjectDef.getObjectDef(objectType);
        c.turnPlayerTo(obX, obY);
        if (c.stopPlayerPacket) {
            return;
        }
		if (Farming.harvest(c, obX, obY)) {
            return;
        }
		if (c.getGnomeAgility().gnomeCourse(c, objectType)) {
			return;
		}
		if (c.getWildernessAgility().wildernessCourse(c, objectType)) {
			return;
		}
		if (c.getBarbarianAgility().barbarianCourse(c, objectType)) {
			return;
		}
		if (c.getBarbarianAgility().barbarianCourse(c, objectType)) {
			return;
		}
		if (c.getAgilityShortcuts().agilityShortcuts(c, objectType)) {
			return;
		}
		if (c.getRoofTopSeers().execute(c, objectType)) {
			return;
		}
		if (c.getRoofTopFalador().execute(c, objectType)) {
			return;
		}
		if (c.getRoofTopVarrock().execute(c, objectType)) {
			return;
		}
		if (c.getRoofTopArdougne().execute(c, objectType)) {
			return;
		}
		if (c.getLighthouse().execute(c, objectType)) {
			return;
		}
		if (Woodcutting.playerTrees(c, objectType) && objectType != 1292) {
			Woodcutting.startWoodcutting(c, objectType, obX, obY, c.clickObjectType);
			//return;
		}
		c.getLaddersAndStairs().objectClick(1, def.type, obX, obY);
		
		c.getAD().DiaryObjectClick(objectType, 1);
        c.getCompost().handleObjectClick(objectType, obX, obY);
		
		if (Mining.rockExists(objectType))
            c.getMining().startMining(c, objectType, obX, obY, c.clickObjectType);
			//c.getGates().PassDoubleGate_without_req_withTimer(c, objectType, obX, obY);
		c.getGates().OpenDoor_withTimer(c, objectType, obX, obY);
		c.getAbyss().objectInteraction(objectType, obX, obY);	
						switch (def.type) {
							
		case 23644:
			if (c.getPA().getLevel(Skill.AGILITY) <= 70) {
					c.getDH().sendStatement("You need 70 Agility to cross this log.");
					c.sendMessage("You need 70 Agility to cross this log.");
					break;
				}
			if (obX == 2907) {
				AgilityHandler.delayEmote(c, "BALANCE", 2910, 3049, 0, 2);
			} else if (obX == 2909) {
				AgilityHandler.delayEmote(c, "BALANCE", 2906, 3049, 0, 2);
			}
			break;
			
		case 32153:// rune dragon barrier entry
			if (obX == 1574 && (obY <= 5077 && (obY >= 5072 && c.getX() <= 1573))) {
				AgilityHandler.delayEmote(c, -1, 1575, c.getY(), 0, 4);
				c.sendMessage("@pur@You have entered the Rune dragon room.");
				return;
			} else if (obX == 1574 && (obY <= 5077 && (obY >= 5072 && c.getX() >= 1575))) {
				AgilityHandler.delayEmote(c, -1, 1573, c.getY(), 0, 4);
				c.sendMessage("@pur@You have left the Rune dragon room.");
				return;
				//Adamant dragon barrier entry
			} else if (obX == 1561 && (obY <= 5077 && (obY >= 5072 && c.getX() >= 1562))) {
				AgilityHandler.delayEmote(c, -1, 1560, c.getY(), 0, 4);
				c.sendMessage("@pur@You have entered the Adamant dragon room.");
				return;
			} else if (obX == 1561 && (obY <= 5077 && (obY >= 5072 && c.getX() <= 1560))) {
				AgilityHandler.delayEmote(c, -1, 1562, c.getY(), 0, 4);
				c.sendMessage("@pur@You have left the Adamant dragon room.");
				return;
			}
			break;
		case 26709:// strongholdslayer cave
			c.getPA().movePlayer(2429, 9825, 0);
			c.sendMessage("Welcome to the Stronghold slayer cave, you can find many slayer monsters here!");
			break;
		case 26710:// strongholdslayer caveexit
		case 27258:
			c.getPA().movePlayer(2430, 3425, 0);
			break;
		case 28892:// catacomb agility
			if (c.getPA().getLevel(Skill.AGILITY) < 34) {
				c.sendMessage("You need an Agility level of 34 to pass this.");
				return;
			}
			if (c.getX() == 1648) {
				AgilityHandler.delayEmote(c, "CRAWL", 1646, 10000, 0, 2);
			} else if (c.getX() == 1716) {
				AgilityHandler.delayEmote(c, "CRAWL", 1706, 10078, 0, 2);
			} else if (c.getX() == 1706) {
				AgilityHandler.delayEmote(c, "CRAWL", 1716, 10056, 0, 2);
			} else if (c.getX() == 1646) {
				AgilityHandler.delayEmote(c, "CRAWL", 1648, 10009, 0, 2);
			}
			break;
		case 30175:// Stronghold short
			if (c.getPA().getLevel(Skill.AGILITY) < 72) {
				c.sendMessage("You need an Agility level of 72 to pass this.");
				return;
			}
			if (c.getX() == 2429) {
				AgilityHandler.delayEmote(c, "CRAWL", 2435, 9806, 0, 2);
			} else if (c.getX() == 2435) {
				AgilityHandler.delayEmote(c, "CRAWL", 2429, 9806, 0, 2);
			}
			break;
	
		case 536:// Smoke Devil Exit
			if (c.getX() == 2376) {
				AgilityHandler.delayEmote(c, "CRAWL", 2379, 9452, 0, 2);
			}
			break;
			/*
			 * case 17385://taveryly exit AgilityHandler.delayEmote(c, "CLIMB_UP", 1662,
			 * 3529, 0, 2); break;
			 */
		case 1738:// tav entrance
			AgilityHandler.delayEmote(c, "CLIMB_DOWN", 2884, 9798, 0, 2);
			break;
		case 2123:// relleka entrance
			AgilityHandler.delayFade(c, "CRAWL", 2808, 10002, 0, "You crawl into the entrance.",
					"and you end up in a dungeon.", 3);
			c.sendMessage("Welcome to the Relleka slayer dungeon, find many slayer tasks here.");
			break;
		case 2268:// ice dung exit
			AgilityHandler.delayEmote(c, "CLIMB_UP", 1651, 3619, 0, 2);
			break;
		case 2141:// relleka exit
			c.getPA().movePlayer(1259, 3502, 0);
			break;
			/*
			 * case 29734://dgorillas if (objectX == 1349 && objectY == 3591) {
			 * c.getPA().movePlayer(2130, 5646, 0); c.
			 * sendMessage("Welcome to the Demonic Gorilla's Dungeon, try your luck for a heavy frame!"
			 * ); } break;
			 */
		case 28687:// dgexit
			c.getPA().movePlayer(1348, 3590, 0);
			break;
		case 4153:// corpexit
			c.getPA().movePlayer(1547, 3571, 0);
			break;
		case 2544:// daggentrence
			c.getPA().movePlayer(2446, 10147, 0);
			break;
		case 8966:// dagexit
			c.getPA().movePlayer(1547, 3571, 0);
			break;
							case 28983:
							if(obX == 3211 && obY == 3456){
								if(!STASHConfig.EasyStashBuilt[0])
									c.getSTASH().setSTASH(def.type, obX, obY);
								else if(STASHConfig.EasyStashBuilt[0] && STASHConfig.Stored[0][0] && STASHConfig.taken[0][0])
									c.getSTASH().storeSTASH(def.type);
								else if(STASHConfig.EasyStashBuilt[0] && !STASHConfig.Stored[0][0])
									c.getSTASH().storeSTASH(def.type);
								else if(STASHConfig.EasyStashBuilt[0] && STASHConfig.Stored[0][0] && !STASHConfig.taken[0][0])
									c.getSTASH().takeSTASH(def.type);
							}
							break;
							case 26115:
							if(c.absY > obY){
								c.getPA().object(-1, obX, obY, 0, 0);
								c.getPA().object(objectType, obX, obY+1, 2, 0);
								c.getPA().walkTo(0, -1);
								CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
									@Override
										public void execute(CycleEventContainer container) {
											container.stop();
										}

										@Override
										public void stop() {
											c.getPA().object(-1, obX, obY+1, 0, 0);
											c.getPA().object(objectType, obX, obY, 1, 0);
										}

									}, 2);
							}
							break;
							case 10529:
								c.getPA().sendFrame248(4465, 197);
								c.getItems().resetItems(7423);
								break;
					case 11729:	
					if(obX == 2954 && obY == 3338)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2956, 3338, 1, false, false);
					else if(obX == 2960 && obY == 3338)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2959, 3339, 2, false, false);
					else if(obX == 2957 && obY == 3338)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2959, 3338, 3, false, false);
					break;
					case 11731:	
					if(obX == 2955 && obY == 3338)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2956, 3338, 0, false, false);
					else if(obX == 2960 && obY == 3339)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2959, 3339, 1, false, false);
					else if(obX == 2958 && obY == 3338)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2959, 3339, 2, false, false);
					break;
					case 11725:	
					if(obX == 2968 && obY == 3347)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2970, 3347, 0, false, false);
					break;
					case 11724:	
					if(obX == 2968 && obY == 3347)
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2968, 3349, 1, false, false);
					break;
            /**
             * tutorial island objects
             */
			case 26113:
			if(!c.getItems().playerHasItem(2886) && !c.getItems().playerHasItem(9715)){
				c.getDH().sendDialogues(3550, -1);
				//c.getItems().addItem(2886, 1);
			}
			break;
			case 3415:
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2716, 9888, 0, false, false);
				c.getDH().sendDialogues(3551, -1);
			break;
			case 3416:
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, 2709, 3498, 0, false, false);
			break;
			case 3403:
			if(c.EleWorkShop == 3){
				c.EleWorkShop = 4;
			}
			if(c.EleWorkshopWater_stage == 0){
				c.getPA().sendConfig(299, 1 << 4);
				c.EleWorkshopWater_stage = 2;
				c.sendMessage("You turn the handle to the left.");
			} else if(c.EleWorkshopWater_stage == 2){
				c.getPA().sendConfig(299, 0 << 4);
				c.EleWorkshopWater_stage = 0;
				c.sendMessage("You turn the handle to the right");
			} 
			break;
			case 3404:
			if(c.EleWorkshopWater_stage == 2){
				if(c.EleWorkShop == 4){
					c.EleWorkShop = 5;
				}
				c.getPA().sendConfig(299, 3 << 3);
				c.EleWorkshopWater_stage = 3;
				c.sendMessage("You turn the handle to the left.");
			} 
			break;
			case 3406:
			c.sendMessage("You pull the lever.");
			if(c.EleWorkShop < 5){
				c.getPA().sendConfig(299, 0 << 3);
				c.EleWorkshopWater_stage = 0;
				c.sendMessage("Nothing happens...");
			} else if(c.EleWorkShop == 5) {
				c.getPA().sendConfig(299, 7 << 3);
				c.EleWorkshopWater_stage = 7;
				c.sendMessage("You hear the sound of a water wheel starting up.");
				c.EleWorkShop = 6;
			}
			break;
			case 3407:
			c.sendMessage("You pull the lever.");
			if(c.getItems().playerHasItem(1741, 1) && c.getItems().playerHasItem(1733, 1)){
				if(c.EleWorkShop < 6){
					c.sendMessage("now why would i do that...");
				} else if(c.EleWorkShop == 6) {
					c.getPA().sendConfig(299, 55 << 3);
					c.EleWorkshopWater_stage = 55;
					c.sendMessage("You stitch the leather over the hole in the bellows.");
					c.EleWorkShop = 7;
					c.getItems().deleteItem(1741, 1);
				}
			} else {
				c.sendMessage("There appears to be a hole in the bellows, if only I had a piece of @blu@leather..");
			}
			break;
			case 3409:
			if(c.EleWorkShop < 7){
				c.sendMessage("now why would i do that...");
			} else if(c.EleWorkShop == 7) {
				c.getPA().sendConfig(299, 199 << 3);
				c.EleWorkshopWater_stage = 199;
				c.sendMessage("You pull the lever.");
				c.sendMessage("The bellows pump air down the pipe.");
				c.EleWorkShop = 8;
			}
			break;
            case 37002:
            case 36999:
                if (c.tutorialProgress == 28 && c.absX == 3129) {
					PassDoubleDoor(c, 37002, 36999, 3129, 3107, 3129, 3106, 3128, 3107, 3128, 3106, -1, 0, 1, 2);
                } else if (c.tutorialProgress == 28 && c.absX == 3128) {
					PassDoubleDoor(c, 37002, 36999, 3129, 3107, 3129, 3106, 3128, 3107, 3128, 3106, 1, 0, 1, 3);
                }
                break;
            case 3024:
                if (c.tutorialProgress >= 27) {
                    if (Position.checkPosition(c, 3124, 3124, 0)) {
                        //PassDoor.passThroughDoor(player, 3024, 3, 0, 0, 1, 0, 0);
						PassDoor(c, 3024, 3125, 3124, 3124, 3124, 1, 0, 1);
                    }
                    // client.getPacketDispatcher().tutorialIslandInterface(65,
                    // 14);
                    c.getPA().chatbox(6180);
                    c.getDH().chatboxText(
                                    "The guide here will tell you all about making cash. Just click on",
                                    "him to hear what he's got to say.", "", "",
                                    "Financial advice");
                    c.getPA().chatbox(6179);
                    c.getPA().drawHeadicon(1, 7, 0, 0);
                }
                break;
				
            case 3025:
                if (c.tutorialProgress >= 28) {
                    if (Position.checkPosition(c, 3129, 3124, 0)) {
						PassDoor(c, 3025, 3130, 3124, 3129, 3124, 1, 0, 1);
                    }
                    // client.getPacketDispatcher().tutorialIslandInterface(70,
                    // 15);
                    c.getPA().chatbox(6180);
                    c.getDH()
                            .chatboxText(
                                    "Follow the path to the chapel and enter it.",
                                    "Once inside talk to the monk. He'll tell you all about the skill.",
                                    "", "", "Prayer");
                    c.getPA().chatbox(6179);
                    c.getPA().drawHeadicon(1, 8, 0, 0); // sends
                    // to
                    // prayer
                    // dude
                }

                break;
            case 3026:
                if (c.tutorialProgress >= 32) {
                    // client.getPacketDispatcher().tutorialIslandInterface(80,
                    // 17);
                    c.getPA().drawHeadicon(1, 9, 0, 0); // sends
                    // to
                    // prayer
                    // dude
                    if (Position.checkPosition(c, 3122, 3103, 0)) {
                       // PassDoor.passThroughDoor(player, 3026, 0, 1, 0, 0, -1, 0);
						PassDoor(c, 3026, 3122, 3102, 3122, 3101, 1, 0, 2);
                    }
                }
                break;
            case 3045:
                if (c.tutorialProgress == 26) {
                    c.getPA().openUpBank(0);
                    // client.getPacketDispatcher().tutorialIslandInterface(60,
                    // 13);
                    c.getPA().createObjectHints(3125, 3124, c.getH(), 2);
                    c.getPA().chatbox(6180);
                    c.getDH().chatboxText(
                                    "You can store stuff here for safekeeping. If you die anything",
                                    "in your bank will be saved. To deposit something, rich click it",
                                    "and select 'store'. Once you've had a good look, close the",
                                    "window and move on through the door indicated.",
                                    "This is your bank box");
                    c.getPA().chatbox(6179);
                    c.tutorialProgress = 27;
                    c.getPA().createPlayerHints(1, 7);
                } else if (c.tutorialProgress >= 27) {
                    c.getDH().sendDialogues(1013, 494);
                }
                break;		
            case 3039:
                if (c.getItems().playerHasItem(2307) && c.tutorialProgress >= 8) {
                    c.startAnimation(896);
                    c.getPA().requestUpdates();
                    c.getItems().deleteItem(2307, 1);
                    c.getItems().addItem(2309, 1);
                    c.getDH().sendDialogues(3037, -1);
                }
                break;
				
            case 3020:
            case 3021:
                if (c.diedOnTut && (c.getY() == 9502 || c.getY() == 9503)) {
                    c.getDH()
                            .sendStatement(
                                    "You have died so now all you need to do is continue",
                                    "onto the next step.");
                    c.getPA().createObjectHints(3111, 9518,
                            c.getH(), 2);
                } else if (c.diedOnTut == false && c.tutorialProgress >= 21 && (c.getY() == 9502 || c.getY() == 9503)) {
                    c.getPA().chatbox(6180);
                    c.getDH().chatboxText(
                                    "In this area you will find out about combat with swords and",
                                    "bows. Speak to the guide and he will tell you all about it.",
                                    "", "", "Combat");
                    c.getPA().chatbox(6179);
                    c.getPA().object(-1, 3094, 9502, 0, 0);
                    c.getPA().object(3021, 3095, 9502, 7, 0);

                    c.getPA().object(-1, 3094, 9503, 0, 0);
                    c.getPA().object(3020, 3095, 9503, 1, 0);

                    c.getPA().walkTo(1, 0);
                    CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
                        @Override
                        public void execute(CycleEventContainer container) {
                            c.getPA().object(3020, 3094, 9503,
                                    2, 0);
                            c.getPA().object(3021, 3094, 9502,
                                    2, 0);
                            // others
                            c.getPA().object(-1, 3095, 9502, 0,
                                    0);
                            c.getPA().object(-1, 3095, 9503, 0,
                                    0);
                            c.getPA().createPlayerHints(1, 6); // draws
                            // headicon
                            // to
                            // combat dude

                            container.stop();
                        }

                        @Override
                        public void stop() {

                        }
                    }, 2);
                }
                break;
				
            case 3023:
            case 3022:
                if (c.tutorialProgress >= 24
                        && (c.getY() == 9519 || c.getY() == 9518)
                        || c.diedOnTut) {
                    if (c.diedOnTut) {
                        c.getDH()
                                .sendStatement("Be more careful this time",
                                        "now continue to kill the rat and talk to the guide.");
                    }
                    c.getPA().chatbox(6180);
                    c.getDH()
                            .chatboxText(
                                    "",
                                    "To attack the rat, right click it and select the attack option. you",
                                    "will then walk over to it and start hitting it.",
                                    "", "Attacking");
                    c.getPA().chatbox(6179);
                    c.getPA().object(-1, 3111, 9518, 0, 0);
                    c.getPA().object(3022, 3110, 9518, 7, 0);

                    c.getPA().object(-1, 3111, 9519, 0, 0);
                    c.getPA().object(3023, 3110, 9519, 1, 0);

                    CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
                        @Override
                        public void execute(CycleEventContainer container) {

                            c.getPA().object(3022, 3111, 9518,
                                    0, 0);
                            c.getPA().object(3023, 3111, 9519,
                                    0, 0);
                            // others
                            c.getPA().object(-1, 3110, 9518, 7,
                                    0);
                            c.getPA().object(-1, 3110, 9519, 1,
                                    0);
                            c.getPA().createPlayerHints(1, 6); // draws
                            // headicon
                            // to combat ude

                            container.stop();
                        }

                        @Override
                        public void stop() {

                        }
                    }, 4);
                } else if (c.tutorialProgress >= 25
                        && (c.getY() == 9519 || c.getY() == 9518)) {
                    c.getPA().object(-1, 3111, 9518, 0, 0);
                    c.getPA().object(3022, 3110, 9518, 7, 0);

                    c.getPA().object(-1, 3111, 9519, 0, 0);
                    c.getPA().object(3023, 3110, 9519, 1, 0);

                    CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
                        @Override
                        public void execute(CycleEventContainer container) {

                            c.getPA().object(3022, 3111, 9518,
                                    0, 0);
                            c.getPA().object(3023, 3111, 9519,
                                    0, 0);
                            // others
                            c.getPA().object(-1, 3110, 9518, 7,
                                    0);
                            c.getPA().object(-1, 3110, 9519, 1,
                                    0);

                            container.stop();
                        }

                        @Override
                        public void stop() {

                        }
                    }, 4);
                }
                break;
			case 3033:
				Woodcutting.startWoodcutting(c, objectType, obX, obY, c.clickObjectType);
			break;		
			case 15516:	
			if(obX == 3079 && obY == 3501)
				c.getGates().PassDoubleGate_with_req(15516, 15514, obX, obY, 0, -1, 0);
			if(obX == 3253 && obY == 3267)
				c.getGates().PassDoubleGate_with_req(15514, 15516, obX, obY-1, 3, 0, 2);
				break;	
			case 15514:	
			if(obX == 3253 && obY == 3266)
				c.getGates().PassDoubleGate_with_req(15514, 15516, obX, obY, 3, 0, 2);
			else if(obX == 3252 && obY == 3266)
				c.getGates().resetGate(15514);
				break;
			case 36913:	
			if(obX == 3237 && obY == 3295)
				c.getGates().PassDoubleGate_with_req(36913, 36915, obX, obY, 3, 0, 2);
			else if(obX == 3236 && obY == 3295)
				c.getGates().resetGate(36913);
			if(obX == 3213 && obY == 3261)
				c.getGates().PassDoubleGate_with_req(36913, 36915, obX, obY, 3, 0, 2);
			else if(obX == 3212 && obY == 3261)
				c.getGates().resetGate(36913);
				break;
			case 36915:	
			if(obX == 3237 && obY == 3296)
				c.getGates().PassDoubleGate_with_req(36913, 36915, obX, obY-1, 3, 0, 2);
			else if(obX == 3235 && obY == 3295)
				c.getGates().resetGate(36913);
			if(obX == 3213 && obY == 3262)
				c.getGates().PassDoubleGate_with_req(36913, 36915, obX, obY-1, 3, 0, 2);
			else if(obX == 3211 && obY == 3261)
				c.getGates().resetGate(36913);
				break;
				case 36687:
				if(obX == 3209 && obY == 3216) {
                        c.startAnimation(827);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {
							c.getPA().movePlayer(3208, 9616, 0);
						}

					}, 2);
				}
				break;
			case 3015:
            case 3016:
                if (c.tutorialProgress == 7) {
                      c.getDH().sendDialogues(3020, -1);
					if(c.absX == 3089)
						PassDoubleGate(c, 3015, 3090, 3092, 3091, 3092, 3016, 1, 2, 1, 0, 3089, 3092, 3089, 3091);
					else if(c.absX == 3090)
						PassDoubleGate(c, 3015, 3090, 3092, 3091, 3092, 3016, 1, 2, -1, 0, 3089, 3092, 3089, 3091);
                } else {
                        c.sendMessage("You aren't on this part yet.");
                        return;
                }
                break;

            case 3019:
                if (c.tutorialProgress >= 11) {
                   	if(c.absX == 3086 && c.absY == 3126){
						PassDoor(c, 3019, 3086, 3126, 3086, 3125, 0, -1, -1);
                        c.getDH().sendDialogues(3042, -1);
					}
				}
                break;
            case 3018: // door again
                if (c.tutorialProgress > 9) {
                        c.getDH().sendDialogues(3038, -1);
                }
                break;

            case 3017:// door tutorial island
                if (c.tutorialProgress > 6) {
					if (c.absX == 3079) {
						PassDoor(c, 3017, 3079, 3084, 3078, 3084, -1,0, -2);
                        c.getPA().drawHeadicon(1, 3, 0, 0);
                    }
                } else {
                    c.sendMessage("You aren't on this part yet.");
                    return;
                }
                break;				
            case 3014:
                   // PassDoor.passThroughDoor(c, 3014, 1, 0, 0, 1, 0, 0);
                if (c.absX == 3097 && c.tutorialProgress >= 2) {
					c.getPA().object(3014, 3097, 3107, 1, 0);
					c.getPA().object(-1, 3098, 3107, 0, 0);
							c.getPA().walkTo(1, 0);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
							if (c.absY == 3098) {
								container.stop();
							}
						}

						@Override
						public void stop() {

						c.getPA().object(-1, 3097, 3107, -1, 0);
						c.getPA().object(3014, 3098, 3107, 0, 0);
						}

					}, 2);
                    c.getDH().sendDialogues(3011, -1);
                    //c.getPA().createPlayerHints(1, 2);
                } else if (c.tutorialProgress < 2) {
                    c.sendMessage("You aren't on this step yet.");
                    return;
                }
                break;
				
            case 3029:
                if (c.tutorialProgress >= 14){
                        c.getDH().sendDialogues(3051, -1);
                        c.startAnimation(828);
						c.getLaddersAndStairs().climbLadderorStair(obX, obY, 3088, 9520, 0, true, false);
                    } else {
                        c.sendMessage("You aren't on this part yet.");
                        return;
                    }
                break;

            case 3028:
                if (c.tutorialProgress >= 14) {
                    c.sendMessage("You have already completed this step.");
                    return;
                }
                break;
            case 9300: //Lumbridge squeeze-through fence
				if (c.absX == 3240) {
					if (c.absY == 3334) {
                        c.getPA().walkTo(0, -2);
					} else if (c.absY == 3335) {
                        c.getPA().walkTo(0, 2);
					} else {
						c.sendMessage("You can't do that from here.");
                        return;
					}
                        c.getPA().sendFrame36(173, 0);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
                        @Override
                        public void execute(CycleEventContainer container) {
								CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
								@Override
								public void execute(CycleEventContainer container) {
									// TODO Auto-generated method stub
									c.playerWalkIndex = 2750;
									c.playerRunIndex = 2750;
										container.stop();
								}

								@Override
								public void stop() {
									if (c.absY == 3337) {
										c.getPA().walkTo(0, -3);
										c.postProcessing();
									} else if (c.absY == 3332) {
										c.getPA().walkTo(0, 3);
										c.postProcessing();
									}
									container.stop();

								}

							}, 2);
                        }

                        @Override
                        public void stop() {
								c.getPA().resetlogCross(c);
								//c.getPA().resetlogCross(c);
							c.getPA().requestUpdates();
						}
                    }, 6);
                } else {
                    c.sendMessage("You can't do that from here.");
                }
                break;
			case 26293:
				c.getPA().movePlayer(2916, 3745, 0);
			break;
			case 26342:
			if (c.getItems().playerHasItem(954, 1) && !c.GodwarsRope){
				c.getPA().sendConfig(1048, 1);
				c.GodwarsRope = true;
				return;
			} else if (!c.getItems().playerHasItem(954, 1) && !c.GodwarsRope){
				c.sendMessage("You need a rope to do that!");
				return;
			} else if(c.GodwarsRope){
				c.getPA().movePlayer(2881, 5310, 2);
			}
			break;
			case 35999:
			c.isRunning2 = false;
			c.playerStandIndex = 762;
			c.playerWalkIndex = 762;
			c.playerRunIndex = 762;
				c.getPA().walkTo(-4, 0);
				c.getPA().addSkillXP(5, c.playerAgility);
			CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						c.getPA().requestUpdates();
						c.getPA().resetlogCross(c);
						container.stop();
					}
					@Override
					public void stop() {
					}
				}, 4);	
			break;
			
            case 3031:
                if (c.tutorialProgress == 26) {
                    c.sendMessage(
                            "You have already completed this step.");
                    return;
                } else if (c.tutorialProgress > 35) {
                   // UseOther.useDown(player, objectType);
                }
                break;

            case 3030:
                if (c.tutorialProgress == 26) {
					c.getLaddersAndStairs().climbLadderorStair(obX, obY, 3111, 3127, 0, true, false);
                    c.getDH().sendDialogues(3078, -1);
                    //c.startAnimation(828);
                } else if (c.tutorialProgress > 35) {
                    //UseOther.useUp(player, objectType);
                }
                break;
			case 19189:
			if (c.getHunter().trapX == obX && c.getHunter().trapY == obY) {
				c.getHunter().lootAnimal();
				} else if (c.getHunter().trapX2 == obX && c.getHunter().trapY2 == obY) {
				c.getHunter().lootAnimal2();
				} else if (c.getHunter().trapX3 == obX && c.getHunter().trapY3 == obY) {
				c.getHunter().lootAnimal3();
				} else if (c.getHunter().trapX4 == obX && c.getHunter().trapY4 == obY) {
				c.getHunter().lootAnimal4();
				} else if (c.getHunter().trapX5 == obX && c.getHunter().trapY5 == obY) {
				c.getHunter().lootAnimal5();
				} else {
				c.sendMessage("This is not your trap!");
			}
			break;
			case 19654:
			if (c.getHunter().netX == obX && c.getHunter().netY == obY+1) {
				c.getHunter().lootNet();
				} else	if (c.getHunter().netX2 == obX && c.getHunter().netY2 == obY+1) {
				c.getHunter().lootNet2();
				} else	if (c.getHunter().netX3 == obX && c.getHunter().netY3 == obY+1) {
				c.getHunter().lootNet3();
				} else	if (c.getHunter().netX4 == obX && c.getHunter().netY4 == obY+1) {
				c.getHunter().lootNet4();
				} else {
				c.sendMessage("This is not your trap!");
			}
			break;
			case 19187:
			if (c.getHunter().trapX == obX && c.getHunter().trapY == obY) {
				c.getHunter().removeTrap(obX, obY);
				} else if (c.getHunter().trapX2 == obX && c.getHunter().trapY2 == obY) {
				c.getHunter().removeTrap2(obX, obY);
				} else if (c.getHunter().trapX3 == obX && c.getHunter().trapY3 == obY) {
				c.getHunter().removeTrap3(obX, obY);
				} else if (c.getHunter().trapX4 == obX && c.getHunter().trapY4 == obY) {
				c.getHunter().removeTrap4(obX, obY);
				} else if (c.getHunter().trapX5 == obX && c.getHunter().trapY5 == obY) {
				c.getHunter().removeTrap5(obX, obY);
				} else {
				c.sendMessage("This is not your trap!");
			}
			break;
			case 28564:
			
			if (c.getHunter().netX == 0 && c.getHunter().netY == 0) {
				c.getHunter().setNetTrap(obX, obY);
				} else if (c.getHunter().netX2 == 0 && c.getHunter().netY2 == 0) {
				c.getHunter().setNetTrap2(obX, obY);
				} else if (c.getHunter().netX3 == 0 && c.getHunter().netY3 == 0) {
				c.getHunter().setNetTrap3(obX, obY);
				} else if (c.getHunter().netX4 == 0 && c.getHunter().netY4 == 0) {
				c.getHunter().setNetTrap4(obX, obY);
			}
			break;
			case 28563:
			if (Server.npcHandler.NetTrap) {
				c.getHunter().removeNetTrap(obX, obY);
				} else if (Server.npcHandler.NetTrap2) {
				c.getHunter().removeNetTrap2(obX, obY);
				} else if (Server.npcHandler.NetTrap3) {
				c.getHunter().removeNetTrap3(obX, obY);
				} else if (Server.npcHandler.NetTrap4) {
				c.getHunter().removeNetTrap4(obX, obY);
				} else {
				c.sendMessage("This is not your trap!");
			}
			break;	
			//case 28563:
			case 28566:
			if (Server.npcHandler.NetTrap) {
				c.getHunter().removeNetTrap(obX, obY-1);
				} else if (Server.npcHandler.NetTrap2) {
				c.getHunter().removeNetTrap2(obX, obY-1);
				} else if (Server.npcHandler.NetTrap3) {
				c.getHunter().removeNetTrap3(obX, obY-1);
				} else if (Server.npcHandler.NetTrap4) {
				c.getHunter().removeNetTrap4(obX, obY-1);
				} else {
				c.sendMessage("This is not your trap!");
			}
			break;
					case 34819:
			if(c.objectX == 2615 && c.objectY == 3303) {
				c.getPA().object(-1, c.objectX, c.objectY, -2, 0);
				c.getPA().object(-1, c.objectX+1, c.objectY, 0, 0);
				c.getPA().object(34822, c.objectX+1, c.objectY+1, -2, 0);
				c.getPA().object(34819, c.objectX, c.objectY+1, 0, 0);
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						container.stop();
					}
					@Override
					public void stop() {
						c.getPA().object(-1, c.objectX, c.objectY+1, -2, 0);
						c.getPA().object(-1, c.objectX-1, c.objectY+1, 0, 0);
						c.getPA().object(34822, c.objectX, c.objectY, -2, 0);
						c.getPA().object(34819, c.objectX-1, c.objectY, 0, 0);
					}
				}, 250);	
			}
			break;
					case 34822:
			if(c.objectX == 2616 && c.objectY == 3303) {
				c.getPA().object(-1, c.objectX, c.objectY, -2, 0);
				c.getPA().object(-1, c.objectX-1, c.objectY, 0, 0);
				c.getPA().object(34822, c.objectX, c.objectY+1, -2, 0);
				c.getPA().object(34819, c.objectX-1, c.objectY+1, 0, 0);
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						container.stop();
					}
					@Override
					public void stop() {
						c.getPA().object(-1, c.objectX, c.objectY+1, -2, 0);
						c.getPA().object(-1, c.objectX-1, c.objectY+1, 0, 0);
						c.getPA().object(34822, c.objectX, c.objectY, -2, 0);
						c.getPA().object(34819, c.objectX-1, c.objectY, 0, 0);
					}
				}, 250);	
			}
			break;
		case 26913:
			if(obX == 3101 && obY == 3510) {
				c.getPA().object(-1, obX, obY, 0, 0);
				c.getPA().object(-1, obX, obY-1, 0, 0);
				c.getPA().object(26913, obX-1, obY, 1, 0);
				c.getPA().object(26910, obX-1, obY-1, 3, 0);
				CycleEventHandler.getSingleton().addEvent(obX, obY, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						container.stop();
					}
					@Override
					public void stop() {
						c.getPA().object(-1, obX-1, obY, 0, 0);
						c.getPA().object(-1, obX-1, obY-1, 0, 0);
						c.getPA().object(26913, obX, obY, 0, 0);
						c.getPA().object(26910, obX, obY-1, 0, 0);
					}
				}, 300);	
			} else 
			if(obX == 3100 && obY == 3510) {
				CycleEventHandler.getSingleton().stopEvent(3101, 3510);
			}
			break;
			case 29355:
			if(c.objectX == 3097 && c.objectY == 9867)
			c.getPA().movePlayer(3096, 3468, 0);
				if(obX == 3209 && obY == 9616) {
                        c.startAnimation(828);
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {
							c.getPA().movePlayer(3208, 3217, 0);
						}

					}, 2);
				}
				break;
			case 35551:
			if(c.objectX == 3268 && c.objectY == 3228) {
						c.getPA().object(35550, c.objectX, c.objectY, -3, 0);
						c.getPA().object(35552, c.objectX, c.objectY-1, -1, 0);
						if(c.absX == 3267)
						c.getPA().walkTo(1, 0);
						if(c.absX == 3268)
						c.getPA().walkTo(-1, 0);
					
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						container.stop();
					}
					@Override
					public void stop() {
						c.getPA().object(35551, c.objectX, c.objectY, 0, 0);
						c.getPA().object(35549, c.objectX, c.objectY-1, 0, 0);
					}
				}, 2);		
			}
			break;
			case 35549:
			if(c.objectX == 3268 && c.objectY == 3228) {
						c.getPA().object(35550, c.objectX, c.objectY+1, -3, 0);
						c.getPA().object(35552, c.objectX, c.objectY, -1, 0);
						if(c.absX == 3267)
						c.getPA().walkTo(1, 0);
						if(c.absX == 3268)
						c.getPA().walkTo(-1, 0);
					
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						container.stop();
					}
					@Override
					public void stop() {
						c.getPA().object(35551, c.objectX, c.objectY, 0, 0);
						c.getPA().object(35549, c.objectX, c.objectY-1, 0, 0);
					}
				}, 2);		
			}
			break;
			case 9301:
			if(c.objectX == 2575 && c.objectY == 3108) {
				c.startAnimation(827);
			EventManager.getSingleton().addEvent(
					new Event() {
						public void execute(EventContainer C) {
							//c.getPA().object(26933, c.objectX, c.objectY, 0, 0);
							//c.getPA().openTrapdoor(26933, 22);
							c.getPA().movePlayer(2575, 3112, 0);
							C.stop();
						}	
				}, 900); // 100 secs
			}
			break;
			case 9302:
			if(c.objectX == 2575 && c.objectY == 3111) {
				c.startAnimation(827);
			EventManager.getSingleton().addEvent(
					new Event() {
						public void execute(EventContainer C) {
							//c.getPA().object(26933, c.objectX, c.objectY, 0, 0);
							//c.getPA().openTrapdoor(26933, 22);
							c.getPA().movePlayer(2575, 3107, 0);
							C.stop();
						}	
				}, 900); // 100 secs
			}
			break;
			case 9311:
			if(c.objectX == 3139 && c.objectY == 3516) {
				c.startAnimation(827);
			EventManager.getSingleton().addEvent(
					new Event() {
						public void execute(EventContainer C) {
							//c.getPA().object(26933, c.objectX, c.objectY, 0, 0);
							//c.getPA().openTrapdoor(26933, 22);
							c.getPA().movePlayer(3144, 3514, 0);
							C.stop();
						}	
				}, 900); // 100 secs
			}
			break;
			case 9312:
			if(c.objectX == 3143 && c.objectY == 3514) {
				c.startAnimation(827);
			EventManager.getSingleton().addEvent(
					new Event() {
						public void execute(EventContainer C) {
							//c.getPA().object(26933, c.objectX, c.objectY, 0, 0);
							//c.getPA().openTrapdoor(26933, 22);
							c.getPA().movePlayer(3138, 3516, 0);
							C.stop();
						}	
				}, 900); // 100 secs
			}
			break;
			case 26934:
			if(c.objectX == 3097 && c.objectY == 3468) {
				c.startAnimation(828);
				EventManager.getSingleton().addEvent(
					new Event() {
						public void execute(EventContainer C) {
							//c.getPA().object(26933, c.objectX, c.objectY, 0, 0);
							//c.getPA().openTrapdoor(26933, 22);
							c.getPA().movePlayer(3096, 9867, 0);
							C.stop();
						}	
				}, 900); // 100 secs
			}
			break;
			case 23271:
			CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
				@Override
				public void execute(CycleEventContainer container) {
					if (c.getY() == 3520) {
						WildernessDitch.wildernessDitchEnter(c);
						container.stop();
					} else if (c.getY() == 3523) {
						WildernessDitch.wildernessDitchLeave(c);
						container.stop();
					}
				}

				@Override
				public void stop() {
				}
			}, 2);
			break;
			case 26933:
			if(c.objectX == 3097 && c.objectY == 3468){
			c.getPA().openTrapdoor(26933, 26934, 22, 2);
			}
			break;
			case 2465://air
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[0][1], c.getRunecrafting().overworldAltar[0][2], 0);
			break;
			case 2468:
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[1][1], c.getRunecrafting().overworldAltar[1][2], 0);
			break;
			case 2469:
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[2][1], c.getRunecrafting().overworldAltar[2][2], 0);
			break;
			case 2470:
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[4][1], c.getRunecrafting().overworldAltar[4][2], 0);
			break;
			case 2471:
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[8][1], c.getRunecrafting().overworldAltar[8][2], 0);
			break;
			case 2473://nature
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[11][1], c.getRunecrafting().overworldAltar[11][2], 0);
			break;
			case 2477:
					c.getPA().movePlayer(c.getRunecrafting().overworldAltar[6][1], c.getRunecrafting().overworldAltar[6][2], 0);
			break;
		case 2492:
			if (c.killCount >= 20) {
				c.getDH().sendOption4("Armadyl", "Bandos", "Saradomin",
						"Zamorak");
				c.dialogueAction = 20;
			} else {
				c.sendMessage("You need 20 kill count before teleporting to a boss chamber.");
			}
			break;

		case 1765:
			c.getPA().movePlayer(3067, 10256, 0);
			break;
		case 2882:
		case 2883:
			if (c.objectX == 3268) {
				if (c.absX < c.objectX) {
					c.getPA().walkTo(1, 0);
				} else {
					c.getPA().walkTo(-1, 0);
				}
			}
			break;
		case 272:
			c.getPA().movePlayer(c.absX, c.absY, 1);
			break;

		case 273:
			c.getPA().movePlayer(c.absX, c.absY, 0);
			break;
		case 245:
			c.getPA().movePlayer(c.absX, c.absY + 2, 2);
			break;
		case 246:
			c.getPA().movePlayer(c.absX, c.absY - 2, 1);
			break;
		case 1766:
			c.getPA().movePlayer(3016, 3849, 0);
			break;
		case 6552:
			if (c.playerMagicBook == 0) {
				c.playerMagicBook = 1;
				c.setSidebarInterface(6, 12855);
				c.sendMessage("An ancient wisdomin fills your mind.");
				c.getPA().resetAutocast();
			} else {
				c.setSidebarInterface(6, 1151); // modern
				c.playerMagicBook = 0;
				c.sendMessage("You feel a drain on your memory.");
				c.autocastId = -1;
				c.getPA().resetAutocast();
			}
			break;

		case 410:
			if (c.playerMagicBook == 0) {
				c.playerMagicBook = 2;
				c.setSidebarInterface(6, 29999);
				c.sendMessage("Lunar wisdom fills your mind.");
				c.getPA().resetAutocast();
			} else {
				c.setSidebarInterface(6, 1151); // modern
				c.playerMagicBook = 0;
				c.sendMessage("You feel a drain on your memory.");
				c.autocastId = -1;
				c.getPA().resetAutocast();
			}
			break;

		case 1816:
			c.getPA().startTeleport2(2271, 4680, 0);
			break;
		case 1817:
			c.getPA().startTeleport(3067, 10253, 0, "modern");
			break;
		case 1814:
			// ardy lever
			c.getPA().startTeleport(3153, 3923, 0, "modern");
			break;
		case 2833:
			if(c.objectX == 2544 && c.objectY == 3111)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, c.absX, c.absY, 1, true, false);
		break;
		case 2796:
			if(c.objectX == 2549 && c.objectY == 3111)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, c.absX, c.absY, 2, true, false);
		break;
		case 2797:
			if(c.objectX == 2549 && c.objectY == 3111)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, c.absX, c.absY, 1, true, false);
		break;
		case 17122:
			if(c.objectX == 2544 && c.objectY == 3111)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, c.absX, c.absY, 0, true, false);
		break;
		case 9356:
			// c.getPA().enterCaves();
			c.sendMessage("Temporarily removed due to bugs.");
			break;
		case 1733:
			c.getPA().movePlayer(c.absX, c.absY + 6404, 0);
			break;

		case 32270:
			c.getPA().movePlayer(c.absX, c.absY - 6404, 0);
			break;

		case 9357:
			c.getPA().resetTzhaar();
			break;

		case 8959:
			if (c.getX() == 2490 && (c.getY() == 10146 || c.getY() == 10148)) {
				if (c.getPA().checkForPlayer(2490,
						c.getY() == 10146 ? 10148 : 10146)) {
					new Object(6951, c.objectX, c.objectY, c.heightLevel, 1,
							10, 8959, 15);
				}
			}
			break;

            /**
             * Bank Booths
             */
           case 6943:
                c.getDH().sendDialogues(1013, 494);
                break;

		case 10177:
			c.getPA().movePlayer(1890, 4407, 0);
			break;
		case 10230:
			c.getPA().movePlayer(2900, 4449, 0);
			break;
		case 10229:
			c.getPA().movePlayer(1912, 4367, 0);
			break;
		case 2623:
			if (c.absX >= c.objectX)
				c.getPA().walkTo(-1, 0);
			else
				c.getPA().walkTo(1, 0);
			break;
		// pc boat
		case 14315:
			c.getPA().movePlayer(2661, 2639, 0);
			break;
		case 14314:
			c.getPA().movePlayer(2657, 2639, 0);
			break;

		case 1596:
		case 1597:
			if (c.getY() >= c.objectY)
				c.getPA().walkTo(0, -1);
			else
				c.getPA().walkTo(0, 1);
			break;

		case 14235:
		case 14233:
			if (c.objectX == 2670)
				if (c.absX <= 2670)
					c.absX = 2671;
				else
					c.absX = 2670;
			if (c.objectX == 2643)
				if (c.absX >= 2643)
					c.absX = 2642;
				else
					c.absX = 2643;
			if (c.absX <= 2585)
				c.absY += 1;
			else
				c.absY -= 1;
			c.getPA().movePlayer(c.absX, c.absY, 0);
			break;

		case 14829:
		case 14830:
		case 14827:
		case 14828:
		case 14826:
		case 14831:
			// Server.objectHandler.startObelisk(objectType);
			Server.objectManager.startObelisk(objectType);
			break;
		case 4387:
			// Server.castleWars.joinWait(c,1);
			break;

		case 4388:
			// Server.castleWars.joinWait(c,2);
			break;

		case 4408:
			// Server.castleWars.joinWait(c,3);
			break;

		case 9369:
			if (c.getY() > 5175)
				c.getPA().movePlayer(2399, 5175, 0);
			else
				c.getPA().movePlayer(2399, 5177, 0);
			break;

		case 9368:
			if (c.getY() < 5169) {
				Server.fightPits.removePlayerFromPits(c.playerId);
				c.getPA().movePlayer(2399, 5169, 0);
			}
			break;
		case 4411:
		case 4415:
		case 4417:
		case 4418:
		case 4419:
		case 4420:
		case 4469:
		case 4470:
		case 4911:
		case 4912:
		case 1747:
		case 1757:
			// Server.castleWars.handleObjects(c, objectType, obX, obY);
			break;

		case 2286:
		case 154:
		case 4058:
		case 2295:
		case 2285:
		case 2313:
		case 2312:
		case 2314:
			c.getAgility().handleGnomeCourse(objectType, obX, obY);
			break;

			/*
			 * Barrows Chest
			 */
		case 10284:
		int rewardsAmount = 0;
			if (c.barrowsKillCount < 1) {
				c.sendMessage("You haven't killed all the brothers");
			}
			if (c.barrowsKillCount == 5
					&& c.barrowsNpcs[c.randomCoffin][1] == 1) {
				c.sendMessage("I have already summoned this npc.");
			}
			if (c.barrowsNpcs[c.randomCoffin][1] == 0
					&& c.barrowsKillCount >= 5) {
				Server.npcHandler.spawnNpc(c, c.barrowsNpcs[c.randomCoffin][0],
						3551, 9694 - 1, 0, 0, 120, 30, 200, 200, true, true);
				c.barrowsNpcs[c.randomCoffin][1] = 1;
			}
			if(c.BarrowsRewardPotential < 381){
				rewardsAmount = 2;
				if (Misc.random(2) == 1)
				c.getItems().addItem(995, 2+Misc.random(772));
			} else if(c.BarrowsRewardPotential > 381 && c.BarrowsRewardPotential < 506){
				rewardsAmount = 3;
				
				c.getItems().addItem(995, 2+Misc.random(772));
				c.getItems().addItem(558, 253+Misc.random(83));
			}
			if ((c.barrowsKillCount > 5 || c.barrowsNpcs[c.randomCoffin][1] == 2)
					&& c.getItems().freeSlots() >= 2) {
				c.getPA().resetBarrows();
				c.BarrowsKC += 1;
				c.getItems().addItem(c.getPA().randomRunes(),
						Misc.random(150) + 100);
				if (Misc.random(2448/c.barrowsKillCount) == 1){
					c.getItems().addItem(c.getPA().randomBarrows(), 1);
					c.getCollectionLog().addBossLogItems(c.getCollectionLog().barrowsCollectionLog, c.getPA().randomBarrows(), 1);
				}
				if (Misc.random(7-c.barrowsKillCount) == 1){
					int RndAmt = Misc.random(5);
					int minAmt = 35;
					int Amt = minAmt+RndAmt;
					c.getItems().addItem(4740, Amt);
					c.getCollectionLog().addBossLogItems(c.getCollectionLog().barrowsCollectionLog, 4740, Amt);
				}
				//c.getPA().startTeleport(3564, 3288, 0, "modern");
			} else if (c.getItems().freeSlots() < rewardsAmount) {
				c.sendMessage("You need at least " + rewardsAmount + " inventory slots opened.");
				Server.itemHandler.createGroundItem(c, 4207, c.getX(), c.getY(), c.getH(), 1, c.getId());
			}
			break;
		/*
		 * Doors
		 */
		case 6749:
			if (obX == 3562 && obY == 9678) {
				c.getPA().object(3562, 9678, 6749, -3, 0);
				c.getPA().object(3562, 9677, 6730, -1, 0);
			} else if (obX == 3558 && obY == 9677) {
				c.getPA().object(3558, 9677, 6749, -1, 0);
				c.getPA().object(3558, 9678, 6730, -3, 0);
			}
			break;
		case 6730:
			if (obX == 3558 && obY == 9677) {
				c.getPA().object(3562, 9678, 6749, -3, 0);
				c.getPA().object(3562, 9677, 6730, -1, 0);
			} else if (obX == 3558 && obY == 9678) {
				c.getPA().object(3558, 9677, 6749, -1, 0);
				c.getPA().object(3558, 9678, 6730, -3, 0);
			}
			break;
		case 6727:
			if (obX == 3551 && obY == 9684) {
				c.sendMessage("You cant open this door..");
			}
			break;
		case 6746:
			if (obX == 3552 && obY == 9684) {
				c.sendMessage("You cant open this door..");
			}
			break;
		case 6748:
			if (obX == 3545 && obY == 9678) {
				c.getPA().object(3545, 9678, 6748, -3, 0);
				c.getPA().object(3545, 9677, 6729, -1, 0);
			} else if (obX == 3541 && obY == 9677) {
				c.getPA().object(3541, 9677, 6748, -1, 0);
				c.getPA().object(3541, 9678, 6729, -3, 0);
			}
			break;
		case 6729:
			if (obX == 3545 && obY == 9677) {
				c.getPA().object(3545, 9678, 6748, -3, 0);
				c.getPA().object(3545, 9677, 6729, -1, 0);
			} else if (obX == 3541 && obY == 9678) {
				c.getPA().object(3541, 9677, 6748, -1, 0);
				c.getPA().object(3541, 9678, 6729, -3, 0);
			}
			break;
		case 6726:
			if (obX == 3534 && obY == 9684) {
				c.getPA().object(3534, 9684, 6726, -4, 0);
				c.getPA().object(3535, 9684, 6745, -2, 0);
			} else if (obX == 3535 && obY == 9688) {
				c.getPA().object(3535, 9688, 6726, -2, 0);
				c.getPA().object(3534, 9688, 6745, -4, 0);
			}
			break;
		case 6745:
			if (obX == 3535 && obY == 9684) {
				c.getPA().object(3534, 9684, 6726, -4, 0);
				c.getPA().object(3535, 9684, 6745, -2, 0);
			} else if (obX == 3534 && obY == 9688) {
				c.getPA().object(3535, 9688, 6726, -2, 0);
				c.getPA().object(3534, 9688, 6745, -4, 0);
			}
			break;
		case 6743:
			if (obX == 3545 && obY == 9695) {
				c.getPA().object(3545, 9694, 6724, -1, 0);
				c.getPA().object(3545, 9695, 6743, -3, 0);
			} else if (obX == 3541 && obY == 9694) {
				c.getPA().object(3541, 9694, 6724, -1, 0);
				c.getPA().object(3541, 9695, 6743, -3, 0);
			}
			break;
		case 6724:
			if (obX == 3545 && obY == 9694) {
				c.getPA().object(3545, 9694, 6724, -1, 0);
				c.getPA().object(3545, 9695, 6743, -3, 0);
			} else if (obX == 3541 && obY == 9695) {
				c.getPA().object(3541, 9694, 6724, -1, 0);
				c.getPA().object(3541, 9695, 6743, -3, 0);
			}
			break;
		/*
		 * Cofins
		 */
		case 6707: // verac
			c.getPA().movePlayer(3556, 3298, 0);
			break;

		case 6823:
			if (server.model.minigames.Barrows.selectCoffin(c, objectType)) {
				return;
			}
			if (c.barrowsNpcs[0][1] == 0) {
				Server.npcHandler.spawnNpc(c, 2030, c.getX(), c.getY() - 1, -1,
						0, 120, 25, 200, 200, true, true);
				c.barrowsNpcs[0][1] = 1;
			} else {
				c.sendMessage("You have already searched in this sarcophagus.");
			}
			break;

		case 6706: // torag
			c.getPA().movePlayer(3553, 3283, 0);
			break;

		case 6772:
			if (server.model.minigames.Barrows.selectCoffin(c, objectType)) {
				return;
			}
			if (c.barrowsNpcs[1][1] == 0) {
				Server.npcHandler.spawnNpc(c, 2029, c.getX() + 1, c.getY(), -1,
						0, 120, 20, 200, 200, true, true);
				c.barrowsNpcs[1][1] = 1;
			} else {
				c.sendMessage("You have already searched in this sarcophagus.");
			}
			break;

		case 6705: // karil stairs
			c.getPA().movePlayer(3565, 3276, 0);
			break;
		case 6822:
			if (server.model.minigames.Barrows.selectCoffin(c, objectType)) {
				return;
			}
			if (c.barrowsNpcs[2][1] == 0) {
				Server.npcHandler.spawnNpc(c, 2028, c.getX(), c.getY() - 1, -1,
						0, 90, 17, 200, 200, true, true);
				c.barrowsNpcs[2][1] = 1;
			} else {
				c.sendMessage("You have already searched in this sarcophagus.");
			}
			break;

		case 6704: // guthan stairs
			c.getPA().movePlayer(3578, 3284, 0);
			break;
		case 6773:
			if (server.model.minigames.Barrows.selectCoffin(c, objectType)) {
				return;
			}
			if (c.barrowsNpcs[3][1] == 0) {
				Server.npcHandler.spawnNpc(c, 2027, c.getX(), c.getY() - 1, -1,
						0, 120, 23, 200, 200, true, true);
				c.barrowsNpcs[3][1] = 1;
			} else {
				c.sendMessage("You have already searched in this sarcophagus.");
			}
			break;

		case 6703: // dharok stairs
			c.getPA().movePlayer(3574, 3298, 0);
			break;
		case 6771:
			if (server.model.minigames.Barrows.selectCoffin(c, objectType)) {
				return;
			}
			if (c.barrowsNpcs[4][1] == 0) {
				Server.npcHandler.spawnNpc(c, 2026, c.getX(), c.getY() - 1, -1,
						0, 120, 45, 250, 250, true, true);
				c.barrowsNpcs[4][1] = 1;
			} else {
				c.sendMessage("You have already searched in this sarcophagus.");
			}
			break;

			case 5553:
			case 6702: // cave horror exit
				c.getPA().movePlayer(3749, 2973, 0);
			break;
			case 3650:// cave horror entrance
			c.getPA().movePlayer(3747, 9373, 0);
			break;
		// DOORS
		case 1516:
		case 1519:
			if (c.objectY == 9698)
				if (c.absY >= c.objectY)
					c.getPA().walkTo(0, -1);
				else
					c.getPA().walkTo(0, 1);
				break;
		case 1530:
		case 1531:
		case 1533:
		case 1534:
		case 11712:
		case 11711:
		case 11707:
		case 11708:
		case 6725:
		case 3198:
		case 3197:
			Server.objectHandler.doorHandling(objectType, c.objectX, c.objectY,
					0);
			break;

		case 4495:
			if (c.heightLevel == 1) {
				c.getPA().movePlayer(c.absX + 5, c.absY, 2);
			}
			break;

		case 5126:
			if (c.absY == 3554)
				c.getPA().walkTo(0, 1);
			else
				c.getPA().walkTo(0, -1);
			break;
		case 409://altar
			if (c.playerLevel[5] < c.getPA().getLevelForXP(c.playerXP[5])) {
				c.startAnimation(645);
				c.playerLevel[5] = c.getPA().getLevelForXP(c.playerXP[5]);
				c.sendMessage("You recharge your prayer points.");
				c.getPA().refreshSkill(5);
			} else {
				c.sendMessage("You already have full prayer points.");
			}
			break;
		case 881:
			c.getPA().openTrapdoor(881, 882, 10, 2);
			break;
		case 2873:
			if (!c.getItems().ownsCape()) {
				c.startAnimation(645);
				c.sendMessage("Saradomin blesses you with a cape.");
				c.getItems().addItem(2412, 1);
			}
			break;
		case 2875:
			if (!c.getItems().ownsCape()) {
				c.startAnimation(645);
				c.sendMessage("Guthix blesses you with a cape.");
				c.getItems().addItem(2413, 1);
			}
			break;
		case 2874:
			if (!c.getItems().ownsCape()) {
				c.startAnimation(645);
				c.sendMessage("Zamorak blesses you with a cape.");
				c.getItems().addItem(2414, 1);
			}
			break;
		case 2879:
			c.getPA().movePlayer(2538, 4716, 0);
			break;
		case 2878:
			c.getPA().movePlayer(2509, 4689, 0);
			break;
		case 5960:
			c.getPA().startTeleport2(3090, 3956, 0);
			break;

		case 1815:
			c.getPA().startTeleport2(Config.EDGEVILLE_X, Config.EDGEVILLE_Y, 0);
			break;

		case 9706:
			c.getPA().startTeleport2(3105, 3951, 0);
			break;
		case 9707:
			c.getPA().startTeleport2(3105, 3956, 0);
			break;

		case 5959:
			c.getPA().startTeleport2(2539, 4712, 0);
			break;

		case 2558:
			c.sendMessage("This door is locked.");
			break;

		case 9294:
			if (c.absX < c.objectX) {
				c.getPA().movePlayer(c.objectX + 1, c.absY, 0);
			} else if (c.absX > c.objectX) {
				c.getPA().movePlayer(c.objectX - 1, c.absY, 0);
			}
			break;

			case 12309:
			c.getPA().openUpBank(0);
			break;
		//case 3044:
			//c.getSmithing().sendSmelting();
			//break;
		case 733:
			c.startAnimation(451);
			if (c.objectX == 3158 && c.objectY == 3951) {
				new Object(734, c.objectX, c.objectY, c.heightLevel, 1, 10,
						733, 50);
			} else {
				new Object(734, c.objectX, c.objectY, c.heightLevel, 0, 10,
						733, 50);
			}
			break;

		default:
			ScriptManager.callFunc("objectClick1_" + objectType, c, objectType,
					obX, obY);
			break;

		}
	}

	public void secondClickObject(int objectType, int obX, int obY) {
		c.clickObjectType = 0;
		c.getAD().DiaryObjectClick(objectType, 2);
						//c.getPA().requestUpdates();
						
		ObjectDef def = ObjectDef.getObjectDef(objectType);
		c.sendMessage("Object click type 2: " + def.type);
        if (Farming.inspectObject(c, obX, obY)) {
            return;
        }
		switch (def.type) {
			
							case 28983:
							if(obX == 3211 && obY == 3456){
								if(!STASHConfig.EasyStashBuilt[0])
									c.getSTASH().setSTASH(def.type, obX, obY);
								else if(STASHConfig.EasyStashBuilt[0] && !STASHConfig.Stored[1][0] && !STASHConfig.taken[1][0])
									c.getSTASH().storeSTASH(def.type);
								else if(STASHConfig.EasyStashBuilt[0] && STASHConfig.Stored[1][0] && !STASHConfig.taken[1][0])
									c.getSTASH().takeSTASH(def.type);
								else if(STASHConfig.EasyStashBuilt[0] && STASHConfig.Stored[1][0] && STASHConfig.taken[1][0])
									c.getSTASH().storeSTASH(def.type);
							}
							break;
            /**
             * Bank Booths
             */
			 case 25808:
			 case 10060:
			 case 10355:
			 case 7409:
            case 6943:
			c.getPA().openUpBank(0);
			break;
			case 12309:
				c.getShops().openShop(56);
			break;
			case 26829:
			c.getPA().startTeleport2(2862, 5354, 2);
			break;
			
 case 2090:
            case 2091:
            case 3042:
                Mining.prospectRock(c, "copper ore");
                break;
            case 2094:
            case 2095:
            case 3043:
                Mining.prospectRock(c, "tin ore");
                break;
            case 2110:
                Mining.prospectRock(c, "blurite ore");
                break;
            case 2092:
            case 2093:
                Mining.prospectRock(c, "iron ore");
                break;
            case 2100:
            case 2101:
                Mining.prospectRock(c, "silver ore");
                break;
            case 2098:
            case 2099:
                Mining.prospectRock(c, "gold ore");
                break;
            case 2096:
            case 2097:
                Mining.prospectRock(c, "coal");
                break;
            case 2102:
            case 2103:
                Mining.prospectRock(c, "mithril ore");
                break;
            case 2104:
            case 2105:
                Mining.prospectRock(c, "adamantite ore");
                break;
            case 2106:
            case 2107:
                Mining.prospectRock(c, "runite ore");
                break;
            case 10947:
                Mining.prospectRock(c, "granite");
                break;
            case 10946:
                Mining.prospectRock(c, "sandstone");
                break;
            case 2111:
                Mining.prospectRock(c, "gem rocks");
                break;
			case 36774:
			if(obX == 3204 && obY == 3207)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, 3205, 3209, 2, false, false);
			break;
			case 882:
			c.getPA().openTrapdoor(881, 881, 10, 2);
			break;
			case 26934:
			c.getPA().openTrapdoor(26933, 26933, 22, 2);
			break;
							//Client c = client;
		case 34384://baker stall
		if(c.objectX == 2656 && c.objectY == 3310){
		int dessert = Misc.random(10);
			if(dessert >= 0 && dessert <= 9)
				c.getThieving().stealFromStall(1891, 10, 1, c.objectId, 1, 2);//itemId, xp, level
			if(dessert >= 0 && dessert <= 4)
				c.getThieving().stealFromStall(2309, 10, 1, c.objectId, 1, 2);//itemId, xp, level
			if(dessert == 10)
				c.getThieving().stealFromStall(1901, 10, 1, c.objectId, 1, 2);//itemId, xp, level
		} else if(c.objectX == 2667 && c.objectY == 3310){
		int dessert = Misc.random(15);
			if(dessert >= 5 && dessert <= 14)
				c.getThieving().stealFromStall(1891, 10, 1, c.objectId, 3, 2);//itemId, xp, level
			if(dessert >= 0 && dessert <= 4)
				c.getThieving().stealFromStall(2309, 10, 1, c.objectId, 3, 2);//itemId, xp, level
			if(dessert == 15)
				c.getThieving().stealFromStall(1901, 10, 1, c.objectId, 3, 2);//itemId, xp, level
		}
			break;
		case 34383://silk stall
			c.getThieving().stealFromStall(950, 30, 25, c.objectId, 1, 5);
			break;
		case 34382://silver stall
			c.getThieving().stealFromStall(7650, 100, 75, c.objectId, 2, 30);
			break;
		case 34385://gem stall
			c.getThieving().stealFromStall(1613, 170, 90, c.objectId, 3, 100);
			break;
		case 34386://spice stall
			c.getThieving().stealFromStall(2007, 170, 65, c.objectId, 0, 80);
			break;
		case 34387://fur stall
			c.getThieving().stealFromStall(948, 170, 35, c.objectId, 0, 10);
			break;
		case 2558:
			if (System.currentTimeMillis() - c.lastLockPick < 3000
					|| c.freezeTimer > 0)
				break;
			if (c.getItems().playerHasItem(1523, 1)) {
				c.lastLockPick = System.currentTimeMillis();
				if (Misc.random(10) <= 3) {
					c.sendMessage("You fail to pick the lock.");
					break;
				}
				if (c.objectX == 3044 && c.objectY == 3956) {
					if (c.absX == 3045) {
						c.getPA().walkTo2(-1, 0);
					} else if (c.absX == 3044) {
						c.getPA().walkTo2(1, 0);
					}

				} else if (c.objectX == 3038 && c.objectY == 3956) {
					if (c.absX == 3037) {
						c.getPA().walkTo2(1, 0);
					} else if (c.absX == 3038) {
						c.getPA().walkTo2(-1, 0);
					}
				} else if (c.objectX == 3041 && c.objectY == 3959) {
					if (c.absY == 3960) {
						c.getPA().walkTo2(0, -1);
					} else if (c.absY == 3959) {
						c.getPA().walkTo2(0, 1);
					}
				}
			} else {
				c.sendMessage("I need a lockpick to pick this lock.");
			}
			break;
		default:
			ScriptManager.callFunc("objectClick2_" + objectType, c, objectType,
					obX, obY);
			break;
		}
	}

	public void thirdClickObject(int objectType, int obX, int obY) {
		c.clickObjectType = 0;
		c.sendMessage("Object type 3: " + objectType);
						//c.getPA().requestUpdates();
		switch (objectType) {
			
			case 36774:
			if(obX == 3204 && obY == 3207)
				c.getLaddersAndStairs().climbLadderorStair(obX, obY, 3205, 3209, 0, false, false);
			break;
			
			case 12309:
				c.getShops().openShop(57);
			break;
		default:
			ScriptManager.callFunc("objectClick3_" + objectType, c, objectType,
					obX, obY);
			break;
		}
	}

	public void firstClickNpc(int i) {
		c.clickNpcType = 0;
		c.npcClickIndex = 0;
		c.getAD().DiaryNpcFirstClick(i);
		
		if (Fishing.fishingNPC(c, i)) {
			Fishing.fishingNPC(c, 1, i);
		}
		switch (i) {
			
		case 284:
			if (c.doricQuest == 0) {
				c.getDH().sendDialogues(89, i);
			} else if (c.doricQuest == 1) {
				c.getDH().sendDialogues(84, i);
			} else if (c.doricQuest == 2) {
				c.getDH().sendDialogues(86, i);
			} else if (c.doricQuest == 3) {
				c.getDH().sendDialogues(100, i);
			}
			break;
		case 520:/*Lumbridge general shop*/
		case 521:
		//c.getShops().openShop(55);
		break;
		case 608:
			if (c.blackKnight == 0 /*&& c.questPoints >= 12*/) {
				c.getDH().sendDialogues(3902, i);
			} else if (c.blackKnight == 1) {
				c.getDH().sendDialogues(3510, i);
			}else if (c.blackKnight == 2) {
				c.getDH().sendDialogues(3502, i);
			}else if (c.blackKnight == 3) {
				c.sendMessage("He has nothing to say to you.");
			}
			break;
		case 2244:
			c.getDH().sendDialogues(14, i);
			break;
		case 278:
			if (c.cookAss == 0) {
				c.getDH().sendDialogues(50, i);
			} else if (c.cookAss == 1) {
				c.getDH().sendDialogues(67, i);
			} else if (c.cookAss == 2) {
				c.getDH().sendDialogues(69, i);
			} else if (c.cookAss == Config.FINISHEDQUEST) {
				c.getDH().sendDialogues(76, i);
			}
			break;
		/*
		 * tutorial island
		 */
		case 945:
			if (c.tutorialProgress == 0) {
				c.getDH().sendDialogues(3001, i);
			}
			if (c.tutorialProgress == 1) {
				c.getDH().sendDialogues(3008, i);
			}
			if (c.tutorialProgress == 2) {
				c.getDH().sendNpcChat1("You should move on now.", i, "Runescape Guide", 9861);
			}
			break;
			case 943:// survival
			if (c.tutorialProgress == 2) {
				c.getDH().sendDialogues(3012, i);
			}
			if (c.tutorialProgress == 5) {
				c.getDH().sendDialogues(3017, i);
			}
			break;

		case 942: // master chef
			if (c.tutorialProgress == 7) {
				c.getDH().sendDialogues(3021, i);
			} else if (c.tutorialProgress == 8) {
				c.getDH().sendDialogues(3025, i);
			}
			break;

		case 949: // quest guide
			if (c.tutorialProgress == 12) {
				c.getDH().sendDialogues(3043, i);
			}
			if (c.tutorialProgress == 13) {
				c.getDH().sendDialogues(3045, i);
			}
			break;
		case 948: // mining tutor
			if (c.tutorialProgress == 14) {
				c.getDH().sendDialogues(3052, i);
			}
			if (c.tutorialProgress == 16) {
				c.getDH().sendDialogues(3056, i);
			}
			if (c.tutorialProgress == 20) {
				c.getDH().sendDialogues(3063, i);
			}
			break;
			
		case 944: // Combat deud
			if (c.tutorialProgress == 21) {
				c.getDH().sendDialogues(3067, i);
			} else if (c.tutorialProgress == 23
					&& !c.getItems().playerHasItem(1171)
					&& !c.getItems().playerHasItem(1277)) {
				c.getDH().sendDialogues(3072, i);
			} else if (c.getItems().playerHasItem(1171)
					&& c.getItems().playerHasItem(1277) && c.tutorialProgress == 23) {
				c.sendMessage(
						"I already gave you a sword and shield.");
				c.nextChat = 0;
				c.getDH()
						.chatboxText(
								"In your worn inventory panel, right click on the dagger and",
								"select the remove option from the drop down list. After you've",
								"unequipped the dagger, wield the sword and shield. As you",
								"pass the mouse over an item you will see its name.",
								"Unequipping items");
				c.getPA().removeHintIcon(c);
			} else if (c.tutorialProgress == 25) {
				c.getDH().sendDialogues(3074, i);
			}
			break;

		case 947: // fiancial dude
			if (c.tutorialProgress == 27) {
				c.getDH().sendDialogues(3079, i);
			}
			// c.getPacketDispatcher().createArrow(1, 7);
			break;
			
		case 954: // prayer dude
			if (c.tutorialProgress == 28) {
				c.getDH().sendDialogues(3089, i);
			}
			if (c.tutorialProgress == 29) {
				c.getDH().sendDialogues(3092, i);
			}
			if (c.tutorialProgress == 31) {
				c.getDH().sendDialogues(3097, i);
			}
			break;
		case 946:// mage
			if (c.tutorialProgress == 32) {
				c.getDH().sendDialogues(3105, i);
			}
			if (c.tutorialProgress == 33) {
				c.getDH().sendDialogues(3108, i);
			}
			if (c.tutorialProgress == 34) {
				c.getDH().sendDialogues(3110, i);
			}
			if (c.tutorialProgress == 35) {
				c.getDH().sendDialogues(3112, i);
			}
			break;
			case 705:
			/*if(!c.MeleeTutorClaimed) {
				if(!c.getItems().playerHasItem(9703, 1))
					c.getItems().addItem(9703, 1);
				if(!c.getItems().playerHasItem(9704, 1))
					c.getItems().addItem(9704, 1);*/
					c.getDH().sendDialogues(502, 705);
					//c.MeleeTutorClaimed = true;
					//c.LastMeleeTutorClaimed = System.currentTimeMillis();
			//}
				break;
				
		case 6055:
		case 6057:
		if (System.currentTimeMillis() - c.foodDelay >= 3000) {
			c.getHunter().catchImpling1(i);
			c.foodDelay = System.currentTimeMillis();
		}
		break;
				case 170://gnome glider
			c.getPA().showInterface(802);
			break;
		case 6056:
		case 6058:
		case 6059:
		case 6060:
		case 6061:
		case 6062:
		case 6063:
		case 6064:
		if (System.currentTimeMillis() - c.foodDelay >= 3000) {
			c.getHunter().catchImpling(i);
			c.foodDelay = System.currentTimeMillis();
		}
		break;
		case 3505:
		case 3506:
		case 3507:
		case 761:
		case 760:
		case 762:
		case 763:
		case 764:
		case 765:
		case 766:
		case 767:
		case 768:
		case 769:
		case 770:
		case 771:
		case 772:
		case 773:
		c.getPets().pickUpClean(c, c.summonId);
		c.hasNpc = false;
		c.summonId = 0;
			break;
		case 1304:
			c.getDH().sendOption5("Home", "Edgeville", "Island",
					"Dagannoth Kings", "Next Page");
			c.teleAction = 1;
			break;

		case 574:
			c.getDH().sendDialogues(16, i);
		break;
		
		case 463:
			c.getDH().sendDialogues(101, i);
		break;
		case 1152:
			c.getDH().sendDialogues(16, i);
			break;

		case 494:
			c.getPA().openUpBank(0);
			break;

		case 3789:
			c.sendMessage((new StringBuilder()).append("You currently have ")
					.append(c.pcPoints).append(" pest control points.")
					.toString());
			break;

		case 3788:
			c.getShops().openVoid();
			break;

		case 553:
			c.getDH().sendDialogues(4000, i);
			break;
		case 741:
			c.getDH().sendDialogues(4010, i);
			break;
		case 905:
			c.getDH().sendDialogues(5, i);
			break;

		case 460:
			c.getDH().sendDialogues(3, i);
			break;

		case 462:
			c.getDH().sendDialogues(7, i);
			break;

		case 599:
			c.getPA().showInterface(3559);
			c.canChangeAppearance = true;
			break;

		case 904:
			c.sendMessage((new StringBuilder()).append("You have ")
					.append(c.magePoints).append(" points.").toString());
			break;
			default:
			break;
		}
	}

	public void secondClickNpc(int i) {
		int x = NPCHandler.npcs[c.npcClickIndex].getX();
		int y = NPCHandler.npcs[c.npcClickIndex].getY();
		c.clickNpcType = 0;
		c.npcClickIndex = 0;
		//NPC npc = NPCHandler.npcs[i];
		if (Fishing.fishingNPC(c, i)) {
			Fishing.fishingNPC(c, 2, i);
		}
		switch (i) {
			case 2147:
			if(x == 1825 && y == 3691)
				c.getPA().movePlayer(3055, 3245, 0);
			else
				c.getPA().movePlayer(1824, 3691, 0);
			break;
		case 520:/*Lumbridge general shop*/
		case 521:
			c.getShops().openShop(55);
		break;
		case 2258:
		c.getAbyss().loadAbyss(c, 3017, 4848);
		break;
		case 0:
			c.getFarmingTools().loadInterfaces();
			break;
			case 10477:
			c.getAD().completeAchievement("VarrockEasy", "Browse Thessalia's store", 0, 1, 1);
			c.getShops().openShop(37);
			break;
			case 3217:
			if(!c.RangedTutorClaimed) {
			if(!c.getItems().playerHasItem(9705, 1))
				c.getItems().addItem(9705, 1);
			if(!c.getItems().playerHasItem(9706, 1))
				c.getItems().addItem(9706, 30);
					c.getDH().sendDialogues(503, 1861);
				c.RangedTutorClaimed = true;
				c.LastRangedTutorClaimed = System.currentTimeMillis();
			}
				break;
			case 3218:
			if(!c.MagicTutorClaimed) {
			if(!c.getItems().playerHasItem(556, 1))
				c.getItems().addItem(556, 30);	
			if(!c.getItems().playerHasItem(558, 1))
				c.getItems().addItem(558, 30);
					c.getDH().sendDialogues(504, 4707);
				c.MagicTutorClaimed = true;
				c.LastMagicTutorClaimed = System.currentTimeMillis();
			}
			break;
			
		case 1282:
			c.getShops().openShop(7);
			break;
			case 2880:
			c.getShops().openShop(19);
			break;
		case 2884:
		case 2885:
			c.getShops().openShop(28);
		break;
//pets pickup
		case 2055:
		case 3099:
		case 6626:
		case 6627:
		case 6630:
		case 6631:
		case 6632:
		case 6633:
		case 6634:
		case 6635:
		case 6636:
		case 6637:
		case 6638:
		case 6639:
		case 6640:
		case 6296:
		case 388:
		c.getPets().pickUpClean(c, c.summonId);
		c.hasNpc = false;
		c.summonId = 0;
			break;
	case 3800:
	case 3801:
		//sailing cutscene
			Sailing.startTravel(c, 14);
		//3281
		break;
		case 575://hickton
			c.getShops().openShop(30);
			break;
		case 558://gerrants
			c.getShops().openShop(21);
			break;
		case 557://wydin
			c.getShops().openShop(47);
			break;
		case 556://grum
			c.getShops().openShop(50);
			break;
		case 3788:
			c.getShops().openVoid();
			break;

		case 494:
			c.getPA().openUpBank(0);
			break;


		case 904:
			c.getShops().openShop(17);
			break;

		case 2813:
		case 2814:
			c.getShops().openShop(1);
			break;

		case 541:
			c.getShops().openShop(5);
			break;

		case 461:
			c.getShops().openShop(2);
			break;

		case 683:
			c.getShops().openShop(3);
			break;

		case 2882://horviks shop
			c.getShops().openShop(35);
			break;

		case 522:
		case 523:
			c.getShops().openShop(1);
			break;
		case 519://bobs brilliant axes
			c.getShops().openShop(23);
			break;
		case 583://Bettys magic emporium
			c.getShops().openShop(26);
			break;

		case 577://cassies shield shop
			c.getShops().openShop(27);
			break;
			
		case 2538:
			c.getShops().openShop(6);
			break;
		case 2886://aubury
			c.getShops().openShop(25);
			break;

		case 2883://lowe
			c.getShops().openShop(29);
			break;
		case 3789://pest control shop
			c.getShops().openShop(18);
			break;
		case 1: // '\001'
		case 9: // '\t'
		case 18: // '\022'
		case 20: // '\024'
		case 21: // '\025'
		case 26: // '\032'
			c.getThieving().stealFromNPC(i);
			break;
		}
	}

	public void thirdClickNpc(int npcType) {
		c.clickNpcType = 0;
		c.npcClickIndex = 0;
		switch (npcType) {
			
			case 705:
			/*if(!c.MeleeTutorClaimed) {
				if(!c.getItems().playerHasItem(9703, 1))
					c.getItems().addItem(9703, 1);
				if(!c.getItems().playerHasItem(9704, 1))
					c.getItems().addItem(9704, 1);*/
					c.getDH().sendDialogues(502, 705);
					//c.MeleeTutorClaimed = true;
					//c.LastMeleeTutorClaimed = System.currentTimeMillis();
			//}
				break;
		default:
			ScriptManager.callFunc("npcClick3_" + npcType, c, npcType);
			if (c.playerRights == 3)
				Misc.println("Third Click NPC : " + npcType);
			break;

		}
	}

}