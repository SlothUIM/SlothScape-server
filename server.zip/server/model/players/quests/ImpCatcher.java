package server.model.players.quests;
import server.model.players.Client;

/**
 * Imp Catcher
 * @author Andrew (Mr Extremez)
 */

public class ImpCatcher {


	public static void showInformation(Client client) {
		for (int i = 8144; i < 8295; i++) {
			client.getPA().sendFrame126("", i);
		}
		client.getPA().sendFrame126("@dre@Imp Catcher", 8144);
		client.getPA().sendFrame126("", 8145);
		if (client.impsC == 0) {
			client.getPA().sendFrame126( "I can start this quest by speaking to Wizard Mizgog who is", 8147);
			client.getPA().sendFrame126("in the Wizard's Tower.", 8148);
		} else if (client.impsC == 1) {
			client.getPA().sendFrame126("@str@I can start this quest by speaking to Wizard Mizgog who is", 8147);
			client.getPA().sendFrame126("@str@in the Wizard's Tower.", 8148);
			client.getPA().sendFrame126("", 8149);
			client.getPA().sendFrame126("Wizard Mizgog have asked you to get the following items:", 8150);
			client.getPA().sendFrame126("Red bead", 8151);
			client.getPA().sendFrame126("Yellow bead", 8152);
			client.getPA().sendFrame126("Black bead", 8153);
			client.getPA().sendFrame126("White bead", 8154);
		} else if (client.impsC == 2) {
			client.getPA().sendFrame126("@str@I can start this quest by speaking to Wizard Mizgog who is", 8147);
			client.getPA().sendFrame126("@str@in the Wizard's Tower.", 8148);
			client.getPA().sendFrame126("", 8149);
			client.getPA().sendFrame126("@str@Wizard Mizgog have asked you to get the following items:", 8150);
			client.getPA().sendFrame126("@str@Red bead", 8151);
			client.getPA().sendFrame126("@str@Yellow bead", 8152);
			client.getPA().sendFrame126("@str@Black bead", 8153);
			client.getPA().sendFrame126("@str@White bead", 8154);
			client.getPA().sendFrame126("", 8155);
			client.getPA().sendFrame126("You have completed this quest!", 8156);
		}
		client.getPA().showInterface(8134);
	}

}
