package server.model.players.quests;
import server.model.players.Client;

/**
 * Elemental workshop I
 * @author Olivier (JohnsonPhillips / JohnsonMichaels123)
 */

public class EleWorkShop {
		
	public static void showInformation(Client client) {
		for (int i = 8144; i < 8195; i++) {
			client.getPA().sendFrame126("", i);
		}
		client.getPA().sendFrame126("@dre@Elemental workshop I", 8144);
		client.getPA().sendFrame126("", 8145);
		if (client.EleWorkShop == 0) {
			client.getPA().sendFrame126("Elemental workshop I", 8144);
			client.getPA().sendFrame126("I can start this quest by searching houses in ", 8147);
			client.getPA().sendFrame126("@or2@Seers' Village",8148);
			client.getPA().sendFrame126("Minimum Requirements", 8150);
			client.getPA().sendFrame126("20 Mining", 8151);
			client.getPA().sendFrame126("20 Smithing", 8151);
			client.getPA().sendFrame126("20 Crafting", 8152);
			client.getPA().sendFrame126("Ability to defeat a level-16 Rock Golem", 8153);
		} else if (client.EleWorkShop == 1) {
			client.getPA().sendFrame126("Elemental workshop I", 8144);
			client.getPA().sendFrame126("@str@I have found a battered book in a house in Seers' Village.", 8145);
			client.getPA().sendFrame126("@str@It tells of magic ore and a workshop created to fashion it.", 8146);
			client.getPA().sendFrame126("Where is this workshop and how do I get in?", 8148);
		} else if (client.EleWorkShop == 2) {
			client.getPA().sendFrame126("Elemental workshop I", 8144);
			client.getPA().sendFrame126("@str@I have found a battered book in a house in Seers' Village.", 8145);
			client.getPA().sendFrame126("@str@It tells of magic ore and a workshop created to fashion it.", 8146);
			client.getPA().sendFrame126("@str@I've found a book in a bookcase in Seers' Village", 8147);
			client.getPA().sendFrame126("The book speaks about an ore that was discovered" , 8149);
			client.getPA().sendFrame126("in the Fifth Age, able to concentrate elemental ", 8150);
			client.getPA().sendFrame126("energy into itself. Following this revelation,", 8151);
			client.getPA().sendFrame126("calling all craftsmen to invent new devices using", 8152);
			client.getPA().sendFrame126("this unique ore. Unfortunately, realising the destructive", 8153);
			client.getPA().sendFrame126("potential of the ore, the workshop had to be closed down, ", 8154);
			client.getPA().sendFrame126("along with details of any processes involved destroyed.", 8155);
		} else if (client.EleWorkShop == 3) {
			client.getPA().sendFrame126("Elemental workshop I", 8144);
			client.getPA().sendFrame126("@str@I've found a book in a bookcase in Seers' Village", 8147);
			client.getPA().sendFrame126("I've found a @blu@key @bla@in the book", 8148);
			client.getPA().sendFrame126("I need to find what this key goes to.", 8150);
		} else if (client.EleWorkShop == 4) {
			client.getPA().sendFrame126("Elemental workshop I", 8144);
			client.getPA().sendFrame126("@str@I've found a book in a bookcase in Seers' Village", 8147);
			client.getPA().sendFrame126("@str@I've found a @blu@key @bla@in the book", 8148);
			client.getPA().sendFrame126("The key opened a mysterious door hidden in a wall.", 8150);
			client.getPA().sendFrame126("There seems to be a workshop below.", 8151);
			client.getPA().sendFrame126("Now to explore this area thoroughly,", 8152);
			client.getPA().sendFrame126("to find what forgotten secrets it contains.", 8153);
		}
		client.getPA().showInterface(8134);
	}

}
