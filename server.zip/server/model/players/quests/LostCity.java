package server.model.players.quests;
import server.model.players.Client;

/**
 * Lost City
 * @author Olivier (JohnsonPhillips / JohnsonMichaels123)
 */

public class LostCity {
		
	public static void showInformation(Client client) {
		for (int i = 8144; i < 8195; i++) {
			client.getPA().sendFrame126("", i);
		}
		client.getPA().sendFrame126("@dre@Lost City", 8144);
		client.getPA().sendFrame126("", 8145);
		if (client.lostCity == 0) {
			client.getPA().sendFrame126("Lost City", 8144);
			client.getPA().sendFrame126(
					"I can start this quest by speaking to the four adventurers ", 8147);
			client.getPA().sendFrame126(
					"west of Lumbridge swamp.",
					8148);
			client.getPA().sendFrame126("Minimum Requirements", 8150);
			client.getPA().sendFrame126(
					"31 Crafting", 8151);
			client.getPA().sendFrame126(
					"36 Woodcutting", 8151);
			client.getPA().sendFrame126(
					"I must be able to defeat a high-level tree spirit", 8153);
			client.getPA().sendFrame126(
					"without the use of weapons or armour.", 8154);
		} else if (client.lostCity == 1) {
			client.getPA().sendFrame126("Lost City", 8144);
			client.getPA().sendFrame126(
					"@str@I've talked to the adventurers who told me", 8147);
			client.getPA().sendFrame126(
					"that there is a leprechaun hiding in the trees nearby", 8148);
			client.getPA().sendFrame126(
					"who knows how to locate the lost city.", 8149);
		} else if (client.lostCity == 2) {
			client.getPA().sendFrame126("Lost City", 8144);
			client.getPA().sendFrame126(
					"@str@I talked to the leprechaun who told me that", 8147);
			client.getPA().sendFrame126(
					"Zanaris can be accessed through the shed in lumbridge", 8148);
			client.getPA().sendFrame126(
					"Swamp through the use of a Dramen staff, which I can craft", 8149);
			client.getPA().sendFrame126(
					"by obtaining logs from a Spirit Tree.", 8149);
		} else if (client.lostCity == 3) {
			client.getPA().sendFrame126("Lost City", 8144);
			client.getPA().sendFrame126(
					"@str@I defeated the Spirit Tree", 8147);
			client.getPA().sendFrame126("@str@I crafted a dramen staff.",
					8148);
			client.getPA().sendFrame126(
					"I went through the Lumbridge shed and discovered Zanaris!", 8149);
		}
		client.getPA().showInterface(8134);
	}

}
