package server.model.players;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import server.model.players.AchievementDiary;
import server.model.players.AchievementTask;

import server.util.Misc;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.*;

public class PlayerSave {

	/**
	 * Loading
	 **/
	public static int loadGame(Client p, String playerName, String playerPass) {
		String line = "";
		String token = "";
		String token2 = "";
		String[] token3 = new String[3];
		boolean EndOfFile = false;
		int ReadMode = 0;
		BufferedReader characterfile = null;
		boolean File1 = false;

		try {
			characterfile = new BufferedReader(new FileReader("C:/Servercharacters/" + playerName + ".txt"));
			File1 = true;
		} catch (FileNotFoundException fileex1) {
		}

		if (File1) {
			// new File ("./characters/"+playerName+".txt");
		} else {
			Misc.println(playerName + ": character file not found.");
			p.newPlayer = false;
			return 0;
		}
		try {
			line = characterfile.readLine();
		} catch (IOException ioexception) {
			Misc.println(playerName + ": error loading file.");
			return 3;
		}
		while (EndOfFile == false && line != null) {
			line = line.trim();
			int spot = line.indexOf("=");
			if (spot > -1) {
				token = line.substring(0, spot);
				token = token.trim();
				token2 = line.substring(spot + 1);
				token2 = token2.trim();
				token3 = token2.split("\t");
				switch (ReadMode) {
				case 1:
					if (token.equals("character-password")) {
						if (playerPass.equalsIgnoreCase(token2)) {
							playerPass = token2;
						} else {
							return 3;
						}
					}
					break;
				case 2:
					if (token.equals("character-height")) {
						p.heightLevel = Integer.parseInt(token2);
					} else if (token.equals("character-posx")) {
						p.teleportToX = (Integer.parseInt(token2) <= 0 ? 3210
								: Integer.parseInt(token2));
					} else if (token.equals("character-posy")) {
						p.teleportToY = (Integer.parseInt(token2) <= 0 ? 3424
								: Integer.parseInt(token2));
					} else if (token.equals("character-rights")) {
						p.playerRights = Integer.parseInt(token2);
					} else if (token.equals("tutorial-progress")) {
						p.tutorialProgress = Integer.parseInt(token2);
					} else if (token.equals("cookAss")) {
						p.cookAss = Integer.parseInt(token2);
					}else if (token.equals("EleWorkShop")) {
						p.EleWorkShop = Integer.parseInt(token2);
					}else if (token.equals("EleWorkshop-stage")) {
						p.EleWorkshopWater_stage = Integer.parseInt(token2);
					} else if (token.equals("sheepShear")) {
						p.sheepShear = Integer.parseInt(token2);
					} else if (token.equals("runeMist")) {
						p.runeMist = Integer.parseInt(token2);
					} else if (token.equals("doricQuest")) {
						p.doricQuest = Integer.parseInt(token2);
					} else if (token.equals("blackKnight")) {
						p.blackKnight = Integer.parseInt(token2);
					} else if (token.equals("shieldArrav")) {
						p.shieldArrav = Integer.parseInt(token2);
					} else if (token.equals("pirateTreasure")) {
						p.pirateTreasure = Integer.parseInt(token2);
					} else if (token.equals("romeo-juliet")) {
						p.romeojuliet = Integer.parseInt(token2);
					} else if (token.equals("vampSlayer")) {
						p.vampSlayer = Integer.parseInt(token2);
					} else if (token.equals("gertCat")) {
						p.gertCat = Integer.parseInt(token2);
					} else if (token.equals("witchspot")) {
						p.witchspot = Integer.parseInt(token2);
					} else if (token.equals("restGhost")) {
						p.restGhost = Integer.parseInt(token2);
					} else if (token.equals("impsC")) {
						p.impsC = Integer.parseInt(token2);
					} else if (token.equals("RecipeDisaster")) {
						p.RFD = Integer.parseInt(token2);
					} else if (token.equals("knightS")) {
						p.knightS = Integer.parseInt(token2);
					}else if (token.equals("lostCity")) {
						p.lostCity = Integer.parseInt(token2);
					} else if (token.equals("questPoints")) {
						p.questPoints = Integer.parseInt(token2);
					} else if (token.equals("crystal-bow-shots")) {
						p.crystalBowArrowCount = Integer.parseInt(token2);
					} else if (token.equals("skull-timer")) {
						p.skullTimer = Integer.parseInt(token2);
					} else if (token.equals("magic-book")) {
						p.playerMagicBook = Integer.parseInt(token2);
					} else if (token.equals("brother-info")) {
						p.barrowsNpcs[Integer.parseInt(token3[0])][1] = Integer
								.parseInt(token3[1]);
					} else if (token.equals("special-amount")) {
						p.specAmount = Double.parseDouble(token2);
					} else if (token.equals("selected-coffin")) {
						p.randomCoffin = Integer.parseInt(token2);
					} else if (token.equals("barrows-killcount")) {
						p.pkPoints = Integer.parseInt(token2);
					} else if (token.equals("teleblock-length")) {
						p.teleBlockDelay = System.currentTimeMillis();
						p.teleBlockLength = Integer.parseInt(token2);
					} else if (token.equals("pc-points")) {
						p.pcPoints = Integer.parseInt(token2);
					} else if (token.equals("slayerTask")) {
						p.slayerTask = Integer.parseInt(token2);
					} else if (token.equals("taskAmount")) {
						p.taskAmount = Integer.parseInt(token2);
					} else if (token.equals("magePoints")) {
						p.magePoints = Integer.parseInt(token2);
					} else if (token.equals("autoRet")) {
						p.autoRet = Integer.parseInt(token2);
					} else if (token.equals("barrowskillcount")) {
						p.barrowsKillCount = Integer.parseInt(token2);
					} else if (token.equals("flagged")) {
						p.accountFlagged = Boolean.parseBoolean(token2);
					} else if (token.equals("wave")) {
						p.waveId = Integer.parseInt(token2);
					} else if (token.equals("void")) {
						for (int j = 0; j < token3.length; j++) {
							p.voidStatus[j] = Integer.parseInt(token3[j]);
						}
					} else if(token.equals("EasyArdyDiaries")) {
							p.ArdyDiaryEasy = Integer.parseInt(token2);
					} else if(token.equals("Blowpipe-Charges")) {
							p.BlowpipeCharges = Integer.parseInt(token2);
					} else if(token.equals("Blowpipe-Darts")) {
							p.BlowpipeDarts = Integer.parseInt(token2);
					} else if(token.equals("Blowpipe-DartType")) {
							p.DartType = Integer.parseInt(token2);
					} else if (token.equals("gwkc")) {
						p.killCount = Integer.parseInt(token2);
					} else if (token.equals("fightMode")) {
						p.fightMode = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune1")) {
							p.PouchRune1 = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune1Amt")) {
							p.PouchRune1Amt = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune2")) {
							p.PouchRune2 = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune2Amt")) {
							p.PouchRune2Amt = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune3")) {
							p.PouchRune3 = Integer.parseInt(token2);
					} else if(token.equals("RunePouchRune3Amt")) {
							p.PouchRune3Amt = Integer.parseInt(token2);
					}
					break;
				case 3:
					if (token.equals("character-equip")) {
						p.playerEquipment[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[1]);
						p.playerEquipmentN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);
					}
					break;
				case 4:
					if (token.equals("character-look")) {
						p.playerAppearance[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[1]);
					}
					break;
				case 5:
					if (token.equals("character-skill")) {
						p.playerLevel[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[1]);
						p.playerXP[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);
					}
					break;
				case 6:
					if (token.equals("character-item")) {
						p.playerItems[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[1]);
						p.playerItemsN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);
					}
					break;
				case 7:
					if (token.equals("character-item")) {
						p.playerLootItems[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[1]);
						p.playerLootItemsN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);
					}
					break;
				case 8:
					if (token.equals("character-bank")) {
						p.bankItems[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItemsN[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank1")) {
						p.bankItems1[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems1N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank2")) {
						p.bankItems2[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems2N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank3")) {
						p.bankItems3[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems3N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank4")) {
						p.bankItems4[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems4N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank5")) {
						p.bankItems5[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems5N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank6")) {
						p.bankItems6[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems6N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank7")) {
						p.bankItems7[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems7N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					} else if (token.equals("character-bank8")) {
						p.bankItems8[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
						p.bankItems8N[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
					}
					break;
				case 9:
					if (token.equals("character-friend")) {
						p.friends[Integer.parseInt(token3[0])] = Long
								.parseLong(token3[1]);
					}
					break;
				case 10:
					/*
					 * if (token.equals("character-ignore")) {
					 * ignores[Integer.parseInt(token3[0])] =
					 * Long.parseLong(token3[1]); }
					 */
					break;
				case 11:
					if (token.equals("Collectionlog-item")) {
						p.getCollectionLog().barrowsCollectionLog[Integer.parseInt(token3[0])][2] = Integer
								.parseInt(token3[2]);
						/*p.playerItemsN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);*/
					}
					if (token.equals("EasyCollectionlog-item")) {
						p.getCollectionLog().EasyClueCollectionLog[Integer.parseInt(token3[0])][2] = Integer
								.parseInt(token3[2]);
						/*p.playerItemsN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);*/
					}
					if (token.equals("BandosCollectionlog-item")) {
						p.getCollectionLog().bandosCollectionLog[Integer.parseInt(token3[0])][2] = Integer
								.parseInt(token3[2]);
						/*p.playerItemsN[Integer.parseInt(token3[0])] = Integer
								.parseInt(token3[2]);*/
					}
					break;
				case 12:
					if (token.equals("Achievement-Easy")) {
						p.getAD().diaries[Integer.parseInt(token3[0])][0] = Integer
								.parseInt(token3[1]);
					}
					if (token.equals("Achievement-Medium")) {
						p.getAD().diaries[Integer.parseInt(token3[0])][1] = Integer
								.parseInt(token3[1]);
					}
					if (token.equals("Achievement-Hard")) {
						p.getAD().diaries[Integer.parseInt(token3[0])][2] = Integer
								.parseInt(token3[1]);
					}
					if (token.equals("Achievement-Elite")) {
						p.getAD().diaries[Integer.parseInt(token3[0])][3] = Integer
								.parseInt(token3[1]);
					}
					break;
				case 13:
					if (token.startsWith("Task-")) {
						String[] parts = token.split(" = ");
						if (parts.length == 3) {
							String regionAndTask = parts[0].substring("Task - ".length());
							String[] regionAndTaskParts = regionAndTask.split(" - ");
							String[] regionAndTaskParts2 = regionAndTask.split(" = ");
							
							if (regionAndTaskParts.length == 3) {
								String region = regionAndTaskParts[0];
								String taskName = regionAndTaskParts[1];
								boolean isCompleted = Boolean.parseBoolean(parts[1]); // Set this based on your criteria for completion

								// Find the corresponding task list and update completion status
								List<AchievementTask> tasks = p.getAD().achievementMap.get(region);
								if (tasks != null) {
									for (AchievementTask task : tasks) {
										if (task.getTask().equals(taskName)) {
											task.setDone(isCompleted);
											break; // No need to continue searching
										}
									}
								}
							}
						}
					}
					break;
				case 14:
					if (token.equals("Herb-State")) {
						p.getHerbs().herbState[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Herb-Seeds")) {
						p.getHerbs().herbSeeds[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Herb-Stages")) {
						p.getHerbs().herbStages[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Herb-Timer")) {
						p.getHerbs().herbTimer[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					break;
				case 15:
					if (token.equals("Flower-State")) {
						p.getFlowers().flowerState[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Flower-Seeds")) {
						p.getFlowers().flowerSeeds[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Flower-Stages")) {
						p.getFlowers().flowerStages[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Flower-Timer")) {
						p.getFlowers().flowerTimer[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					break;
				case 16:
					if (token.equals("Allotment-State")) {
						p.getAllotment().allotmentState[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Allotment-Seeds")) {
						p.getAllotment().allotmentSeeds[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Allotment-Stages")) {
						p.getAllotment().allotmentStages[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					if (token.equals("Allotment-Timer")) {
						p.getAllotment().allotmentTimer[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
					}
					break;
				}
			} else {
				if (line.equals("[ACCOUNT]")) {
					ReadMode = 1;
				} else if (line.equals("[CHARACTER]")) {
					ReadMode = 2;
				} else if (line.equals("[EQUIPMENT]")) {
					ReadMode = 3;
				} else if (line.equals("[LOOK]")) {
					ReadMode = 4;
				} else if (line.equals("[SKILLS]")) {
					ReadMode = 5;
				} else if (line.equals("[ITEMS]")) {
					ReadMode = 6;
				} else if (line.equals("[LOOTBAG]")) {
					ReadMode = 7;
				} else if (line.equals("[BANK]")) {
					ReadMode = 8;
				} else if (line.equals("[FRIENDS]")) {
					ReadMode = 9;
				} else if (line.equals("[IGNORES]")) {
					ReadMode = 10;
				} else if (line.equals("[COLLECTLOG]")) {
					ReadMode = 11;
				} else if (line.equals("[ACHIEVEMENTS]")) {
					ReadMode = 12;
				} else if (line.equals("[TASKS]")) {
					ReadMode = 13;
				} else if (line.equals("[HERBS]")) {
					ReadMode = 14;
				} else if (line.equals("[FLOWERS]")) {
					ReadMode = 15;
				} else if (line.equals("[ALLOTMENTS]")) {
					ReadMode = 16;
				} else if (line.equals("[EOF]")) {
					try {
						characterfile.close();
					} catch (IOException ioexception) {
					}
					return 1;
				}
			}
			try {
				line = characterfile.readLine();
			} catch (IOException ioexception1) {
				EndOfFile = true;
			}
		}
		try {
			characterfile.close();
		} catch (IOException ioexception) {
		}
		return 13;
	}

	/**
	 * Saving
	 **/
	public static boolean saveGame(Client p) {
		if (!p.saveFile || p.newPlayer || !p.saveCharacter) {
			// System.out.println("first");
			return false;
		}
		if (p.playerName == null
				|| PlayerHandler.players[p.playerId] == null) {
			// System.out.println("second");
			return false;
		}
		p.playerName = p.playerName2;
		int tbTime = (int) (p.teleBlockDelay - System.currentTimeMillis() + p.teleBlockLength);
		if (tbTime > 300000 || tbTime < 0) {
			tbTime = 0;
		}

		BufferedWriter characterfile = null;
		try {
			characterfile = new BufferedWriter(new FileWriter(
					"C:/Servercharacters/" + p.playerName + ".txt"));

			/* ACCOUNT */
			characterfile.write("[ACCOUNT]", 0, 9);
			characterfile.newLine();
			characterfile.write("character-username = ", 0, 21);
			characterfile.write(p.playerName, 0, p.playerName.length());
			characterfile.newLine();
			characterfile.write("character-password = ", 0, 21);
			characterfile.write(p.playerPass, 0, p.playerPass.length());
			characterfile.newLine();
			characterfile.newLine();

			/* CHARACTER */
			characterfile.write("[CHARACTER]", 0, 11);
			characterfile.newLine();
			characterfile.write("character-height = ", 0, 19);
			characterfile.write(Integer.toString(p.heightLevel), 0, Integer
					.toString(p.heightLevel).length());
			characterfile.newLine();
			characterfile.write("character-posx = ", 0, 17);
			characterfile.write(Integer.toString(p.absX), 0,
					Integer.toString(p.absX).length());
			characterfile.newLine();
			characterfile.write("character-posy = ", 0, 17);
			characterfile.write(Integer.toString(p.absY), 0,
					Integer.toString(p.absY).length());
			characterfile.newLine();
			characterfile.write("character-rights = ", 0, 19);
			characterfile.write(Integer.toString(p.playerRights), 0, Integer
					.toString(p.playerRights).length());
			characterfile.newLine();
			characterfile.write("tutorial-progress = ", 0, 20);
			characterfile.write(Integer.toString(p.tutorialProgress), 0, Integer
					.toString(p.tutorialProgress).length());
			characterfile.newLine();
			characterfile.write("crystal-bow-shots = ", 0, 20);
			characterfile.write(Integer.toString(p.crystalBowArrowCount), 0,
					Integer.toString(p.crystalBowArrowCount).length());
			characterfile.newLine();
			characterfile.write("skull-timer = ", 0, 14);
			characterfile.write(Integer.toString(p.skullTimer), 0, Integer
					.toString(p.skullTimer).length());
			characterfile.newLine();
			characterfile.write("magic-book = ", 0, 13);
			characterfile.write(Integer.toString(p.playerMagicBook), 0, Integer
					.toString(p.playerMagicBook).length());
			characterfile.newLine();
			for (int b = 0; b < p.barrowsNpcs.length; b++) {
				characterfile.write("brother-info = ", 0, 15);
				characterfile.write(Integer.toString(b), 0, Integer.toString(b)
						.length());
				characterfile.write("	", 0, 1);
				characterfile.write(
						p.barrowsNpcs[b][1] <= 1 ? Integer.toString(0)
								: Integer.toString(p.barrowsNpcs[b][1]), 0,
						Integer.toString(p.barrowsNpcs[b][1]).length());
				characterfile.newLine();
			}
			characterfile.write("special-amount = ", 0, 17);
			characterfile.write(Double.toString(p.specAmount), 0, Double
					.toString(p.specAmount).length());
			characterfile.newLine();
			characterfile.write("selected-coffin = ", 0, 18);
			characterfile.write(Integer.toString(p.randomCoffin), 0, Integer
					.toString(p.randomCoffin).length());
			characterfile.newLine();
			characterfile.write("runeMist = " + p.runeMist);
			characterfile.newLine();
			characterfile.write("blackKnight = " + p.blackKnight);
			characterfile.newLine();
			characterfile.write("shieldArrav = " + p.shieldArrav);
			characterfile.newLine();
			characterfile.write("cookAss = " + p.cookAss);
			characterfile.newLine();
			characterfile.write("pirateTreasure = " + p.pirateTreasure);
			characterfile.newLine();
			characterfile.write("doricQuest = " + p.doricQuest);
			characterfile.newLine();
			characterfile.write("impsC = " + p.impsC);
			characterfile.newLine();
			characterfile.write("RecipeDisaster = " + p.RFD);
			characterfile.newLine();
			characterfile.write("knightS = " + p.knightS);
			characterfile.newLine();
			characterfile.write("sheepShear = " + p.sheepShear);
			characterfile.newLine();
			characterfile.write("romeo-juliet = " + p.romeojuliet);
			characterfile.newLine();
			characterfile.write("gertCat = " + p.gertCat);
			characterfile.newLine();
			characterfile.write("lostCity = " + p.lostCity);
			characterfile.newLine();
			characterfile.write("EleWorkShop = " + p.EleWorkShop);
			characterfile.newLine();
			characterfile.write("EleWorkshop-stage = " + p.EleWorkshopWater_stage);
			characterfile.newLine();
			characterfile.write("questPoints = " + p.questPoints);
			characterfile.newLine();
			characterfile.write("barrows-killcount = ", 0, 20);
			characterfile.write(Integer.toString(p.barrowsKillCount), 0,
					Integer.toString(p.barrowsKillCount).length());
			characterfile.newLine();
			characterfile.write("teleblock-length = ", 0, 19);
			characterfile.write(Integer.toString(tbTime), 0,
					Integer.toString(tbTime).length());
			characterfile.newLine();
			characterfile.write("pc-points = ", 0, 12);
			characterfile.write(Integer.toString(p.pcPoints), 0, Integer
					.toString(p.pcPoints).length());
			characterfile.newLine();
			characterfile.write("slayerTask = ", 0, 13);
			characterfile.write(Integer.toString(p.slayerTask), 0, Integer
					.toString(p.slayerTask).length());
			characterfile.newLine();
			characterfile.write("taskAmount = ", 0, 13);
			characterfile.write(Integer.toString(p.taskAmount), 0, Integer
					.toString(p.taskAmount).length());
			characterfile.newLine();
			characterfile.write("magePoints = ", 0, 13);
			characterfile.write(Integer.toString(p.magePoints), 0, Integer
					.toString(p.magePoints).length());
			characterfile.newLine();
			characterfile.write("autoRet = ", 0, 10);
			characterfile.write(Integer.toString(p.autoRet), 0, Integer
					.toString(p.autoRet).length());
			characterfile.newLine();
			characterfile.write("barrowskillcount = ", 0, 19);
			characterfile.write(Integer.toString(p.barrowsKillCount), 0,
					Integer.toString(p.barrowsKillCount).length());
			characterfile.newLine();
			characterfile.write("flagged = ", 0, 10);
			characterfile.write(Boolean.toString(p.accountFlagged), 0, Boolean
					.toString(p.accountFlagged).length());
			characterfile.newLine();
			characterfile.write("wave = ", 0, 7);
			characterfile.write(Integer.toString(p.waveId), 0, Integer
					.toString(p.waveId).length());
			characterfile.newLine();
			characterfile.write("gwkc = ", 0, 7);
			characterfile.write(Integer.toString(p.killCount), 0, Integer
					.toString(p.killCount).length());
			characterfile.newLine();
			characterfile.write("ArdyDiaries = ", 0, 14);
			characterfile.write(Integer.toString(p.ArdyDiaryEasy), 0,
					Integer.toString(p.ArdyDiaryEasy).length());
			characterfile.newLine();
			characterfile.write("Blowpipe-Charges = ", 0, 19);
			characterfile.write(Integer.toString(p.BlowpipeCharges), 0,
					Integer.toString(p.BlowpipeCharges).length());
			characterfile.newLine();
			characterfile.write("Blowpipe-Darts = ", 0, 17);
			characterfile.write(Integer.toString(p.BlowpipeDarts), 0,
					Integer.toString(p.BlowpipeDarts).length());
			characterfile.newLine();
			characterfile.write("Blowpipe-DartType = ", 0, 20);
			characterfile.write(Integer.toString(p.DartType), 0,
					Integer.toString(p.DartType).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune1 = ", 0, 17);
			characterfile.write(Integer.toString(p.PouchRune1), 0,
					Integer.toString(p.PouchRune1).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune1Amt = ", 0, 20);
			characterfile.write(Integer.toString(p.PouchRune1Amt), 0,
					Integer.toString(p.PouchRune1Amt).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune2 = ", 0, 17);
			characterfile.write(Integer.toString(p.PouchRune2), 0,
					Integer.toString(p.PouchRune2).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune2Amt = ", 0, 20);
			characterfile.write(Integer.toString(p.PouchRune2Amt), 0,
					Integer.toString(p.PouchRune2Amt).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune3 = ", 0, 17);
			characterfile.write(Integer.toString(p.PouchRune3), 0,
					Integer.toString(p.PouchRune3).length());
			characterfile.newLine();
			characterfile.write("RunePouchRune3Amt = ", 0, 20);
			characterfile.write(Integer.toString(p.PouchRune3Amt), 0,
					Integer.toString(p.PouchRune3Amt).length());
			characterfile.newLine();
			characterfile.write("fightMode = ", 0, 12);
			characterfile.write(Integer.toString(p.fightMode), 0, Integer
					.toString(p.fightMode).length());
			characterfile.newLine();
			characterfile.write("void = ", 0, 7);
			String toWrite = p.voidStatus[0] + "\t" + p.voidStatus[1] + "\t"
					+ p.voidStatus[2] + "\t" + p.voidStatus[3] + "\t"
					+ p.voidStatus[4];
			characterfile.write(toWrite);
			characterfile.newLine();
			characterfile.newLine();

			/* EQUIPMENT */
			characterfile.write("[EQUIPMENT]", 0, 11);
			characterfile.newLine();
			for (int i = 0; i < p.playerEquipment.length; i++) {
				characterfile.write("character-equip = ", 0, 18);
				characterfile.write(Integer.toString(i), 0, Integer.toString(i)
						.length());
				characterfile.write("	", 0, 1);
				characterfile.write(Integer.toString(p.playerEquipment[i]), 0,
						Integer.toString(p.playerEquipment[i]).length());
				characterfile.write("	", 0, 1);
				characterfile.write(Integer.toString(p.playerEquipmentN[i]), 0,
						Integer.toString(p.playerEquipmentN[i]).length());
				characterfile.write("	", 0, 1);
				characterfile.newLine();
			}
			characterfile.newLine();

			/* LOOK */
			characterfile.write("[LOOK]", 0, 6);
			characterfile.newLine();
			for (int i = 0; i < p.playerAppearance.length; i++) {
				characterfile.write("character-look = ", 0, 17);
				characterfile.write(Integer.toString(i), 0, Integer.toString(i)
						.length());
				characterfile.write("	", 0, 1);
				characterfile.write(Integer.toString(p.playerAppearance[i]), 0,
						Integer.toString(p.playerAppearance[i]).length());
				characterfile.newLine();
			}
			characterfile.newLine();

			/* SKILLS */
			characterfile.write("[SKILLS]", 0, 8);
			characterfile.newLine();
			for (int i = 0; i < p.playerLevel.length; i++) {
				characterfile.write("character-skill = ", 0, 18);
				characterfile.write(Integer.toString(i), 0, Integer.toString(i)
						.length());
				characterfile.write("	", 0, 1);
				characterfile.write(Integer.toString(p.playerLevel[i]), 0,
						Integer.toString(p.playerLevel[i]).length());
				characterfile.write("	", 0, 1);
				characterfile.write(Integer.toString(p.playerXP[i]), 0, Integer
						.toString(p.playerXP[i]).length());
				characterfile.newLine();
			}
			characterfile.newLine();

			/* ITEMS */
			characterfile.write("[ITEMS]", 0, 7);
			characterfile.newLine();
			for (int i = 0; i < p.playerItems.length; i++) {
				if (p.playerItems[i] > 0) {
					characterfile.write("character-item = ", 0, 17);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.playerItems[i]), 0,
							Integer.toString(p.playerItems[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.playerItemsN[i]), 0,
							Integer.toString(p.playerItemsN[i]).length());
					characterfile.newLine();
				}
			}
			characterfile.newLine();
			/* COLLECT LOG */
			characterfile.write("[COLLECTLOG]", 0, 12);
			characterfile.newLine();
			for (int i = 0; i < p.getCollectionLog().barrowsCollectionLog.length; i++) {
				if (p.getCollectionLog().barrowsCollectionLog[i][2] > 0) {
					characterfile.write("Collectionlog-item = ", 0, 21);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().barrowsCollectionLog[i][0]), 0, Integer
							.toString(p.getCollectionLog().barrowsCollectionLog[i][0]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().barrowsCollectionLog[i][2]), 0,
							Integer.toString(p.getCollectionLog().barrowsCollectionLog[i][2]).length());
					characterfile.newLine();
				}
			}
				
					characterfile.newLine();
			for (int i = 0; i < p.getCollectionLog().EasyClueCollectionLog.length; i++) {
				if (p.getCollectionLog().EasyClueCollectionLog[i][2] > 0) {
					characterfile.write("EasyCollectionlog-item = ", 0, 25);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().EasyClueCollectionLog[i][0]), 0,
							Integer.toString(p.getCollectionLog().EasyClueCollectionLog[i][0]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().EasyClueCollectionLog[i][2]), 0,
							Integer.toString(p.getCollectionLog().EasyClueCollectionLog[i][2]).length());
					characterfile.newLine();
				}
			}	
			characterfile.newLine();
			for (int i = 0; i < p.getCollectionLog().bandosCollectionLog.length; i++) {
				if (p.getCollectionLog().bandosCollectionLog[i][2] > 0) {
					characterfile.write("BandosCollectionlog-item = ", 0, 27);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().bandosCollectionLog[i][0]), 0, Integer
							.toString(p.getCollectionLog().bandosCollectionLog[i][0]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.getCollectionLog().bandosCollectionLog[i][2]), 0,
							Integer.toString(p.getCollectionLog().bandosCollectionLog[i][2]).length());
					characterfile.newLine();
				}
			}
			characterfile.newLine();
			/* COLLECT LOG */
			characterfile.write("[ACHIEVEMENTS]", 0, 14);
			characterfile.newLine();
			for (int i = 0; i < p.getAD().diaries.length; i++) {
					if (p.getAD().diaries[i][0] > 0) {
						characterfile.write("Achievement-Easy = ", 0, 19);
						characterfile.write(Integer.toString(i), 0, Integer
								.toString(i).length());
						characterfile.write("	", 0, 1);
						characterfile.write(Integer.toString(p.getAD().diaries[i][0]), 0, Integer
								.toString(p.getAD().diaries[i][0]).length());
						characterfile.newLine();
					}
					if (p.getAD().diaries[i][1] > 0) {
						characterfile.write("Achievement-Medium = ", 0, 21);
						characterfile.write(Integer.toString(i), 0, Integer
								.toString(i).length());
						characterfile.write("	", 0, 1);
						characterfile.write(Integer.toString(p.getAD().diaries[i][1]), 0, Integer
								.toString(p.getAD().diaries[i][1]).length());
						characterfile.newLine();
					}
					if (p.getAD().diaries[i][2] > 0) {
						characterfile.write("Achievement-Hard = ", 0, 19);
						characterfile.write(Integer.toString(i), 0, Integer
								.toString(i).length());
						characterfile.write("	", 0, 1);
						characterfile.write(Integer.toString(p.getAD().diaries[i][2]), 0, Integer
								.toString(p.getAD().diaries[i][2]).length());
						characterfile.newLine();
					}
					if (p.getAD().diaries[i][3] > 0) {
						characterfile.write("Achievement-Elite = ", 0, 20);
						characterfile.write(Integer.toString(i), 0, Integer
								.toString(i).length());
						characterfile.write("	", 0, 1);
						characterfile.write(Integer.toString(p.getAD().diaries[i][3]), 0, Integer
								.toString(p.getAD().diaries[i][3]).length());
						characterfile.newLine();
					}
			}
			characterfile.newLine();
			characterfile.write("[TASKS]", 0, 7);
			characterfile.newLine();

			for (Map.Entry<String, List<AchievementTask>> entry : p.getAD().achievementMap.entrySet()) {
				String region = entry.getKey();
				List<AchievementTask> tasks = entry.getValue();
				for (AchievementTask task : tasks) {
					if (task.isDone()) {
						characterfile.write("Task - ", 0, 7);
						characterfile.write(region, 0, region.length());
						characterfile.write(" = ", 0, 3);
						characterfile.write(task.getTask(), 0, task.getTask().length());
						characterfile.write(" = ", 0, 3);
						characterfile.write(Boolean.toString(task.isDone()), 0, Boolean.toString(task.isDone()).length());
						characterfile.newLine();
					}
				}
			}
			characterfile.newLine();

			/* LOOTBAG */
			characterfile.write("[LOOTBAG]", 0, 9);
			characterfile.newLine();
			for (int i = 0; i < p.playerLootItems.length; i++) {
				if (p.playerLootItems[i] > 0) {
					characterfile.write("character-item = ", 0, 17);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.playerLootItems[i]), 0,
							Integer.toString(p.playerLootItems[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.playerLootItemsN[i]), 0,
							Integer.toString(p.playerLootItemsN[i]).length());
					characterfile.newLine();
				}
			}
			characterfile.newLine();

			/* BANK */
			characterfile.write("[BANK]", 0, 6);
			characterfile.newLine();
			for (int i = 0; i < p.bankItems.length; i++) {
				if (p.bankItems[i] > 0) {
					characterfile.write("character-bank = ", 0, 17);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems[i]), 0,
							Integer.toString(p.bankItems[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItemsN[i]), 0,
							Integer.toString(p.bankItemsN[i]).length());
					characterfile.newLine();
				}
			}
			characterfile.newLine();
/*BANK*/
			characterfile.write("[BANK]", 0, 6);
			characterfile.newLine();
			for (int i = 0; i < p.bankItems.length; i++) {
				if (p.bankItems[i] > 0) {
					characterfile.write("character-bank = ", 0, 17);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems[i]), 0, Integer.toString(p.bankItems[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItemsN[i]), 0, Integer.toString(p.bankItemsN[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems1.length; i++) {
				if (p.bankItems1[i] > 0) {
					characterfile.write("character-bank1 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems1[i]), 0, Integer.toString(p.bankItems1[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems1N[i]), 0, Integer.toString(p.bankItems1N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems2.length; i++) {
				if (p.bankItems2[i] > 0) {
					characterfile.write("character-bank2 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems2[i]), 0, Integer.toString(p.bankItems2[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems2N[i]), 0, Integer.toString(p.bankItems2N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems3.length; i++) {
				if (p.bankItems3[i] > 0) {
					characterfile.write("character-bank3 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems3[i]), 0, Integer.toString(p.bankItems3[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems3N[i]), 0, Integer.toString(p.bankItems3N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems4.length; i++) {
				if (p.bankItems4[i] > 0) {
					characterfile.write("character-bank4 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems4[i]), 0, Integer.toString(p.bankItems4[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems4N[i]), 0, Integer.toString(p.bankItems4N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems5.length; i++) {
				if (p.bankItems5[i] > 0) {
					characterfile.write("character-bank5 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems5[i]), 0, Integer.toString(p.bankItems5[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems5N[i]), 0, Integer.toString(p.bankItems5N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems6.length; i++) {
				if (p.bankItems6[i] > 0) {
					characterfile.write("character-bank6 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems6[i]), 0, Integer.toString(p.bankItems6[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems6N[i]), 0, Integer.toString(p.bankItems6N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems7.length; i++) {
				if (p.bankItems7[i] > 0) {
					characterfile.write("character-bank7 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems7[i]), 0, Integer.toString(p.bankItems7[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems7N[i]), 0, Integer.toString(p.bankItems7N[i]).length());
					characterfile.newLine();
				}
			}
			for (int i = 0; i < p.bankItems8.length; i++) {
				if (p.bankItems8[i] > 0) {
					characterfile.write("character-bank8 = ", 0, 18);
					characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems8[i]), 0, Integer.toString(p.bankItems8[i]).length());
					characterfile.write("	", 0, 1);
					characterfile.write(Integer.toString(p.bankItems8N[i]), 0, Integer.toString(p.bankItems8N[i]).length());
					characterfile.newLine();
				}
			}
			characterfile.newLine();
			
			/* FRIENDS */
			characterfile.write("[FRIENDS]", 0, 9);
			characterfile.newLine();
			for (int i = 0; i < p.friends.length; i++) {
				if (p.friends[i] > 0) {
					characterfile.write("character-friend = ", 0, 19);
					characterfile.write(Integer.toString(i), 0, Integer
							.toString(i).length());
					characterfile.write("	", 0, 1);
					characterfile.write("" + p.friends[i]);
					characterfile.newLine();
				}
			}
			characterfile.newLine();
characterfile.write("[HERBS]", 0, 7);
    characterfile.newLine();
    for (int i = 0; i < p.getHerbs().herbStages.length; i++) {
		if (p.getHerbs().herbStages[i] > 3){
					characterfile.write("Herb-State = ", 0, 13);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getHerbs().herbState[i]));
			characterfile.newLine();
					characterfile.write("Herb-Seeds = ", 0, 13);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getHerbs().herbSeeds[i]));
			characterfile.newLine();
					characterfile.write("Herb-Stages = ", 0, 14);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getHerbs().herbStages[i]));
			characterfile.newLine();
					characterfile.write("Herb-Timer = ", 0, 13);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Long.toString(p.getHerbs().herbTimer[i]));
			characterfile.newLine();
		}		
	}		
		characterfile.newLine();
characterfile.write("[FLOWERS]", 0, 9);
    characterfile.newLine();
    for (int i = 0; i < p.getFlowers().flowerStages.length; i++) {
		if (p.getFlowers().flowerStages[i] > 3){
					characterfile.write("Flower-State = ", 0, 15);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getFlowers().flowerState[i]));
			characterfile.newLine();
					characterfile.write("Flower-Seeds = ", 0, 15);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getFlowers().flowerSeeds[i]));
			characterfile.newLine();
					characterfile.write("Flower-Stages = ", 0, 16);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getFlowers().flowerStages[i]));
			characterfile.newLine();
					characterfile.write("Flower-Timer = ", 0, 15);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Long.toString(p.getFlowers().flowerTimer[i]));
			characterfile.newLine();
		}	
	}		
		characterfile.newLine();
characterfile.write("[ALLOTMENTS]", 0, 12);
    characterfile.newLine();
    for (int i = 0; i < p.getAllotment().allotmentStages.length; i++) {
		if (p.getAllotment().allotmentStages[i] > 3){
					characterfile.write("Allotment-State = ", 0, 18);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getAllotment().allotmentState[i]));
			characterfile.newLine();
					characterfile.write("Allotment-Seeds = ", 0, 18);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getAllotment().allotmentSeeds[i]));
			characterfile.newLine();
					characterfile.write("Allotment-Stages = ", 0, 19);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Integer.toString(p.getAllotment().allotmentStages[i]));
			characterfile.newLine();
					characterfile.write("Allotment-Timer = ", 0, 18);
			characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
			characterfile.write("	", 0, 1);
			characterfile.write(Long.toString(p.getAllotment().allotmentTimer[i]));
			characterfile.newLine();
		}
	}
    
    characterfile.newLine();
			/* IGNORES */
			/*
			 * characterfile.write("[IGNORES]", 0, 9); characterfile.newLine();
			 * for (int i = 0; i < ignores.length; i++) { if (ignores[i] > 0) {
			 * characterfile.write("character-ignore = ", 0, 19);
			 * characterfile.write(Integer.toString(i), 0,
			 * Integer.toString(i).length()); characterfile.write("	", 0, 1);
			 * characterfile.write(Long.toString(ignores[i]), 0,
			 * Long.toString(ignores[i]).length()); characterfile.newLine(); } }
			 * characterfile.newLine();
			 */
			/* EOF */
			characterfile.write("[EOF]", 0, 5);
			characterfile.newLine();
			characterfile.newLine();
			characterfile.close();
		} catch (IOException ioexception) {
			Misc.println(p.playerName + ": error writing file.");
			ioexception.printStackTrace();
				return false;
		}
		return true;
	}

}