package server.model.players.skills;

import server.model.players.skills.*;
import server.model.players.*;
import server.model.players.Client;
import server.*;
import server.model.players.skills.cooking.*;
import server.model.players.skills.runecraft.*;
import server.model.players.skills.farming.*;
import server.model.players.skills.mining.*;
import server.model.objects.*;
import server.util.Misc;

public class SkillHandler {

	public static void resetSkills(Client player) {// call when walking, dropping,
												// picking up, leveling up
		if (player.playerSkilling[10]) {// fishing
			Fishing.resetFishing(player);
		} else if (player.isMining) {// mining
			Mining.resetMining(player);
		} else if (player.playerIsFletching) {// fletching
			player.playerIsFletching = false;
		} else if (player.playerIsCooking) {// cooking
			Cooking.setCooking(player, false);
		} //else if (player.isSmithing) {// smithing
			//player.isSmithing = false;
		//} //else if (isSkilling[12]) {// crafting
		//	isSkilling[12] = false;
		//} else 
			if (player.isSmelting) {
			player.isSmelting = false;
		//} //else if (player.isCrafting) {
		//	player.isCrafting = false;
		//} else if (player.isPotionMaking) {// herblore
		//	Herblore.resetHerblore(player);
		} else if (player.isWoodcutting) {// woodcutting
			Woodcutting.stopWoodcutting(player);
		}// else if (player.isSpinning) {// spinning
		//	player.isSpinning = false;
		//} else if (player.isPotCrafting) {// pot crafting
		//	player.isPotCrafting = false;
		//}
	}
}