package server.model.players.skills;

import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
//import com.rebotted.game.content.music.sound.SoundList;
//import com.rebotted.game.content.randomevents.RandomEventHandler;
//import com.rebotted.game.content.randomevents.TreeSpirit;
//import com.rebotted.game.content.skills.SkillHandler;
import server.model.items.ItemAssistant;
import server.model.objects.Object;
import server.model.players.Client;
import server.model.players.Player;
import server.model.players.Sound;
import server.model.players.PlayerHandler;
import server.util.Misc;

public class Woodcutting {
	private Client c;
	public Woodcutting(Client c) {
		this.c = c;
	}
	public final static int[][] Axe_Settings = {
			{1351, 1, 1, 879},
			{1349, 1, 2, 877}, 
			{1353, 6, 3, 875}, 
			{1361, 6, 4, 873},
			{1355, 21, 5, 871},
			{1357, 31, 6, 869}, 
			{1359, 41, 7, 867}, 
			{6739, 61, 8, 2846}, 
			{13661, 41, 8, 10251} 
		};
	
	private static enum treeData {
		TREE(new int[] {1276, 1278, 1286, 3033, 1282, 1383}, 1342, 1, 25, 1511, 8, 100),
		OAK(new int[] {10820}, 1356, 15, 38, 1521, 25, 20),
		WILLOW(new int[] {10819, 10831, 10829, 10833}, 7399, 30, 68, 1519, 30, 8),
		MAPLE(new int[] {10832}, 1343, 45, 100, 1517, 48, 8),
		YEW(new int[] {10822}, 7402, 60, 175, 1515, 79, 5),
		MAGIC(new int[] {10834}, 7401, 75, 250, 1513, 150, 3),
		EVERGREEN(new int[] {1319, 1318, 1315, 1316, 1332}, 1341, 1, 25, 1511, 11, 100),
		ACHEY(new int[] {2023}, 3371, 1, 25, 1511, 11, 100),
		DRAMEN(new int[] {1292}, 1341, 1, 25, 771, 45, 100),
		REDWOOD(new int[] {29668, 29670}, -1, 90, 350, 771, 45, 100);
		
		private int[] treeId;
		private int stumpId, levelReq, xpRecieved, logRecieved, respawnTime, cutChance;
		
		private treeData(int[] treeId, int stumpId, int levelReq, int xpRecieved, int logRecieved, int respawnTime, int cutChance) {
			this.treeId = treeId;
			this.stumpId = stumpId;
			this.levelReq = levelReq;
			this.xpRecieved = xpRecieved;
			this.logRecieved = logRecieved;
			this.respawnTime = respawnTime;
			this.cutChance = cutChance;
		}
		
		private int getStump() {
			return stumpId;
		}
		
		private int getLevelReq() {
			return levelReq;
		}
		
		private int getXpReceived() {
			return xpRecieved;
		}
		
		private int getLogRecieved() {
			return logRecieved;
		}
		
		private int getRespawnTime() {
			return respawnTime;
		}
		
		private int getChance() {
			return cutChance;
		}
		
		private int getObject(int object) {
			for (int element : treeId) {
				if (object == element) {
					return element;
				}
			}
			return -1;
		}
		
		private static treeData getTree(int objectId) {
			for (treeData tree : treeData.values()) {
				if (objectId == tree.getObject(objectId)) {
					return tree;
				}
			}
			return null;
		}
		
	}

	public static int[][] FIX_AXE = { { 492, 508, 1351 }, { 492, 510, 1349 },
			{ 492, 512, 1353 }, { 492, 514, 1361 }, { 492, 516, 1355 },
			{ 492, 518, 1357 }, { 492, 520, 1359 }, };

	public static void repeatAnimation(final Client p) {
		CycleEventHandler.getSingleton().addEvent(p, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				if (p.isWoodcutting) {
					if ((p.woodcuttingAxe >= 0) && (p.woodcuttingAxe < Axe_Settings.length))	{
						try {
							p.startAnimation(Axe_Settings[p.woodcuttingAxe][3]);
						} catch (ArrayIndexOutOfBoundsException exception) {
							System.out.println("LOL this happend again: " + exception);
						}
						//p.getPacketSender().sendSound(SoundList.TREE_CUTTING, 100, 0);
						//p.getPA().sendSound(Sound.SOUND_LIST.TREE_CUT_BEGIN.getSound(), 0, 8);
						p.getPA().sendSound(Sound.SOUND_LIST.TREE_CUTTING.getSound(), 0, 8);
					}
				} else {
					container.stop();
				}
			}

			@Override
			public void stop() {
				stopWoodcutting(p);
			}
		}, 3);
	}

	public static void handleCanoe(final Client player, final int objectId) {
		Boolean gotAxe = false;
		if (player.playerLevel[player.playerWoodcutting] < 12) {
			player.sendMessage("You need a woodcutting level of at least 12 to use the canoe station.");
			return;
		}

		for (int axes[] : Axe_Settings) {
			int type = axes[0];
			if ( player.getItems().playerHasItem(type) || player.playerEquipment[player.playerWeapon] == type) {
				gotAxe = true;
			}
		}
		if (gotAxe) {
			player.sendMessage("You swing your axe at the station.");
		} else {
			player.sendMessage("You need an axe to cut the station.");
			return;
		}
		for (int axes[] : Axe_Settings) {
			int type = axes[0];
			int level = axes[1];
			int anim = axes[3];
			if (player.playerLevel[player.playerWoodcutting] >= level && player.getItems().playerHasItem(type) || player.playerLevel[player.playerWoodcutting] >= level && player.playerEquipment[player.playerWeapon] == type) {
				player.turnPlayerTo(player.objectX, player.objectY);
				player.startAnimation(anim);
				CycleEventHandler.getSingleton().addEvent(player, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						addFallenTree(player, objectId);
						CycleEventHandler.getSingleton().addEvent(player, new CycleEvent() {
							@Override
							public void execute(CycleEventContainer container) {
								//player.getPlayerAssistant().handleCanoe();
								container.stop();
							}

							@Override
							public void stop() {
								
							}

						}, 1);
						player.sendMessage("You cut down the canoe. Please wait...");
						container.stop();
					}

					@Override
					public void stop() {
						
					}
				}, 4);
			}
		}
	}

	public void fixAxe(final Client player) {
		for (int fix[] : FIX_AXE) {
			int axeHandle = fix[0];
			int axeHead = fix[1];
			final int fixedAxe = fix[2];
			if (player.getItems().playerHasItem(axeHandle) && player.getItems().playerHasItem(axeHead)) {
				player.isWoodcutting = true;
				player.getItems().deleteItem(axeHandle, 1);
				player.getItems().deleteItem(axeHead, 1);
				player.getPA().closeAllWindows();
				player.sendMessage("Your axe handle and axe head have been taken.");
				CycleEventHandler.getSingleton().addEvent(player, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						player.getItems().addItem(fixedAxe, 1);
						player.sendMessage("Your axe has been fixed.");
						container.stop();
					}
					@Override
					public void stop() {
						
					}
				}, 1);
			}
		}
	}

	public static void addFallenTree(Client player, int canoe) {
		if (canoe == player.objectId) {
			for (Player players : PlayerHandler.players) {
				if (players != null) {
					new Object(1296, player.objectX, player.objectY, 0, 0, 10, canoe, 20 + Misc.random(40));
				}
			}
		}
	}
	
	public static boolean hasAxe(Client player) {
		for (int i = 0; i < Axe_Settings.length; i++) {
			if (player.getItems().playerHasItem(Axe_Settings[i][0]) || player.playerEquipment[player.playerWeapon] == Axe_Settings[i][0]) {
				return true;
			}
		}
		return false;
	}

	public static void startWoodcutting(Client p, int objectId, final int x, final int y, final int type) {
		CycleEventHandler.getSingleton().stopEvents(p);
		if (p.isWoodcutting || p.isFletching || p.isFiremaking || p.playerIsFletching) {
			return;
		}
		if (p.absX == 2717 && p.absY == 3461) {
			p.sendMessage("You can't cut the tree from here!");
			return;
		}
		//if (!SkillHandler.WOODCUTTING) {
			//p.sendMessage("This skill is currently disabled.");
			//return;
		//}
		int wcLevel = p.playerLevel[8];
		p.woodcuttingAxe = -1;
		treeData tree = treeData.getTree(objectId);
		p.turnPlayerTo(x, y);
		if (tree.getLevelReq() > wcLevel) {
			p.sendMessage("You need a Woodcutting level of " + tree.getLevelReq() + " to cut this tree.");
			return;
		}
		for (int i = 0; i < Axe_Settings.length; i++) {
			if (p.getItems().playerHasItem(Axe_Settings[i][0]) || p.playerEquipment[p.playerWeapon] == Axe_Settings[i][0]) {
				if (Axe_Settings[i][1] <= wcLevel) {
					p.woodcuttingAxe = i;
				}
			}
		}
		if (p.woodcuttingAxe == -1) {
			p.sendMessage("You need an axe to cut this tree.");
			return;
		}
		if (p.getItems().freeSlots() < 1) {
			p.sendMessage("You do not have enough inventory slots to do that.");
			return;
		}
		if (p.goodDistance(p.objectX, p.objectY, p.absX, p.absY, 3)) {
			if (p.isWoodcutting) {
				p.sendMessage("You are already woodcutting!");
				return;
			}
			p.startAnimation(Axe_Settings[p.woodcuttingAxe][3]);
			p.isWoodcutting = true;
			p.getPA().sendSound(Sound.SOUND_LIST.TREE_CUT_BEGIN.getSound(), 0, 8);
			//p.getPacketSender().sendSound(SoundList.TREE_CUT_BEGIN, 100, 0);
			repeatAnimation(p);
			p.treeX = x;
			p.treeY = y;
			if (p.tutorialProgress == 3) {
				p.getPA().closeAllWindows();
				p.getPA().chatbox(6180);
				if (p.playerAppearance[0] == 0) {
					p.getDH().sendStartInfo("", "Your character is now attempting to cut down the tree. Sit back", "for a moment while he does all the hard work.", "", "Please wait");
				} else {
					p.getDH().sendStartInfo("", "Your character is now attempting to cut down the tree. Sit back", "for a moment while she does all the hard work.", "", "Please wait");
				}
				p.getPA().chatbox(6179);
			} else {
				p.sendMessage("You swing your axe at the tree.");
			}
			CycleEventHandler.getSingleton().addEvent(p, new CycleEvent() {

				@Override
				public void execute(CycleEventContainer container) {
					if (p.woodcuttingAxe <= -1)
					{
						container.stop();
						return;
					}
					if (!p.isWoodcutting) {
						container.stop();
						return;
					}
					if (p.disconnected) {
						container.stop();
						return;
					}
					if (p.isWoodcutting) {
						p.startAnimation(Axe_Settings[p.woodcuttingAxe][3]);
					}
					if (p.getItems().freeSlots() < 1) {
						p.sendMessage("You have ran out of inventory slots.");
						container.stop();
					}
					int XP = tree.getXpReceived();
					if (p.isWoodcutting) {
						p.getItems().addItem(tree.getLogRecieved(), 1);
						p.getPA().addSkillXP(XP, 8);
						p.sendMessage("You manage to get some " + ItemAssistant.getItemName(tree.getLogRecieved()).toLowerCase() + " from the tree.");
					}
					if (p.tutorialProgress == 3) {
						p.getDH().sendDialogues(3014, 0);
					}
					//if (p.isWoodcutting) {
					//	BirdNest.birdNests(p);
					//}
					//if (p.isWoodcutting && p.tutorialProgress >= 36 && p.treeSpiritSpawned == false) {
					//	RandomEventHandler.addRandom(p);
					//}
					//if (p.isWoodcutting && Misc.random(350) == 69 && p.tutorialProgress >= 36 && p.randomEventsEnabled) {
						//TreeSpirit.spawnTreeSpirit(p);
					//}
					if (p.playerIsFletching || p.isFiremaking) {
						container.stop();
					}
					if (Misc.random(100) <= tree.getChance()) {
						cutDownTree(tree.getRespawnTime(), x, y, type, tree.getStump(), objectId);
						//p.getPacketSender().sendSound(SoundList.TREE_EMPTY, 100, 0);
						p.getPA().sendSound(Sound.SOUND_LIST.TREE_EMPTY.getSound(), 0, 8);
						container.stop();
					}
				}
				@Override
				public void stop() {
					p.startAnimation(65535);
					p.isWoodcutting = false;
					p.treeX = 0;
					p.treeY = 0;
				}
			}, getTimer(tree, p.woodcuttingAxe, wcLevel));
		}
	}

	public static void stopWoodcutting(Client player) {
		player.startAnimation(65535);
		player.isWoodcutting = false;
		player.treeX = 0;
		player.treeY = 0;
	}
	
	public static int getTimer(treeData tree, int axe, int level) {
		double timer = (int)((tree.getLevelReq()  * 2) + 20 + Misc.random(20))-((Axe_Settings[axe][2] * (Axe_Settings[axe][2] * 0.75)) + level);
		if (timer < 3.0) {
			return 3;
		} else {
			return (int)timer;
		}
	}

	public static boolean playerTrees(Client player, int tree) {
		boolean trees2 = false;
			for (int i1 = 0; i1 < 6; i1++) {
				for (int i = 0; i < trees[i1].length; i++) {
				if (tree == trees[i1][i]) {
					trees2 = true;
				}
			}
		}
		return trees2;
	}

	public static int[][] trees = {
			{ // NORMAL
			1276, 1277, 1278, 1365, 1286, 1289,  1282, 3648, 

			},
			{ // OAK
			10820,},
			{ // WILLOW
			10819, 10831, 10829, 10833,},
			{ // MAPLE
			10832,}, 
			{ // YEW
			10828, 10822,}, 
			{ // MAGIC
			10834, } };

	public static void cutDownTree(int respawnTime, int objectX, int objectY, int type, int stumpID, int treeID) {
		new Object(stumpID, objectX, objectY, 0, type, 10, treeID, respawnTime);
		for (int t = 0; t < PlayerHandler.players.length; t++) {
			if (PlayerHandler.players[t] != null) {
				if (PlayerHandler.players[t].treeX == objectX && PlayerHandler.players[t].treeY == objectY) {
					PlayerHandler.players[t].isWoodcutting = false;
					PlayerHandler.players[t].startAnimation(65535);
					PlayerHandler.players[t].treeX = 0;
					PlayerHandler.players[t].treeY = 0;
				}
			}
		}
	}
}
