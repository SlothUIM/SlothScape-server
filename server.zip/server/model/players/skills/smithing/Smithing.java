package server.model.players.skills.smithing;

import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import server.model.items.ItemAssistant;
import server.model.players.Player;
import server.model.players.Client;

public class Smithing {

	private int addItem, xp, removeItem, removeAmount, makeTimes;
	
	private boolean hasItem(Client player, int type, String string) {
		return (ItemAssistant.getItemName(type).contains(string));
	}

	public void readInput(Client player, int levelReq, int type, int amountToMake) {
		if (hasItem(player, type, "Bronze")) {
			 removeItem = 2349;
		} else if (hasItem(player, type, "Iron")) {
			 removeItem = 2351;
		} else if (hasItem(player, type, "Steel")) {
			 removeItem = 2353;
		} else if (hasItem(player, type, "Mith")) {
			 removeItem = 2359;
		} else if (hasItem(player, type, "Adam") || hasItem(player, type, "Addy")) {
			 removeItem = 2361;
		} else if (hasItem(player, type, "Rune") || hasItem(player, type, "Runite")) {
			 removeItem = 2363;
		}
		checkBar(player, levelReq, amountToMake, type);
	}
	 
	private void checkBar(Client player, int level, int amountToMake, int type) {
    	SmithingData item = SmithingData.forId(type);
		if (item != null) {
			if (player.playerLevel[player.playerSmithing] >= item.getLvl()) {
				if (type == item.getId()) {
					addItem = item.getId();
					System.out.println("type = "+type);
					removeAmount = item.getAmount();
					makeTimes = amountToMake;
					xp = item.getXp();
			    	smithItem(player, addItem, removeItem, removeAmount, makeTimes, xp);
				}
			} else {
				 player.sendMessage("You don't have a high enough level to make this item.");
			}
		}
    }

    public static void smithItem(Client player, int addItem, int removeItem1, int removeItem2, int timesToMake, int XP) {
		player.doAmount = timesToMake;
		player.getPA().closeAllWindows();
		String name = ItemAssistant.getItemName(addItem);
		if (player.getItems().playerHasItem(removeItem1, 1)) {
			if (!player.isSmithing) {
				player.isSmithing = true;
				player.startAnimation(898);
				CycleEventHandler.getSingleton().addEvent(player, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						if (player.doAmount <= 0 || !player.getItems().playerHasItem(removeItem1, 1) 
								|| !player.isSmithing || player.isBanking 
								|| player.isSmelting) {
							container.stop();
						} else {
							player.startAnimation(898);
							player.getPA().sendSound(468, 100, 0);
							if (name.contains("ball")) {
								player.sendMessage("You make some " + name.toLowerCase() + "s.");
							} else if (name.charAt(name.length() -1) == 's') {
								player.sendMessage("You make some " + name.toLowerCase() + ".");
							} else {
								if (name.charAt(1) == 'a' || name.charAt(1) == 'e' || name.toLowerCase().charAt(1) == 'i' || name.charAt(1) == 'o' || name.charAt(1) == 'u') {
									player.sendMessage("You make an " + name.toLowerCase() + ".");
								} else {
									player.sendMessage("You make a " + name.toLowerCase() + ".");
								}
							}
							player.getItems().deleteItem(removeItem1, removeItem2);
							if (name.contains("bolt")) {
								player.getItems().addItem(addItem, 10);
							} else if (name.contains("dart tip")) {
								player.getItems().addItem(addItem, 10);
							} else if (name.contains("arrow") || name.contains("nail") || (name.contains("tip") && !name.contains("dart tip"))) {
								player.getItems().addItem(addItem, 15);
							} else if (name.contains("knife")) {
								player.getItems().addItem(addItem, 5);
							} else if (name.contains("ball")) {
								player.getItems().addItem(addItem, 4);
							} else {
								player.getItems().addItem(addItem, 1);
							}
							
							if(player.tutorialProgress == 20) {
								player.getDH().sendDialogues(3066, -1);
							}
							player.getPA().addSkillXP(XP, player.playerSmithing);
							player.doAmount--;
						}
					}

					@Override
					public void stop() {
						player.isSmithing = false;
					}
				}, addItem == 2 ? 10 : 3);
			}
		} else {
			player.sendMessage("You don't have enough bars to make this item!");
			player.isSmithing = false;
		}
	}
    
}