package server.model.players.skills;

import server.model.players.Client;
import server.Config;
import server.event.*;

public class Fletching {

	Client c;

	public Fletching(Client c) {
		this.c = c;
	}

	int[][] arrows = { { 52, 314, 53, 15, 1 }, { 53, 39, 882, 40, 1 },
			{ 53, 40, 884, 58, 15 }, { 53, 41, 886, 95, 30 },
			{ 53, 42, 888, 132, 45 }, { 53, 43, 890, 170, 60 },
			{ 53, 44, 892, 207, 75 } };

	public void makeArrows(int item1, int item2) {
		for (int j = 0; j < arrows.length; j++) {
			if ((item1 == arrows[j][0] && item2 == arrows[j][1])
					|| (item2 == arrows[j][0] && item1 == arrows[j][1])) {
				if (c.getItems().playerHasItem(item1, 15)
						&& c.getItems().playerHasItem(item2, 15)) {
					if (c.playerLevel[c.playerFletching] >= arrows[j][4]) {
						c.getItems().deleteItem(item1,
								c.getItems().getItemSlot(item1), 15);
						c.getItems().deleteItem(item2,
								c.getItems().getItemSlot(item2), 15);
						c.getItems().addItem(arrows[j][2], 15);
						c.getPA().addSkillXP(
								arrows[j][3] * Config.FLETCHING_EXPERIENCE,
								c.playerFletching);
					} else {
						c.sendMessage("You need a fletching level of "
								+ arrows[j][4] + " to fletch this.");
					}
				} else {
					c.sendMessage("You must have 15 of each supply to do this.");
				}
			}
		}
	}

	public boolean fletching = false;
	int fletchType = 0, amount = 0, log = 0;

	public void handleFletchingClick(int clickId, int amount) {
		for (int j = 0; j < buttons.length; j++) {
			if (buttons[j][0] == clickId) {
				fletchType = buttons[j][1];
				amount = buttons[j][2];
				for (int i = 0; i < logType.length; i++)
					if (log == logType[i]) {
						fletchBow(i, amount);
						break;
					}
				break;
			}
		}
	}
	public static void deleteTime(Client c) {
		c.doAmount--;
	}
	public void fletchBow(int index, int amount) {
		int toAdd = getItemToAdd(index);
		int amountToAdd = getAmountToAdd(toAdd);		
		if (c.playerLevel[c.playerFletching] < reqs[index]) {
			c.sendMessage("You need a Fletching level of "+ reqs[index] + " to make a "+toAdd);
			return;
		}
		int item = c.getItems().getItemAmount(logType[index]);
		if(amount > item) {
			amount = item;
		}
		c.doAmount = amount;
		c.getPA().removeAllWindows();

		final int itemToDelete = logType[index];
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				if (c.playerLevel[c.playerFletching] >= reqs[index]) {
					c.getItems().deleteItem(itemToDelete, c.getItems().getItemSlot(itemToDelete), c.playerSkillProp[9][1] == 52 ? 15 : 1);
					c.getItems().addItem(toAdd, 1);
					c.getPA().addSkillXP(getExp(index) * Config.FLETCHING_EXPERIENCE, c.playerFletching);
				}
				c.startAnimation(6702);
				deleteTime(c);
				if(!c.getItems().playerHasItem(itemToDelete, 1) || c.doAmount <= 0) {
					//resetFletching(c);
					container.stop();
				}
				/*if(!c.stopPlayerSkill) {
					resetFletching(c);
					container.stop();
				}*/
			}
			@Override
			public void stop() {

			}
		}, 2);
	}
	public void StringBow(int index, int item1, int item2) {
		int toAdd = 0;	
		if (c.playerLevel[c.playerFletching] < reqs[index]) {
			c.sendMessage("You need a Fletching level of "+ reqs[index] + " to make a "+toAdd);
			return;
		}
			if(item1 == UNSTRUNG_SHORTBOWS[index] || item2 == UNSTRUNG_LONGBOWS[index]) {
					c.startAnimation(STRINGING_ANIMS_SHORTBOW[index]);
			} else if(item1 == UNSTRUNG_LONGBOWS[index] || item2 == UNSTRUNG_LONGBOWS[index]) {
					c.startAnimation(STRINGING_ANIMS_LONGBOW[index]);
			}
		int item = c.getItems().getItemAmount(1777);
		c.doAmount = item;
			CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
			@Override
			public void execute(CycleEventContainer container) {
				
			if(item1 == UNSTRUNG_SHORTBOWS[index] || item2 == UNSTRUNG_LONGBOWS[index]) {
				if (c.playerLevel[c.playerFletching] >= reqs[index]) {
					c.getItems().deleteItem(item1, c.getItems().getItemSlot(item1), 1);
					c.getItems().deleteItem(item2, c.getItems().getItemSlot(item2), 1);
					c.getItems().addItem(STRUNG_SHORTBOWS[index], 1);
					c.getPA().addSkillXP(getShortBowExp[index], c.playerFletching);
				}
			} else if(item1 == UNSTRUNG_LONGBOWS[index] || item2 == UNSTRUNG_LONGBOWS[index]) {
				if (c.playerLevel[c.playerFletching] >= reqs[index]) {
					c.getItems().deleteItem(item1, c.getItems().getItemSlot(item1), 1);
					c.getItems().deleteItem(item2, c.getItems().getItemSlot(item2), 1);
					c.getItems().addItem(STRUNG_LONGBOWS[index], 1);
					c.getPA().addSkillXP(getLongBowExp[index], c.playerFletching);
				}
			}
				deleteTime(c);
				if(!c.getItems().playerHasItem(1777, 1) || c.doAmount <= 0) {
					//resetFletching(c);
					container.stop();
				}
				/*if(!c.stopPlayerSkill) {
					resetFletching(c);
					container.stop();
				}*/
			}
			@Override
			public void stop() {

			}
		}, 2);
	}
	public int getExp(int index) {
		if (fletchType == 3)
			return 5;
		else if (fletchType == 1)
			return exps[index];
		else
			return exps[index] + 8;

	}

	public int getItemToAdd(int index) {
		if (fletchType == 3)
			return ARROW_SHAFTS;
		else if (fletchType == 1)
			return UNSTRUNG_SHORTBOWS[index];
		else if (fletchType == 2)
			return UNSTRUNG_LONGBOWS[index];
		else if (fletchType == 4)
			return CROSSBOW_STOCKS[index];
		return 0;
	}
	public int getBowToAdd(int index, int slot) {
		if(slot == 0)
			return STRUNG_SHORTBOWS[index];
		else if(slot == 1)
			return STRUNG_LONGBOWS[index];
		else if(slot == 2)
			return CROSSBOWS[index];
		return 0;
	}
	public int getAmountToAdd(int id) {
		if (id == ARROW_SHAFTS)
			return 15;
		else
			return 1;
	}
	
	public int KNIFE = 946;
	public int ARROW_SHAFTS = 52;
	public int BOWSTRING = 1777;
	public int CROSSBOW_STRING = 9438;
	public int[] logType = { 1511, 1521, 1519, 1517, 1515, 1513 };
	public int[] UNSTRUNG_SHORTBOWS = { 50, 54, 60, 64, 68, 72 };
	public int[] UNSTRUNG_LONGBOWS = { 48, 56, 58, 62, 66, 70 };
	public int[] exps = { 5, 16, 33, 50, 67, 83 };
	public int[] reqs = { 5, 20, 35, 50, 65, 80 };
	public int[] STRINGING_ANIMS_SHORTBOW = { 6678, 6679, 6680, 6681, 6682, 6683 };
	public int[] STRINGING_ANIMS_LONGBOW = { 6684, 6685, 6686, 6687, 6688, 6689 };
	public int[] STRINGING_ANIMS_CROSSBOW = { 6671, 6672, 6673, 6674, 6675, 6676 };
	public int[] STRUNG_SHORTBOWS = { 841, 843, 849, 853, 857, 861 };
	public int[] getShortBowExp = { 5, 16, 33, 50, 67, 83 };
	public int[] STRUNG_LONGBOWS = { 839, 845, 847, 851, 855, 859 };
	public int[] getLongBowExp = { 10, 25, 41, 50, 75, 91 };
	public int[] CROSSBOW_STOCKS = { 9440, 9442, 9444, 9446, 9448, 9450, 9452 };
	public int[] CROSSBOW_LIMBS = { 9420, 9422, 9423, 9425, 9427, 9429, 9431 };
	public int[] CROSSBOWS_U = { 9454, 9456 , 9457, 9459, 9461, 9463, 9365};
	public int[] CROSSBOWS = { 9174, 9176, 9177 , 9179, 9181, 9183, 9185};

	public void handleLog(int item1, int item2) {
		if (item1 == KNIFE) {
			openFletching(item2);
		} else {
			openFletching(item1);
		}
	}
	public void handleString(int item1, int item2, int index) {
		if (item1 == BOWSTRING && item2 == UNSTRUNG_SHORTBOWS[index]) {
			StringBow(index, item1, item2);
		}
		if (item2 == BOWSTRING && item1 == UNSTRUNG_SHORTBOWS[index]) {
			StringBow(index, item1, item2);
		}
		if (item1 == BOWSTRING && item2 == UNSTRUNG_LONGBOWS[index]) {
			StringBow(index, item1, item2);
		}
		if (item2 == BOWSTRING && item1 == UNSTRUNG_LONGBOWS[index]) {
			StringBow(index, item1, item2);
		}
	}
	public int[][] buttons = { 
	/**Make item interface with 4 items**/
	{ 34205, 1, 1 }, { 34204, 1, 5 }, { 34203, 1, 10 }, //first item make 1, 5, 10
	{ 34209, 2, 1 }, { 34208, 2, 5 }, { 34207, 2, 10 }, //second item make 1, 5, 10
	{ 34213, 3, 1 }, { 34212, 3, 5 }, { 34211, 3, 10 }, //third item make 1, 5, 10
	{ 34217, 4, 1 }, { 34216, 4, 5 }, { 34215, 4, 10 }, //fourth item make 1, 5, 10
	
	/**Make item interface with 2 items**/
	{ 34170, 1, 1 }, { 34169, 1, 5 }, { 34168, 1, 10 }, //first item make 1, 5, 10
	{ 34174, 2, 1 }, { 34173, 2, 5 }, { 34172, 2, 10 } //second item make 1, 5, 10
	};

	public void openFletching(int item) {
		if (item == 1511) {
			c.getPA().sendFrame164(8899);
			c.getPA().sendFrame126("What would you like to make?", 8898);
			c.getPA().sendFrame246(8902, 250, 50); // left middle middle
			c.getPA().sendFrame246(8903, 250, 48); // left picture
			c.getPA().sendFrame246(8904, 250, 52); // right middle pic
			c.getPA().sendFrame246(8905, 250, 9440); // right pic
			c.getPA().sendFrame126("Shortbow", 8909);
			c.getPA().sendFrame126("Longbow", 8913);
			c.getPA().sendFrame126("Wooden stock", 8917);
			c.getPA().sendFrame126("Arrow shafts", 8921);
			log = item;
		} else if (item == 1521) {
			c.getPA().sendFrame164(8899);
			c.getPA().sendFrame126("What would you like to make?", 8898);
			c.getPA().sendFrame246(8902, 250, 54); // left middle middle
			c.getPA().sendFrame246(8903, 250, 56); // left picture
			c.getPA().sendFrame246(8904, 250, 52); // right middle pic
			c.getPA().sendFrame246(8905, 250, 9442); // right pic
			c.getPA().sendFrame126("Oak Shortbow", 8909);
			c.getPA().sendFrame126("Oak Longbow", 8913);
			c.getPA().sendFrame126("Oak stock", 8917);
			c.getPA().sendFrame126("Arrow shafts", 8921);
			log = item;
		} else if (item == 1519) {
			c.getPA().sendFrame164(8899);
			c.getPA().sendFrame126("What would you like to make?", 8898);
			c.getPA().sendFrame246(8902, 250, 60); // left middle middle
			c.getPA().sendFrame246(8903, 250, 58); // left picture
			c.getPA().sendFrame246(8904, 250, 52); // right middle pic
			c.getPA().sendFrame246(8905, 250, 9444); // right pic
			c.getPA().sendFrame126("Willow Shortbow", 8909);
			c.getPA().sendFrame126("Willow Longbow", 8913);
			c.getPA().sendFrame126("Willow stock", 8917);
			c.getPA().sendFrame126("Arrow shafts", 8921);
			log = item;
		} else if (item == 1517) {
			c.getPA().sendFrame164(8899);
			c.getPA().sendFrame126("What would you like to make?", 8898);
			c.getPA().sendFrame246(8902, 250, 64); // left middle middle
			c.getPA().sendFrame246(8903, 250, 62); // left picture
			c.getPA().sendFrame246(8904, 250, 52); // right middle pic
			c.getPA().sendFrame246(8905, 250, 9448); // right pic
			c.getPA().sendFrame126("Maple Shortbow", 8909);
			c.getPA().sendFrame126("Maple Longbow", 8913);
			c.getPA().sendFrame126("Maple stock", 8917);
			c.getPA().sendFrame126("Arrow shafts", 8921);
			log = item;
		} else if (item == 1515) {
			c.getPA().sendFrame164(8899);
			c.getPA().sendFrame126("What would you like to make?", 8898);
			c.getPA().sendFrame246(8902, 250, 68); // left middle middle
			c.getPA().sendFrame246(8903, 250, 66); // left picture
			c.getPA().sendFrame246(8904, 250, 52); // right middle pic
			c.getPA().sendFrame246(8905, 250, 9452); // right pic
			c.getPA().sendFrame126("Yew Shortbow", 8909);
			c.getPA().sendFrame126("Yew Longbow", 8913);
			c.getPA().sendFrame126("Yew stock", 8917);
			c.getPA().sendFrame126("Arrow shafts", 8921);
			log = item;
		} else if (item == 1513) {
			c.getPA().sendFrame164(8866);
			c.getPA().sendFrame126("What would you like to make?", 8966);
			c.getPA().sendFrame246(8869, 250, 72); // left middle middle
			c.getPA().sendFrame246(8870, 250, 70); // left picture
			c.getPA().sendFrame126("Magic Shortbow", 8874);
			c.getPA().sendFrame126("Magic Longbow", 8878);
			log = item;
		} 
		fletching = true;
	}
}