package server.model.players.skills;

import server.Server;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
//import com.rebotted.game.content.music.sound.SoundList;
//import com.rebotted.game.content.skills.SkillHandler;
//import server.model.players.skills.cooking.Cooking;
import server.model.items.ItemAssistant;
import server.model.objects.Object;
import server.model.players.Player;
import server.model.players.Client;
import server.util.Misc;
import server.model.players.Sound;
import server.world.Boundary;
import server.clip.Region;

public class Firemaking {
	
	public static void stopFiremaking(Client c) {
		c.startAnimation(65535);
		c.lastSkillingAction = System.currentTimeMillis();
		c.isFiremaking = false;
		//Cooking.setCooking(c, false);
		c.logLit = false;
	}
	private Client c;
	public Firemaking(Client c){
		this.c = c;
	}
	public static void attemptFire(final Client c, final int itemUsed, final int usedWith, final int x, final int y, final boolean groundObject) {
		int firemakingItems[] = {590, 7329, 7330, 7331};
		for (int i = 0; i < firemakingItems.length; i++) {
		if (c.pickedUpFiremakingLog) {
			c.sendMessage("You can't do that!");
			c.pickedUpFiremakingLog = false;
			return;
		}
		if (c.isFiremaking && c.logLit == false) {
			return;
		}
		/*if (!SkillHandler.FIREMAKING) {
			c.getPacketSender().sendMessage("This skill is currently disabled.");
			return;
		}*/
		for (final LogData l : LogData.values()) {
			final int logId = usedWith == firemakingItems[i] ? itemUsed : usedWith;
			if (logId == l.getLogId()) {
				if (c.playerLevel[11] < l.getLevel()) {
					c.sendMessage("You need a firemaking level of " + l.getLevel() + " to light " + ItemAssistant.getItemName(logId));
					return;
				}
				if (Boundary.isIn(c, Boundary.EDGE_BANK) || Boundary.isIn(c, Boundary.LIGHTHOUSE)) {
					c.sendMessage("You cannot light a fire here.");
					return;
				}
				//if (Server.objectManager.objectExists(c.absX, c.absY, c.heightLevel)) {
					//c.sendMessage("You cannot light a fire here.");
					//return;
				//}
				c.isFiremaking = true;
				c.logLit = false;
				boolean notInstant = System.currentTimeMillis() - c.lastSkillingAction > 2500;
				int cycle = 2;
				if (notInstant) {
					c.sendMessage("You attempt to light a fire.");
						c.getPA().sendSound(Sound.SOUND_LIST.FIRE_LIGHT.getSound(), 0, 8);
					if (!notInstant) {
						c.getPA().sendSound(Sound.SOUND_LIST.FIRST_ATTEMPT.getSound(), 0, 8);
					}
					if (c.tutorialProgress == 4) {
						c.getPA().chatbox(6180);
						c.getDH().chatboxText("", "Your character is now attempting to light the fire.", "This should only take a few seconds.", "", "Please wait");
						c.getPA().chatbox(6179);
					}
					if (groundObject == false) {
						c.getItems().deleteItem(logId, c.getItems().getItemSlot(logId), 1);
						Server.itemHandler.createGroundItem(c, logId, c.absX, c.absY, c.heightLevel, 1, c.playerId);
					}
					cycle = 3 + Misc.random(6);
				} else {
					if (groundObject == false) {
						c.getItems().deleteItem(logId, c.getItems().getItemSlot(logId), 1);
						Server.itemHandler.createGroundItem(c, logId, c.absX, c.absY, c.heightLevel, 1, c.playerId);
					}
				}
				final boolean walk;
				if (Region.getClipping(x - 1, y, c.heightLevel, -1, 0)) {
					walk = true;
				} else {
					walk = false;
				}
				c.startAnimation(733);
				c.getPA().walkTo(walk ? -1 : 1, 0);
				c.stopFiremaking = false;
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {

					@Override
					public void execute(CycleEventContainer container) {
						if (c.stopFiremaking) {
							c.stopFiremaking = false;
							return;
						}
						if (c.isWoodcutting || c.playerIsFletching || c.isFletching) {
							container.stop();
						}
						if (c.isFiremaking) {
							Server.itemHandler.removeGroundItem(c, logId, x, y, false);
							c.getPA().sendSound(Sound.SOUND_LIST.FIRE_SUCCESSFUL.getSound(), 0, 8);
							if (itemUsed == 7331 || usedWith == 7331)
								new Object(11406, x, y, 0, 0, 10, -1, 60 + Misc.random(30));
							else if (itemUsed == 7330 || usedWith == 7330)
								new Object(11405, x, y, 0, 0, 10, -1, 60 + Misc.random(30));
							else if (itemUsed == 7329 || usedWith == 7329)
								new Object(11404, x, y, 0, 0, 10, -1, 60 + Misc.random(30));
							else
								new Object(2732, x, y, 0, 0, 10, -1, 60 + Misc.random(30));
							c.sendMessage("The fire catches and the log beings to burn.");
							c.getPA().addSkillXP((int) l.getXp(), 11);
							if (c.tutorialProgress == 4) {
								c.getDH().sendDialogues(3016, 943);
							}
							CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {

										@Override
										public void execute(CycleEventContainer container) {
											c.turnPlayerTo(walk ? x + 1 : x - 1, y);
											c.logLit = true;
											stopFiremaking(c);
											container.stop();
										}

										@Override
										public void stop() {
										}
									}, 2);
							container.stop();
						} else {
							return;
						}
					}

					@Override
					public void stop() {
						stopFiremaking(c);
					}
				}, cycle);
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
					@Override
					public void execute(CycleEventContainer container) {
						//if (c.playerIsCooking) {
						//	Cooking.setCooking(c, false);
						//}
						Server.objectHandler.createAnObject(c, -1, x, y);
						Server.itemHandler.createGroundItem(c, 592, x, y, c.getH(), 1, c.getId());
						container.stop();
					}
					@Override
					public void stop() {

					}
					}, 60);
				}
			}
		}
	}
}
