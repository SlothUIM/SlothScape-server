package server.model.players.skills;

import server.model.players.Client;
import server.Config;
import server.Server;
import server.model.players.PlayerHandler;
import server.util.Misc;
import server.model.players.packets.ClickingButtons;

	public class ProcessSkillGuides {
		
		private Client c;
		public ProcessSkillGuides(Client c){
			this.c = c;
		}
		
		public String[][] SideBarTexts = {
			{"Attack", "Weapons", "Armour", "Salamanders"},
			{"Strength", "Weapons", "Armour", "Shortcuts", "Areas", "Barbarian"},
			{"Defence", "Armour", "Penance", "Prayers", "Shields"},
			{"Ranged", "Bows", "Thrown", "Crossbows", "Armour", "Miscellaneous", "Shortcuts", "Salamanders"},
			{"Prayer", "Standard Prayers", "Equipment", "Other"},
			{"Magic", "Normal Spells", "Ancient Magicks", "Lunar Spells", "Armour", "Bolts", "Weapons", "Equipment", "Salamanders"},
			{"RuneCraft", "Runes", "Multiple Runes", "Rune Pouches", "Infusing", "Other"},
			{"Construction", "Rooms", "Skills", "Surfaces", "Decorative", "Trophies", "Games", "Garden", "Dungeon", "Chapel", "Other", "Servants", "House Size"},
			
			{"Hitpoints", "Hitpoints", "Healing", "Equipment"},
			{"Agility", "Courses", "Areas", "Shortcuts", "Barbarian", "Other"},
			{"Herblore", "Potions", "Herbs", "Barbarian Potions", "Other"},
			{"Theiving", "Pickpocket", "Stalls", "Chests", "Other"},
			{"Crafting", "Weaving", "Armour", "Spinning", "Pottery", "Glass", "Jewellery", "Weaponry", "Other"},
			{"Fletching", "Arrows", "Bows", "Bolts", "Darts", "Crossbows", "Javelins", "Shields", "Other"},
			{"Slayer", "Monsters", "Equipment", "Slayer Masters"},
			{"Hunter", "Tracking", "Birds", "Butterflies", "Implings", "Deadfall", "Box Trap", "Net Trap", "Pitfalls", "Aeriel", "Traps", "Clothing", "Other"},
			
			{"Mining", "Rocks", "Equipment", "Areas", "Shooting Stars"},
			{"Smithing", "Smelting", "Bronze", "Blurite", "Iron", "Steel", "Mithril", "Adamant", "Rune", "Other"},
			{"Fishing", "Small Net", "Big Net", "Rod", "Harpoon", "Aerial", "Cage", "Barbarian", "Equipment", "Other"},
			{"Cooking", "Meats", "Bread", "Pies", "Stews", "Pizzas", "Cakes", "Wine", "Hot Drinks", "Brewing", "Vegetable", "Dairy", "Gnome"},
			{"Firemaking", "Burning", "Barbarian", "Equipment", "Miscellaneous"},
			{"Woodcutting", "Trees", "Axes", "Other"},
			{"Farming", "Allotments", "Hops", "Trees", "Fruit Trees", "Bushes", "Flowers", "Herbs", "Special", "Scarecrows", "Multiple roots", "Other"}
			}; 			
		public String[][] FirstitemTexts = {
			{"Bronze", "Iron", "Steel", "Black", "Members: White", "Mithril", "Adamant", "Members: Battlestaves\\n(with 30 magic)", "Rune", "Members: Brine Sabre", "Members: Mystic staffs\\n(with 40 magic)", "Members: Granite Maul\\n(with 50 Strength)", "Members: Keris", "Members: Ancient Staff", "Members: Dragon", "Members: Barrelchest Anchor\\n(with 40 Strength)", "Members: Obsidian", "Members: 3rd Age Weapons", "Members: Saradomin Sword", "Members: Zamorakian Spear", "Members: Abyssal Whip and Dagger", "Members: Ahrims Staff", "Members: Dharoks Greataxe", "Members: Torags Hammers", "Members: Veracs Flail", "Members: Guthans Warspear", "Members: Godswords", "Members: Abyssal Tentacle", "Members: Dragonhunter Lance", "Members: Scythe of Vitur\\n(with 90 Strength)"},
			{"Bronze warhammer", "Iron warhammer", "Steel warhammer", "Members: Black halberd\\n(with 10 Attack)", "Members: White halberd\\n(with 10 Attack)", "Black warhammer", "Members: White warhammer\\n(with 10 Prayer)", "Members: Mithril halberd\\n(with 20 Attack)", "Members: Adamant halberd\\n(with 30 Attack)", "Mithril warhammer", "Members: Rune halberd\\n(with 40 Attack)", "Adamant warhammer", "Members: Dragon halberd\\n(with 60 Attack)", "Rune warhammer", "Members: Barrelchest Anchor\\n(with 60 Attack)", "Members: Granite Maul\\n(with 50 Attack)", "Members: TzHaar-Ket-Om", "Members: Dragon warhammer", "Members: Dharok's greataxe\\n(with 70 Attack)", "Members: Torag's hammers\\n(with 70 Attack)", "Members: Scythe of Vitur\\n(with 80 Attack)"},
			{"Bronze", "Iron", "Steel", "Black", "Members: White", "Members: Slayer helm", "Mithril", "Members: Yak-hide", "Members: Initiate armour\\n(after Recruitment Drive, with 10\\nPrayer)", "Adamantite", "Members: Proselyte armour\\n(after Slug Menace, with 20 Prayer)", "Rune", "Members: Rock-shell armour\\n(after Fremennik Trials)", "Members: Void Knight equipment\\n(with 42 combat stats and 22 Prayer)", "Members: Fremennik helmets\\n(after Fremennik Trials)", "Members: Granite\\n(with 50 Strength)", "Members: Helm of neitiznot\\n(after Fremennik Isles)", "Members: Dragon", "Members: Bandos armour", "Members: 3rd age fighter armour", "Members: Barrows armour", "Members: Armadyl armour\\n(with 70 Ranged)", "Members: Crystal shield\\n(with 50 Agility)", "Members: Primordial boots\\n(with 75 Strength)", "Members: Eternal boots\\n(with 75 Magic)", "Members: Pegasian boots\\n(with 75 Ranged)"},
			{"Standard bows\\n Ammo: Arrows up to iron", "Oak bows\\n Ammo: Arrows up to steel", "Willow bows\\n Ammo: Arrows up to mithril", "Maple bows\\n Ammo: Arrows up to adamant", "Members: Ogre composite bows\\n Ammo: 'Brutal' Arrows up to rune", "Members: Yew bows\\n Ammo: Arrows up to rune","Members: Magic bows\\n Ammo: Arrows up to amethyst","Members: Seerculls\\n Ammo: Arrows up to amethyst","Members: Dark bows\\n Ammo: Arrows up to dragon","Members: 3rd age bow\\n Ammo: Arrows up to dragon","Members: Crystal bows(with 50 Agility)\\n Ammo: None","Members: Twisted bow\\n Ammo: Arrows up to dragon"},
			{"Prayer", "Standard Prayers", "Equipment", "Other"},
			{"Magic", "Normal Spells", "Ancient Magicks", "Lunar Spells", "Armour", "Bolts", "Weapons", "Equipment", "Salamanders"},
			{"RuneCraft", "Runes", "Multiple Runes", "Rune Pouches", "Infusing", "Other"},
			{"Construction", "Rooms", "Skills", "Surfaces", "Decorative", "Trophies", "Games", "Garden", "Dungeon", "Chapel", "Other", "Servants", "House Size"},
			
			{"Hitpoints are used to tell you how\\nhealthy your character is. A character\\nwho reaches 0 Hitpoints has died, but\\nwill reappear in their chosen respawn\\nlocation(normally Lumbridge).", "", "if your see any red 'hit splats' during\\ncombat, the number shown corresponds\\nto the number of Hitpoints lost as a\\nresult of that strike.", "", "Blue hit splats mean no damage has\\nbeen dealt.", "Green hit splats are poison damage.", "Teal hit splats are venom damage.\\n(Members)", "Orange hit splats are disease damage.\\n(Members)"},
			{"Agility", "Courses", "Areas", "Shortcuts", "Barbarian", "Other"},
			{"Attack potion\\nGuam leaf & eye of newt", "Anti-poison potion\\nMarrentill & ground unicorn horn", "Relicym's balm", "Strength potion\\nTarromin & limpwurt root","Serum 207\\nTarromin & ashes","Guam tar\\nGuam leaf & swamp tar","Compost potion\\nHarralander & volcanic ash","Stat restore potion\\nHarralander & red spiders' eggs","Energy potion\\nHarralander & chocolate dust","Defence potion\\nRanarr weed & white berries","Marrentill tar\\nMarrentill & swamp tar","Agility potion\\nToadflax & toad legs","Combat potion\\nHarralander & ground desert goat horn","Prayer restore potion\\nRanarr weed & snape grass","Tarromin tar\\nTarromin & swamp tar","Harralander tar\\nHarralander & swamp tar","Super attack potion\\nIrit leaf & eye of newt","Super anti-poison potion\\nIrit leaf & ground unicorn horn","Fishing potion\\nAvantoe & snape grass","Super energy potion\\nAvantoe & Mort Myre fungi","Hunting potion - Avantoe & ground\\nsabre-toothed kebbit teeth","Super strength potion\\nKwuarm & limpwurt root","Magic essence potion\\nStar flower & ground gorak's claw","Weapon poison\\nKwuarm & ground blue dragon scale","Super restore potion\\nSnapdragon & red spiders' eggs","Super defence potion\\nCadantine & white berries","Antidote+\\nCoconut milk, toadflax & yew roots","Anti-firebreath potion\\nLantadyme & ground blue dragon scale","Ranging potion\\nDwarf weed & wine of Zamorak","Weapon poison(+)\\nCoconut milk, cactus spine & red\\nspiders' eggs","Magic potion\\nLantadyme & potato cactus", "Stamina potion\\nAmylase & super energy potion", "Zamorak brew\\nTorstol & jangerberries","Antidote++\\nCoconut milk, irit leaf & magic tree\\nroots", "Saradomin brew\\nToadflax & crushed birdnest", "Weapon poison(++)\\nCoconut milk, nightshade & poison ivy\\nberries","Extended antifire potion\\nAntifire potion & lava scale shards", "Anti-venom\\nAntidote++ & Zulrah's scales","Super combat potion\\nSuper attack potion, super defence\\npotion, super strength potion & torstol","Super antifire potion\\nAntifire potion & crushed superior\\ndragon bones","Anti-venom+\\nAnti-venom & Torstol"},
			{"Theiving", "Pickpocket", "Stalls", "Chests", "Other"},
			{"Crafting", "Weaving", "Armour", "Spinning", "Pottery", "Glass", "Jewellery", "Weaponry", "Other"},
			
			{"15 Arrow shafts(Logs)", "Bronze Arrows", "Bronze 'brutal' arrows", "30 Arrow shafts(Oak logs)", "Iron arrows", "Iron 'brutal' arrows", "45 Arrow shafts (Willow logs)", "Steel arrows", "Steel 'brutal' arrows", "60 Arrow shafts(Maple logs)", "Mithril arrows","Mithril 'brutal' arrows", "Broad arrows\\n(after purchasing the ability with 300 Slayer points)", "Adamant arrows", "75 Arrow shafts(Yew logs)", "Adamant 'brutal' arrows", "90 Arrow shafts(Magic logs)", "Rune arrows","Rune 'brutal' arrows"},
			
			{"Slayer", "Monsters", "Equipment", "Slayer Masters"},
			{"Hunter", "Tracking", "Birds", "Butterflies", "Implings", "Deadfall", "Box Trap", "Net Trap", "Pitfalls", "Aeriel", "Traps", "Clothing", "Other"},
			
			{"Mining", "Rocks", "Equipment", "Areas", "Shooting Stars"},
			{"Smithing", "Smelting", "Bronze", "Blurite", "Iron", "Steel", "Mithril", "Adamant", "Rune", "Other"},
			{"Fishing", "Small Net", "Big Net", "Rod", "Harpoon", "Aerial", "Cage", "Barbarian", "Equipment", "Other"},
			{"Cooking", "Meats", "Bread", "Pies", "Stews", "Pizzas", "Cakes", "Wine", "Hot Drinks", "Brewing", "Vegetable", "Dairy", "Gnome"},
			{"Firemaking", "Burning", "Barbarian", "Equipment", "Miscellaneous"},
			{"Woodcutting", "Trees", "Axes", "Other"},
			{"Potatoes\\nPayment: Compost x2", "Onions\\nPayment: Potatoes(10)", "Cabbages\\nPayment: Onions(10)", "Tomatoes\\nPayment: Cabbages(10) x2", "Sweetcorn\\nPayment: Jute fibre x10", "Strawberries\\nPayment: Apples(5)", "Watermelons\\nPayment: Curry leaf x10", "Snape grass\\nPayment: Jangerberries x5"}
			}; 			
		public String[][] SeconditemTexts = {
			{"Void Knight equipment\\n(with 42 combat stats and 22 Prayer)"},
			{"Void Knight equipment\\n(with 42 combat stats and 22 Prayer)", "Granite armour\\n(with 50 defence)", "Primordial boots\\n(with 75 Defence)"},
			{"Fighter torso", "Runner boots", "Penance gloves", "Penance skirt\\n(with 60 Ranged)", "Fighter hat", "Ranger hat", "Healer hat", "Runner hat"},
			{"Bronze items", "Iron items", "Steel items", "Black items", "Mithril items", "Adamant items", "Rune items", "Chinchompas", "Amethyst darts", "Carnivorous chinchompas", "Dragon darts", "Dragon knives", "TokTz-Xil-Ul", "Dragon thrownaxes", "Toxic Blowpipe"},
			{"Initiate armour\\n (after Recruitment Drive, with 20\\n Defence)", "Proselyte armour\\n (after Slug Menace, with 30 Defence)", "Vestment robe top", "Vestment robe legs", "Void Knight equipment\\n (with 42 combat stats)", "Holy sandals", "Vestment cloak", "Vestment mitre", "Use completed prayer books\\n to bless holy and unholy symbols", "Spirit Shield\\n (with 45 Defence)", "Vestment stole", "Crozier", "Blessed spirit shield\\n (with 70 Defence)","Arcane & Spectral spirit shields\\n (with 75 Defence and 65 Magic)", "Elysian spirit shield\\n (with 75 Defence)"},
			{"Magic", "Normal Spells", "Ancient Magicks", "Lunar Spells", "Armour", "Bolts", "Weapons", "Equipment", "Salamanders"},
			{"RuneCraft", "Runes", "Multiple Runes", "Rune Pouches", "Infusing", "Other"},
			{"Construction", "Rooms", "Skills", "Surfaces", "Decorative", "Trophies", "Games", "Garden", "Dungeon", "Chapel", "Other", "Servants", "House Size"},
			
			{"Hitpoints", "Hitpoints", "Healing", "Equipment"},
			{"Agility", "Courses", "Areas", "Shortcuts", "Barbarian", "Other"},
			{"Herblore", "Potions", "Herbs", "Barbarian Potions", "Other"},
			{"Theiving", "Pickpocket", "Stalls", "Chests", "Other"},
			{"Crafting", "Weaving", "Armour", "Spinning", "Pottery", "Glass", "Jewellery", "Weaponry", "Other"},
			{"Shortbow", "Longbow", "Oak shortbow", "Oak longbow", "Composite bows", "Willow shortbow", "Willow longbow", "Maple shortbow", "Maple longbow", "Yew shortbow", "Yew longbow", "Magic shortbow", "Magic longbow"},
			{"Slayer", "Monsters", "Equipment", "Slayer Masters"},
			{"Hunter", "Tracking", "Birds", "Butterflies", "Implings", "Deadfall", "Box Trap", "Net Trap", "Pitfalls", "Aeriel", "Traps", "Clothing", "Other"},
			
			{"Mining", "Rocks", "Equipment", "Areas", "Shooting Stars"},
			{"Smithing", "Smelting", "Bronze", "Blurite", "Iron", "Steel", "Mithril", "Adamant", "Rune", "Other"},
			{"Fishing", "Small Net", "Big Net", "Rod", "Harpoon", "Aerial", "Cage", "Barbarian", "Equipment", "Other"},
			{"Cooking", "Meats", "Bread", "Pies", "Stews", "Pizzas", "Cakes", "Wine", "Hot Drinks", "Brewing", "Vegetable", "Dairy", "Gnome"},
			{"Firemaking", "Burning", "Barbarian", "Equipment", "Miscellaneous"},
			{"Woodcutting", "Trees", "Axes", "Other"},
			{"Barley\\nPayment: Compost x3",  "Hammerstone hops\\nPayment: Marigolds",  "Asgarnian hops\\nPayment: Onions(10)",  "Jute plants\\nPayment: Barley malt x6",  "Yanillian hops\\nPayment: Tomatoes(5)",  "Krandorian hops\\nPayment: Cabbages(10) x3",  "Wildblood hops\\nPayment: Nasturtiums", }
			}; 			
		public String[][] ThirditemTexts = {
			{"Bronze", "Iron", "Steel", "Black", "Members: White", "Mithril", "Adamant", "Members: Battlestaves\\n(with 30 magic)", "Rune", "Members: Brine Sabre", "Members: Mystic staffs\\n(with 40 magic)", "Members: Granite Maul\\n(with 50 Strength)", "Members: Keris", "Members: Ancient Staff", "Members: Dragon", "Members: Barrelchest Anchor\\n(with 40 Strength)", "Members: Obsidian", "Members: 3rd Age Weapons", "Members: Saradomin Sword", "Members: Zamorakian Spear", "Members: Abyssal Whip and Dagger", "Members: Ahrims Staff", "Members: Dharoks Greataxe", "Members: Torags Hammers", "Members: Veracs Flail", "Members: Guthans Warspear", "Members: Godswords", "Members: Abyssal Tentacle", "Members: Dragonhunter Lance", "Members: Scythe of Vitur\\n(with 90 Strength)"},
			{"Bronze warhammer", "Iron warhammer", "Steel warhammer", "Members: Black halberd\\n(with 10 Attack)", "Members: White halberd\\n(with 10 Attack)", "Black warhammer", "Members: White warhammer\\n(with 10 Prayer)", "Members: Mithril halberd\\n(with 20 Attack)", "Members: Adamant halberd\\n(with 30 Attack)", "Mithril warhammer", "Members: Rune halberd\\n(with 40 Attack)", "Members: Barrelchest Anchor\\n(with 60 Attack)", "Members: Granite Maul\\n(with 50 Attack)", "Members: TzHaar-Ket-Om", "Members: Dragon warhammer", "Members: Dharok's greataxe\\n(with 70 Attack)", "Members: Torag's hammers\\n(with 70 Attack)", "Members: Scythe of Vitur\\n(with 80 Attack)"},
			{"Bronze", "Iron", "Steel", "Black", "Members: White", "Members: Slayer helm", "Mithril", "Members: Yak-hide", "Members: Initiate armour\\n(after Recruitment Drive, with 10\\nPrayer)", "Adamantite", "Members: Proselyte armour\\n(after Slug Menace, with 20 Prayer)", "Rune", "Members: Rock-shell armour\\n(after Fremennik Trials)", "Members: Void Knight equipment\\n(with 42 combat stats and 22 Prayer)", "Members: Fremennik helmets\\n(after Fremennik Trials)", "Members: Granite\\n(with 50 Strength)", "Members: Helm of neitiznot\\n(after Fremennik Isles)", "Members: Dragon", "Members: Bandos armour", "Members: 3rd age fighter armour", "Members: Barrows armour", "Members: Armadyl armour\\n(with 70 Ranged)", "Members: Crystal shield\\n(with 50 Agility)", "Members: Primordial boots\\n(with 75 Strength)", "Members: Eternal boots\\n(with 75 Magic)", "Members: Pegasian boots\\n(with 75 Ranged)"},
			{"Crossbow\\n Ammo: Bronze crossbow bolts", "Phoenix Crossbow\\n Ammo: Bronze crossbow bolts", "Bronze crossbow\\n Ammo: Bronze crossbow bolts", "Blurite crossbow\\n Ammo: Bolts up to blurite", "Iron crossbow\\n Ammo: Bolts up to iron", "Dorgeshuun Crossbow\\n Ammo: Bolts up to iron", "Steel crossbow\\n Ammo: Bolts up to steel", "Mithril crossbow\\n Ammo: Bolts up to mithril", "Adamant crossbow\\n Ammo: Bolts up to adamant", "Hunter crossbow\\n Ammo: Kebbit bolts", "Runite crossbow\\n Ammo: Bolts up to runite", "Karil's crossbow\\n Ammo: Bolt racks", "Armadyl crossbow\\n Ammo: Bolts up to dragon"},
			{"Prayer"},
			{"Magic", "Normal Spells", "Ancient Magicks", "Lunar Spells", "Armour", "Bolts", "Weapons", "Equipment", "Salamanders"},
			{"RuneCraft", "Runes", "Multiple Runes", "Rune Pouches", "Infusing", "Other"},
			{"Construction", "Rooms", "Skills", "Surfaces", "Decorative", "Trophies", "Games", "Garden", "Dungeon", "Chapel", "Other", "Servants", "House Size"},
			
			{"Hitpoints", "Hitpoints", "Healing", "Equipment"},
			{"Agility", "Courses", "Areas", "Shortcuts", "Barbarian", "Other"},
			{"Herblore", "Potions", "Herbs", "Barbarian Potions", "Other"},
			{"Theiving", "Pickpocket", "Stalls", "Chests", "Other"},
			{"Crafting", "Weaving", "Armour", "Spinning", "Pottery", "Glass", "Jewellery", "Weaponry", "Other"},
			{"Bronze bolts", "Opal-tipped bronze bolts", "Blurite bolts", "Iron bolts", "Pearl-tipped iron bolts", "Silver bolts", "Steel bolts", "Red topaz-tipped steel bolts", "Barbed-tipped bronze bolts","Mithril bolts","Broad bolts","Sapphire-tipped mithril bolts", "Emerald-tipped mithril bolts", "Adamant bolts","Ruby-tipped adamant bolts","Diamond-tipped adamant bolts","Rune bolts","Dragonstone-tipped runite bolts","Onyx-tipped runite bolts"},
			{"Slayer", "Monsters", "Equipment", "Slayer Masters"},
			{"Hunter", "Tracking", "Birds", "Butterflies", "Implings", "Deadfall", "Box Trap", "Net Trap", "Pitfalls", "Aeriel", "Traps", "Clothing", "Other"},
			
			{"Mining", "Rocks", "Equipment", "Areas", "Shooting Stars"},
			{"Smithing", "Smelting", "Bronze", "Blurite", "Iron", "Steel", "Mithril", "Adamant", "Rune", "Other"},
			{"Fishing", "Small Net", "Big Net", "Rod", "Harpoon", "Aerial", "Cage", "Barbarian", "Equipment", "Other"},
			{"Cooking", "Meats", "Bread", "Pies", "Stews", "Pizzas", "Cakes", "Wine", "Hot Drinks", "Brewing", "Vegetable", "Dairy", "Gnome"},
			{"Firemaking", "Burning", "Barbarian", "Equipment", "Miscellaneous"},
			{"Woodcutting", "Trees", "Axes", "Other"},
			{"Oak trees\\nPayment: Tomatoes(5)", "Willow trees\\nPayment: Apples(5)", "Maple trees\\nPayment: Oranges(5)", "Yew trees\\nPayment: Cactus spine x10", "Magic trees\\nPayment: Coconut x25", }
			}; 		
		public String[][] FourthitemTexts = {
			{""},
			{"Bronze warhammer", "Iron warhammer", "Steel warhammer", "Members: Black halberd\\n(with 10 Attack)", "Members: White halberd\\n(with 10 Attack)", "Black warhammer", "Members: White warhammer\\n(with 10 Prayer)", "Members: Mithril halberd\\n(with 20 Attack)", "Members: Adamant halberd\\n(with 30 Attack)", "Mithril warhammer", "Members: Rune halberd\\n(with 40 Attack)", "Members: Barrelchest Anchor\\n(with 60 Attack)", "Members: Granite Maul\\n(with 50 Attack)", "Members: TzHaar-Ket-Om", "Members: Dragon warhammer", "Members: Dharok's greataxe\\n(with 70 Attack)", "Members: Torag's hammers\\n(with 70 Attack)", "Members: Scythe of Vitur\\n(with 80 Attack)"},
			{"Bronze", "Iron", "Steel", "Black", "Members: White", "Members: Slayer helm", "Mithril", "Members: Yak-hide", "Members: Initiate armour\\n(after Recruitment Drive, with 10\\nPrayer)", "Adamantite", "Members: Proselyte armour\\n(after Slug Menace, with 20 Prayer)", "Rune", "Members: Rock-shell armour\\n(after Fremennik Trials)", "Members: Void Knight equipment\\n(with 42 combat stats and 22 Prayer)", "Members: Fremennik helmets\\n(after Fremennik Trials)", "Members: Granite\\n(with 50 Strength)", "Members: Helm of neitiznot\\n(after Fremennik Isles)", "Members: Dragon", "Members: Bandos armour", "Members: 3rd age fighter armour", "Members: Barrows armour", "Members: Armadyl armour\\n(with 70 Ranged)", "Members: Crystal shield\\n(with 50 Agility)", "Members: Primordial boots\\n(with 75 Strength)", "Members: Eternal boots\\n(with 75 Magic)", "Members: Pegasian boots\\n(with 75 Ranged)"},
			{"Plain leather items", "Hard leather body\\n (with 10 Defence)", "Studded leather body\\n (with 20 Defence)", "Studded leather chaps", "Coif", "Members: Frog-leather\\n (with 25 Defence)", "Members: Snakeskin armour\\n (with 30 Defence)", "Members: Ava's attractor\\n (After Animal Magnetism)", "Members: Ranger boots", "Members: Robin hood hat", "Members: Spined armour\\n (after The Fremennik Trials, with 40\\n Defence)", "Green dragonhide vambraces", "Green dragonhide chaps", "Members: Green dragonhide body", "Members: Void Knight equipment\\n (with 42 combat stats and 22 prayer)", "Members: Ava's accumulator\\n (after Animal Magnetism)", "Members: Blue dragonhide vambraces", "Members: Blue dragonhide chaps", "Members: Blue dragonhide body\\n (with 40 Defence)", "Members: Penance skirt\\n (with 40 Defence)", "Members: Red dragonhide vambraces", "Members: Red dragonhide chaps", "Members: Red dragonhide body\\n (with 40 Defence)", "Members: 3rd age range armour\\n (with 45 Defence)", "Members: Black dragonhide vambraces", "Members: Black dragonhide chaps", "Members: Black dragonhide body\\n (with 40 Defence)", "Members: God dragonhide armour\\n (with 45 Defence)", "Members: Armadyl armour\\n (with 70 Defence)", "Members: Karil's leather armour\\n (with 70 Defence)", "Members: Pegasian boots\\n (with 75 Defence)"},
			{""},
			{"Magic"},
			{"RuneCraft"},
			{"Construction"},
			
			{""},
			{"Agility"},
			{"Herblore"},
			{"Theiving"},
			{"Crafting"},
			{"Bronze darts", "Iron darts", "Steel darts", "Mithril darts", "Toxic blowpipe", "Adamant darts", "Rune darts"},
			{"Slayer", "Monsters", "Equipment", "Slayer Masters"},
			{"Hunter", "Tracking", "Birds", "Butterflies", "Implings", "Deadfall", "Box Trap", "Net Trap", "Pitfalls", "Aeriel", "Traps", "Clothing", "Other"},
			
			{"Mining", "Rocks", "Equipment", "Areas", "Shooting Stars"},
			{"Smithing", "Smelting", "Bronze", "Blurite", "Iron", "Steel", "Mithril", "Adamant", "Rune", "Other"},
			{"Fishing", "Small Net", "Big Net", "Rod", "Harpoon", "Aerial", "Cage", "Barbarian", "Equipment", "Other"},
			{"Cooking", "Meats", "Bread", "Pies", "Stews", "Pizzas", "Cakes", "Wine", "Hot Drinks", "Brewing", "Vegetable", "Dairy", "Gnome"},
			{"Firemaking", "Burning", "Barbarian", "Equipment", "Miscellaneous"},
			{""},
			{"Apple trees\\nPayment: Sweetcorn x9", "Banana trees\\nPayment: Apples(5) x4", "Orange trees\\nPayment: Strawberries(5) x3", "Curry trees\\nPayment: Bananas(5) x5", "Pineapple trees\\nPayment: Watermelon x10", "Papaya trees\\nPayment: Pineapple x10", "Palm trees\\nPayment: Papaya fruit x15"}
			}; 		
		public String[][] FifthitemTexts = {
			{""},
			{"Bronze warhammer"},
			{""},
			{"Void Knight equipment\\n (with 42 combat stats and 22 Prayer)"},
			{""},
			{"Magic"},
			{"RuneCraft"},
			{"Construction"},
			
			{""},
			{"Agility"},
			{"Herblore"},
			{"Theiving"},
			{"Crafting"},
			{"Bronze/wooden crossbow", "Blurite/oak crossbow", "Iron/willow crossbow", "Steel/teak crossbow", "Mithril/maple crossbow", "Adamant/mahogany crossbow", "Rune/yew crossbow"},
			{"Slayer"},
			{"Hunter"},
			
			{"Mining"},
			{"Smithing"},
			{"Fishing"},
			{"Cooking"},
			{"Firemaking"},
			{""},
			{"Redberry bushes\\nPayment: Cabbages(10) x4", "Cadavaberry bushes\\nPayment: Tomatoes(5) x3", "Dwellberry bushes\\nPayment: Strawberries(5) x3", "Jangerberry bushes\\nPayment: Watermelon x6", "White berry bushes\\nPayment: Mushroom x8", "Poison ivy bushes", }
			}; 
		public String[][] SixthitemTexts = {
			{""},
			{"Bronze warhammer"},
			{""},
			{"Void Knight equipment\\n (with 42 combat stats and 22 Prayer)"},
			{""},
			{"Magic"},
			{"RuneCraft"},
			{"Construction"},
			
			{""},
			{"Agility"},
			{"Herblore"},
			{"Theiving"},
			{"Crafting"},
			{"Bronze/wooden crossbow", "Blurite/oak crossbow", "Iron/willow crossbow", "Steel/teak crossbow", "Mithril/maple crossbow", "Adamant/mahogany crossbow", "Rune/yew crossbow"},
			{"Slayer"},
			{"Hunter"},
			
			{"Mining"},
			{"Smithing"},
			{"Fishing"},
			{"Cooking"},
			{"Firemaking"},
			{""},
			{"Marigolds\\nProtects onions, tomatoes and\\npotatoes", "Rosemary\\nProtects cabbages from disease", "Make and place a scarecrow\\nProtects sweetcorn from birds", "Nasturtiums\\nProtects watermelons from disease", "Woad", "Limpwurt plants", }
			}; 	
		public String[][] SeventhitemTexts = {
			{""},
			{"Bronze warhammer"},
			{""},
			{"Void Knight equipment\\n (with 42 combat stats and 22 Prayer)"},
			{""},
			{"Magic"},
			{"RuneCraft"},
			{"Construction"},
			
			{""},
			{"Agility"},
			{"Herblore"},
			{"Theiving"},
			{"Crafting"},
			{"Bronze/wooden crossbow", "Blurite/oak crossbow", "Iron/willow crossbow", "Steel/teak crossbow", "Mithril/maple crossbow", "Adamant/mahogany crossbow", "Rune/yew crossbow"},
			{"Slayer"},
			{"Hunter"},
			
			{"Mining"},
			{"Smithing"},
			{"Fishing"},
			{"Cooking"},
			{"Firemaking"},
			{""},
			{"Guam leaf", "Marrentill", "Tarromin", "Harralander", "Goutweed", "Ranarr weed", "Toadflax", "Irit leaf", "Avantoe", "Kwuarm", "Snapdragon", "Cadantine", "Lantadyme", "Dwarf weed", "Torstol"}
			}; 		
		public int[][] LevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{1, 5, 20, 30, 30, 40, 50, 50, 60, 65, 70, 85},//range
			{0, 0, 1, 4, 7 , 8, 9, 10, 13, 16, 19, 22, 25, 26, 27, 28, 31, 34, 37, 40, 43, 44, 45, 46, 49, 52, 60, 70, 0, 0},//prayer
			{1},//magic
			{1, 2, 5, 6, 9, 10, 13, 14, 15, 19, 20, 23, 27, 35, 40, 44, 54, 65, 77, 90},//runecraft
			{1, 1, 5, 10, 15, 20, 25, 30, 32, 35, 37, 40, 42, 45, 50, 55, 60, 65, 70, 75},//construction
			
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},//hitpoints
			{1},//agil
			{3,5,8,12,15,19,22,22,26,30,31,34,36,38,39,44,45,48,50,52,53,55,57,60,63,66,68,69,72,73,76,77,78,79,81,82,84,87,90,92,94},//herb
			{1},//theif
			{1},//craft
			{1,1,7,15,15,18,30,30,33,45,45,49,52,60,60,62,75,75,77},//fletch
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{1, 5, 7, 12, 20, 31, 47, 61}//farming
			}; 		
		public int[][] SecondLevelTexts = {
			{42},//attk
			{42, 50, 75},//str
			{40, 40, 40, 40, 45, 45, 45, 45},//def
			{1,1,5,10,20,30,40,45,50,55,60,60,60,61,75},//range
			{10,20,20,20,22,31,40,40,50,55,60,60,60,70,75},//prayer
			{1},//magic
			{1, 2, 5, 6, 9, 10, 13, 14, 15, 19, 20, 23, 27, 35, 40, 44, 54, 65, 77, 90},//runecraft
			{1, 1, 5, 10, 15, 20, 25, 30, 32, 35, 37, 40, 42, 45, 50, 55, 60, 65, 70, 75},//construction
			
			{0,0,0,0,0,0,0,0,0,0},//hitpoints
			{1},//agil
			{1},//herb
			{1},//theif
			{1},//craft
			{5,10,20,25,30,35,40,50,55,65,70,80,85},//fletch
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{3, 4, 8, 13, 16, 21, 28}
			}; 		
		public int[][] ThirdLevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{1, 1, 1, 16, 26, 28, 31, 36, 46, 50, 61, 70, 70},//range
			{1},//prayer
			{1},//magic
			{1},//runecraft
			{1},//construction
			
			{0},//hitpoints
			{1},
			{1},
			{1},
			{1},
			{9, 11, 24,39,41,43,46,48,51,54,55,56,58,61,63,65,69,71,73},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{15,30,45,60,75}
			}; 			
		public int[][] FourthLevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{1,1,20,20,20,25,30,30,40,40,40,40,40,40,42,50,50,50,50,60,60,60,60,65,70,70,70,70,70,70,75},//range
			{1},//prayer
			{1},//magic
			{1},//runecraft
			{1},//construction
			
			{0},//hitpoints
			{1},
			{1},
			{1},
			{1},
			{10,22,37,52,53,67,81},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{27,33,39,42,51,57,68}
			}; 			
		public int[][] FifthLevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{42},//range
			{1},//prayer
			{1},//magic
			{1},//runecraft
			{1},//construction
			
			{0},//hitpoints
			{1},
			{1},
			{1},
			{1},
			{9,24,39,46,54,61,69},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{10,22,36,48,59,70}
			}; 		
		public int[][] SixthLevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{42},//range
			{1},//prayer
			{1},//magic
			{1},//runecraft
			{1},//construction
			
			{0},//hitpoints
			{1},
			{1},
			{1},
			{1},
			{9,24,39,46,54,61,69},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{2,11,23,24,25,26}
			}; 	
		public int[][] SeventhLevelTexts = {
			{1, 1, 5, 10, 10, 20, 30, 30, 40, 40, 40, 50, 50, 50, 60, 60, 60, 65, 70, 70, 70, 70, 70, 70, 70, 70, 75, 75, 75, 80},//attk
			{1, 1, 5, 5, 5, 10, 10, 10, 15, 20, 20, 30, 30, 40, 40, 50, 60, 60, 70, 70, 90},//str
			{1, 1, 5, 10, 10, 10, 20, 20, 20, 30, 30, 40, 40, 42, 45, 50, 55, 60, 65, 65, 70, 70, 70, 75,75,75},//def
			{42},//range
			{1},//prayer
			{1},//magic
			{1},//runecraft
			{1},//construction
			
			{0},//hitpoints
			{1},
			{1},
			{1},
			{1},
			{9,24,39,46,54,61,69},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{9,14,19,26,29,32,38,44,50,56,62,67,73,79,85}
			}; 		
		public int[][] itemIds = {
			{1205, 1203, 1207, 1217, 6591, 1209, 1211, 1391, 1213, 11037, 1405, 4153, 10581, 4675, 1215, 10887, 6523, 12426, 11730, 11716, 4151, 4710, 4718, 4747, 4755, 4726, 11700, 12006, 22978, 11944},
			{1337, 1335, 1339, 3196, 6599, 1341, 6613, 3198, 3200, 1343, 3202, 1345, 3204, 1347, 10887, 4153, 6527, 13576, 4718, 4747, 11944},
			{1139, 1137, 1141, 1151, 6621, 13263, 1143, 10822, 5574, 1145, 9672, 1147, 6128, 8839, 3751, 3122, 10828, 1149, 11724, 10350, 4745, 11718, 4224, 13239, 13235, 13237},
			{841, 843, 849, 851, 4827, 855, 861, 6724, 11235, 12424, 4212 ,11946},//range
			{1},
			{1},
			{1},
			{1},
			
			{-1, 6548},//hitpoints
			{1},//agil
			{221, 235, 4840, 225, 592, 10142, 1502, 223, 1550, 1975, 239, 10143, 2152, 9736, 231, 10144, 10145, 221, 235, 231, 2970,10109,225,9016,241,223, 239, 6049, 241, 245, 6016, 3138, 3138, 247, 6051, 6693, 6018, 6018, 12934, 269, 269},//herb
			{1},//theif
			{1},//craft
			{52,882,4773,52,884,4778,52,886,4783,52,888, 4793, 4172,890,52,4798, 52, 892, 4803},//fletching
			{1},//slayer
			{1},//hunter
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{1942, 1957, 1965, 1982, 5986, 5504,5982, 231}
			}; 
		public int[][] SeconditemIds = {
			{8839},
			{8839, 4153, 13239},
			{10551, 10552, 10553, 10555, 10548, 10550, 10547, 10549},
			{864,863,865,869,866,867,868,9976,812,9977,11230,11230,6522,805,12926},//range
			{5574, 9672, 10458, 10464, 8839, 12598, 10446, 10452, 1718, 13734, 10470, 10440, 13736, 13744, 13742},
			{-1},
			{1},
			{1},
			
			{-1, 6548},
			{1},
			{1},
			{1},
			{1},
			{841,839,843,845,4827,849,847,853,851,857,855,861,859},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{6006, 5994, 5996, 5931, 5998, 6000, 6002}
			}; 
		public int[][] ThirditemIds = {
			{1205, 1203, 1207, 1217, 6591, 1209, 1211, 1391, 1213, 11037, 1405, 4153, 10581, 4675, 1215, 10887, 6523, 12426, 11730, 11716, 4151, 4710, 4718, 4747, 4755, 4726, 11700, 12006, 22978, 11944},
			{1337, 1335, 1339, 3196, 6599, 1341, 6613, 3198, 3200, 1343, 3202, 1345, 3204, 1347, 10887, 4153, 6527, 13576, 4718, 4747, 11944},
			{1139, 1137, 1141, 1151, 6621, 13263, 1143, 10822, 5574, 1145, 9672, 1147, 6128, 8839, 3751, 3122, 10828, 1149, 11724, 10350, 4745, 11718, 4224, 13239, 13235, 13237},
			{837, 767, 9174, 9176, 9177, 8880, 9179, 9181, 9183, 2883, 9185, 4734, 14378},//range
			{-1},
			{-1},
			{1},
			{1},
			
			{-1, 6548},
			{1},
			{1},
			{1},
			{1},
			{877, 879, 9139, 9140, 880, 9145, 9141, 9336, 881, 9142, 13280, 9337, 9338, 9143, 9339, 9340, 9144,9341,9342},
			{1},
			{1},
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{1521, 1519, 1517, 1515, 1513}
			}; 
		public int[][] FourthitemIds = {
			{-1},
			{1},
			{1},
			{1129, 1131, 1133, 1097, 1169, 10954, 6322, 10498, 2577, 2581, 6133, 1065, 1099, 1135, 8839, 10499, 2487, 2493, 2499, 10555, 2489, 2495, 2501, 10330, 2491, 2497, 2503, 10370, 11718, 4736, 13237},//range
			{-1},
			{-1},
			{1},
			{1},
			
			{-1, 6548},//hitpoints
			{1},//agil
			{1},//herb
			{1},//theif
			{1},//craft
			{806,807,808,809,810,811},//fletching
			{1},//slayer
			{1},//hunter
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{1955, 1963, 2108, 5970, 2114, 5972, 5974}
			}; 
		public int[][] FifthitemIds = {
			{-1},
			{1},
			{1},
			{8841},//range
			{-1},
			{-1},
			{1},
			{1},
			
			{-1, 6548},//hitpoints
			{1},//agil
			{1},//herb
			{1},//theif
			{1},//craft
			{9174,9176,9177,9179,9181,9183, 9185},//fletching
			{1},//slayer
			{1},//hunter
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{1951, 753, 2126, 247, 239,6018}
			}; 
		public int[][] SixthitemIds = {
			{-1},
			{1},
			{1},
			{8841},//range
			{-1},
			{-1},
			{1},
			{1},
			
			{-1, 6548},//hitpoints
			{1},//agil
			{1},//herb
			{1},//theif
			{1},//craft
			{9174,9176,9177,9179,9181,9183, 9185},//fletching
			{1},//slayer
			{1},//hunter
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{6010, 6014, 6059, 6012, 5738, 225}
			}; 
		public int[][] SeventhitemIds = {
			{-1},
			{1},
			{1},
			{8841},//range
			{-1},
			{-1},
			{1},
			{1},
			
			{-1, 6548},//hitpoints
			{1},//agil
			{1},//herb
			{1},//theif
			{1},//craft
			{9174,9176,9177,9179,9181,9183, 9185},//fletching
			{1},//slayer
			{1},//hunter
			
			{1},
			{1},
			{1},
			{1},
			{1},
			{1},
			{249,251,253,255,3261,257, 2998, 259, 261,263, 3000, 265, 2481, 267, 269}
			}; 
		public void LoadSidebarText(int skillId, int slot) {
			int maxElements = Math.min(SideBarTexts[skillId].length, 13);

			for (int i = 1; i < maxElements; i++) {
				if (SideBarTexts[skillId][i] != null)
					c.getPA().sendFrame126("" + SideBarTexts[skillId][i], 8822 + i);
			}

			if (maxElements >= 0 && slot >= 0) {
				c.getPA().sendFrame126("" + SideBarTexts[skillId][0], 8716); // title
				c.getPA().sendFrame126("" + SideBarTexts[skillId][1], 8720); // subtitle
			}

			c.getPA().showInterface(8714);
		}
		public static int skillid = 0;
		public static boolean open = false;
		public void clearInterface(){
					for(int i = 0; i < 58; i++){
						c.getPA().sendFrame126("" , 8726+i);
						c.getPA().sendFrame126("" , 28836+i);
						c.getPA().sendFrame34a(8724, -1, i, 1);
					}
					for(int i = 0; i < 14; i++){
						c.getPA().sendFrame126("", 8823 + i);
					}
		}
		public void LoadMainInterface(int skillId, int slot, boolean open) {
					c.getPA().sendFrame126("" + SideBarTexts[skillId][0], 8719); // title
					LoadSidebarText(skillId, slot);
					LoadSkillItems(skillId, slot);
					LoadSkillLevels(skillId, slot);
					LoadItemText(skillId, slot);
					skillid = skillId;
					open = open;
					c.getPA().showInterface(8714);
		}
		public void LoadSkillItems(int skillId, int slot) {
			int maxElements = 58;
			if(slot == 0){
				maxElements = Math.min(itemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
					if(skillId == 13)
						c.getPA().sendFrame34a(8724, itemIds[skillId][i], i, 5);
					else
						c.getPA().sendFrame34a(8724, itemIds[skillId][i], i, 1);
				}
			} else if(slot == 1){
				maxElements = Math.min(SeconditemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++)
					c.getPA().sendFrame34a(8724, SeconditemIds[skillId][i], i, 1);
			} else if(slot == 2){
				maxElements = Math.min(ThirditemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
					if(skillId == 13)
						c.getPA().sendFrame34a(8724, ThirditemIds[skillId][i], i, 5);
					else
						c.getPA().sendFrame34a(8724, ThirditemIds[skillId][i], i, 1);
				}
			}  else if(slot == 3){
				maxElements = Math.min(FourthitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, FourthitemIds[skillId][i], i, 1);
				}
			}  else if(slot == 4){
				maxElements = Math.min(FifthitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, FifthitemIds[skillId][i], i, 1);
				}
			}  else if(slot == 5){
				maxElements = Math.min(SixthitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, SixthitemIds[skillId][i], i, 1);
				}
			}   else if(slot == 6){
				maxElements = Math.min(SeventhitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, SeventhitemIds[skillId][i], i, 1);
				}
			}   else if(slot == 7){
				maxElements = Math.min(SeventhitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, SeventhitemIds[skillId][i], i, 1);
				}
			}   else if(slot == 8){
				maxElements = Math.min(SeventhitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, SeventhitemIds[skillId][i], i, 1);
				}
			}   else if(slot == 9){
				maxElements = Math.min(SeventhitemIds[skillId].length, 58);
				for(int i = 0; i < maxElements; i++){
						c.getPA().sendFrame34a(8724, SeventhitemIds[skillId][i], i, 1);
				}
			} 
				c.getPA().sendFrame126("" + SideBarTexts[skillId][slot+1], 8720); // title
		}
		
		public void LoadSkillLevels(int skillId, int slot) {
				int maxElements = 58;
			if(slot == 0){
				maxElements = Math.min(LevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(LevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + LevelTexts[skillId][i], 8726 + i);
						else
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 1){
				maxElements = Math.min(SecondLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SecondLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SecondLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 2){
				maxElements = Math.min(ThirdLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(ThirdLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + ThirdLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 3){
				maxElements = Math.min(FourthLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(FourthLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + FourthLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 4){
				maxElements = Math.min(FifthLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(FifthLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + FifthLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 5){
				maxElements = Math.min(SixthLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SixthLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SixthLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			} else if(slot == 6){
				maxElements = Math.min(SeventhLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SeventhLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SeventhLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			}else if(slot == 7){
				maxElements = Math.min(SeventhLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SeventhLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SeventhLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			}else if(slot == 8){
				maxElements = Math.min(SeventhLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SeventhLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SeventhLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			}else if(slot == 9){
				maxElements = Math.min(SeventhLevelTexts[skillId].length, 58);
				for (int i = 0; i < maxElements; i++) {
						if(SeventhLevelTexts[skillId][i] > 0)
							c.getPA().sendFrame126("" + SeventhLevelTexts[skillId][i], 8726 + i);
						else 
							c.getPA().sendFrame126("", 8726 + i);
				}
			}
		}
		
		public void LoadItemText(int skillId, int slot){
			int maxElements = 58;
			if(slot == 0) {
			maxElements = Math.min(FirstitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + FirstitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 1) {
			maxElements = Math.min(SeconditemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SeconditemTexts[skillId][i], 28836+i); // title
			} else if(slot == 2) {
			maxElements = Math.min(ThirditemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + ThirditemTexts[skillId][i], 28836+i); // title
			} else if(slot == 3) {
			maxElements = Math.min(FourthitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + FourthitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 4) {
			maxElements = Math.min(FifthitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + FifthitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 5) {
			maxElements = Math.min(SixthitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SixthitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 6) {
			maxElements = Math.min(SeventhitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SeventhitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 7) {
			maxElements = Math.min(SeventhitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SeventhitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 8) {
			maxElements = Math.min(SeventhitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SeventhitemTexts[skillId][i], 28836+i); // title
			} else if(slot == 9) {
			maxElements = Math.min(SeventhitemTexts[skillId].length, 58);
			for(int i = 0; i < maxElements; i++)
				c.getPA().sendFrame126("" + SeventhitemTexts[skillId][i], 28836+i); // title
			}
		}
		
		
		
		
		
		
		
		
		
		
	}