package server.model.players.skills;

import server.Server;
import server.model.players.*;
import server.event.*;
import server.Config;
import server.util.Misc;

/**
* Hunter Class
* @author Aintaro
* This class needs a lot of improvement, Lack of time - > no arrays - > bad codes
* Refresh this up to add arrays where needed and shorten codes.
*/

public class Hunter {
	
	Client c;
	
	public Hunter(Client c) {
		this.c = c;
	}
	
	private int implingId;
	
	/**
	* npcid, level Req, item req, exp, itemReward, Amount
	*/
	
	public int[][] implings = {
			{6055, 1, 11259, 155, 11238, 1},
			{6056, 18, 11259, 250, 11240, 1},
			{6057, 34, 11259, 300, 11242, 1},
			{6058, 44, 11259, 370, 11244, 1},
			{6059, 57, 11259, 380, 11246, 1},
			{6060, 66, 11259, 400, 11248, 1},
			{6061, 75, 11259, 466, 11250, 1},
			{6062, 83, 11259, 500, 11252, 1},
			{6063, 87, 11259, 788, 11254, 1},
			{6064, 94, 11259, 900, 11256, 1},
			
	};	public int[][] implingLoot = {
			{6055, 1, 11259, 155, 11238, 1},
			{6056, 18, 11259, 250, 11240, 1},
			{6057, 34, 11259, 300, 11242, 1},
			{6058, 44, 11259, 370, 11244, 1},
			{6059, 57, 11259, 380, 11246, 1},
			{6060, 66, 11259, 400, 11248, 1},
			{6061, 75, 11259, 466, 11250, 1},
			{6062, 83, 11259, 500, 11252, 1},
			{6063, 87, 11259, 788, 11254, 1},
			{6064, 94, 11259, 900, 11256, 1},
			
	};
	private int[][] trapNpc = {
			{10033, 1000},
			{10092, 500},
			{12758, 1520},
			{12760, 1520},
			{10149, 1520},
			{10146, 2240},
			{10034, 3000}
	};
	
	/**
	* I didn't use an array simply to not cause any confusion between the objectIds
	* declared static final because their constant and do not change.
	*/
	
	private static final int TRAP_ITEM = 10008;
	private static final int TRAP_OBJECT = 19187;
	private static final int CATCHED_OBJECT = 19188;
	private static final int SHAKING_OBJECT = 19189;
	
	private static final int TRAP_ITEM2 = 10008;
	private static final int TRAP_OBJECT2 = 19187;
	private static final int CATCHED_OBJECT2 = 19188;
	private static final int SHAKING_OBJECT2 = 19189;
	
	private static final int TRAP_ITEM3 = 10006;
	private static final int TRAP_OBJECT3 = 19174;
	private static final int CATCHED_OBJECT3 = 19188;
	private static final int SHAKING_OBJECT3 = 19189;
	
	private static final int MAX_TRAPS = 5;
	
	/**
	* How many traps has a player set up.
	*/
	
	private int trapSet = 0;
	private int NetTrapSet = 0;
	
	/**
	* trapX and trapY will help us locate where the trap has been set up.
	* Whenever an npc enters this position it will get caught.
	*/
	
	public int trapX, trapY = 0;
	public int trapX2, trapY2 = 0;
	public int trapX3, trapY3 = 0;
	public int trapX4, trapY4 = 0;
	public int trapX5, trapY5 = 0;
	public int netX, netY, netX2, netY2, netX3, netY3, netX4, netY4 = 0;
	public int npcCatch, npcCatch2, npcCatch3, npcCatch4, npcCatch5, NetCatch, NetCatch2, NetCatch3, NetCatch4;
	
	/**
	* Variables for the second hunter box 
	*/
	
	
	
	/**
	* bunch of coords for the implings to respawn
	* they are syncronized - this mean 2340 belongs to 3668 etc.
	*/
	
	private int[] xCoords = {2340, 3086, 3545, 2660, 3422, 2894, 2730, 2706, 2705, 2730, 2761, 2729, 2789, 2752};
	private int[] yCoords = {3668, 3478, 3312, 3700, 3537, 9771, 9643, 9628, 9611, 9641, 9612, 9617, 9651, 9626};
	
	/**
	* First hunter box
	* Creating the object when setting up the trap
	* Checking some things before setting up trap (levels, AMT trapset)
	*/
	
	public void setTrap() {
		if (c.getItems().playerHasItem(TRAP_ITEM, 1)) {
			if (c.playerLevel[22] >= 20) {
				if (trapSet <= 1) {
					if (trapX == 0 && trapY == 0) {
							Server.npcHandler.trapBox = true;
							c.getPA().object(TRAP_OBJECT, c.absX, c.absY, 0, 10);
							c.getItems().deleteItem(TRAP_ITEM, 1);
							trapX = c.absX;
							trapY = c.absY;
							c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							trapSet++;
							c.sendMessage("You set up the box trap.");
					}
				} else {
					c.sendMessage("You can only set up 1 trap.");
				}
			} else {
				c.sendMessage("You need atleast 20 hunter to set up a box trap.");
			}
		}
	}
	/**
	* Second hunter box
	* Creating the object when setting up the trap
	* Checking some things before setting up trap (levels, AMT trapset)
	*/
	
	public void setTrap2() {
		if (c.getItems().playerHasItem(TRAP_ITEM, 1)) {
			if (trapSet <= 2 && c.playerLevel[22] >= 20) {
				if (trapX2 == 0 && trapY2 == 0) {
						Server.npcHandler.trapBox2 = true;
						c.getPA().object(TRAP_OBJECT, c.absX, c.absY, 0, 10);
						c.getItems().deleteItem(TRAP_ITEM, 1);
						trapX2 = c.absX;
						trapY2 = c.absY;
						c.getPA().walkTo(+1,0);
						c.startAnimation(827);
						trapSet++;
						c.sendMessage("You set up the box trap.");
				}
			} else {
				c.sendMessage("You can only set up a max of 2 traps!");
			}
		}
	}
	public void setTrap3() {
		if (c.getItems().playerHasItem(TRAP_ITEM, 1)) {
			if(c.playerLevel[22] >= 40) {	
				if (trapSet <= 3) {					
					if (trapX3 == 0 && trapY3 == 0) {
							Server.npcHandler.trapBox3 = true;
							c.getPA().object(TRAP_OBJECT, c.absX, c.absY, 0, 10);
							c.getItems().deleteItem(TRAP_ITEM, 1);
							trapX3 = c.absX;
							trapY3 = c.absY;
							c.startAnimation(827);
							trapSet++;
							c.sendMessage("You set up the box trap.");
					}
				} else {
					c.sendMessage("You can only set up a max of 3 traps!");
				}
			} else {
				c.sendMessage("You can only set up 3 traps!");
			}	
		}
	}
	public void setTrap4() {
		if (c.getItems().playerHasItem(TRAP_ITEM, 1)) {
				if (trapSet <= 4 && c.playerLevel[22] >= 60) {					
					if (trapX4 == 0 && trapY4 == 0) {
							Server.npcHandler.trapBox4 = true;
							c.getPA().object(TRAP_OBJECT, c.absX, c.absY, 0, 10);
							c.getItems().deleteItem(TRAP_ITEM, 1);
							trapX4 = c.absX;
							trapY4 = c.absY;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							trapSet++;
							c.sendMessage("You set up the box trap.");
					}
				} else {
					c.sendMessage("You can only set up a max of 4 traps!");
				}
		}
	}
	public void setTrap5() {
		if (c.getItems().playerHasItem(TRAP_ITEM, 1)) {
				if (trapSet <= 5 && c.playerLevel[22] >= 80) {					
					if (trapX5 == 0 && trapY5 == 0) {
							Server.npcHandler.trapBox5 = true;
							c.getPA().object(TRAP_OBJECT, c.absX, c.absY, 0, 10);
							c.getItems().deleteItem(TRAP_ITEM, 1);
							trapX5 = c.absX;
							trapY5 = c.absY;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							trapSet++;
							c.sendMessage("You set up the box trap.");
					}
				} else {
					c.sendMessage("You can only set up a max of 5 traps!");
				}
		}
	}
		public void setNetTrap(int objectX, int objectY) {
		if (c.getItems().playerHasItem(303, 1) && c.getItems().playerHasItem(954, 1)) {
			if (c.playerLevel[22] >= 29) {
				if (NetTrapSet != MAX_TRAPS) {
					if (netX == 0 && netY == 0) {
							Server.npcHandler.NetTrap = true;
							c.getPA().object(28563, objectX, objectY, 0, 10);
							c.getPA().object(28566, objectX, objectY+1, 0, 10);
							c.getItems().deleteItem(303, 1);
							c.getItems().deleteItem(954, 1);
							netX = objectX;
							netY = objectY+1;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							NetTrapSet++;
							c.sendMessage("You set up the net trap.");
							c.sendMessage("netX: "+netX+ " netY: "+netY);
					}
				} else {
					c.sendMessage("You have set up a max of 10 traps!");
				}
			} else {
				c.sendMessage("You need atleast 29 hunter to set up a net trap.");
			}
		}
	}
		public void setNetTrap2(int objectX, int objectY) {
		if (c.getItems().playerHasItem(303, 1) && c.getItems().playerHasItem(954, 1)) {
			if (c.playerLevel[22] >= 29) {
				if (NetTrapSet != MAX_TRAPS) {
					if (netX2 == 0 && netY2 == 0) {
							Server.npcHandler.NetTrap2 = true;
							c.getPA().object(28563, objectX, objectY, 0, 10);
							c.getPA().object(28566, objectX, objectY+1, 0, 10);
							c.getItems().deleteItem(303, 1);
							c.getItems().deleteItem(954, 1);
							netX2 = objectX;
							netY2 = objectY+1;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							NetTrapSet++;
							c.sendMessage("You set up the net trap.");
					}
				} else {
					c.sendMessage("You have set up a max of 10 traps!");
				}
			} else {
				c.sendMessage("You need atleast 29 hunter to set up a net trap.");
			}
		}
	}
		public void setNetTrap3(int objectX, int objectY) {
		if (c.getItems().playerHasItem(303, 1) && c.getItems().playerHasItem(954, 1)) {
			if (c.playerLevel[22] >= 29) {
				if (NetTrapSet != MAX_TRAPS) {
					if (netX3 == 0 && netY3 == 0) {
							Server.npcHandler.NetTrap3 = true;
							c.getPA().object(28563, objectX, objectY, 0, 10);
							c.getPA().object(28566, objectX, objectY+1, 0, 10);
							c.getItems().deleteItem(303, 1);
							c.getItems().deleteItem(954, 1);
							netX3 = objectX;
							netY3 = objectY+1;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							NetTrapSet++;
							c.sendMessage("You set up the net trap.");
					}
				} else {
					c.sendMessage("You have set up a max of 10 traps!");
				}
			} else {
				c.sendMessage("You need atleast 29 hunter to set up a net trap.");
			}
		}
	}
		public void setNetTrap4(int objectX, int objectY) {
		if (c.getItems().playerHasItem(303, 1) && c.getItems().playerHasItem(954, 1)) {
			if (c.playerLevel[22] >= 29) {
				if (NetTrapSet != MAX_TRAPS) {
					if (netX4 == 0 && netY4 == 0) {
							Server.npcHandler.NetTrap4 = true;
							c.getPA().object(28563, objectX, objectY, 0, 10);
							c.getPA().object(28566, objectX, objectY+1, 0, 10);
							c.getItems().deleteItem(303, 1);
							c.getItems().deleteItem(954, 1);
							netX4 = objectX;
							netY4 = objectY+1;
						c.getPA().walkTo(+1,0);
							c.startAnimation(827);
							NetTrapSet++;
							c.sendMessage("You set up the net trap.");
					}
				} else {
					c.sendMessage("You have set up a max of 10 traps!");
				}
			} else {
				c.sendMessage("You need atleast 29 hunter to set up a net trap.");
			}
		}
	}
	/**
	* First trap
	* Method used when a player picks up the trap.
	*/
	
	public void removeTrap(int x, int y) {
		if (c.getItems().freeSlots() > 0) {
			if (trapSet > 0) {
				trapX = 0;
				trapY = 0;
				trapSet = 0;
				c.getPA().object(6951, x, y, 0, 10);
				c.startAnimation(827);
				c.getItems().addItem(TRAP_ITEM, 1);
				Server.npcHandler.trapBox = false;
				c.sendMessage("You picked up your box trap");
			} else {
			c.sendMessage("This is not your trap!");
			}
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	/**
	* Picking up your trap by clicking on the object.
	*/
	public void removeTrap2(int x, int y) {
		if (c.getItems().freeSlots() > 0) {
			if (trapSet > 0) {
				trapX2 = 0;
				trapY2 = 0;
				trapSet -= 1;
				c.getPA().object(6951, x, y, 0, 10);
				c.startAnimation(827);
				c.getItems().addItem(TRAP_ITEM, 1);
				Server.npcHandler.trapBox2 = false;
				c.sendMessage("You picked up your box trap");
			} else {
				c.sendMessage("This is not your trap!");
			}
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	/**
	* Picking up your trap by clicking on the object.
	*/
	public void removeTrap3(int x, int y) {
		if (c.getItems().freeSlots() > 0) {
			if (trapSet > 0) {
				trapX3 = 0;
				trapY3 = 0;
				trapSet -= 1;
				c.getPA().object(6951, x, y, 0, 10);
				c.startAnimation(827);
				c.getItems().addItem(TRAP_ITEM, 1);
				Server.npcHandler.trapBox3 = false;
				c.sendMessage("You picked up your box trap");
			} else {
				c.sendMessage("This is not your trap!");
			}
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	public void removeTrap4(int x, int y) {
		if (c.getItems().freeSlots() > 0) {
			if (trapSet > 0) {
				trapX4 = 0;
				trapY4 = 0;
				trapSet -= 1;
				c.getPA().object(6951, x, y, 0, 10);
				c.startAnimation(827);
				c.getItems().addItem(TRAP_ITEM, 1);
				Server.npcHandler.trapBox4 = false;
				c.sendMessage("You picked up your box trap");
			} else {
				c.sendMessage("This is not your trap!");
			}
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	
	public void removeTrap5(int x, int y) {
		if (c.getItems().freeSlots() > 0) {
			if (trapSet > 0) {
				trapX5 = 0;
				trapY5 = 0;
				trapSet = 0;
				c.getPA().object(6951, x, y, 0, 10);
				c.startAnimation(827);
				c.getItems().addItem(TRAP_ITEM, 1);
				Server.npcHandler.trapBox5 = false;
				c.sendMessage("You picked up your box trap");
			} else {
			c.sendMessage("This is not your trap!");
			}
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	public void removeNetTrap(int x, int y) {
		if (c.getItems().freeSlots() > 1 && NetTrapSet > 0) {
			netX = 0;
			netY = 0;
			NetTrapSet -= 1;
			c.getPA().object(28564, x, y, 0, 10);
			c.getPA().object(6951, x, y+1, 0, 10);
			c.startAnimation(827);
			c.getItems().addItem(954, 1);
			c.getItems().addItem(303, 1);
			Server.npcHandler.NetTrap = false;
			c.sendMessage("You dismantle the net trap.");
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	public void removeNetTrap2(int x, int y) {
		if (c.getItems().freeSlots() > 1 && NetTrapSet > 0) {
			netX2 = 0;
			netY2 = 0;
			NetTrapSet -= 1;
			c.getPA().object(28564, x, y, 0, 10);
			c.getPA().object(6951, x, y+1, 0, 10);
			c.startAnimation(827);
			c.getItems().addItem(954, 1);
			c.getItems().addItem(303, 1);
			Server.npcHandler.NetTrap2 = false;
			c.sendMessage("You dismantle the net trap.");
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	public void removeNetTrap3(int x, int y) {
		if (c.getItems().freeSlots() > 1 && NetTrapSet > 0) {
			netX3 = 0;
			netY3 = 0;
			NetTrapSet -= 1;
			c.getPA().object(28564, x, y, 0, 10);
			c.getPA().object(6951, x, y+1, 0, 10);
			c.startAnimation(827);
			c.getItems().addItem(954, 1);
			c.getItems().addItem(303, 1);
			Server.npcHandler.NetTrap3 = false;
			c.sendMessage("You dismantle the net trap.");
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	public void removeNetTrap4(int x, int y) {
		if (c.getItems().freeSlots() > 1 && NetTrapSet > 0) {
			netX4 = 0;
			netY4 = 0;
			NetTrapSet -= 1;
			c.getPA().object(28564, x, y, 0, 10);
			c.getPA().object(6951, x, y+1, 0, 10);
			c.startAnimation(827);
			c.getItems().addItem(954, 1);
			c.getItems().addItem(303, 1);
			Server.npcHandler.NetTrap4 = false;
			c.sendMessage("You dismantle the net trap.");
		} else {
			c.sendMessage("You don't have enough space in your inventory.");
		}
	}
	
	/**
	* Easy made option to investigate the object.
	*/
	
	public void investigate() {
		c.sendMessage("You started investigate your box...");
		EventManager.getSingleton().addEvent(
		new Event() {
			public void execute(EventContainer C) {
				c.sendMessage("It looks empty.");
				C.stop();
			}
		}, 2500); // 5 secs
	}
	
	/**
	* update the box, send the player a message, spawn a new npc.
	*/
	public void catchNormalChin(int npcId) {
		npcCatch = npcId;
		
					CycleEventHandler.getSingleton().addEvent(npcId, new CycleEvent() {
					@Override
						public void execute(CycleEventContainer container) {
							stop();
							container.stop();
						}
						@Override
						public void stop() {
						c.getPA().object(SHAKING_OBJECT, trapX, trapY, 0, 10);
						}
					}, 2);
						c.sendMessage("It looks like you caught something...");
						Server.npcHandler.spawnNpc2(5079, trapX + Misc.random(4), trapY + Misc.random(4), 0, 1, 0, 0, 0, 0);
						c.success = true;
	}
	
	public void catchNormalChin2(int npcId) {
		npcCatch2 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX2, trapY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5079, trapX2 + Misc.random(3), trapY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	public void catchNormalChin3(int npcId) {
		npcCatch3 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX3, trapY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5079, trapX3 + Misc.random(3), trapY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	public void catchNormalChin4(int npcId) {
		npcCatch4 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX4, trapY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5079, trapX4 + Misc.random(3), trapY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	public void catchNormalChin5(int npcId) {
		npcCatch5 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX5, trapY5, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5079, trapX5 + Misc.random(3), trapY5 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success5 = true;
	}
	
	public void catchRedChin(int npcId) {
		npcCatch = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX, trapY, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5080, trapX + Misc.random(3), trapY + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success = true;
	}
	public void catchRedChin2(int npcId) {
		npcCatch2 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX2, trapY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5080, trapX2 + Misc.random(3), trapY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	public void catchRedChin3(int npcId) {
		npcCatch3 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX3, trapY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5080, trapX3 + Misc.random(3), trapY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	public void catchRedChin4(int npcId) {
		npcCatch4 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX4, trapY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5080, trapX4 + Misc.random(3), trapY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	public void catchRedChin5(int npcId) {
		npcCatch5 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX5, trapY5, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5080, trapX5 + Misc.random(3), trapY5 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success5 = true;
	}
	public void catchFerret(int npcId) {
		npcCatch = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX, trapY, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5081, trapX + Misc.random(3), trapY + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success = true;
	}
	public void catchFerret2(int npcId) {
		npcCatch2 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX2, trapY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5081, trapX2 + Misc.random(3), trapY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	public void catchFerret3(int npcId) {
		npcCatch3 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX3, trapY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5081, trapX3 + Misc.random(3), trapY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	public void catchFerret4(int npcId) {
		npcCatch4 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX4, trapY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5081, trapX4 + Misc.random(3), trapY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	public void catchFerret5(int npcId) {
		npcCatch5 = npcId;
		c.getPA().object(SHAKING_OBJECT, trapX5, trapY5, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5081, trapX5 + Misc.random(3), trapY5 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success5 = true;
	}
	public void catchSquirrel(int npcId) {
		NetCatch = npcId;
		c.getPA().object(19654, netX, netY-1, 0, 10);
		c.getPA().object(6951, netX, netY, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(7311, netX + Misc.random(3), netY + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success = true;
	}
	public void catchSquirrel2(int npcId) {
		NetCatch2 = npcId;
		c.getPA().object(19654, netX2, netY2, 0, 10);
		c.getPA().object(6951, netX2, netY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(7311, netX2 + Misc.random(3), netY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	
	public void catchSquirrel3(int npcId) {
		NetCatch3 = npcId;
		c.getPA().object(19654, netX3, netY3-1, 0, 10);
		c.getPA().object(6951, netX3, netY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(7311, netX3 + Misc.random(3), netY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	public void catchSquirrel4(int npcId) {
		NetCatch4 = npcId;
		c.getPA().object(19654, netX, netY4-1, 0, 10);
		c.getPA().object(6951, netX4, netY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(7311, netX4 + Misc.random(3), netY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	public void catchSWLizard(int npcId) {
		NetCatch = npcId;
		c.getPA().object(19654, netX, netY-1, 0, 10);
		c.getPA().object(6951, netX, netY, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5117, netX + Misc.random(3), netY + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success = true;
	}
	public void catchSWLizard2(int npcId) {
		NetCatch2 = npcId;
		c.getPA().object(19654, netX2, netY2-1, 0, 10);
		c.getPA().object(6951, netX2, netY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5117, netX2 + Misc.random(3), netY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	public void catchSWLizard3(int npcId) {
		NetCatch3 = npcId;
		c.getPA().object(19654, netX3, netY3-1, 0, 10);
		c.getPA().object(6951, netX3, netY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5117, netX3 + Misc.random(3), netY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	public void catchSWLizard4(int npcId) {
		NetCatch4 = npcId;
		c.getPA().object(19654, netX4, netY4-1, 0, 10);
		c.getPA().object(6951, netX4, netY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5117, netX4 + Misc.random(3), netY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	public void catchORLizard(int npcId) {
		NetCatch = npcId;
		c.getPA().object(19654, netX, netY-1, 0, 10);
		c.getPA().object(6951, netX, netY, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5114, netX + Misc.random(3), netY + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success = true;
	}
	public void catchORLizard2(int npcId) {
		NetCatch2 = npcId;
		c.getPA().object(19654, netX2, netY2-1, 0, 10);
		c.getPA().object(6951, netX2, netY2, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5114, netX2 + Misc.random(3), netY2 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success2 = true;
	}
	
	public void catchORLizard3(int npcId) {
		NetCatch3 = npcId;
		c.getPA().object(19654, netX3, netY3-1, 0, 10);
		c.getPA().object(6951, netX3, netY3, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5114, netX3 + Misc.random(3), netY3 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success3 = true;
	}
	
	public void catchORLizard4(int npcId) {
		NetCatch4 = npcId;
		c.getPA().object(19654, netX4, netY4-1, 0, 10);
		c.getPA().object(6951, netX4, netY4, 0, 10);
		c.sendMessage("It looks like you caught something...");
		Server.npcHandler.spawnNpc2(5114, netX4 + Misc.random(3), netY4 + Misc.random(4), 0, 1, 0, 0, 0, 0);
		c.success4 = true;
	}
	
	/**
	* First trap
	* Click on the loot shaking object, reset variables.
	*/
	
	public void lootAnimal() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == npcCatch) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(6951, trapX, trapY, 0, 10);
				trapX = 0;
				trapY = 0;
			c.startAnimation(827);
				c.getItems().addItem(LOOT[0], 1);
				c.getItems().addItem(TRAP_ITEM, 1);
				c.success = false;
				npcCatch = 0;
				trapSet -= 1;
				Server.npcHandler.trapBox = false;
				//writeHunter();
				break;
			}
		}
	}

	/**
	* Second trap
	* Click on the loot shaking object, reset variables.
	*/
	
	public void lootAnimal2() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == npcCatch2) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(6951, trapX2, trapY2, 0, 10);
				trapX2 = 0;
				trapY2 = 0;
			c.startAnimation(827);
				c.getItems().addItem(LOOT[0], 1);
				c.getItems().addItem(TRAP_ITEM, 1);
				c.success2 = false;
				npcCatch2 = 0;
				trapSet -= 1;
				Server.npcHandler.trapBox2 = false;
				//writeHunter();
				break;
			}
		}
	}
	/**
	* Third trap
	* Click on the loot shaking object, reset variables.
	*/
	
	public void lootAnimal3() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == npcCatch3) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(6951, trapX3, trapY3, 0, 10);
				trapX3 = 0;
				trapY3 = 0;
			c.startAnimation(827);
				c.getItems().addItem(LOOT[0], 1);
				c.getItems().addItem(TRAP_ITEM, 1);
				c.success3 = false;
				npcCatch3 = 0;
				trapSet -= 1;
				Server.npcHandler.trapBox3 = false;
				//writeHunter();
				break;
			}
		}
	}
	
	/**
	* fourth trap
	* Click on the loot shaking object, reset variables.
	*/
	public void lootAnimal4() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == npcCatch4) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(6951, trapX4, trapY4, 0, 10);
				trapX4 = 0;
				trapY4 = 0;
				c.startAnimation(827);
				c.getItems().addItem(LOOT[0], 1);
				c.getItems().addItem(TRAP_ITEM, 1);
				c.success4 = false;
				npcCatch4 = 0;
				trapSet -= 1;
				Server.npcHandler.trapBox4 = false;
				//writeHunter();
				break;
			}
		}
	}
	
	/**
	* Fifth trap
	* Click on the loot shaking object, reset variables.
	*/
	
	public void lootAnimal5() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == npcCatch) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(6951, trapX5, trapY5, 0, 10);
				trapX5 = 0;
				trapY5 = 0;
			c.startAnimation(827);
				c.getItems().addItem(LOOT[0], 1);
				c.getItems().addItem(TRAP_ITEM, 1);
				c.success5 = false;
				npcCatch5 = 0;
				trapSet -= 1;
				Server.npcHandler.trapBox5 = false;
				//writeHunter();
				break;
			}
		}
	}
	public void lootNet() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == NetCatch) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(28564, netX, netY-1, 0, 10);
				c.getPA().object(6951, netX, netY, 0, 10);
				netX = 0;
				netY = 0;
				c.getItems().addItem(LOOT[0], 1);
				c.startAnimation(827);
				c.getItems().addItem(954, 1);
				c.getItems().addItem(303, 1);
				c.success = false;
				NetCatch = 0;
				NetTrapSet -= 1;
				Server.npcHandler.NetTrap = false;
				//writeHunter();
				break;
			}
		}
	}
	public void lootNet2() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == NetCatch2) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(28564, netX2, netY2-1, 0, 10);
				c.getPA().object(6951, netX2, netY2, 0, 10);
				netX2 = 0;
				netY2 = 0;
				c.getItems().addItem(LOOT[0], 1);
				c.startAnimation(827);
				c.getItems().addItem(954, 1);
				c.getItems().addItem(303, 1);
				c.success = false;
				NetCatch2 = 0;
				NetTrapSet -= 1;
				Server.npcHandler.NetTrap2 = false;
				//writeHunter();
				break;
			}
		}
	}
	public void lootNet3() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == NetCatch3) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(28564, netX3, netY3-1, 0, 10);
				c.getPA().object(6951, netX3, netY3, 0, 10);
				netX3 = 0;
				netY3 = 0;
				c.getItems().addItem(LOOT[0], 1);
				c.startAnimation(827);
				c.getItems().addItem(954, 1);
				c.getItems().addItem(303, 1);
				c.success = false;
				NetCatch3 = 0;
				NetTrapSet -= 1;
				Server.npcHandler.NetTrap3 = false;
				//writeHunter();
				break;
			}
		}
	}
	public void lootNet4() {
		for (int[] LOOT : trapNpc) {
			if (LOOT[0] == NetCatch4) {
				c.getPA().addSkillXP(LOOT[1], 22);
				c.getPA().object(28564, netX4, netY4-1, 0, 10);
				c.getPA().object(6951, netX4, netY4, 0, 10);
				netX4 = 0;
				netY4 = 0;
				c.getItems().addItem(LOOT[0], 1);
				c.startAnimation(827);
				c.getItems().addItem(954, 1);
				c.getItems().addItem(303, 1);
				c.success = false;
				NetCatch4 = 0;
				NetTrapSet -= 1;
				Server.npcHandler.NetTrap4 = false;
				//writeHunter();
				break;
			}
		}
	}
	
	/**
	*	 Huntertext method, simply easier for use.
	*/
	
	private void hunterText(String text, int frameId) {
		c.getPA().sendFrame126(text, frameId);
	}
	
	/**
	* Things put in the quest tab.
	*/
	
	public void writeHunter() {
		hunterText("@blu@Go to Hunter Area", 19520);
		hunterText("Hunter Lvl : @gre@" + c.playerLevel[23], 19521);
		hunterText("Hunter Exp : @gre@" + c.playerXP[23], 19522);
		hunterText("Next level at : @gre@" + c.getPA().getXPForLevel(c.getPA().getLevelForXP(c.playerXP[23]) + 1), 19523);
		hunterText("@whi@Impling Catches : " + c.implingCatches, 19524);
	}
	
	/**
	* Guide
	* Status : unfinished
	*/
	
	public void hunterGuide() {
		c.getPA().showInterface(8134);
	}
	
	/**
	* This removes the npc and do some checks.
	*/
	
	public void catchImpling(int npcId) {
		for (int[] CATCH : implings) {
			if (npcId == CATCH[0]) {
				if (c.playerEquipment[c.playerWeapon] == CATCH[2]) {
					if (c.playerLevel[22] >= CATCH[1]) {
					try {
						implingId = npcId;
						c.getItems().addItem(CATCH[4], CATCH[5]);
						c.getPA().addSkillXP(CATCH[3], 22);
						c.startAnimation(2066);
						//writeHunter();
						Server.npcHandler.dismissImpling(c, npcId);
						respawnImpling(npcId);
						c.implingCatches += 1;
						c.sendMessage("Impling Caught");
						break;
					} catch(Exception e) {
					
						}
					} else {
						c.sendMessage("You need " + CATCH[1] + " hunter to catch this impling.");
						break;
					}
				} else {
					c.sendMessage("You have to equip a butterfly net before you can catch it !");
					break;
				}
			} 
		}
	}
	public void catchImpling1(int npcId) {
		for (int[] CATCH : implings) {
			if (npcId == CATCH[0]) {
				if (c.playerEquipment[c.playerWeapon] == CATCH[2]) {
					if (c.playerLevel[22] >= CATCH[1]) {
					try {
						implingId = npcId;
						c.getItems().addItem(CATCH[4], CATCH[5]);
						c.getPA().addSkillXP(CATCH[3], 22);
						c.startAnimation(2066);
						//writeHunter();
						Server.npcHandler.dismissImpling(c, npcId);
						respawnImpling1(npcId);
						c.implingCatches += 1;
						c.sendMessage("Impling Caught");
						break;
					} catch(Exception e) {
					
						}
					} else {
						c.sendMessage("You need " + CATCH[1] + " hunter to catch this impling.");
						break;
					}
				} else {
					c.sendMessage("You have to equip a butterfly net before you can catch it !");
					break;
				}
			} 
		}
	}
	
	/**
	* Respawn Implings method, random coords.
	*/
	
	private void respawnImpling(final int i) {
	final int xCoord;
	final int yCoord;
	int randomNumber = Misc.random(xCoords.length-1);
	xCoord = xCoords[randomNumber];
	yCoord = yCoords[randomNumber];
			EventManager.getSingleton().addEvent(
			new Event() {
				public void execute(EventContainer C) {
					Server.npcHandler.spawnNpc2(implingId, xCoord, yCoord, 0, 1, 300, 40, 300, 300);
					C.stop();
				}
			}, 2500); // 5 secs
	}
	public final int EdgexCoord = 3102;
	public final int EdgeyCoord = 3503;
	private void respawnImpling1(final int i) {
			EventManager.getSingleton().addEvent(
			new Event() {
				public void execute(EventContainer C) {
					Server.npcHandler.spawnNpc2(implingId, EdgexCoord+Misc.random(5), EdgeyCoord+Misc.random(3), 0, 1, 300, 40, 300, 300);
					C.stop();
				}
			}, 2500); // 5 secs
	}
}