package server.model.players;

import server.Config;
import server.Server;
import server.model.npcs.NPCHandler;
import server.model.npcs.NPC;
import server.util.Misc;
import server.event.Event;
import server.model.players.Music;
import server.model.players.skills.Skill;
import server.clip.*;
import server.world.TileControl;
import server.clip.PathFinder;
import server.model.objects.Object;
import server.model.objects.Objects;
import server.event.EventContainer;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;
import java.text.DecimalFormat;
import server.model.items.Item;
import server.model.items.ItemDefinition;
import server.model.items.ItemData;
import server.world.Boundary;
import java.util.Arrays;
import server.event.Events;
import server.event.EventHandler;

public class PlayerAssistant {

	private Client c;

	public PlayerAssistant(Client Client) {
		this.c = Client;
	}

	public int CraftInt, Dcolor, FletchInt;

	/**
	 * MulitCombat icon
	 * 
	 * @param i1
	 *            0 = off 1 = on
	 */
	public void multiWay(int i1) {
		// synchronized(c) {
		c.outStream.createFrame(61);
		c.outStream.writeByte(i1);
		c.updateRequired = true;
		c.setAppearanceUpdateRequired(true);
	}

	/*
	 * Vengeance
	 */
	public void castVeng() {
		if (c.playerLevel[6] < 94) {
			c.sendMessage("You need a magic level of 94 to cast this spell.");
			return;
		}
		if (c.playerLevel[1] < 40) {
			c.sendMessage("You need a defence level of 40 to cast this spell.");
			return;
		}
		if (!c.getItems().playerHasItem(9075, 4)
				|| !c.getItems().playerHasItem(557, 10)
				|| !c.getItems().playerHasItem(560, 2)) {
			c.sendMessage("You don't have the required runes to cast this spell.");
			return;
		}
		if (System.currentTimeMillis() - c.lastCast < 30000) {
			c.sendMessage("You can only cast vengeance every 30 seconds.");
			return;
		}
		if (c.vengOn) {
			c.sendMessage("You already have vengeance casted.");
			return;
		}
		//c.startAnimation(905);
		//c.gfx100(666);// Just use c.gfx100
		c.getItems().deleteItem2(9075, 4);
		c.getItems().deleteItem2(557, 10);// For these you need to change to
											// deleteItem(item, itemslot,
											// amount);.
		c.getItems().deleteItem2(560, 2);
		addSkillXP(112, 6);
		refreshSkill(6);
		c.vengOn = true;
		c.lastCast = System.currentTimeMillis();
	}

	public void clearClanChat() {
		c.clanId = -1;
		c.getPA().sendFrame126("Talking in: ", 18139);
		c.getPA().sendFrame126("Owner: ", 18140);
		for (int j = 18144; j < 18244; j++)
			c.getPA().sendFrame126("", j);
	}

	public void resetAutocast() {
		c.autocastId = 0;
		c.autocasting = false;
		c.getPA().sendFrame36(108, 0);
	}

	public void sendSong(int id) {
		if (c.getOutStream() != null && c != null && id != -1) {
			c.getOutStream().createFrame(74);
			c.getOutStream().writeWordBigEndian(id);
			c.flushOutStream();
		}
	}
			

			
	public void musicManager(String action, int songID) {
		if (c.getOutStream() != null && c != null) {
		if (action == "PLAY") {
			c.getOutStream().createFrame(74);
			c.getOutStream().writeWordBigEndian(songID);
			c.flushOutStream();
		}
		if (action == "STOP") {
			c.getOutStream().createFrame(74);
			c.getOutStream().writeWordBigEndian(65535);
			c.flushOutStream();
		}
				c.updateRequired = true;
				c.getPA().requestUpdates();
		}
	}
	public void sendQuickSong(int id, int songDelay) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(121);
			c.getOutStream().writeWordBigEndian(id);
			c.getOutStream().writeWordBigEndian(songDelay);
			c.flushOutStream();
		}
	}
	public void sendSound(int id, int delay, int volume) {
		sendSound(id, 0, delay, volume);
		}
	public void sendAreaSound(int id, int delay, int volume) {
		sendSoundArea(id, 0, delay, volume);
		}
	public void sendSound(int id, int type, int delay, int volume) {
		if(c.getOutStream() != null && c != null && id != -1) {
			c.getOutStream().createFrame(174);
			c.getOutStream().writeWord(id);
			c.getOutStream().writeByte(type);
			c.getOutStream().writeWord(delay);
			c.getOutStream().writeWord(volume);
			c.flushOutStream();
		}
	}
	public void sendSoundArea(int id, int type, int delay, int volume) {
		if(c.getOutStream() != null && c != null && id != -1) {
			c.getOutStream().createFrame(179);
			c.getOutStream().writeWord(id);
			c.getOutStream().writeByte(type);
			c.getOutStream().writeWord(delay);
			c.getOutStream().writeWord(volume);
			c.flushOutStream();
		}
	}
	public void sendFrame126(String s, int id) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrameVarSizeWord(126);
			c.getOutStream().writeString(s);
			c.getOutStream().writeWordA(id);
			c.getOutStream().endFrameVarSizeWord();
			c.flushOutStream();
		}
	}

	public void sendLink(String s) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrameVarSizeWord(187);
			c.getOutStream().writeString(s);
		}
	}

	public void setSkillLevel(int skillNum, int currentLevel, int XP) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(134);
			c.getOutStream().writeByte(skillNum);
			c.getOutStream().writeDWord_v1(XP);
			c.getOutStream().writeByte(currentLevel);
			c.flushOutStream();
		}
	}

	public void sendFrame106(int sideIcon) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(106);
			c.getOutStream().writeByteC(sideIcon);
			c.flushOutStream();
			requestUpdates();
		}
	}

	public void sendFrame107() {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(107);
			c.flushOutStream();
		}
	}

	public void sendFrame178(int id, int state) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(178);
			c.getOutStream().writeWord(id);
			c.getOutStream().writeWord(state);
			c.flushOutStream();
		}
	}

	public void sendConfig(int id, int value) {
		if (c.getOutStream() != null && c != null) {
			if (value < Byte.MIN_VALUE || value > Byte.MAX_VALUE) {
				c.getOutStream().createFrame(87);
				c.getOutStream().writeWordBigEndian_dup(id);
				c.getOutStream().writeDWord_v1(value);
			c.flushOutStream();
			} else {
				c.getOutStream().createFrame(36);
				c.getOutStream().writeWordBigEndian(id);
				c.getOutStream().writeByte(value);
			c.flushOutStream();
			}
			System.out.println("ID: " + id + " Value: " + value);
		}
	}
	public void sendFrame36(int id, int state) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(36);
			c.getOutStream().writeWordBigEndian(id);
			c.getOutStream().writeByte(state);
			c.flushOutStream();
		}
	}
	public void sendFrame185(int Frame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(185);
			c.getOutStream().writeWordBigEndianA(Frame);
		}
	}

	public void showInterface(int interfaceid) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(97);
			c.getOutStream().writeWord(interfaceid);
			c.flushOutStream();
		}
	}

	public void sendFrame248(int MainFrame, int SubFrame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(248);
			c.getOutStream().writeWordA(MainFrame);
			c.getOutStream().writeWord(SubFrame);
			c.flushOutStream();
		}
	}

	public void sendFrame246(int MainFrame, int SubFrame, int SubFrame2) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(246);
			c.getOutStream().writeWordBigEndian(MainFrame);
			c.getOutStream().writeWord(SubFrame);
			c.getOutStream().writeWord(SubFrame2);
			c.flushOutStream();
		}
	}

	public void sendFrame171(int MainFrame, int SubFrame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(171);
			c.getOutStream().writeByte(MainFrame);
			c.getOutStream().writeWord(SubFrame);
			c.flushOutStream();
		}
	}
	public void setInterfaceVisible(int interfaceId, boolean visible) {
		c.outStream.createFrame(171);
		c.outStream.writeByte(visible ? 1 : 0);
		c.outStream.writeWord(interfaceId);
	}
	public void sendFrame200(int MainFrame, int SubFrame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(200);
			c.getOutStream().writeWord(MainFrame);
			c.getOutStream().writeWord(SubFrame);
			c.flushOutStream();
		}
	}

	public void sendFrame70(int i, int o, int id) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(70);
			c.getOutStream().writeWord(i);
			c.getOutStream().writeWordBigEndian(o);
			c.getOutStream().writeWordBigEndian(id);
			c.flushOutStream();
		}
	}

	public void sendFrame75(int MainFrame, int SubFrame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(75);
			c.getOutStream().writeWordBigEndianA(MainFrame);
			c.getOutStream().writeWordBigEndianA(SubFrame);
			c.flushOutStream();
		}
	}

	public void sendFrame164(int Frame) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(164);
			c.getOutStream().writeWordBigEndian_dup(Frame);
			c.flushOutStream();
		}
	}

	public void setPrivateMessaging(int i) { // friends and ignore list status
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(221);
			c.getOutStream().writeByte(i);
			c.flushOutStream();
		}
	}

	public void setChatOptions(int publicChat, int privateChat, int tradeBlock) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(206);
			c.getOutStream().writeByte(publicChat);
			c.getOutStream().writeByte(privateChat);
			c.getOutStream().writeByte(tradeBlock);
			c.flushOutStream();
		}
	}

	public void sendFrame87(int id, int state) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(87);
			c.getOutStream().writeWordBigEndian_dup(id);
			c.getOutStream().writeDWord_v1(state);
			c.flushOutStream();
		}
	}

	public void sendPM(long name, int rights, byte[] chatmessage,
			int messagesize) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrameVarSize(196);
			c.getOutStream().writeQWord(name);
			c.getOutStream().writeDWord(c.lastChatId++);
			c.getOutStream().writeByte(rights);
			c.getOutStream().writeBytes(chatmessage, messagesize, 0);
			c.getOutStream().endFrameVarSize();
			c.flushOutStream();
			Misc.textUnpack(chatmessage, messagesize);
			Misc.longToPlayerName(name);
		}
	}

	/**
	 * Flashes Sidebar Icon
	 */

	public void flashSideBarIcon(int i1) {
		// Makes the sidebar Icons flash
		// Usage: i1 = 0 through -12 inorder to work
		if (c.getOutStream() != null) {
			c.outStream.createFrame(24);
			c.outStream.writeByteA(i1);
		}
		c.updateRequired = true;
		c.setAppearanceUpdateRequired(true);
	}
	public void createPlayerHints(int type, int id) {
		if (c.getOutStream() == null) return;
		if (c != null) {
			c.getOutStream().createFrame(254);
			c.getOutStream().writeByte(type);
			c.getOutStream().writeWord(id);
			c.getOutStream().write3Byte(0);
			c.flushOutStream();
		}
	}

	public void createObjectHints(int x, int y, int height, int pos) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(254);
			c.getOutStream().writeByte(pos);
			c.getOutStream().writeWord(x);
			c.getOutStream().writeWord(y);
			c.getOutStream().writeByte(height);
			c.flushOutStream();
		}
	}

	public void loadPM(long playerName, int world) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			if (world != 0) {
				world += 9;
			} else if (!Config.WORLD_LIST_FIX) {
				world += 1;
			}
			c.getOutStream().createFrame(50);
			c.getOutStream().writeQWord(playerName);
			c.getOutStream().writeByte(world);
			c.flushOutStream();
		}
	}

	public void removeAllWindows() {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getPA().resetVariables();
			c.getOutStream().createFrame(219);
			c.flushOutStream();
		}
	}

	public void closeAllWindows() {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(219);
			c.flushOutStream();
		}
	}

	public void sendFrame34(int id, int slot, int column, int amount) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.outStream.createFrameVarSizeWord(34); // init item to smith
													// screen
			c.outStream.writeWord(column); // Column Across Smith Screen
			c.outStream.writeByte(4); // Total Rows?
			c.outStream.writeDWord(slot); // Row Down The Smith Screen
			c.outStream.writeWord(id + 1); // item
			c.outStream.writeByte(amount); // how many there are?
			c.outStream.endFrameVarSizeWord();
		}
	}
	
	public void sendFrame34a(int frame, int item, int slot, int amount) {
		c.outStream.createFrameVarSizeWord(34);
		c.outStream.writeWord(frame);
		c.outStream.writeByte(slot);
		c.outStream.writeWord(item + 1);
		c.outStream.writeByte(255);
		c.outStream.writeDWord(amount);
		c.outStream.endFrameVarSizeWord();
	}
	public void walkableInterface(int id) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(208);
			c.getOutStream().writeWordBigEndian_dup(id);
			c.flushOutStream();
		}
	}	
	public void walkableInterface2(int id) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(209);
			c.getOutStream().writeWordBigEndian_dup(id);
			c.flushOutStream();
		}
	}

	public int mapStatus = 0;

	public void sendFrame99(int state) { // used for disabling map
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			if (mapStatus != state) {
				mapStatus = state;
				c.getOutStream().createFrame(99);
				c.getOutStream().writeByte(state);
				c.flushOutStream();
			}
		}
	}

	public void sendCrashFrame() { // used for crashing cheat clients
			synchronized(c) {
				if (c.getOutStream() != null && c != null) {
					c.getOutStream().createFrame(123);
					c.flushOutStream();
				}
			 }
	}

	/**
	 * Reseting animations for everyone
	 **/

	public void frame1() {
		// synchronized(c) {
		for (int i = 0; i < Config.MAX_PLAYERS; i++) {
			if (PlayerHandler.players[i] != null) {
				Client person = (Client) PlayerHandler.players[i];
				if (person != null) {
					if (person.getOutStream() != null && !person.disconnected) {
						if (c.distanceToPoint(person.getX(), person.getY()) <= 25) {
							person.getOutStream().createFrame(1);
							person.flushOutStream();
							person.getPA().requestUpdates();
						}
					}
				}
			}
		}
	}

	/**
	 * Creating projectile
	 **/
	public void createProjectile(int x, int y, int offX, int offY, int angle,
			int speed, int gfxMoving, int startHeight, int endHeight,
			int lockon, int time) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(85);
			c.getOutStream().writeByteC((y - (c.getMapRegionY() * 8)) - 2);
			c.getOutStream().writeByteC((x - (c.getMapRegionX() * 8)) - 3);
			c.getOutStream().createFrame(117);
			c.getOutStream().writeByte(angle);
			c.getOutStream().writeByte(offY);
			c.getOutStream().writeByte(offX);
			c.getOutStream().writeWord(lockon);
			c.getOutStream().writeWord(gfxMoving);
			c.getOutStream().writeByte(startHeight);
			c.getOutStream().writeByte(endHeight);
			c.getOutStream().writeWord(time);
			c.getOutStream().writeWord(speed);
			c.getOutStream().writeByte(16);
			c.getOutStream().writeByte(64);
			c.flushOutStream();
		}
	}
	public void createProjectile2(int x, int y, int offX, int offY, int angle,
			int speed, int gfxMoving, int startHeight, int endHeight,
			int lockon, int time, int slope) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(85);
			c.getOutStream().writeByteC((y - (c.getMapRegionY() * 8)) - 2);
			c.getOutStream().writeByteC((x - (c.getMapRegionX() * 8)) - 3);
			c.getOutStream().createFrame(117);
			c.getOutStream().writeByte(angle);
			c.getOutStream().writeByte(offY);
			c.getOutStream().writeByte(offX);
			c.getOutStream().writeWord(lockon);
			c.getOutStream().writeWord(gfxMoving);
			c.getOutStream().writeByte(startHeight);
			c.getOutStream().writeByte(endHeight);
			c.getOutStream().writeWord(time);
			c.getOutStream().writeWord(speed);
			c.getOutStream().writeByte(slope);
			c.getOutStream().writeByte(64);
			c.flushOutStream();
		}
	}

	// projectiles for everyone within 25 squares
	public void createPlayersProjectile(int x, int y, int offX, int offY,
			int angle, int speed, int gfxMoving, int startHeight,
			int endHeight, int lockon, int time) {
		// synchronized(c) {
		for (int i = 0; i < Config.MAX_PLAYERS; i++) {
			Player p = PlayerHandler.players[i];
			if (p != null) {
				Client person = (Client) p;
				if (person != null) {
					if (person.getOutStream() != null) {
						if (person.distanceToPoint(x, y) <= 25) {
							if (p.heightLevel == c.heightLevel)
								person.getPA().createProjectile(x, y, offX,
										offY, angle, speed, gfxMoving,
										startHeight, endHeight, lockon, time);
						}
					}
				}
			}
		}
	}

	public void createPlayersProjectile2(int x, int y, int offX, int offY,
			int angle, int speed, int gfxMoving, int startHeight,
			int endHeight, int lockon, int time, int slope) {
		// synchronized(c) {
		for (int i = 0; i < Config.MAX_PLAYERS; i++) {
			Player p = PlayerHandler.players[i];
			if (p != null) {
				Client person = (Client) p;
				if (person != null) {
					if (person.getOutStream() != null) {
						if (person.distanceToPoint(x, y) <= 25) {
							person.getPA().createProjectile2(x, y, offX, offY,
									angle, speed, gfxMoving, startHeight,
									endHeight, lockon, time, slope);
						}
					}
				}
			}
		}
	}

	/**
	 ** GFX
	 **/
	public void stillGfx(int id, int x, int y, int height, int time) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(85);
			c.getOutStream().writeByteC(y - (c.getMapRegionY() * 8));
			c.getOutStream().writeByteC(x - (c.getMapRegionX() * 8));
			c.getOutStream().createFrame(4);
			c.getOutStream().writeByte(0);
			c.getOutStream().writeWord(id);
			c.getOutStream().writeByte(height);
			c.getOutStream().writeWord(time);
			c.flushOutStream();
		}
	}

	// creates gfx for everyone
	public void createPlayersStillGfx(int id, int x, int y, int height, int time) {
		// synchronized(c) {
		for (int i = 0; i < Config.MAX_PLAYERS; i++) {
			Player p = PlayerHandler.players[i];
			if (p != null) {
				Client person = (Client) p;
				if (person != null) {
					if (person.getOutStream() != null) {
						if (person.distanceToPoint(x, y) <= 25) {
							person.getPA().stillGfx(id, x, y, height, time);
						}
					}
				}
			}
		}
	}

	/**
	 * Objects, add and remove
	 **/
	public void object(int objectId, int objectX, int objectY, int face,
			int objectType) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(85);
			c.getOutStream().writeByteC(objectY - (c.getMapRegionY() * 8));
			c.getOutStream().writeByteC(objectX - (c.getMapRegionX() * 8));
			c.getOutStream().createFrame(101);
			c.getOutStream().writeByteC((objectType << 2) + (face & 3));
			c.getOutStream().writeByte(0);

			if (objectId != -1) { // removing
				c.getOutStream().createFrame(151);
				c.getOutStream().writeByteS(0);
				c.getOutStream().writeWordBigEndian(objectId);
				c.getOutStream().writeByteS((objectType << 2) + (face & 3));
			}
			c.flushOutStream();
		}
	}

	public void checkObjectSpawn(int objectId, int objectX, int objectY,
			int face, int objectType) {
		if (c.distanceToPoint(objectX, objectY) > 60)
			return;
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			c.getOutStream().createFrame(85);
			c.getOutStream().writeByteC(objectY - (c.getMapRegionY() * 8));
			c.getOutStream().writeByteC(objectX - (c.getMapRegionX() * 8));
			c.getOutStream().createFrame(101);
			c.getOutStream().writeByteC((objectType << 2) + (face & 3));
			c.getOutStream().writeByte(0);

			if (objectId != -1) { // removing
				c.getOutStream().createFrame(151);
				c.getOutStream().writeByteS(0);
				c.getOutStream().writeWordBigEndian(objectId);
				c.getOutStream().writeByteS((objectType << 2) + (face & 3));
			}
			c.flushOutStream();
		}
	}

	/**
	 * Show option, attack, trade, follow etc
	 **/
	public String optionType = "null";

	public void showOption(int i, int l, String s, int a) {
		// synchronized(c) {
		if (c.getOutStream() != null && c != null) {
			if (!optionType.equalsIgnoreCase(s)) {
				optionType = s;
				c.getOutStream().createFrameVarSize(104);
				c.getOutStream().writeByteC(i);
				c.getOutStream().writeByteA(l);
				c.getOutStream().writeString(s);
				c.getOutStream().endFrameVarSize();
				c.flushOutStream();
			}
		}
	}

	/**
	 * Open bank
	 **/
	public void openUpBank(int tab) {
		if (c.isBanking = false) {
			closeAllWindows();
			return;
		}
			if (c.takeAsNote)
				sendFrame36(115, 1);
			else
				sendFrame36(115, 0);
		// synchronized(c) {
		if (!Boundary.isIn(c, Boundary.BANK_AREA) && c.playerRights < 3) {
			c.sendMessage("You can't open a bank unless you're in a bank area!");
			c.sendMessage("If this is a bug, please report it! Your coords are [" + c.absX + "," + c.absY + "]");
			closeAllWindows();
			return;
		}
		if (c.absX == 2813 && c.absY == 3443) {
			return;
		}
		if (c.inTrade || c.tradeStatus == 1) {
			Client o = (Client) PlayerHandler.players[c.tradeWith];
			if (o != null) {
				o.getTradeAndDuel().declineTrade();
			}
		}
		if (c.duelStatus == 1) {
			Client o = (Client) PlayerHandler.players[c.duelingWith];
			if (o != null) {
				o.getTradeAndDuel().resetDuel();
			}
		}
		if (c.getOutStream() != null && c != null)
			{
				c.isBanking = true;
				c.bankingTab = tab;
				sendTabs();
				c.getPA().sendFrame126(Integer.toString(getBankItems(-1)), 21026);//Send total Bank Items
				c.getPA().sendFrame126(Integer.toString(Config.BANK_SIZE), 21025);//Send max Bank Items - 496
				

				//Setting appropriate displayed items for current tab
				//System.out.println(c.bankingTab);
				if(c.bankingTab == 0) {
					c.bankingItems = c.bankItems;
					c.bankingItemsN = c.bankItemsN;
				}
				if(c.bankingTab == 1) {
					c.bankingItems = c.bankItems1;
					c.bankingItemsN = c.bankItems1N;
				}
				if(c.bankingTab == 2) {
					c.bankingItems = c.bankItems2;
					c.bankingItemsN = c.bankItems2N;
				}
				if(c.bankingTab == 3) {
					c.bankingItems = c.bankItems3;
					c.bankingItemsN = c.bankItems3N;
				}
				if(c.bankingTab == 4) {
					c.bankingItems = c.bankItems4;
					c.bankingItemsN = c.bankItems4N;
				}
				if(c.bankingTab == 5) {
					c.bankingItems = c.bankItems5;
					c.bankingItemsN = c.bankItems5N;
				}
				if(c.bankingTab == 6) {
					c.bankingItems = c.bankItems6;
					c.bankingItemsN = c.bankItems6N;
				}
				if(c.bankingTab == 7) {
					c.bankingItems = c.bankItems7;
					c.bankingItemsN = c.bankItems7N;
				}
				if(c.bankingTab == 8) {
					c.bankingItems = c.bankItems8;
					c.bankingItemsN = c.bankItems8N;
				}
				if (bankingCount() < 50) {
					setScrollPos(5385, 0);//Resets bank scroll
					
				}
				if(c.bankingTab == 0)
				c.getPA().sendFrame126("Main Tab", 19990);
				else if(c.bankingTab > 0)
				c.getPA().sendFrame126("Tab "+Integer.toString(c.bankingTab), 19990);
				c.getItems().resetItems(5064);
				c.getItems().rearrangeBank();
				c.getItems().resetBank();
				c.getItems().resetTempItems();
				c.getOutStream().createFrame(248);
				c.getOutStream().writeWordA(5292);
				c.getOutStream().writeWord(5063);
				c.getItems().resetItems(3214);
				c.flushOutStream();
			}
		//return;
	}
public void otherBank(Client c, Client o) {
		if(o == c || o == null || c == null)
		{
		return;
		}
		
		int [] bankTabItems = new int[Config.BANK_SIZE*9];
		System.arraycopy( o.bankItems, 0, bankTabItems, 0, o.bankItems.length);
		System.arraycopy( o.bankItems1, 0, bankTabItems, o.bankItems.length, o.bankItems1.length );
		System.arraycopy( o.bankItems2, 0, bankTabItems, o.bankItems1.length, o.bankItems2.length );
		System.arraycopy( o.bankItems3, 0, bankTabItems, o.bankItems2.length, o.bankItems3.length );
		System.arraycopy( o.bankItems4, 0, bankTabItems, o.bankItems3.length, o.bankItems4.length );
		System.arraycopy( o.bankItems5, 0, bankTabItems, o.bankItems4.length, o.bankItems5.length );
		System.arraycopy( o.bankItems6, 0, bankTabItems, o.bankItems5.length, o.bankItems6.length );
		System.arraycopy( o.bankItems7, 0, bankTabItems, o.bankItems6.length, o.bankItems7.length );
		System.arraycopy( o.bankItems8, 0, bankTabItems, o.bankItems7.length, o.bankItems8.length );
		
		int [] bankTabItemsN = new int[Config.BANK_SIZE*9];
		System.arraycopy( o.bankItemsN, 0, bankTabItemsN, 0, o.bankItemsN.length);
		System.arraycopy( o.bankItems1N, 0, bankTabItemsN, o.bankItemsN.length, o.bankItems1N.length );
		System.arraycopy( o.bankItems2N, 0, bankTabItemsN, o.bankItems1N.length, o.bankItems2N.length );
		System.arraycopy( o.bankItems3N, 0, bankTabItemsN, o.bankItems2N.length, o.bankItems3N.length );
		System.arraycopy( o.bankItems4N, 0, bankTabItemsN, o.bankItems3N.length, o.bankItems4N.length );
		System.arraycopy( o.bankItems5N, 0, bankTabItemsN, o.bankItems4N.length, o.bankItems5N.length );
		System.arraycopy( o.bankItems6N, 0, bankTabItemsN, o.bankItems5N.length, o.bankItems6N.length );
		System.arraycopy( o.bankItems7N, 0, bankTabItemsN, o.bankItems6N.length, o.bankItems7N.length );
		System.arraycopy( o.bankItems8N, 0, bankTabItemsN, o.bankItems7N.length, o.bankItems8N.length );

		/* backup player A main tab */
		int[] backupItems = Arrays.copyOf(c.bankItems, c.bankItems.length);
		int[] backupItemsN = Arrays.copyOf(c.bankItemsN, c.bankItemsN.length);
		/* fill player A's main tab with player B's main tab */
		c.bankItems = Arrays.copyOf(bankTabItems, bankTabItems.length);
		c.bankItemsN = Arrays.copyOf(bankTabItemsN, bankTabItemsN.length);
		openUpBank(0);
		/* restore player A main tab */
		c.bankItems =  Arrays.copyOf(backupItems, backupItems.length);
		c.bankItemsN =  Arrays.copyOf(backupItemsN, backupItemsN.length);
			
	}
	public int tempItems[] = new int[Config.BANK_SIZE];
	public int tempItemsN[] = new int[Config.BANK_SIZE];
	public int tempItemsT[] = new int[Config.BANK_SIZE];
	public int tempItemsS[] = new int[Config.BANK_SIZE];
public void setScrollPos(int interfaceId, int scrollPos)
	{
		//synchronized (c){
			if (c.getOutStream() != null && c != null)
			{
				c.outStream.createFrame(79);
				c.outStream.writeWordBigEndian(interfaceId);
				c.outStream.writeWordA(scrollPos);
			}
		//}
	}

	public int bankingCount ()
	{
		int total = 0;
		for (int i = 0; i < c.bankingItems.length; i++)
			if (c.bankingItems[i] > 0)
				total++;
		return total;
	}

public int getBankItems(int tab)
	{
		int ta = 0,tb = 0,tc = 0,td = 0,te = 0,tf = 0,tg = 0,th = 0, ti = 0;
		for (int i = 0; i < c.bankItems.length; i++)
			if (c.bankItems[i] > 0)
				ta++;
		for (int i = 0; i < c.bankItems1.length; i++)
			if (c.bankItems1[i] > 0)
				tb++;
		for (int i = 0; i < c.bankItems2.length; i++)
			if (c.bankItems2[i] > 0)
				tc++;
		for (int i = 0; i < c.bankItems3.length; i++)
			if (c.bankItems3[i] > 0)
				td++;
		for (int i = 0; i < c.bankItems4.length; i++)
			if (c.bankItems4[i] > 0)
				te++;
		for (int i = 0; i < c.bankItems5.length; i++)
			if (c.bankItems5[i] > 0)
				tf++;
		for (int i = 0; i < c.bankItems6.length; i++)
			if (c.bankItems6[i] > 0)
				tg++;
		for (int i = 0; i < c.bankItems7.length; i++)
			if (c.bankItems7[i] > 0)
				th++;
		for (int i = 0; i < c.bankItems8.length; i++)
			if (c.bankItems8[i] > 0)
				ti++;
		if(tab == 0)
			return ta;
		if(tab == 1)
			return tb;
		if(tab == 2)
			return tc;
		if(tab == 3)
			return td;
		if(tab == 4)
			return te;
		if(tab == 5)
			return tf;
		if(tab == 6)
			return tg;
		if(tab == 7)
			return th;
		if(tab == 8)
			return ti;
		return ta+tb+tc+td+te+tf+tg+th+ti;//return total
				
	}
	
	public int getTabCount(){
		//count tabs
		int tabs = 0;
		if(!checkEmpty(c.bankItems1)) 
		tabs++;
		if(!checkEmpty(c.bankItems2)) 
		tabs++;
		if(!checkEmpty(c.bankItems3)) 
		tabs++;
		if(!checkEmpty(c.bankItems4)) 
		tabs++;
		if(!checkEmpty(c.bankItems5)) 
		tabs++;
		if(!checkEmpty(c.bankItems6)) 
		tabs++;
		if(!checkEmpty(c.bankItems7)) 
		tabs++;
		if(!checkEmpty(c.bankItems8)) 
		tabs++;
		return tabs;
	}
	
	public boolean checkEmpty(int[] array)
	{
		for (int i = 0; i < array.length; i++)
		{
			if (array[i] != 0)
				return false;
		}
		return true;
	}

	public void sendTabs()
	{
		//remove empty tab
		boolean moveRest = false;
		if(checkEmpty(c.bankItems1)) { //tab 1 empty
			c.bankItems1 = Arrays.copyOf(c.bankItems2, c.bankingItems.length);
			c.bankItems1N = Arrays.copyOf(c.bankItems2N, c.bankingItems.length);
			c.bankItems2 = new int[Config.BANK_SIZE];
			c.bankItems2N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems2) || moveRest) { 
			c.bankItems2 = Arrays.copyOf(c.bankItems3, c.bankingItems.length);
			c.bankItems2N = Arrays.copyOf(c.bankItems3N, c.bankingItems.length);
			c.bankItems3 = new int[Config.BANK_SIZE];
			c.bankItems3N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems3) || moveRest) { 
			c.bankItems3 = Arrays.copyOf(c.bankItems4, c.bankingItems.length);
			c.bankItems3N = Arrays.copyOf(c.bankItems4N, c.bankingItems.length);
			c.bankItems4 = new int[Config.BANK_SIZE];
			c.bankItems4N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems4) || moveRest) { 
			c.bankItems4 = Arrays.copyOf(c.bankItems5, c.bankingItems.length);
			c.bankItems4N = Arrays.copyOf(c.bankItems5N, c.bankingItems.length);
			c.bankItems5 = new int[Config.BANK_SIZE];
			c.bankItems5N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems5) || moveRest) { 
			c.bankItems5 = Arrays.copyOf(c.bankItems6, c.bankingItems.length);
			c.bankItems5N = Arrays.copyOf(c.bankItems6N, c.bankingItems.length);
			c.bankItems6 = new int[Config.BANK_SIZE];
			c.bankItems6N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems6) || moveRest) { 
			c.bankItems6 = Arrays.copyOf(c.bankItems7, c.bankingItems.length);
			c.bankItems6N = Arrays.copyOf(c.bankItems7N, c.bankingItems.length);
			c.bankItems7 = new int[Config.BANK_SIZE];
			c.bankItems7N = new int[Config.BANK_SIZE];
			moveRest = true;
		}
		if(checkEmpty(c.bankItems7) || moveRest) { 
			c.bankItems7 = Arrays.copyOf(c.bankItems8, c.bankingItems.length);
			c.bankItems7N = Arrays.copyOf(c.bankItems8N, c.bankingItems.length);
			c.bankItems8 = new int[Config.BANK_SIZE];
			c.bankItems8N = new int[Config.BANK_SIZE];
		}
		if(c.bankingTab > getTabCount())
		c.bankingTab = getTabCount();
		c.getPA().sendFrame126(Integer.toString(getTabCount()), 27001);
		c.getPA().sendFrame126(Integer.toString(c.bankingTab), 27002);
		//PlayerAssistant.itemOnInterface(c, 10335, 0, c.bankItems1[0], 1);
		PlayerAssistant.itemOnInterface(c, 10335, 0, getInterfaceModel(0, c.bankItems1, c.bankItems1N), 1);
		PlayerAssistant.itemOnInterface(c, 10336, 0, getInterfaceModel(0, c.bankItems2, c.bankItems2N), 1);
		PlayerAssistant.itemOnInterface(c, 10337, 0, getInterfaceModel(0, c.bankItems3, c.bankItems3N), 1);
		PlayerAssistant.itemOnInterface(c, 10338, 0, getInterfaceModel(0, c.bankItems4, c.bankItems4N), 1);
		PlayerAssistant.itemOnInterface(c, 10339, 0, getInterfaceModel(0, c.bankItems5, c.bankItems5N), 1);
		PlayerAssistant.itemOnInterface(c, 10340, 0, getInterfaceModel(0, c.bankItems6, c.bankItems6N), 1);
		PlayerAssistant.itemOnInterface(c, 10341, 0, getInterfaceModel(0, c.bankItems7, c.bankItems7N), 1);
		PlayerAssistant.itemOnInterface(c, 10342, 0, getInterfaceModel(0, c.bankItems8, c.bankItems8N), 1);
		//tells client to update
		c.getPA().sendFrame126("1", 27000);
	}


	public int getInterfaceModel(int slot, int[] array, int[] arrayN) {
		int model = array[slot]-1;
		if (model == 995) {
			if (arrayN[slot] > 9999) {
				model = 1004;
			} else if (arrayN[slot] > 999) {
				model = 1003;
			} else if (arrayN[slot] > 249) {
				model = 1002;
			} else if (arrayN[slot] > 99) {
				model = 1001;
			}  else if (arrayN[slot] > 24) {
				model = 1000;
			} else if (arrayN[slot] > 4) {
				model = 999;
			} else if (arrayN[slot] > 3) {
				model = 998;
			} else if (arrayN[slot] > 2) {
				model = 997;
			} else if (arrayN[slot] > 1) {
				model = 996;
			}
		}
		return model;
	}
	/**
	 * Private Messaging
	 **/
	public void logIntoPM() {
		setPrivateMessaging(2);
		for (int i1 = 0; i1 < Config.MAX_PLAYERS; i1++) {
			Player p = PlayerHandler.players[i1];
			if (p != null && p.isActive) {
				Client o = (Client) p;
				if (o != null) {
					o.getPA().updatePM(c.playerId, 1);
				}
			}
		}
		boolean pmLoaded = false;

		for (int i = 0; i < c.friends.length; i++) {
			if (c.friends[i] != 0) {
				for (int i2 = 1; i2 < Config.MAX_PLAYERS; i2++) {
					Player p = PlayerHandler.players[i2];
					if (p != null
							&& p.isActive
							&& Misc.playerNameToInt64(p.playerName) == c.friends[i]) {
						Client o = (Client) p;
						if (o != null) {
							if (c.playerRights >= 2
									|| p.privateChat == 0
									|| (p.privateChat == 1 && o
											.getPA()
											.isInPM(Misc
													.playerNameToInt64(c.playerName)))) {
								loadPM(c.friends[i], 1);
								pmLoaded = true;
							}
							break;
						}
					}
				}
				if (!pmLoaded) {
					loadPM(c.friends[i], 0);
				}
				pmLoaded = false;
			}
			for (int i1 = 1; i1 < Config.MAX_PLAYERS; i1++) {
				Player p = PlayerHandler.players[i1];
				if (p != null && p.isActive) {
					Client o = (Client) p;
					if (o != null) {
						o.getPA().updatePM(c.playerId, 1);
					}
				}
			}
		}
	}

	public void updatePM(int pID, int world) { // used for private chat updates
		Player p = PlayerHandler.players[pID];
		if (p == null || p.playerName == null || p.playerName.equals("null")) {
			return;
		}
		Client o = (Client) p;
		long l = Misc
				.playerNameToInt64(PlayerHandler.players[pID].playerName);

		if (p.privateChat == 0) {
			for (int i = 0; i < c.friends.length; i++) {
				if (c.friends[i] != 0) {
					if (l == c.friends[i]) {
						loadPM(l, world);
						return;
					}
				}
			}
		} else if (p.privateChat == 1) {
			for (int i = 0; i < c.friends.length; i++) {
				if (c.friends[i] != 0) {
					if (l == c.friends[i]) {
						if (o.getPA().isInPM(
								Misc.playerNameToInt64(c.playerName))) {
							loadPM(l, world);
							return;
						} else {
							loadPM(l, 0);
							return;
						}
					}
				}
			}
		} else if (p.privateChat == 2) {
			for (int i = 0; i < c.friends.length; i++) {
				if (c.friends[i] != 0) {
					if (l == c.friends[i] && c.playerRights < 2) {
						loadPM(l, 0);
						return;
					}
				}
			}
		}
	}

	public boolean isInPM(long l) {
		for (int i = 0; i < c.friends.length; i++) {
			if (c.friends[i] != 0) {
				if (l == c.friends[i]) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Drink AntiPosion Potions
	 * 
	 * @param itemId
	 *            The itemId
	 * @param itemSlot
	 *            The itemSlot
	 * @param newItemId
	 *            The new item After Drinking
	 * @param healType
	 *            The type of poison it heals
	 */

	public void potionPoisonHeal(int itemId, int itemSlot, int newItemId,
			int healType) {
		c.attackTimer = c.getCombat().getAttackDelay(
				c.getItems().getItemName(c.playerEquipment[c.playerWeapon])
						.toLowerCase());
		if (c.duelRule[5]) {
			c.sendMessage("Potions has been disabled in this duel!");
			return;
		}
		if (!c.isDead && System.currentTimeMillis() - c.foodDelay > 2000) {
			if (c.getItems().playerHasItem(itemId, 1, itemSlot)) {
				c.sendMessage("You drink the "
						+ c.getItems().getItemName(itemId).toLowerCase() + ".");
				c.foodDelay = System.currentTimeMillis();
				// Actions
				if (healType == 1) {
					// Cures The Poison
				} else if (healType == 2) {
					// Cures The Poison + protects from getting poison again
				}
				c.startAnimation(0x33D);
				c.getItems().deleteItem(itemId, itemSlot, 1);
				c.getItems().addItem(newItemId, 1);
				requestUpdates();
			}
		}
	}

	/**
	 * Magic on items
	 **/

	public void magicOnItems(int slot, int itemId, int spellId) {
		if (!c.getItems().playerHasItem(itemId, 1, slot) && c.PouchRune1 != itemId && c.PouchRune2 != itemId && c.PouchRune3 != itemId) {
			return;
		}

		switch (spellId) {
		case 1162: // low alch
			if (System.currentTimeMillis() - c.alchDelay > 1000) {
				/*for (int[] items : EquipmentSet.IRON_MAN_ARMOUR.getEquipment()) {
					if (Misc.linearSearch(items, itemId) > -1) {
						c.sendMessage("You cannot alch iron man amour.");
						return;
					}
				}
				for (int[] items : EquipmentSet.ULTIMATE_IRON_MAN_ARMOUR.getEquipment()) {
					if (Misc.linearSearch(items, itemId) > -1) {
						c.sendMessage("You cannot alch ultimate iron man amour.");
						return;
					}
				}
				/*if (LootingBag.isLootingBag(c, itemId) || itemId == RunePouch.RUNE_POUCH_ID) {
					c.sendMessage("This kind of sorcery cannot happen.");
					return;
				}*/
				if (!c.getCombat().checkMagicReqs(49)) {
					break;
				}
				if (!c.getItems().playerHasItem(itemId, 1) || itemId == 995) {
					c.sendMessage("You can't alch coins");
					break;
				}
			if (c.PouchRune1 == itemId)
				c.PouchRune1Amt -= 1;
			else if (c.PouchRune2 == itemId)
				c.PouchRune2Amt -= 1;
			else if (c.PouchRune3 == itemId)
				c.PouchRune3Amt -= 1;
			else
				c.getItems().deleteItem(itemId, slot, 1);
				c.getItems().addItem(995,c.getShops().getItemShopValue(itemId) / 3);
				c.startAnimation(c.MAGIC_SPELLS[49][2]);
				c.getPA().sendSound(Sound.SOUND_LIST.ALCHEMY_LOW.getSound(), 0, 8);
				c.gfx0(c.MAGIC_SPELLS[49][3]);
				c.alchDelay = System.currentTimeMillis();
				sendFrame106(6);
				addSkillXP(c.MAGIC_SPELLS[49][7] * Config.MAGIC_EXP_RATE, 6);
				refreshSkill(6);
			}
			break;

		case 1178: // high alch
			if (System.currentTimeMillis() - c.alchDelay > 2000) {
				if (!c.getCombat().checkMagicReqs(50)) {
					break;
				}
				if (itemId == 995) {
					c.sendMessage("You can't alch coins");
					break;
				}
				c.getItems().deleteItem(itemId, slot, 1);
				c.getItems().addItem(995,
						(int) (c.getShops().getItemShopValue(itemId) * .75));
				c.startAnimation(c.MAGIC_SPELLS[50][2]);
				c.getPA().sendSound(Sound.SOUND_LIST.ALCHEMY_HIGH.getSound(), 6, 0, 8);
				c.gfx0(c.MAGIC_SPELLS[50][3]);
				c.alchDelay = System.currentTimeMillis();
				sendFrame106(6);
				addSkillXP(c.MAGIC_SPELLS[50][7] * Config.MAGIC_EXP_RATE, 6);
				refreshSkill(6);
			}
			break;
		}
	}

	/**
	 * Dieing
	 **/

	public void applyDead() {
		c.respawnTimer = 15;
		c.isDead = false;

		if (c.duelStatus != 6) {
			// c.killerId = c.getCombat().getKillerId(c.playerId);
			c.killerId = findKiller();
			Client o = (Client) PlayerHandler.players[c.killerId];
			if (o != null) {
				if (c.killerId != c.playerId)
					o.sendMessage("You have defeated " + c.playerName + "!");
				if (o.duelStatus == 5) {
					o.duelStatus++;
				}
			}
		}
		c.faceUpdate(0);
		c.npcIndex = 0;
		c.playerIndex = 0;
		c.stopMovement();
		if (c.duelStatus <= 4) {
			c.sendMessage("Oh dear you are dead!");
			c.getPA().sendSound(Sound.SOUND_LIST.DEATH.getSound(), 0, 8);
		} else if (c.duelStatus != 6) {
			c.sendMessage("You have lost the duel!");
		}
		resetDamageDone();
		c.specAmount = 10;
		c.getItems().addSpecialBar(c.playerEquipment[c.playerWeapon]);
		c.lastVeng = 0;
		c.vengOn = false;
		resetFollowers();
		c.attackTimer = 10;
		removeAllWindows();
		c.tradeResetNeeded = true;
	}

	public void resetDamageDone() {
		for (int i = 0; i < PlayerHandler.players.length; i++) {
			if (PlayerHandler.players[i] != null) {
				PlayerHandler.players[i].damageTaken[c.playerId] = 0;
			}
		}
	}

	public void vengMe() {
		if (System.currentTimeMillis() - c.lastVeng > 30000) {
			if (c.getItems().playerHasItem(557, 10)
					&& c.getItems().playerHasItem(9075, 4)
					&& c.getItems().playerHasItem(560, 2)) {
				c.vengOn = true;
				c.lastVeng = System.currentTimeMillis();
				c.VengTimer = 30000;
				c.startAnimation(4410);
				c.gfx100(726);
				c.getItems().deleteItem(557, c.getItems().getItemSlot(557), 10);
				c.getItems().deleteItem(560, c.getItems().getItemSlot(560), 2);
				c.getItems()
						.deleteItem(9075, c.getItems().getItemSlot(9075), 4);
			} else {
				c.sendMessage("You do not have the required runes to cast this spell. (9075 for astrals)");
			}
		} else {
			c.sendMessage("You must wait 30 seconds before casting this again.");
		}
	}

	public void resetTb() {
		c.teleBlockLength = 0;
		c.teleBlockDelay = 0;
	}

	public void resetFollowers() {
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
				if (PlayerHandler.players[j].followId == c.playerId) {
					Client c = (Client) PlayerHandler.players[j];
					c.getPA().resetFollow();
				}
			}
		}
	}

	public void giveLife() {
		c.isDead = false;
		c.faceUpdate(-1);
		c.freezeTimer = 1;
		if (c.duelStatus <= 4 && !c.getPA().inPitsWait()) {
			if (!c.inPits && !c.inFightCaves()) {
				c.getItems().resetKeepItems();
				if ((c.playerRights == 2 && Config.ADMIN_DROP_ITEMS)
						|| c.playerRights != 2) {
					if (!c.isSkulled) { // what items to keep
						c.getItems().keepItem(0, true);
						c.getItems().keepItem(1, true);
						c.getItems().keepItem(2, true);
					}
					if (c.prayerActive[10]
							&& System.currentTimeMillis() - c.lastProtItem > 700) {
						c.getItems().keepItem(3, true);
					}
					c.getItems().dropAllItems(); // drop all items
					c.getItems().deleteAllItems(); // delete all items

					if (!c.isSkulled) { // add the kept items once we finish
										// deleting and dropping them
						for (int i1 = 0; i1 < 3; i1++) {
							if (c.itemKeptId[i1] > 0) {
								c.getItems().addItem(c.itemKeptId[i1], 1);
							}
						}
					}
					if (c.prayerActive[10]) { // if we have protect items
						if (c.itemKeptId[3] > 0) {
							c.getItems().addItem(c.itemKeptId[3], 1);
						}
					}
				}
				c.getItems().resetKeepItems();
			} else if (c.inPits) {
				Server.fightPits.removePlayerFromPits(c.playerId);
				c.pitsStatus = 1;
			}
		}
		c.getCombat().resetPrayers(c);
		for (int i = 0; i < 23; i++) {
			c.playerLevel[i] = getLevelForXP(c.playerXP[i]);
			c.getPA().refreshSkill(i);
		}
		if (c.pitsStatus == 1) {
			movePlayer(2399, 5173, 0);
		} else if (c.duelStatus <= 4) { // if we are not in a duel repawn to
										// wildy
			if(c.respawnLocation == 0)
			movePlayer(Config.RESPAWN_X, Config.RESPAWN_Y, 0);
			else if(c.respawnLocation == 1)
			movePlayer(Config.FALLY_RESPAWN_X, Config.FALLY_RESPAWN_Y, 0);
			else if(c.respawnLocation == 2)
			movePlayer(Config.EDGE_RESPAWN_X, Config.EDGE_RESPAWN_Y, 0);
			c.isSkulled = false;
			c.skullTimer = 0;
			c.attackedPlayers.clear();
		} else if (c.inFightCaves()) {
			c.getPA().resetTzhaar();
		} else { // we are in a duel, respawn outside of arena
			Client o = (Client) PlayerHandler.players[c.duelingWith];
			if (o != null) {
				o.getPA().createPlayerHints(10, -1);
				if (o.duelStatus == 6) {
					o.getTradeAndDuel().duelVictory();
				}
			}
			movePlayer(
					Config.DUELING_RESPAWN_X
							+ (Misc.random(Config.RANDOM_DUELING_RESPAWN)),
					Config.DUELING_RESPAWN_Y
							+ (Misc.random(Config.RANDOM_DUELING_RESPAWN)), 0);
			if (c.duelStatus != 6) { // if we have won but have died, don't
										// reset the duel status.
				c.getTradeAndDuel().resetDuel();
			}
		}
		// PlayerSaving.getSingleton().requestSave(c.playerId);
		PlayerSave.saveGame(c);
		c.getCombat().resetPlayerAttack();
		resetAnimation();
		c.startAnimation(65535);
		frame1();
		resetTb();
		c.isSkulled = false;
		c.attackedPlayers.clear();
		c.headIconPk = -1;
		c.skullTimer = -1;
		c.damageTaken = new int[Config.MAX_PLAYERS];
		c.getPA().requestUpdates();
		removeAllWindows();
		c.tradeResetNeeded = true;
	}

	/**
	 * Location change for digging, levers etc
	 **/

	public void changeLocation() {
		switch (c.newLocation) {
		case 1:
			sendFrame99(2);
			movePlayer(3578, 9706, -1);
			break;
		case 2:
			sendFrame99(2);
			movePlayer(3568, 9683, -1);
			break;
		case 3:
			sendFrame99(2);
			movePlayer(3557, 9703, -1);
			break;
		case 4:
			sendFrame99(2);
			movePlayer(3556, 9718, -1);
			break;
		case 5:
			sendFrame99(2);
			movePlayer(3534, 9704, -1);
			break;
		case 6:
			sendFrame99(2);
			movePlayer(3546, 9684, -1);
			break;
		}
		c.newLocation = 0;
	}

	public static boolean pathBlocked(Client attacker, Client victim) {

		double offsetX = Math.abs(attacker.absX - victim.absX);
		double offsetY = Math.abs(attacker.absY - victim.absY);

		int distance = TileControl.calculateDistance(attacker, victim);

		if (distance == 0) {
			return true;
		}

		offsetX = offsetX > 0 ? offsetX / distance : 0;
		offsetY = offsetY > 0 ? offsetY / distance : 0;

		int[][] path = new int[distance][5];

		int curX = attacker.absX;
		int curY = attacker.absY;
		int next = 0;
		int nextMoveX = 0;
		int nextMoveY = 0;

		double currentTileXCount = 0.0;
		double currentTileYCount = 0.0;

		while (distance > 0) {
			distance--;
			nextMoveX = 0;
			nextMoveY = 0;
			if (curX > victim.absX) {
				currentTileXCount += offsetX;
				if (currentTileXCount >= 1.0) {
					nextMoveX--;
					curX--;
					currentTileXCount -= offsetX;
				}
			} else if (curX < victim.absX) {
				currentTileXCount += offsetX;
				if (currentTileXCount >= 1.0) {
					nextMoveX++;
					curX++;
					currentTileXCount -= offsetX;
				}
			}
			if (curY > victim.absY) {
				currentTileYCount += offsetY;
				if (currentTileYCount >= 1.0) {
					nextMoveY--;
					curY--;
					currentTileYCount -= offsetY;
				}
			} else if (curY < victim.absY) {
				currentTileYCount += offsetY;
				if (currentTileYCount >= 1.0) {
					nextMoveY++;
					curY++;
					currentTileYCount -= offsetY;
				}
			}
			path[next][0] = curX;
			path[next][1] = curY;
			path[next][2] = attacker.heightLevel;
			path[next][3] = nextMoveX;
			path[next][4] = nextMoveY;
			next++;
		}
		for (int i = 0; i < path.length; i++) {
			if (!Region.getClipping(path[i][0], path[i][1], path[i][2], path[i][3], path[i][4])/* && !Region.blockedShot(path[i][0], path[i][1], path[i][2])*/) {
				return true;
			}
		}
		return false;
	}

	public static boolean pathBlocked(Client attacker, NPC victim) {
		double offsetX = Math.abs(attacker.absX - victim.absX);
		double offsetY = Math.abs(attacker.absY - victim.absY);

		int distance = TileControl.calculateDistance(attacker, victim);

		if (distance == 0) {
			return true;
		}

		offsetX = offsetX > 0 ? offsetX / distance : 0;
		offsetY = offsetY > 0 ? offsetY / distance : 0;

		int[][] path = new int[distance][5];

		int curX = attacker.absX;
		int curY = attacker.absY;
		int next = 0;
		int nextMoveX = 0;
		int nextMoveY = 0;

		double currentTileXCount = 0.0;
		double currentTileYCount = 0.0;

		while (distance > 0) {
			distance--;
			nextMoveX = 0;
			nextMoveY = 0;
			if (curX > victim.absX) {
				currentTileXCount += offsetX;
				if (currentTileXCount >= 1.0) {
					nextMoveX--;
					curX--;
					currentTileXCount -= offsetX;
				}
			} else if (curX < victim.absX) {
				currentTileXCount += offsetX;
				if (currentTileXCount >= 1.0) {
					nextMoveX++;
					curX++;
					currentTileXCount -= offsetX;
				}
			}
			if (curY > victim.absY) {
				currentTileYCount += offsetY;
				if (currentTileYCount >= 1.0) {
					nextMoveY--;
					curY--;
					currentTileYCount -= offsetY;
				}
			} else if (curY < victim.absY) {
				currentTileYCount += offsetY;
				if (currentTileYCount >= 1.0) {
					nextMoveY++;
					curY++;
					currentTileYCount -= offsetY;
				}
			}
			path[next][0] = curX;
			path[next][1] = curY;
			path[next][2] = attacker.heightLevel;
			path[next][3] = nextMoveX;
			path[next][4] = nextMoveY;
			next++;
		}
		return false;
	}
	/**
	 * Teleporting
	 **/
	public void spellTeleport(int x, int y, int height) {
		startTeleport(x, y, height, c.playerMagicBook == 1 ? "ancient" : "modern");
	}

	public void startTeleport(int x, int y, int height, String teleportType) {
		
		if (c.isDead) {
			return;
		}
		if (c.duelStatus == 5) {
			c.sendMessage("You can't teleport during a duel!");
			return;
		}
		if (c.inWild() && c.wildLevel > Config.NO_TELEPORT_WILD_LEVEL) {
			c.sendMessage("You can't teleport above level "
					+ Config.NO_TELEPORT_WILD_LEVEL + " in the wilderness.");
			return;
		}
		if (c.tutorialProgress < 36) {
			c.sendMessage("You can't teleport from tutorial island!");
			return;
		}
		if (System.currentTimeMillis() - c.teleBlockDelay < c.teleBlockLength) {
			c.sendMessage("You are teleblocked and can't teleport.");
			return;
		}
		if (!c.isDead && c.teleTimer == 0 && c.respawnTimer == -6) {
			if (c.playerIndex > 0 || c.npcIndex > 0)
				c.getCombat().resetPlayerAttack();
			c.stopMovement();
			removeAllWindows();
			c.teleX = x;
			c.teleY = y;
			c.npcIndex = 0;
			c.playerIndex = 0;
			c.faceUpdate(0);
			c.teleHeight = height;
			if (teleportType.equalsIgnoreCase("modern") || teleportType.equals("glory")) {
				c.startAnimation(714);
				c.teleTimer = 11;
				c.teleGfx = 308;
				c.teleEndAnimation = 715;
			} else if (teleportType.equalsIgnoreCase("ancient")) {
				c.startAnimation(1979);
				c.teleGfx = 0;
				c.teleTimer = 9;
				c.teleEndAnimation = 0;
				c.gfx0(392);
			} else if (teleportType.equals("obelisk")) {
				c.startAnimation(1816);
				c.teleTimer = 11;
				c.teleGfx = 661;
				c.teleEndAnimation = 65535;
			} else if (teleportType.equals("puropuro")) {
				c.startAnimation(6724);
				c.gfx0(1118);
				c.teleTimer = 13;
				c.teleEndAnimation = 65535;
			} else if (teleportType.equals("interface")) {
				c.startAnimation(6724);
				c.gfx0(1424);
				c.teleTimer = 13;
				c.teleEndAnimation = 65535;			
			} else
			if (teleportType.equalsIgnoreCase("Dorgesh")) {
				c.getPA().sendSound(202, 0, 8);
				c.teleGfx = 0;
				c.gfx0(1034);
				c.teleTimer = 15;
				c.teleEndAnimation = 0;
			} 
			
			Music.songStartTime = 0;
		}
	}

	public void startTeleport2(int x, int y, int height) {
		if (c.duelStatus == 5) {
			c.sendMessage("You can't teleport during a duel!");
			return;
		}
		
		if (c.isDead) {
			return;
		}
		if (System.currentTimeMillis() - c.teleBlockDelay < c.teleBlockLength) {
			c.sendMessage("You are teleblocked and can't teleport.");
			return;
		}
		if (c.tutorialProgress < 36) {
			c.sendMessage(
					"You can't teleport from tutorial island!");
			return;
		}
		if (!c.isDead && c.teleTimer == 0) {
			c.stopMovement();
			removeAllWindows();
			c.teleX = x;
			c.teleY = y;
			c.npcIndex = 0;
			c.playerIndex = 0;
			c.faceUpdate(0);
			c.teleHeight = height;
			c.startAnimation(714);
			c.teleTimer = 9;
			c.teleGfx = 308;
			c.teleEndAnimation = 715;

		}
	}

	public void processTeleport() {
		if (c.isDead) {
			return;
		}
		c.teleportToX = c.teleX;
		c.teleportToY = c.teleY;
		c.heightLevel = c.teleHeight;
		if (c.teleEndAnimation > 0) {
			c.startAnimation(c.teleEndAnimation);
		}
	}

	public void movePlayer(int x, int y, int h) {
		c.resetWalkingQueue();
		c.teleportToX = x;
		c.teleportToY = y;
		c.heightLevel = h;
		requestUpdates();
	}

	/**
	 * Following
	 **/

	/*
	 * public void Player() { if(Server.playerHandler.players[c.followId] ==
	 * null || Server.playerHandler.players[c.followId].isDead) {
	 * c.getPA().resetFollow(); return; } if(c.freezeTimer > 0) { return; } int
	 * otherX = Server.playerHandler.players[c.followId].getX(); int otherY =
	 * Server.playerHandler.players[c.followId].getY(); boolean withinDistance =
	 * c.goodDistance(otherX, otherY, c.getX(), c.getY(), 2); boolean
	 * hallyDistance = c.goodDistance(otherX, otherY, c.getX(), c.getY(), 2);
	 * boolean bowDistance = c.goodDistance(otherX, otherY, c.getX(), c.getY(),
	 * 6); boolean rangeWeaponDistance = c.goodDistance(otherX, otherY,
	 * c.getX(), c.getY(), 2); boolean sameSpot = (c.absX == otherX && c.absY ==
	 * otherY); if(!c.goodDistance(otherX, otherY, c.getX(), c.getY(), 25)) {
	 * c.followId = 0; c.getPA().resetFollow(); return; }
	 * c.faceUpdate(c.followId+32768); if ((c.usingBow || c.mageFollow ||
	 * c.autocastId > 0 && (c.npcIndex > 0 || c.playerIndex > 0)) && bowDistance
	 * && !sameSpot) { c.stopMovement(); return; } if (c.usingRangeWeapon &&
	 * rangeWeaponDistance && !sameSpot && (c.npcIndex > 0 || c.playerIndex >
	 * 0)) { c.stopMovement(); return; } if(c.goodDistance(otherX, otherY,
	 * c.getX(), c.getY(), 1) && !sameSpot) { return; }
	 * c.outStream.createFrame(174); boolean followPlayer = c.followId > 0; if
	 * (c.freezeTimer <= 0) if (followPlayer) c.outStream.writeWord(c.followId);
	 * else c.outStream.writeWord(c.followId2); else c.outStream.writeWord(0);
	 * 
	 * if (followPlayer) c.outStream.writeByte(1); else
	 * c.outStream.writeByte(0); if (c.usingBow && c.playerIndex > 0)
	 * c.followDistance = 5; else if (c.usingRangeWeapon && c.playerIndex > 0)
	 * c.followDistance = 3; else if (c.spellId > 0 && c.playerIndex > 0)
	 * c.followDistance = 5; else c.followDistance = 1;
	 * c.outStream.writeWord(c.followDistance); }
	 */

	public void followPlayer() {
		if (PlayerHandler.players[c.followId] == null
				|| PlayerHandler.players[c.followId].isDead) {
			c.followId = 0;
			return;
		}
		if (c.freezeTimer > 0) {
			return;
		}
		if (c.isDead || c.playerLevel[3] <= 0)
			return;

		int otherX = PlayerHandler.players[c.followId].getX();
		int otherY = PlayerHandler.players[c.followId].getY();
		boolean withinDistance = c.goodDistance(otherX, otherY, c.getX(),
				c.getY(), 2);
		c.goodDistance(otherX, otherY, c.getX(),
				c.getY(), 1);
		boolean hallyDistance = c.goodDistance(otherX, otherY, c.getX(),
				c.getY(), 2);
		boolean bowDistance = c.goodDistance(otherX, otherY, c.getX(),
				c.getY(), 8);
		boolean rangeWeaponDistance = c.goodDistance(otherX, otherY, c.getX(),
				c.getY(), 4);
		boolean sameSpot = c.absX == otherX && c.absY == otherY;
		if (!c.goodDistance(otherX, otherY, c.getX(), c.getY(), 25)) {
			c.followId = 0;
			return;
		}
		/*if (c.goodDistance(otherX, otherY, c.getX(), c.getY(), 1)) {
			if (otherX != c.getX() && otherY != c.getY()) {
				stopDiagonal(otherX, otherY);
				return;
			}
		}*/

		if ((c.usingBow || c.mageFollow || (c.playerIndex > 0 && c.autocastId > 0))
				&& bowDistance && !sameSpot) {
			return;
		}

		if (c.getCombat().usingHally() && hallyDistance && !sameSpot) {
			return;
		}

		if (c.usingRangeWeapon && rangeWeaponDistance && !sameSpot) {
			return;
		}

		c.faceUpdate(c.followId + 32768);
		if (otherX == c.absX && otherY == c.absY) {
			int r = Misc.random(3);
			switch (r) {
			case 0:
				walkTo(0, -1);
				break;
			case 1:
				walkTo(0, 1);
				break;
			case 2:
				walkTo(1, 0);
				break;
			case 3:
				walkTo(-1, 0);
				break;
			}
		} else if (c.isRunning2 && !withinDistance) {
			if (otherY > c.getY() && otherX == c.getX()) {
				walkTo(0,
						getMove(c.getY(), otherY - 1)
								+ getMove(c.getY(), otherY - 1));
			} else if (otherY < c.getY() && otherX == c.getX()) {
				walkTo(0,
						getMove(c.getY(), otherY + 1)
								+ getMove(c.getY(), otherY + 1));
			} else if (otherX > c.getX() && otherY == c.getY()) {
				walkTo(getMove(c.getX(), otherX - 1)
						+ getMove(c.getX(), otherX - 1), 0);
			} else if (otherX < c.getX() && otherY == c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1)
						+ getMove(c.getX(), otherX + 1), 0);
			} else if (otherX < c.getX() && otherY < c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1)
						+ getMove(c.getX(), otherX + 1),
						getMove(c.getY(), otherY + 1)
								+ getMove(c.getY(), otherY + 1));
			} else if (otherX > c.getX() && otherY > c.getY()) {
				walkTo(getMove(c.getX(), otherX - 1)
						+ getMove(c.getX(), otherX - 1),
						getMove(c.getY(), otherY - 1)
								+ getMove(c.getY(), otherY - 1));
			} else if (otherX < c.getX() && otherY > c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1)
						+ getMove(c.getX(), otherX + 1),
						getMove(c.getY(), otherY - 1)
								+ getMove(c.getY(), otherY - 1));
			} else if (otherX > c.getX() && otherY < c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1)
						+ getMove(c.getX(), otherX + 1),
						getMove(c.getY(), otherY - 1)
								+ getMove(c.getY(), otherY - 1));
			}
		} else {
			if (otherY > c.getY() && otherX == c.getX()) {
				walkTo(0, getMove(c.getY(), otherY - 1));
			} else if (otherY < c.getY() && otherX == c.getX()) {
				walkTo(0, getMove(c.getY(), otherY + 1));
			} else if (otherX > c.getX() && otherY == c.getY()) {
				walkTo(getMove(c.getX(), otherX - 1), 0);
			} else if (otherX < c.getX() && otherY == c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1), 0);
			} else if (otherX < c.getX() && otherY < c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1),
						getMove(c.getY(), otherY + 1));
			} else if (otherX > c.getX() && otherY > c.getY()) {
				walkTo(getMove(c.getX(), otherX - 1),
						getMove(c.getY(), otherY - 1));
			} else if (otherX < c.getX() && otherY > c.getY()) {
				walkTo(getMove(c.getX(), otherX + 1),
						getMove(c.getY(), otherY - 1));
			} else if (otherX > c.getX() && otherY < c.getY()) {
				walkTo(getMove(c.getX(), otherX - 1),
						getMove(c.getY(), otherY + 1));
			}
		}
		c.faceUpdate(c.followId + 32768);
	}
	/*OBJECT TYPES:

0	- straight walls, fences etc
1	- diagonal walls corner, fences etc connectors
2	- entire walls, fences etc corners
3	- straight wall corners, fences etc connectors
4	- straight inside wall decoration
5	- straight outside wall decoration
6	- diagonal outside wall decoration
7	- diagonal inside wall decoration
8	- diagonal in wall decoration
9	- diagonal walls, fences etc
10	- all kinds of objects, trees, statues, signs, fountains etc etc
11	- ground objects like daisies etc
12	- straight sloped roofs
13	- diagonal sloped roofs
14	- diagonal slope connecting roofs
15	- straight sloped corner connecting roofs
16	- straight sloped corner roof
17	- straight flat top roofs
18	- straight bottom egde roofs
19	- diagonal bottom edge connecting roofs
20	- straight bottom edge connecting roofs
21	- straight bottom edge connecting corner roofs
22	- ground decoration + map signs (quests, water fountains, shops etc)*/
	public void openTrapdoor(int oldtrapdoorid, int newtrapdoorid, int type, int face){
		new Object(newtrapdoorid, c.objectX, c.objectY, 0, face, type, oldtrapdoorid, 100);
	}	
	public void PassGate(int oldGateId, int newGateId, int type, int face, int objX, int objY){
		new Object(newGateId, objX, objY, 0, face, type, oldGateId, 5);
	}
	public void followNpc() {
		NPC npc = NPCHandler.npcs[c.followId2];
		if (npc == null || npc.isDead) {
			return;
		}
		int x = NPCHandler.npcs[c.followId2].getX();
		int y = NPCHandler.npcs[c.followId2].getY();
		if (!c.goodDistance(x, y, c.getX(), c.getY(), 25)) {
			c.followId2 = 0;
			resetFollow();
			return;
		}
		boolean withinDistance = c.goodDistance(x, y, c.getX(),
				c.getY(), 1+NPCHandler.npcSize(c.followId2));
		c.goodDistance(x, y, c.getX(),
				c.getY(), 1+NPCHandler.npcSize(c.followId2));
		boolean hallyDistance = c.goodDistance(x, y, c.getX(),
				c.getY(), 2);
		boolean bowDistance = c.goodDistance(x, y, c.getX(),
				c.getY(), 8);
		boolean BpDistance = c.goodDistance(x, y, c.getX(),
				c.getY(), 6);
		boolean rangeWeaponDistance = c.goodDistance(x, y, c.getX(),
				c.getY(), 4);
		boolean sameSpot = c.absX == x && c.absY == y;
		if(c.playerEquipment[c.playerWeapon] == 12926 && BpDistance)
			return;
		if ((c.usingBow || c.mageFollow || (c.npcIndex > 0 && c.autocastId > 0))
				&& bowDistance && !sameSpot) {
			return;
		}

		if (c.getCombat().usingHally() && hallyDistance && !sameSpot) {
			return;
		}

		if (c.usingRangeWeapon && rangeWeaponDistance && !sameSpot) {
			return;
		}
		int[] follow = getFollowLocation(x, y);
		c.faceUpdate(c.followId2);
		PathFinder.getPathFinder().findRoute(c, follow[0], follow[1], false, 1, 1);
	}
	public int[] getFollowLocation(int x, int y) {
		int[] nonDiags = {0, 2, 4, 6};
		int[][] nodes = {
				{ x + Misc.directionDeltaX[nonDiags[0]], y + Misc.directionDeltaY[nonDiags[0]] },
				{ x + Misc.directionDeltaX[nonDiags[1]], y + Misc.directionDeltaY[nonDiags[1]] },
				{ x + Misc.directionDeltaX[nonDiags[2]], y + Misc.directionDeltaY[nonDiags[2]] },
				{ x + Misc.directionDeltaX[nonDiags[3]], y + Misc.directionDeltaY[nonDiags[3]] }
		};

		int bestX = 0;
		int bestY = 0;
		double bestDist = 99999;

		boolean projectile = c.usingMagic || c.usingBow || c.usingRangeWeapon || c.playerEquipment[c.playerWeapon] == 12926;

		for (int i = 0; i < nodes.length; i++) {
			double dist = Misc.distance(c.absX, c.absY, nodes[i][0], nodes[i][1]);
			if (dist < bestDist) {
				if (PathFinder.getPathFinder().accessible(c.absX, c.absY, c.heightLevel, nodes[i][0], nodes[i][1])) {
					if (!projectile || PathFinder.isProjectilePathClear(nodes[i][0], nodes[i][1], c.heightLevel, x, y)) {
						bestDist = dist;
						bestX = nodes[i][0];
						bestY = nodes[i][1];
					}
				}
			}
		}

		if (bestX == 0 && bestY == 0) {
			bestX = x;
			bestY = y;
		}

		return new int[] {bestX, bestY};
	}
	public void playerWalk(int x, int y) {
		PathFinder.getPathFinder().findRoute(c, x, y, true, 1, 1);
	}
	public int getRunningMove(int i, int j) {
		if (j - i > 2)
			return 2;
		else if (j - i < -2)
			return -2;
		else
			return j - i;
	}

	public void resetFollow() {
		c.followId = 0;
		c.followId2 = 0;
		c.mageFollow = false;
	}
	public void LoginInfo(int DaysSinceRecovChange, int unreadMessages, int members, int i, int daysSinceLastLogin, int playersOnline) {
		//c.followId = 0;
		//c.followId2 = 0;
		//c.mageFollow = false;
		c.outStream.createFrame(176);
		c.outStream.writeByteC(DaysSinceRecovChange);
		c.outStream.writeWordBigEndian(unreadMessages);
		c.outStream.writeByte(members);
		c.outStream.writeDWord(i);
		c.outStream.writeWord(daysSinceLastLogin);
		c.outStream.writeWord(playersOnline);
	}
	public void sendRuneTypes(int runeType1, int runeType2, int runeType3, int runeAMT1, int runeAMT2, int runeAMT3) {

		c.outStream.createFrame(172);
		c.outStream.writeWord(runeType1);
		c.outStream.writeWord(runeType2);
		c.outStream.writeWord(runeType3);
		c.outStream.writeWord(runeAMT1);
		c.outStream.writeWord(runeAMT2);
		c.outStream.writeWord(runeAMT3);
	}
public void sendAchieveProgress(int area, int tier, int updated) {
    c.outStream.createFrame(173);
    
    // Write the area and tier
    c.outStream.writeByte(area);
    c.outStream.writeByte(tier);
    
    // Write the updated status
    c.outStream.writeByte(updated);
}


	public void walkTo(int i, int j) {
		c.newWalkCmdSteps = 0;
		if (++c.newWalkCmdSteps > 50)
			c.newWalkCmdSteps = 0;
		int k = c.getX() + i;
		k -= c.mapRegionX * 8;
		c.getNewWalkCmdX()[0] = c.getNewWalkCmdY()[0] = 0;
		int l = c.getY() + j;
		l -= c.mapRegionY * 8;

		for (int n = 0; n < c.newWalkCmdSteps; n++) {
			c.getNewWalkCmdX()[n] += k;
			c.getNewWalkCmdY()[n] += l;
		}
	}

	public void walkTo2(int i, int j) {
		if (c.freezeDelay > 0)
			return;
		c.newWalkCmdSteps = 0;
		if (++c.newWalkCmdSteps > 50)
			c.newWalkCmdSteps = 0;
		int k = c.getX() + i;
		k -= c.mapRegionX * 8;
		c.getNewWalkCmdX()[0] = c.getNewWalkCmdY()[0] = 0;
		int l = c.getY() + j;
		l -= c.mapRegionY * 8;

		for (int n = 0; n < c.newWalkCmdSteps; n++) {
			c.getNewWalkCmdX()[n] += k;
			c.getNewWalkCmdY()[n] += l;
		}
	}

	public void stopDiagonal(int otherX, int otherY) {
		if (c.freezeDelay > 0)
			return;
		c.newWalkCmdSteps = 1;
		int xMove = otherX - c.getX();
		int yMove = 0;
		if (xMove == 0)
			yMove = otherY - c.getY();
		/*
		 * if (!clipHor) { yMove = 0; } else if (!clipVer) { xMove = 0; }
		 */

		int k = c.getX() + xMove;
		k -= c.mapRegionX * 8;
		c.getNewWalkCmdX()[0] = c.getNewWalkCmdY()[0] = 0;
		int l = c.getY() + yMove;
		l -= c.mapRegionY * 8;

		for (int n = 0; n < c.newWalkCmdSteps; n++) {
			c.getNewWalkCmdX()[n] += k;
			c.getNewWalkCmdY()[n] += l;
		}

	}

	public void walkToCheck(int i, int j) {
		if (c.freezeDelay > 0)
			return;
		c.newWalkCmdSteps = 0;
		if (++c.newWalkCmdSteps > 50)
			c.newWalkCmdSteps = 0;
		int k = c.getX() + i;
		k -= c.mapRegionX * 8;
		c.getNewWalkCmdX()[0] = c.getNewWalkCmdY()[0] = 0;
		int l = c.getY() + j;
		l -= c.mapRegionY * 8;

		for (int n = 0; n < c.newWalkCmdSteps; n++) {
			c.getNewWalkCmdX()[n] += k;
			c.getNewWalkCmdY()[n] += l;
		}
	}

	public int getMove(int place1, int place2) {
		if (System.currentTimeMillis() - c.lastSpear < 4000)
			return 0;
		if ((place1 - place2) == 0) {
			return 0;
		} else if ((place1 - place2) < 0) {
			return 1;
		} else if ((place1 - place2) > 0) {
			return -1;
		}
		return 0;
	}

	public boolean fullVeracs() {
		return c.playerEquipment[c.playerHat] == 4753
				&& c.playerEquipment[c.playerChest] == 4757
				&& c.playerEquipment[c.playerLegs] == 4759
				&& c.playerEquipment[c.playerWeapon] == 4755;
	}

	public boolean fullGuthans() {
		return c.playerEquipment[c.playerHat] == 4724
				&& c.playerEquipment[c.playerChest] == 4728
				&& c.playerEquipment[c.playerLegs] == 4730
				&& c.playerEquipment[c.playerWeapon] == 4726;
	}
	public void chatbox(int i1) {
		if (c.getOutStream() != null && c != null) {
			c.outStream.createFrame(218);
			c.outStream.writeWordBigEndianA(i1);
			c.updateRequired = true;
			c.setAppearanceUpdateRequired(true);
		}
	}
	/**
	 * reseting animation
	 **/
	public void resetAnimation() {
		c.getCombat().getPlayerAnimIndex(
				c.getItems().getItemName(c.playerEquipment[c.playerWeapon])
						.toLowerCase());
		c.startAnimation(c.playerStandIndex);
		requestUpdates();
	}
	public void setAnimationBack() {
		c.isRunning = true;
		sendFrame36(173,1);
		c.getCombat().getPlayerAnimIndex(
				c.getItems().getItemName(c.playerEquipment[c.playerWeapon])
						.toLowerCase());
		requestUpdates();
	}
	public void requestUpdates() {
		sendFrame107(); // reset screen
		c.updateRequired = true;
		c.setAppearanceUpdateRequired(true);
		c.updateWalkEntities();
	}

	public void handleAlt(int id) {
		if (!c.getItems().playerHasItem(id)) {
			c.getItems().addItem(id, 1);
		}
	}
	public void firstTimeTutorial() {
		if (Config.TUTORIAL_ISLAND && c.tutorialProgress == 0) {
			c.getItems().deleteAllItems();
			c.getPA().hideAllSideBars();
			c.getPA().movePlayer(3094, 3107, 0);
			c.getDH().sendDialogues(3000, -1);
			c.tutorialProgress = 0;
			c.isRunning2 = false;
			c.autoRet = 1;
			sendAutoRetalitate();
			ChangeAppearance();
			//LightSources.saveBrightness(player);
		} else if (c.tutorialProgress == 0 && !Config.TUTORIAL_ISLAND) {
			c.sendSidebars();
			c.getPA().removeHintIcon(c);
			c.getPA().walkableInterface(-1);
			c.getPA().chatbox(-1);
			c.getItems().deleteAllItems();
			//c.getItems().clearBank();
			addStarter();
			c.getPA().movePlayer(3233, 3229, 0);
			c.sendMessage("Welcome to @blu@" + Config.SERVER_NAME + "@bla@ - we are currently in Server Stage v@blu@" + Config.CLIENT_VERSION + "@bla@.");
			//c.getDH().sendDialogues(3115, 2224);
			c.isRunning2 = false;
			c.autoRet = 1;
			sendAutoRetalitate();
			//LightSources.saveBrightness(player);
			//if (!player.hasBankpin) {
				c.sendMessage("You do not, have a bank pin it is highly recommended you set one.");
			//}
		}
	}		
	public static void removeHintIcon(Client c) {
		c.getPA().drawHeadicon(0, 0, 0, 0);
	}
	public void sendAutoRetalitate() {
		c.getPA().sendConfig(172, c.autoRet == 1 ? 0 : 1);
	}

	public void hideAllSideBars() {
		for (int i = 0; i < 17; i++) {
			c.setSidebarInterface(i, -1);
		}
		c.setSidebarInterface(10, 2449);
	}
			DecimalFormat formatter = new DecimalFormat("#,###");
	public void levelUp(int skill) {
		int totalLevel = (getLevelForXP(c.playerXP[0])
				+ getLevelForXP(c.playerXP[1]) + getLevelForXP(c.playerXP[2])
				+ getLevelForXP(c.playerXP[3]) + getLevelForXP(c.playerXP[4])
				+ getLevelForXP(c.playerXP[5]) + getLevelForXP(c.playerXP[6])
				+ getLevelForXP(c.playerXP[7]) + getLevelForXP(c.playerXP[8])
				+ getLevelForXP(c.playerXP[9]) + getLevelForXP(c.playerXP[10])
				+ getLevelForXP(c.playerXP[11]) + getLevelForXP(c.playerXP[12])
				+ getLevelForXP(c.playerXP[13]) + getLevelForXP(c.playerXP[14])
				+ getLevelForXP(c.playerXP[15]) + getLevelForXP(c.playerXP[16])
				+ getLevelForXP(c.playerXP[17]) + getLevelForXP(c.playerXP[18])
				+ getLevelForXP(c.playerXP[19]) + getLevelForXP(c.playerXP[20])
				+ getLevelForXP(c.playerXP[21]) + getLevelForXP(c.playerXP[22]));
		int p = c.playerXP[0] + c.playerXP[1] + c.playerXP[2] + c.playerXP[3] + c.playerXP[4] + c.playerXP[5] + c.playerXP[6] + c.playerXP[7] + 
					c.playerXP[8] + c.playerXP[9] + c.playerXP[10] + c.playerXP[11] + c.playerXP[12] + c.playerXP[13] + c.playerXP[14] + c.playerXP[15] + 
					c.playerXP[16] + c.playerXP[17] + c.playerXP[18] + c.playerXP[19] + c.playerXP[20] + c.playerXP[21] + c.playerXP[22];
			c.totalEXP = p;
			// Create a DecimalFormat instance with comma formatting

			// Format the totalEXP with commas
			String formattedTotalEXP = formatter.format(c.totalEXP);
			sendFrame126(formattedTotalEXP, 55799);
			sendFrame126("" + c.combatLevel, 55804);
			sendFrame126("" + totalLevel, 55806);//c.combatLevel
			sendFrame126("Total level:\\n " + totalLevel, 27127);
		
		switch (skill) {
case 0:
			sendFrame126("Congratulations! You've just advanced a Attack level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+"!", 4269);
			c.sendMessage("Congratulations! You've just advanced a attack level.");	
			sendFrame164(6247);
			break;
			
			case 1:
            		sendFrame126("Congratulations! You've just advanced a Defence level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Defence level.");
			sendFrame164(6253);
			break;
			
			case 2:
            		sendFrame126("Congratulations! You've just advanced a Strength level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Strength level.");
			sendFrame164(6206);
			break;
			
			case 3:
            		sendFrame126("Congratulations! You've just advanced a Hitpoints level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Hitpoints level.");
			sendFrame164(6216);
			break;
			
			case 4:
            		sendFrame126("Congratulations! You've just advanced a Ranged level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Ranging level.");
			sendFrame164(4443);
			break;
			
			case 5:
            		sendFrame126("Congratulations! You've just advanced a Prayer level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Prayer level.");
			sendFrame164(6242);
			sendFrame126("" +c.playerLevel[5]+"/"+getLevelForXP(c.playerXP[5])+"", 687);//Prayer frame
			break;
			
			case 6:
            		sendFrame126("Congratulations! You've just advanced a Magic level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Magic level.");
			sendFrame164(6211);
			break;
			
			case 7:
            		sendFrame126("Congratulations! You've just advanced a Cooking level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Cooking level.");
			sendFrame164(6226);
			break;
			
			case 8:
			sendFrame126("Congratulations! You've just advanced a Woodcutting level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Woodcutting level.");
			sendFrame164(4272);
            		break;
			
            		case 9:
            		sendFrame126("Congratulations! You've just advanced a Fletching level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Fletching level.");
			sendFrame164(6231);
           		break;
			
			case 10:
            		sendFrame126("Congratulations! You've just advanced a Fishing level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Fishing level.");
			sendFrame164(6258);
			break;
			
			case 11:
			sendFrame126("Congratulations! You've just advanced a Fire making level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Fire making level.");
			sendFrame164(4282);
            		break;
			
            		case 12:
			sendFrame126("Congratulations! You've just advanced a Crafting level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Crafting level.");
			sendFrame164(6263);
            		break;
			
			case 13:
			sendFrame126("Congratulations! You've just advanced a Smithing level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Smithing level.");
			sendFrame164(6221);
			break;
			
			case 14:
			sendFrame126("Congratulations! You've just advanced a Mining level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Mining level.");
			sendFrame164(4416);
            		break;
			
			case 15:
            		sendFrame126("Congratulations! You've just advanced a Herblore level!", 4268);
            		sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Herblore level.");
			sendFrame164(6237);
            		break;
			
			case 16:
			sendFrame126("Congratulations! You've just advanced a Agility level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Agility level.");
			sendFrame164(4277);
           		break;
			
			case 17:
			sendFrame126("Congratulations! You've just advanced a Thieving level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
            		c.sendMessage("Congratulations! You've just advanced a Thieving level.");
			sendFrame164(4261);
			break;
			
			case 18:
			sendFrame126("Congratulations! You've just advanced a Slayer level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Slayer level.");
			sendFrame164(12122);
            		break;

            		case 19:
			sendFrame126("Congratulations! You've just advanced a Farming level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Farming level.");
			sendFrame164(5267);
           	 	break;
            
            		case 20:
			sendFrame126("Congratulations! You've just advanced a Runecrafting level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Runecrafting level.");
			sendFrame164(4267);
           	 	break;
            		case 21:
			sendFrame126("Congratulations! You've just advanced a Construction level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Construction level.");
			sendFrame164(7267);
           	 	break;
            		case 22:
			sendFrame126("Congratulations! You've just advanced a Hunter level!", 4268);
			sendFrame126("You have now reached level "+getLevelForXP(c.playerXP[skill])+".", 4269);
			c.sendMessage("Congratulations! You've just advanced a Hunter level.");
			sendFrame164(8267);
           	 	break;
		}
		c.dialogueAction = 0;
		c.nextChat = 0;
	}

	 public void resetlogCross(final Client c) {
		c.playerStandIndex = 0x328;
		c.playerTurnIndex = 0x337;
		c.playerWalkIndex = 0x333;
		c.getPA().requestUpdates();
	 }
	public void refreshSkill(int i) {
		int totalLevel = (getLevelForXP(c.playerXP[0])
				+ getLevelForXP(c.playerXP[1]) + getLevelForXP(c.playerXP[2])
				+ getLevelForXP(c.playerXP[3]) + getLevelForXP(c.playerXP[4])
				+ getLevelForXP(c.playerXP[5]) + getLevelForXP(c.playerXP[6])
				+ getLevelForXP(c.playerXP[7]) + getLevelForXP(c.playerXP[8])
				+ getLevelForXP(c.playerXP[9]) + getLevelForXP(c.playerXP[10])
				+ getLevelForXP(c.playerXP[11]) + getLevelForXP(c.playerXP[12])
				+ getLevelForXP(c.playerXP[13]) + getLevelForXP(c.playerXP[14])
				+ getLevelForXP(c.playerXP[15]) + getLevelForXP(c.playerXP[16])
				+ getLevelForXP(c.playerXP[17]) + getLevelForXP(c.playerXP[18])
				+ getLevelForXP(c.playerXP[19]) + getLevelForXP(c.playerXP[20])
				+ getLevelForXP(c.playerXP[21]) + getLevelForXP(c.playerXP[22]));
		int p = c.playerXP[0] + c.playerXP[1] + c.playerXP[2] + c.playerXP[3] + c.playerXP[4] + c.playerXP[5] + c.playerXP[6] + c.playerXP[7] + 
					c.playerXP[8] + c.playerXP[9] + c.playerXP[10] + c.playerXP[11] + c.playerXP[12] + c.playerXP[13] + c.playerXP[14] + c.playerXP[15] + 
					c.playerXP[16] + c.playerXP[17] + c.playerXP[18] + c.playerXP[19] + c.playerXP[20] + c.playerXP[21] + c.playerXP[22];
			c.totalEXP = p;
			// Create a DecimalFormat instance with comma formatting
			DecimalFormat formatter = new DecimalFormat("#,###");

			// Format the totalEXP with commas
			String formattedTotalEXP = formatter.format(c.totalEXP);
			sendFrame126(formattedTotalEXP, 55799);
			sendFrame126("" + c.combatLevel, 55804);
			sendFrame126("" + totalLevel, 55806);//c.combatLevel
			sendFrame126("Total level:\\n " + totalLevel, 27127);
		switch (i) {
		case 0://attack
			sendFrame126("" + c.playerLevel[0] + "", 27159);
			sendFrame126("" + getLevelForXP(c.playerXP[0]) + "", 27160);
			sendFrame126("" + c.playerXP[0] + "", 4044);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[0]) + 1)
					+ "", 4045);
			break;

		case 1://defense
			sendFrame126("" + c.playerLevel[1] + "", 27161);
			sendFrame126("" + getLevelForXP(c.playerXP[1]) + "", 27162);
			sendFrame126("" + c.playerXP[1] + "", 4056);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[1]) + 1)
					+ "", 4057);
			break;

		case 2://strength
			sendFrame126("" + c.playerLevel[2] + "", 27163);
			sendFrame126("" + getLevelForXP(c.playerXP[2]) + "", 27164);
			sendFrame126("" + c.playerXP[2] + "", 4050);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[2]) + 1)
					+ "", 4051);
			break;

		case 3://hitpoints
			sendFrame126("" + c.playerLevel[3] + "", 27175);
			sendFrame126("" + getLevelForXP(c.playerXP[3]) + "", 27176);
			sendFrame126("" + c.playerXP[3] + "", 4080);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[3]) + 1)
					+ "", 4081);
			break;

		case 4://ranged
		
			sendFrame126("" + c.playerLevel[4] + "", 27165);
			sendFrame126("" + getLevelForXP(c.playerXP[4]) + "", 27166);
			sendFrame126("" + c.playerXP[4] + "", 4062);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[4]) + 1)
					+ "", 4063);
			break;

		case 5://prayer
			sendFrame126("" + c.playerLevel[5] + "", 27167);
			sendFrame126("" + getLevelForXP(c.playerXP[5]) + "", 27168);
			sendFrame126("" + c.playerXP[5] + "", 4068);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[5]) + 1)
					+ "", 4069);
			sendFrame126("" + c.playerLevel[5] + "/"
					+ getLevelForXP(c.playerXP[5]) + "", 687);// Prayer frame
			break;

		case 6://magic
			sendFrame126("" + c.playerLevel[6] + "", 27171);
			sendFrame126("" + getLevelForXP(c.playerXP[6]) + "", 27172);
			sendFrame126("" + c.playerXP[6] + "", 4074);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[6]) + 1)
					+ "", 4075);
			break;

		case 7://cooking
			sendFrame126("" + c.playerLevel[7] + "", 27197);
			sendFrame126("" + getLevelForXP(c.playerXP[7]) + "", 27198);
			sendFrame126("" + c.playerXP[7] + "", 4134);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[7]) + 1)
					+ "", 4135);
			break;

		case 8://woodcut
			sendFrame126("" + c.playerLevel[8] + "", 27201);
			sendFrame126("" + getLevelForXP(c.playerXP[8]) + "", 27202);
			sendFrame126("" + c.playerXP[8] + "", 4146);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[8]) + 1)
					+ "", 4147);
			break;

		case 9://fletching
			sendFrame126("" + c.playerLevel[9] + "", 27185);
			sendFrame126("" + getLevelForXP(c.playerXP[9]) + "", 27186);
			sendFrame126("" + c.playerXP[9] + "", 4110);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[9]) + 1)
					+ "", 4111);
			break;

		case 10://fishing
			sendFrame126("" + c.playerLevel[10] + "", 27195);
			sendFrame126("" + getLevelForXP(c.playerXP[10]) + "", 27196);
			sendFrame126("" + c.playerXP[10] + "", 4128);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[10]) + 1)
					+ "", 4129);
			break;

		case 11://firemaking
			sendFrame126("" + c.playerLevel[11] + "", 27199);
			sendFrame126("" + getLevelForXP(c.playerXP[11]) + "", 27200);
			sendFrame126("" + c.playerXP[11] + "", 4140);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[11]) + 1)
					+ "", 4141);
			break;

		case 12://crafting
			sendFrame126("" + c.playerLevel[12] + "", 27183);
			sendFrame126("" + getLevelForXP(c.playerXP[12]) + "", 27184);
			sendFrame126("" + c.playerXP[12] + "", 4104);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[12]) + 1)
					+ "", 4105);
			break;

		case 13://smithing
			sendFrame126("" + c.playerLevel[13] + "", 27193);
			sendFrame126("" + getLevelForXP(c.playerXP[13]) + "", 27194);
			sendFrame126("" + c.playerXP[13] + "", 4122);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[13]) + 1)
					+ "", 4123);
			break;

		case 14://mining
			sendFrame126("" + c.playerLevel[14] + "", 27191);
			sendFrame126("" + getLevelForXP(c.playerXP[14]) + "", 27192);
			sendFrame126("" + c.playerXP[14] + "", 4116);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[14]) + 1)
					+ "", 4117);
			break;

		case 15://herblore
			sendFrame126("" + c.playerLevel[15] + "", 27179);
			sendFrame126("" + getLevelForXP(c.playerXP[15]) + "", 27180);
			sendFrame126("" + c.playerXP[15] + "", 4092);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[15]) + 1)
					+ "", 4093);
			break;

		case 16://agility
			sendFrame126("" + c.playerLevel[16] + "", 27177);
			sendFrame126("" + getLevelForXP(c.playerXP[16]) + "", 27178);
			sendFrame126("" + c.playerXP[16] + "", 4086);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[16]) + 1)
					+ "", 4087);
			break;

		case 17://theiving
			sendFrame126("" + c.playerLevel[17] + "", 27181);
			sendFrame126("" + getLevelForXP(c.playerXP[17]) + "", 27182);
			sendFrame126("" + c.playerXP[17] + "", 4098);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[17]) + 1)
					+ "", 4099);
			break;

		case 18://slayer
			sendFrame126("" + c.playerLevel[18] + "", 27187);
			sendFrame126("" + getLevelForXP(c.playerXP[18]) + "", 27188);
			sendFrame126("" + c.playerXP[18] + "", 12171);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[18]) + 1)
					+ "", 12172);
			break;

		case 19://farming
			sendFrame126("" + c.playerLevel[19] + "", 27189);
			sendFrame126("" + getLevelForXP(c.playerXP[19]) + "", 27190);
			sendFrame126("" + c.playerXP[19] + "", 13921);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[19]) + 1)
					+ "", 13922);
			break;

		case 20:
			sendFrame126("" + c.playerLevel[20] + "", 27173);
			sendFrame126("" + getLevelForXP(c.playerXP[20]) + "", 27174);
			sendFrame126("" + c.playerXP[20] + "", 4157);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[20]) + 1)
					+ "", 4158);
			break;
		case 21:
			sendFrame126("" + c.playerLevel[21] + "", 27157);
			sendFrame126("" + getLevelForXP(c.playerXP[21]) + "", 27158);
			sendFrame126("" + c.playerXP[21] + "", 4157);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[21]) + 1)
					+ "", 4158);
			break;
		case 22:
			sendFrame126("" + c.playerLevel[22] + "", 27169);
			sendFrame126("" + getLevelForXP(c.playerXP[22]) + "", 27170);
			sendFrame126("" + c.playerXP[22] + "", 4157);
			sendFrame126("" + getXPForLevel(getLevelForXP(c.playerXP[22]) + 1)
					+ "", 4158);
			break;
		}
	}

	public int getXPForLevel(int level) {
		int points = 0;
		int output = 0;

		for (int lvl = 1; lvl <= level; lvl++) {
			points += Math.floor((double) lvl + 300.0
					* Math.pow(2.0, (double) lvl / 7.0));
			if (lvl >= level)
				return output;
			output = (int) Math.floor(points / 4);
		}
		return 0;
	}

	public int getLevelForXP(int exp) {
		int points = 0;
		int output = 0;
		if (exp > 13034430)
			return 99;
		for (int lvl = 1; lvl <= 99; lvl++) {
			points += Math.floor((double) lvl + 300.0
					* Math.pow(2.0, (double) lvl / 7.0));
			output = (int) Math.floor(points / 4);
			if (output >= exp) {
				return lvl;
			}
		}
		return 0;
	}

	public boolean addSkillXP(int amount, int skill) {
		if (amount + c.playerXP[skill] < 0 || c.playerXP[skill] > 200000000) {
			if (c.playerXP[skill] > 200000000) {
				c.playerXP[skill] = 200000000;
			}
			return false;
		}
		amount *= Config.SERVER_EXP_BONUS;
		int oldLevel = getLevelForXP(c.playerXP[skill]);
		c.playerXP[skill] += amount;
		if (oldLevel < getLevelForXP(c.playerXP[skill])) {
			if (c.playerLevel[skill] < c.getLevelForXP(c.playerXP[skill])
					&& skill != 3 && skill != 5)
				c.playerLevel[skill] = c.getLevelForXP(c.playerXP[skill]);
			levelUp(skill);
			//c.gfx100(199);
			requestUpdates();
		}
		setSkillLevel(skill, c.playerLevel[skill], c.playerXP[skill]);
		refreshSkill(skill);
		return true;
	}
	public int getLevel(Skill skill) {
        return c.playerLevel[skill.ordinal()];
    }
	public int getSkillCurrentLevel(int skill) {
			return c.playerLevel[skill];
		}
	public int getXP(int skill) {
			return c.playerXP[skill];
		}
	public void resetBarrows() {
		c.barrowsNpcs[0][1] = 0;
		c.barrowsNpcs[1][1] = 0;
		c.barrowsNpcs[2][1] = 0;
		c.barrowsNpcs[3][1] = 0;
		c.barrowsNpcs[4][1] = 0;
		c.barrowsNpcs[5][1] = 0;
		c.barrowsKillCount = 0;
		c.randomCoffin = Misc.random(3) + 1;
	}
	public static void displayReward(Client c, int item, int amount, int item2, int amount2, int item3, int amount3, int item4, int amount4, int item5, int amount5) {
		int[] items = {
			item, item2, item3, item4, item5
		};
		int[] amounts = {
			amount, amount2, amount3,	amount4,	amount5
		};
		c.outStream.createFrameVarSizeWord(53);
		c.outStream.writeWord(6963);
		c.outStream.writeWord(items.length);
		for(int i = 0; i < items.length; i++) {
			if(c.playerItemsN[i] > 254) {
				c.outStream.writeByte(255);
				c.outStream.writeDWord_v2(amounts[i]);
			} else {
				c.outStream.writeByte(amounts[i]);
			}
			if(items[i] > 0) {
				c.outStream.writeWordBigEndianA(items[i] + 1);
			} else {
				c.outStream.writeWordBigEndianA(0);
			}
		}
		c.outStream.endFrameVarSizeWord();
		c.flushOutStream();
		c.getItems().addItem(item, amount);
		c.getItems().addItem(item2, amount2);
		c.getItems().addItem(item3, amount3);
		c.getPA().showInterface(6960);
	}	
	public static void displayChestReward(Client c, int item, int amount, int item2, int amount2, int item3, int amount3, int item4, int amount4, int item5, int amount5) {
		int[] items = {
			item, item2, item3, item4, item5
		};
		int[] amounts = {
			amount, amount2, amount3,	amount4,	amount5
		};
		c.outStream.createFrameVarSizeWord(53);
		c.outStream.writeWord(6963);
		c.outStream.writeWord(items.length);
		for(int i = 0; i < items.length; i++) {
			if(c.playerItemsN[i] > 254) {
				c.outStream.writeByte(255);
				c.outStream.writeDWord_v2(amounts[i]);
			} else {
				c.outStream.writeByte(amounts[i]);
			}
			if(items[i] > 0) {
				c.outStream.writeWordBigEndianA(items[i] + 1);
			} else {
				c.outStream.writeWordBigEndianA(0);
			}
		}
		c.outStream.endFrameVarSizeWord();
		c.flushOutStream();
		c.getItems().addItem(item, amount);
		c.getItems().addItem(item2, amount2);
		c.getItems().addItem(item3, amount3);
		c.getPA().showInterface(6960);
	}	
	public static void itemOnInterface(Client c, int frame, int slot, int id,
			int amount) {
		c.outStream.createFrameVarSizeWord(34);
		c.outStream.writeWord(frame);
		c.outStream.writeByte(slot);
		c.outStream.writeWord(id + 1);
		c.outStream.writeByte(255);
		c.outStream.writeDWord(amount);
		c.outStream.endFrameVarSizeWord();
	}
		/*public static void sendUpdateItems(Client c, int frame, int[] items) {
		c.outStream.createFrameVarSizeWord(53);
		c.outStream.writeWord(frame);
		c.outStream.writeWord(items.length);
		int[] var6 = items;
		for (int i = 0; i < items.length; i++) {
			int item = var6[i];
				if (c.getItems().getItemAmount(item) > 254) {
					c.outStream.writeByte(255);
					c.outStream.writeDWord_v2(1);
				} else {
					c.outStream.writeByte(1);
				}

				c.outStream.writeWordBigEndianA(item);
		}
	}*/
	public static void displayReward(Client c, int item, int amount, int item2, int amount2, int item3, int amount3) {
		int[] items = {
			item, item2, item3
		};
		int[] amounts = {
			amount, amount2, amount3
		};
		c.outStream.createFrameVarSizeWord(53);
		c.outStream.writeWord(6963);
		c.outStream.writeWord(items.length);
		for(int i = 0; i < items.length; i++) {
			if(c.playerItemsN[i] > 254) {
				c.outStream.writeByte(255);
				c.outStream.writeDWord_v2(amounts[i]);
			} else {
				c.outStream.writeByte(amounts[i]);
			}
			if(items[i] > 0) {
				c.outStream.writeWordBigEndianA(items[i] + 1);
			} else {
				c.outStream.writeWordBigEndianA(0);
			}
		}
		c.outStream.endFrameVarSizeWord();
		c.flushOutStream();
		c.getItems().addItem(item, amount);
		c.getItems().addItem(item2, amount2);
		c.getItems().addItem(item3, amount3);
		c.getPA().showInterface(6960);
	}
	public static int Barrows[] = { 4708, 4710, 4712, 4714, 4716, 4718, 4720,
			4722, 4724, 4726, 4728, 4730, 4732, 4734, 4736, 4738, 4745, 4747,
			4749, 4751, 4753, 4755, 4757, 4759 };
	public static int Bandos[] = { 11704, 11710, 11712, 11714, 11724, 11726, 11728};
	public static int sharedClueRewards[] = {3827,3828,3829,3830,3831,3832,3833,3834,3835,3836,3837,3838,3839,10476,995,7329,7330,73331 };
	public static int commonEasyClueRewards[] = {1165,1125,1089,1077,1133,1169,1097,1367,1361,1381,1297,1269,1273,1217,847,849,10366,10280 };
		public static int EasyClue[] = {
        2587,
        2583,
        2585, 
        3668, 
        2589,
        2595,
        2591,
        2593,
        3669, 
        2597,
        10665, 
        10668,
        10671,
        10674,
        10677,
        10699, 
        10700, 
        10701, 
        10702, 
        10703, 
        7362, 
        7366, 
        7364,
        7368,
        7394, 
        7390,
        7386, 
        7396,
        7392,
        7388, 
        10458, 
        10464, 
        10462, 
        10466,
        10460, 
        10468, 
        10316,
        10318,
        10320,
        10322,
        10324, 
        2631,
        2633,
        2635, 
        2637,
        10392,
        10398,
        10396,
        10404,
        10424,
        10406,
        10426,
        10412,
        10432, 
        10414,
        10434,
        10408,
        10428,
        10410,
        10430,
        10366,
        10280 };
	public static int Runes[] = { 4740, 558, 560, 565 };
	public static int Pots[] = {};

	public int randomBarrows() {
		return Barrows[(int) (Math.random() * Barrows.length)];
	}	
	public int randomBandos() {
		return Bandos[(int) (Math.random() * Bandos.length)];
	}
	public int randomEasyItem() {
		return EasyClue[(int) (Math.random() * EasyClue.length)];
	}

	public int randomCommonEasyItem() {
		return commonEasyClueRewards[(int) (Math.random() * commonEasyClueRewards.length)];
	}
	public int randomSharedItem() {
		return sharedClueRewards[(int) (Math.random() * sharedClueRewards.length)];
	}
	public int randomRunes() {
		return Runes[(int) (Math.random() * Runes.length)];
	}

	public int randomPots() {
		return Pots[(int) (Math.random() * Pots.length)];
	}
				public void CollLogPopUp(int[][] bossCollectionLog, int itemID, int amount) {
					String itemName = c.getItems().getItemName(itemID);
					// check if the collection log amount is 0, if it is continue
					if(c.getCollectionLog().getCollectionLogItemAmount(bossCollectionLog, itemID) == 0 && c.CollLogTimer == 0){
						c.remainingTime = System.currentTimeMillis();
						c.CollLogTimer = 15000;
						c.newCollItem = true;
						sendFrame126("@whi@" + itemName , 18034);
						c.sendMessage("New item added to your collection log: "+ itemName);
						//c.sendMessage("Collection log slot: completed."+ itemName);
					}
					else if(c.getCollectionLog().getCollectionLogItemAmount(bossCollectionLog, itemID) > 0){
						c.remainingTime = 0;
						c.CollLogTimer = 0;
						c.newCollItem = false;
						sendFrame126("" , 18034);
					}
						c.getCollectionLog().addBossLogItems(bossCollectionLog, itemID, amount); 
				}				


	public void CollLogPopUp() {
		if(c.CollLogTimer > 0) {
			long currentTime = System.currentTimeMillis();
			long elapsedTime = currentTime - c.remainingTime;
    
				while (elapsedTime >= 1000) {
					c.CollLogTimer -= 1000;
					elapsedTime -= 1000;
					c.remainingTime += 1000;
				}
				int VengSeconds = (int) ((c.CollLogTimer / 1000) % 60);
				sendFrame126("" +VengSeconds, 18035);
				System.out.println("timer:" + VengSeconds);

			if(VengSeconds == 0){
				c.CollLogTimer = 0;
				c.remainingTime = 0;
				sendFrame126("" , 18034);
				sendFrame126("0", 18035);
			}
		}
	}
	/**
	 * Show an arrow icon on the selected player.
	 * 
	 * @Param i - Either 0 or 1; 1 is arrow, 0 is none.
	 * @Param j - The player/Npc that the arrow will be displayed above.
	 * @Param k - Keep this set as 0
	 * @Param l - Keep this set as 0
	 */
	public void drawHeadicon(int i, int j, int k, int l) {
		// synchronized(c) {
		c.outStream.createFrame(254);
		c.outStream.writeByte(i);

		if (i == 1 || i == 10) {
			c.outStream.writeWord(j);
			c.outStream.writeWord(k);
			c.outStream.writeByte(l);
		} else {
			c.outStream.writeWord(k);
			c.outStream.writeWord(l);
			c.outStream.writeByte(j);
		}
	}

	public int getNpcId(int id) {
		for (int i = 0; i < NPCHandler.maxNPCs; i++) {
			if (NPCHandler.npcs[i] != null) {
				if (NPCHandler.npcs[i].npcId == id) {
					return i;
				}
			}
		}
		return -1;
	}

	public void removeObject(int x, int y) {
		object(-1, x, x, 10, 10);
	}

	private void objectToRemove(int X, int Y) {
		object(-1, X, Y, 10, 10);
	}

	private void objectToRemove2(int X, int Y) {
		object(-1, X, Y, -1, 0);
	}

	public void removeObjects() {
		objectToRemove(2638, 4688);
		objectToRemove2(2635, 4693);
		objectToRemove2(2634, 4693);
	}

	public void handleGlory(int gloryId) {
		c.getDH().sendOption4("Edgeville", "Al Kharid", "Karamja", "Draynor");
		c.usingGlory = true;
	}
	public void handleArdyCloak(int gloryId) {
		if(c.ArdyDiaryEasy == 0) {
			c.sendMessage("You must complete the Ardougne easy achievement diaries to teleport!");	
		} else if(c.ArdyDiaryEasy == 10 && c.ArdyDiaryMed == 10) {
			c.getDH().sendOption2("Ardougne Monastery", "Cancel");
		} else
			c.getDH().sendOption2("Ardougne Monastery", "Ardougne farm");
		
		c.usingCloak = true;
	}
	public void handleObjectRegion(int objectId, int minX, int minY, int maxX, int maxY) {
		for (int i = minX; i < maxX+1; i++) {
			for (int j = minY; j < maxY+1; j++) {
				c.getPA().object(objectId, i, j, -1, 10);
			}
		}
	}
	
	public boolean itemUsedInRegion(int minX, int maxX, int minY, int maxY) {
		return (c.objectX >= minX && c.objectX <= maxX) && (c.objectY >= minY && c.objectY <= maxY);
	}
	public void resetVariables() {
		c.getCrafting().resetCrafting();
		c.usingGlory = false;
		c.smeltInterface = false;
		c.openLootBag = false;
		c.addingToRP = false;
		c.addingCharges = false;
		c.smeltType = 0;
		c.smeltAmount = 0;
	}

	public boolean inPitsWait() {
		return c.getX() <= 2404 && c.getX() >= 2394 && c.getY() <= 5175
				&& c.getY() >= 5169;
	}

	public void castleWarsObjects() {
		object(-1, 2373, 3119, -3, 10);
		object(-1, 2372, 3119, -3, 10);
	}

	public void removeFromCW() {
		if (c.castleWarsTeam == 1) {
			if (c.inCwWait) {
				Server.castleWars.saradominWait
						.remove(Server.castleWars.saradominWait
								.indexOf(c.playerId));
			} else {
				Server.castleWars.saradomin.remove(Server.castleWars.saradomin
						.indexOf(c.playerId));
			}
		} else if (c.castleWarsTeam == 2) {
			if (c.inCwWait) {
				Server.castleWars.zamorakWait
						.remove(Server.castleWars.zamorakWait
								.indexOf(c.playerId));
			} else {
				Server.castleWars.zamorak.remove(Server.castleWars.zamorak
						.indexOf(c.playerId));
			}
		}
	}

	public int antiFire() {
		int toReturn = 0;
		if (c.antiFirePot)
			toReturn++;
		if (c.playerEquipment[c.playerShield] == 1540 || c.prayerActive[12]
				|| c.playerEquipment[c.playerShield] == 11284)
			toReturn++;
		return toReturn;
	}

	public boolean checkForFlags() {
		int[][] itemsToCheck = { { 995, 100000000 }, { 35, 5 }, { 667, 5 },
				{ 2402, 5 }, { 746, 5 }, { 4151, 150 }, { 565, 100000 },
				{ 560, 100000 }, { 555, 300000 }, { 11235, 10 } };
		for (int j = 0; j < itemsToCheck.length; j++) {
			if (itemsToCheck[j][1] < c.getItems().getTotalCount(
					itemsToCheck[j][0]))
				return true;
		}
		return false;
	}

	public void ChangeAppearance() {
		c.getPA().showInterface(3559);
		c.canChangeAppearance = true;
		//c.onTutorialIsland = true;
	}
	private static final int[][] STARTER_ITEMS = { { 1351, 1 }, { 590, 1 },
			{ 303, 1 }, { 315, 1 }, { 1925, 1 }, { 1931, 1 }, { 2309, 1 },
			{ 1265, 1 }, { 1205, 1 }, { 1277, 1 }, { 1171, 1 }, { 841, 1 },
			{ 882, 25 }, { 556, 25 }, { 558, 15 }, { 555, 6 }, { 557, 4 },
			{ 559, 2 } };

	public void addStarter() {
		for (int[] element : STARTER_ITEMS) {
			int item = element[0];
			int amount = element[1];
			c.getItems().addItem(item, amount);
		}
	}
	public int getWearingAmount() {
		int count = 0;
		for (int j = 0; j < c.playerEquipment.length; j++) {
			if (c.playerEquipment[j] > 0)
				count++;
		}
		return count;
	}

	public void useOperate(int itemId) {
		ItemDefinition def = ItemDefinition.forId(itemId);
		//Optional<DegradableItem> d = DegradableItem.forId(itemId);
		switch (itemId) {
		//	case 12904:
			//c.sendMessage("The toxic staff of the dead has " + c.getToxicStaffOfTheDeadCharge() + " charges remaining.");
			//break;
		case 13199:
		case 13197:
			c.sendMessage("The " + def.getName() + " has " + c.getSerpentineHelmCharge() + " charges remaining.");
			break;
		case 11907:
		case 12899:
			int charge = itemId == 11907 ? c.getTridentCharge() : c.getToxicTridentCharge();
			c.sendMessage("The " + def.getName() + " has " + charge + " charges remaining.");
			break;
		
		case 12926:
			def = ItemDefinition.forId(c.getToxicBlowpipeAmmo());
			c.sendMessage("The blowpipe has " + c.getToxicBlowpipeAmmoAmount() + " " + def.getName() + " and "
					+ c.getToxicBlowpipeCharge() + " charge remaining.");
			break;
		case 19675:
			c.sendMessage("Your Arclight has " + c.getArcLightCharge() + " charges remaining.");
			break;
		case 12931:
			def = ItemDefinition.forId(itemId);
			if (def == null) {
				return;
			}
			c.sendMessage("The " + def.getName() + " has " + c.getSerpentineHelmCharge() + " charge remaining.");
			break;
		case 1712:
		case 1710:
		case 1708:
		case 1706:
		case 19707:
			if (c.wildLevel > 30) {
				c.sendMessage("@cr10@You can not teleport above 30 wilderness.");
				return;
			}
			handleGlory(itemId);
			break;
		case 11283:
		case 11284:
			if (c.playerIndex > 0) {
				c.getCombat().handleDfs();
			} else if (c.npcIndex > 0) {
				c.getCombat().handleDfsNPC();
			}
			break;
			/*
		 * Crafting cape
		 */
		case 9780:
		case 9781:
			//startTeleport(2936, 3283, 0, "modern", false);
			break;
			/*
		 * Magic skillcape
		 */
		case 9762:
		case 9763:
			//if (!Boundary.isIn(c, Boundary.EDGEVILLE_PERIMETER)) {
			//	c.sendMessage("This cape can only be operated within the edgeville perimeter.");
			//	return;
			//}
			if (c.inWild()) {
				return;
			}
			if (c.playerMagicBook == 0) {
				c.playerMagicBook = 1;
				c.setSidebarInterface(6, 12855);
				c.autocasting = false;
				c.sendMessage("An ancient wisdomin fills your mind.");
				c.getPA().resetAutocast();
			} else if (c.playerMagicBook == 1) {
				c.sendMessage("You switch to the lunar spellbook.");
				c.setSidebarInterface(6, 29999);
				c.playerMagicBook = 2;
				c.autocasting = false;
				c.autocastId = -1;
				c.getPA().resetAutocast();
			} else if (c.playerMagicBook == 2) {
				c.setSidebarInterface(6, 1151);
				c.playerMagicBook = 0;
				c.autocasting = false;
				c.sendMessage("You feel a drain on your memory.");
				c.autocastId = -1;
				c.getPA().resetAutocast();
			}
			break;
		}
	}

	public void getSpeared(int otherX, int otherY) {
		int x = c.absX - otherX;
		int y = c.absY - otherY;
		if (x > 0)
			x = 1;
		else if (x < 0)
			x = -1;
		if (y > 0)
			y = 1;
		else if (y < 0)
			y = -1;
		moveCheck(x, y);
		c.lastSpear = System.currentTimeMillis();
	}

	public void moveCheck(int xMove, int yMove) {
		movePlayer(c.absX + xMove, c.absY + yMove, c.heightLevel);
	}

	public int findKiller() {
		int killer = c.playerId;
		int damage = 0;
		for (int j = 0; j < Config.MAX_PLAYERS; j++) {
			if (PlayerHandler.players[j] == null)
				continue;
			if (j == c.playerId)
				continue;
			if (c.goodDistance(c.absX, c.absY, PlayerHandler.players[j].absX,
					PlayerHandler.players[j].absY, 40)
					|| c.goodDistance(c.absX, c.absY + 9400,
							PlayerHandler.players[j].absX,
							PlayerHandler.players[j].absY, 40)
					|| c.goodDistance(c.absX, c.absY,
							PlayerHandler.players[j].absX,
							PlayerHandler.players[j].absY + 9400, 40))
				if (c.damageTaken[j] > damage) {
					damage = c.damageTaken[j];
					killer = j;
				}
		}
		return killer;
	}

	public void resetTzhaar() {
		c.waveId = -1;
		c.tzhaarToKill = -1;
		c.tzhaarKilled = -1;
		c.getPA().movePlayer(2438, 5168, 0);
	}

	public void enterCaves() {
		c.getPA().movePlayer(2413, 5117, c.playerId * 4);
		c.waveId = 0;
		c.tzhaarToKill = -1;
		c.tzhaarKilled = -1;
		Server.fightCaves.spawnNextWave(c);
	}

	public void appendPoison(int damage) {
		if (System.currentTimeMillis() - c.lastPoisonSip > c.poisonImmune) {
			c.sendMessage("You have been poisoned.");
			c.poisonDamage = damage;
		}
	}

	public boolean checkForPlayer(int x, int y) {
		for (Player p : PlayerHandler.players) {
			if (p != null) {
				if (p.getX() == x && p.getY() == y)
					return true;
			}
		}
		return false;
	}

	public void checkPouch(int i) {
		if (i < 0)
			return;
		c.sendMessage("This pouch has " + c.pouches[i] + " rune ess in it.");
	}

	public void fillPouch(int i) {
		if (i < 0)
			return;
		int toAdd = c.POUCH_SIZE[i] - c.pouches[i];
		if (toAdd > c.getItems().getItemAmount(1436)) {
			toAdd = c.getItems().getItemAmount(1436);
		}
		if (toAdd > c.POUCH_SIZE[i] - c.pouches[i])
			toAdd = c.POUCH_SIZE[i] - c.pouches[i];
		if (toAdd > 0) {
			c.getItems().deleteItem(1436, toAdd);
			c.pouches[i] += toAdd;
		}
	}

	public void emptyPouch(int i) {
		if (i < 0)
			return;
		int toAdd = c.pouches[i];
		if (toAdd > c.getItems().freeSlots()) {
			toAdd = c.getItems().freeSlots();
		}
		if (toAdd > 0) {
			c.getItems().addItem(1436, toAdd);
			c.pouches[i] -= toAdd;
		}
	}

	public void fixAllBarrows() {
		int totalCost = 0;
		int cashAmount = c.getItems().getItemAmount(995);
		for (int j = 0; j < c.playerItems.length; j++) {
			boolean breakOut = false;
			for (int i = 0; i < Config.brokenBarrows.length; i++) {
				if (c.playerItems[j] - 1 == Config.brokenBarrows[i][1]) {
					if (totalCost + 80000 > cashAmount) {
						breakOut = true;
						c.sendMessage("You have run out of money.");
						break;
					} else {
						totalCost += 80000;
					}
					c.playerItems[j] = Config.brokenBarrows[i][0] + 1;
				}
			}
			if (breakOut)
				break;
		}
		if (totalCost > 0)
			c.getItems().deleteItem(995, c.getItems().getItemSlot(995),
					totalCost);
	}

	public void handleLoginText() {
		c.getPA().sendFrame126("Monster Teleport", 13037);
		c.getPA().sendFrame126("Minigame Teleport", 13047);
		c.getPA().sendFrame126("Boss Teleport", 13055);
		c.getPA().sendFrame126("Pking Teleport", 13063);
		c.getPA().sendFrame126("Skill Teleport", 13071);
		c.getPA().sendFrame126("Monster Teleport", 1300);
		c.getPA().sendFrame126("Minigame Teleport", 1325);
		c.getPA().sendFrame126("Boss Teleport", 1350);
		c.getPA().sendFrame126("Pking Teleport", 1382);
		c.getPA().sendFrame126("Skill Teleport", 1415);
	}

	public void handleWeaponStyle() {
		if (c.fightMode == 0) {
			c.getPA().sendFrame36(43, c.fightMode);
		} else if (c.fightMode == 1) {
			c.getPA().sendFrame36(43, 3);
		} else if (c.fightMode == 2) {
			c.getPA().sendFrame36(43, 1);
		} else if (c.fightMode == 3) {
			c.getPA().sendFrame36(43, 2);
		}
	}

}
