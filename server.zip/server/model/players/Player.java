package server.model.players;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.jboss.netty.buffer.ChannelBuffers;
import org.jboss.netty.channel.Channel;

import com.google.common.collect.Queues;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import server.Config;
import server.Server;
import server.model.items.Item;
import server.model.npcs.NPC;
import server.model.Entity;
import server.model.npcs.NPCHandler;
import server.util.ISAACRandomGen;
import server.util.Misc;
import server.util.Buffer;
import server.model.players.Client;
import server.model.players.PlayerAssistant;
import server.model.players.combat.MeleeMaxHit;
import server.model.items.ItemAssistant;
import server.event.EventHandler;
import server.event.Events;

@Slf4j
public abstract class Player extends Entity{

	public ArrayList<String> killedPlayers = new ArrayList<String>();
	public ArrayList<Integer> attackedPlayers = new ArrayList<Integer>();

	public long lastButton, clickDelay = 0, lastMarkDropped;

	public ArrayList<String> lastKilledPlayers = new ArrayList<String>();

	public long lastCast = 0;

		public int[][] playerSkillProp = new int[20][15];
		public boolean[] playerSkilling = new boolean[20];
		public boolean stopPlayerSkill;
		public int doAmount;
		public boolean playerFletch;
		
	public boolean initialized = false, disconnected = false,
			ruleAgreeButton = false, RebuildNPCList = false, isActive = false,
			isKicked = false, isSkulled = false, friendUpdate = false,
			newPlayer = false, hasMultiSign = false, saveCharacter = false,
			mouseButton = false, splitChat = false, chatEffects = true,
			isNpc = false,
			acceptAid = false, nextDialogue = false, autocasting = false,
			usedSpecial = false, mageFollow = false, dbowSpec = false,
			craftingLeather = false, properLogout = false, secDbow = false,
			maxNextHit = false, ssSpec = false, vengOn = false, canWalkTutorial, closeTutorialInterface,
			addStarter = false, accountFlagged = false, msbSpec = false, stopPlayerPacket,stopPlayer,
			wildernessWarning, isWoodcutting, playerIsFiremaking,
			isFiremaking, playerIsFletching, playerIsFishing, diedOnTut,playerIsCooking, isFletching, isSmithing, miningRock,
			isSmelting, isMining, ratdied2;

	public int

	saveDelay, playerKilled, pkPoints, totalPlayerDamageDealt, killedBy,
			lastChatId = 1, privateChat, friendSlot = 0, dialogueId,
			randomCoffin, newLocation, specEffect, specBarId, attackLevelReq,
			defenceLevelReq, strengthLevelReq, rangeLevelReq, magicLevelReq,
			npcId2,
			followId, skullTimer, votingPoints, tutorialProgress, cookStage1 = 1, nextChat = 0, talkingNpc = -1,
			dialogueAction = 0, autocastId, followDistance, followId2,
			barrageCount = 0, delayedDamage = 0, delayedDamage2 = 0,
			pcPoints = 0, magePoints = 0,
			lastArrowUsed = -1, clanId = -1, autoRet = 0, pcDamage = 0,
			xInterfaceId = 0, xRemoveId = 0, xRemoveSlot = 0, tzhaarToKill = 0,
			tzhaarKilled = 0, waveId, frozenBy = 0, poisonDamage = 0,
			teleAction = 0, bonusAttack = 0, lastNpcAttacked = 0,
			killCount = 0, saraKC = 0,armadylKC = 0,bandosKC = 0, zammyKC = 0,
			treeX, treeY, rockX, rockY, smeltingItem, cookingItem,cookingObject,
			questPoints, pirateTreasure, gertCat, witchspot, RFD, TheLostTribe, QuestsCompleted,
			romeojuliet,restGhost,knightS,vampSlayer,runeMist,sheepShear, EleWorkShop, desertTreasure = 0,
			doricQuest,impsC,cookAss,blackKnight,shieldArrav,lostCity, characterSummaryTab, currentSong, bookPage, EleWorkshopWater_stage, hitCount;
	public String clanName, properName;
	public int[] voidStatus = new int[5];
	
	public boolean[] killedPheasant = new boolean[5];
	public boolean playerHasRandomEvent;
	public boolean canLeaveArea;
	public int pieSelect = 0, getPheasent, kebabSelect = 0, breadID,
			chocSelect = 0, bagelSelect = 0, triangleSandwich = 0,
			squareSandwich = 0, breadSelect = 0;
	public int miningAxe = -1, woodcuttingAxe = -1;
	public int[] itemKeptId = new int[4];
	public int[] pouches = new int[4];
	public final int[] POUCH_SIZE = { 3, 6, 9, 12 };
	public boolean[] invSlot = new boolean[28], equipSlot = new boolean[14];
	public long friends[] = new long[200];
	public double specAmount = 0;
	public double specAccuracy = 1;
	public double specDamage = 1;
	public double prayerPoint = 1.0;
	    public boolean hasNpc = false;
    public int summonId;
	public int PouchRune1, PouchRune2, PouchRune3, PouchRune1Slot, PouchRune2Slot, PouchRune3Slot, PouchRune1Amt, PouchRune2Amt, PouchRune3Amt;
	public String runeTypes1, runeTypes, runeTypes2;
	public boolean addingToRP = false;
	public boolean openLootBag = false;
	public boolean oneClickDeposit = false;
	
	public boolean stopFiremaking, pickedUpFiremakingLog, logLit;
	public int teleGrabItem, teleGrabX, teleGrabY, duelCount, underAttackBy,
			underAttackBy2, wildLevel, teleTimer, respawnTimer, saveTimer = 0,
			teleBlockLength, poisonDelay;
	public int poisonImmunity;
	public int remainingMinutes;
	public int remainingSeconds;
	public int DestroyID;
	public boolean onPlaylist = false;
	public long lastUpdateTime;
	public long VengTimer;
	public String timerString;
	public String remainingTime;
	public long lastPlayerMove, lastPoison, lastPoisonSip, poisonImmune,
			lastSpear, lastProtItem, dfsDelay, lastVeng, lastYell,
			teleGrabDelay, protMageDelay, protMeleeDelay, protRangeDelay,
			lastAction, lastThieve, lastLockPick, alchDelay, specDelay = System
					.currentTimeMillis(), duelDelay, teleBlockDelay,
			godSpellDelay, singleCombatDelay, singleCombatDelay2, reduceStat,
			restoreStatsDelay, logoutDelay, buryDelay, foodDelay, potDelay, lastSkillingAction;
	public boolean canChangeAppearance = false;
	public boolean mageAllowed;
	public byte poisonMask = 0;

	public final int[] BOWS = { 9185, 839, 845, 847, 851, 855, 859, 841, 843,
			849, 853, 857, 861, 4212, 4214, 4215, 11235, 4216, 4217, 4218,
			4219, 4220, 4221, 4222, 4223, 6724, 4734, 4934, 4935, 4936, 4937};
	public final int[] ARROWS = { 882, 884, 886, 888, 890, 892, 4740, 11212,
			9140, 9141, 4142, 9143, 9144, 9240, 9241, 9242, 9243, 9244, 9245 };
	public final int[] NO_ARROW_DROP = { 4212, 4214, 4215, 4216, 4217, 4218,
			4219, 4220, 4221, 4222, 4223, 4734, 4934, 4935, 4936, 4937 };
	public final int[] OTHER_RANGE_WEAPONS = { 863, 864, 865, 866, 867, 868,
			869, 806, 807, 808, 809, 810, 811, 825, 826, 827, 828, 829, 830,
			800, 801, 802, 803, 804, 805, 6522 };

	public final int[][] MAGIC_SPELLS = {
			// example {magicId, level req, animation, startGFX, projectile Id,
			// endGFX, maxhit, exp gained, rune 1, rune 1 amount, rune 2, rune 2
			// amount, rune 3, rune 3 amount, rune 4, rune 4 amount}

			// Modern Spells
			{ 1152, 1, 711, 90, 91, 92, 2, 5, 556, 1, 558, 1, 0, 0, 0, 0 }, // wind
																			// strike
			{ 1154, 5, 711, 93, 94, 95, 4, 7, 555, 1, 556, 1, 558, 1, 0, 0 }, // water
																				// strike
			{ 1156, 9, 711, 96, 97, 98, 6, 9, 557, 2, 556, 1, 558, 1, 0, 0 },// earth
																				// strike
			{ 1158, 13, 711, 99, 100, 101, 8, 11, 554, 3, 556, 2, 558, 1, 0, 0 }, // fire
																					// strike
			{ 1160, 17, 711, 117, 118, 119, 9, 13, 556, 2, 562, 1, 0, 0, 0, 0 }, // wind
																					// bolt
			{ 1163, 23, 711, 120, 121, 122, 10, 16, 556, 2, 555, 2, 562, 1, 0,
					0 }, // water bolt
			{ 1166, 29, 711, 123, 124, 125, 11, 20, 556, 2, 557, 3, 562, 1, 0,
					0 }, // earth bolt
			{ 1169, 35, 711, 126, 127, 128, 12, 22, 556, 3, 554, 4, 562, 1, 0,
					0 }, // fire bolt
			{ 1172, 41, 711, 132, 133, 134, 13, 25, 556, 3, 560, 1, 0, 0, 0, 0 }, // wind
																					// blast
			{ 1175, 47, 711, 135, 136, 137, 14, 28, 556, 3, 555, 3, 560, 1, 0,
					0 }, // water blast
			{ 1177, 53, 711, 138, 139, 140, 15, 31, 556, 3, 557, 4, 560, 1, 0,
					0 }, // earth blast
			{ 1181, 59, 711, 129, 130, 131, 16, 35, 556, 4, 554, 5, 560, 1, 0,
					0 }, // fire blast
			{ 1183, 62, 711, 158, 159, 160, 17, 36, 556, 5, 565, 1, 0, 0, 0, 0 }, // wind
																					// wave
			{ 1185, 65, 711, 161, 162, 163, 18, 37, 556, 5, 555, 7, 565, 1, 0,
					0 }, // water wave
			{ 1188, 70, 711, 164, 165, 166, 19, 40, 556, 5, 557, 7, 565, 1, 0,
					0 }, // earth wave
			{ 1189, 75, 711, 155, 156, 157, 20, 42, 556, 5, 554, 7, 565, 1, 0,
					0 }, // fire wave
			{ 1153, 3, 716, 102, 103, 104, 0, 13, 555, 3, 557, 2, 559, 1, 0, 0 }, // confuse
			{ 1157, 11, 716, 105, 106, 107, 0, 20, 555, 3, 557, 2, 559, 1, 0, 0 }, // weaken
			{ 1161, 19, 716, 108, 109, 110, 0, 29, 555, 2, 557, 3, 559, 1, 0, 0 }, // curse
			{ 1542, 66, 729, 167, 168, 169, 0, 76, 557, 5, 555, 5, 566, 1, 0, 0 }, // vulnerability
			{ 1543, 73, 729, 170, 171, 172, 0, 83, 557, 8, 555, 8, 566, 1, 0, 0 }, // enfeeble
			{ 1562, 80, 729, 173, 174, 107, 0, 90, 557, 12, 555, 12, 556, 1, 0,
					0 }, // stun
			{ 1572, 20, 711, 177, 178, 181, 0, 30, 557, 3, 555, 3, 561, 2, 0, 0 }, // bind
			{ 1582, 50, 711, 177, 178, 180, 2, 60, 557, 4, 555, 4, 561, 3, 0, 0 }, // snare
			{ 1592, 79, 711, 177, 178, 179, 4, 90, 557, 5, 555, 5, 561, 4, 0, 0 }, // entangle
			{ 1171, 39, 724, 145, 146, 147, 15, 25, 556, 2, 557, 2, 562, 1, 0,
					0 }, // crumble undead
			{ 1539, 50, 708, 87, 88, 89, 25, 42, 554, 5, 560, 1, 0, 0, 0, 0 }, // iban
																				// blast
			{ 12037, 50, 1576, 327, 328, 329, 19, 30, 560, 1, 558, 4, 0, 0, 0,
					0 }, // magic dart
			{ 1190, 60, 811, 0, 0, 76, 20, 60, 554, 2, 565, 2, 556, 4, 0, 0 }, // sara
																				// strike
			{ 1191, 60, 811, 0, 0, 77, 20, 60, 554, 1, 565, 2, 556, 4, 0, 0 }, // cause
																				// of
																				// guthix
			{ 1192, 60, 811, 0, 0, 78, 20, 60, 554, 4, 565, 2, 556, 1, 0, 0 }, // flames
																				// of
																				// zammy
			{ 12445, 85, 1819, 0, 344, 345, 0, 65, 563, 1, 562, 1, 560, 1, 0, 0 }, // teleblock

			// Ancient Spells
			{ 12939, 50, 1978, 0, 384, 385, 13, 30, 560, 2, 562, 2, 554, 1,
					556, 1 }, // smoke rush
			{ 12987, 52, 1978, 0, 378, 379, 14, 31, 560, 2, 562, 2, 566, 1,
					556, 1 }, // shadow rush
			{ 12901, 56, 1978, 0, 0, 373, 15, 33, 560, 2, 562, 2, 565, 1, 0, 0 }, // blood
																					// rush
			{ 12861, 58, 1978, 0, 360, 361, 16, 34, 560, 2, 562, 2, 555, 2, 0,
					0 }, // ice rush
			{ 12963, 62, 1979, 0, 0, 389, 19, 36, 560, 2, 562, 4, 556, 2, 554,
					2 }, // smoke burst
			{ 13011, 64, 1979, 0, 0, 382, 20, 37, 560, 2, 562, 4, 556, 2, 566,
					2 }, // shadow burst
			{ 12919, 68, 1979, 0, 0, 376, 21, 39, 560, 2, 562, 4, 565, 2, 0, 0 }, // blood
																					// burst
			{ 12881, 70, 1979, 0, 0, 363, 22, 40, 560, 2, 562, 4, 555, 4, 0, 0 }, // ice
																					// burst
			{ 12951, 74, 1978, 0, 386, 387, 23, 42, 560, 2, 554, 2, 565, 2,
					556, 2 }, // smoke blitz
			{ 12999, 76, 1978, 0, 380, 381, 24, 43, 560, 2, 565, 2, 556, 2,
					566, 2 }, // shadow blitz
			{ 12911, 80, 1978, 0, 374, 375, 25, 45, 560, 2, 565, 4, 0, 0, 0, 0 }, // blood
																					// blitz
			{ 12871, 82, 1978, 366, 0, 367, 26, 46, 560, 2, 565, 2, 555, 3, 0,
					0 }, // ice blitz
			{ 12975, 86, 1979, 0, 0, 391, 27, 48, 560, 4, 565, 2, 556, 4, 554,
					4 }, // smoke barrage
			{ 13023, 88, 1979, 0, 0, 383, 28, 49, 560, 4, 565, 2, 556, 4, 566,
					3 }, // shadow barrage
			{ 12929, 92, 1979, 0, 0, 377, 29, 51, 560, 4, 565, 4, 566, 1, 0, 0 }, // blood
																					// barrage
			{ 12891, 94, 1979, 0, 0, 369, 30, 52, 560, 4, 565, 2, 555, 6, 0, 0 }, // ice
																					// barrage

			{ -1, 80, 811, 301, 0, 0, 0, 0, 554, 3, 565, 3, 556, 3, 0, 0 }, // charge
			{ -1, 21, 712, 112, 0, 0, 0, 10, 554, 3, 561, 1, 0, 0, 0, 0 }, // low
																			// alch
			{ -1, 55, 713, 113, 0, 0, 0, 20, 554, 5, 561, 1, 0, 0, 0, 0 }, // high
																			// alch
			{ -1, 33, 728, 142, 143, 144, 0, 35, 556, 1, 563, 1, 0, 0, 0, 0 } // telegrab

	};

	public boolean isAutoButton(int button) {
		for (int j = 0; j < autocastIds.length; j += 2) {
			if (autocastIds[j] == button)
				return true;
		}
		return false;
	}

	public int[] autocastIds = { 51133, 32, 51185, 33, 51091, 34, 24018, 35,
			51159, 36, 51211, 37, 51111, 38, 51069, 39, 51146, 40, 51198, 41,
			51102, 42, 51058, 43, 51172, 44, 51224, 45, 51122, 46, 51080, 47,
			7038, 0, 7039, 1, 7040, 2, 7041, 3, 7042, 4, 7043, 5, 7044, 6,
			7045, 7, 7046, 8, 7047, 9, 7048, 10, 7049, 11, 7050, 12, 7051, 13,
			7052, 14, 7053, 15, 47019, 27, 47020, 25, 47021, 12, 47022, 13,
			47023, 14, 47024, 15 };

	// public String spellName = "Select Spell";
	public void assignAutocast(int button) {
		for (int j = 0; j < autocastIds.length; j++) {
			if (autocastIds[j] == button) {
				Client c = (Client) PlayerHandler.players[this.playerId];
				autocasting = true;
				autocastId = autocastIds[j + 1];
				c.getPA().sendFrame36(108, 1);
				c.setSidebarInterface(0, 328);
				// spellName = getSpellName(autocastId);
				// spellName = spellName;
				// c.getPA().sendFrame126(spellName, 354);
				c = null;
				break;
			}
		}
	}

	public String getSpellName(int id) {
		switch (id) {
		case 0:
			return "Air Strike";
		case 1:
			return "Water Strike";
		case 2:
			return "Earth Strike";
		case 3:
			return "Fire Strike";
		case 4:
			return "Air Bolt";
		case 5:
			return "Water Bolt";
		case 6:
			return "Earth Bolt";
		case 7:
			return "Fire Bolt";
		case 8:
			return "Air Blast";
		case 9:
			return "Water Blast";
		case 10:
			return "Earth Blast";
		case 11:
			return "Fire Blast";
		case 12:
			return "Air Wave";
		case 13:
			return "Water Wave";
		case 14:
			return "Earth Wave";
		case 15:
			return "Fire Wave";
		case 32:
			return "Shadow Rush";
		case 33:
			return "Smoke Rush";
		case 34:
			return "Blood Rush";
		case 35:
			return "Ice Rush";
		case 36:
			return "Shadow Burst";
		case 37:
			return "Smoke Burst";
		case 38:
			return "Blood Burst";
		case 39:
			return "Ice Burst";
		case 40:
			return "Shadow Blitz";
		case 41:
			return "Smoke Blitz";
		case 42:
			return "Blood Blitz";
		case 43:
			return "Ice Blitz";
		case 44:
			return "Shadow Barrage";
		case 45:
			return "Smoke Barrage";
		case 46:
			return "Blood Barrage";
		case 47:
			return "Ice Barrage";
		default:
			return "Select Spell";
		}
	}
		public int bankingItems[] = new int[Config.BANK_SIZE];
		public int bankingItemsN[] = new int[Config.BANK_SIZE];
		
		public int bankingTab = 0;// -1 = bank closed
		
		public int bankItems1[] = new int[Config.BANK_SIZE];
		public int bankItems1N[] = new int[Config.BANK_SIZE];
		public int bankItems2[] = new int[Config.BANK_SIZE];
		public int bankItems2N[] = new int[Config.BANK_SIZE];
		public int bankItems3[] = new int[Config.BANK_SIZE];
		public int bankItems3N[] = new int[Config.BANK_SIZE];
		public int bankItems4[] = new int[Config.BANK_SIZE];
		public int bankItems4N[] = new int[Config.BANK_SIZE];
		public int bankItems5[] = new int[Config.BANK_SIZE];
		public int bankItems5N[] = new int[Config.BANK_SIZE];
		public int bankItems6[] = new int[Config.BANK_SIZE];
		public int bankItems6N[] = new int[Config.BANK_SIZE];
		public int bankItems7[] = new int[Config.BANK_SIZE];
		public int bankItems7N[] = new int[Config.BANK_SIZE];
		public int bankItems8[] = new int[Config.BANK_SIZE];
		public int bankItems8N[] = new int[Config.BANK_SIZE];
		public String searchTerm = "";
	public boolean fullVoidRange() {
		return playerEquipment[playerHat] == 11664
				&& playerEquipment[playerLegs] == 8840
				&& playerEquipment[playerChest] == 8839
				&& playerEquipment[playerHands] == 8842;
	}

	public boolean fullVoidMage() {
		return playerEquipment[playerHat] == 11663
				&& playerEquipment[playerLegs] == 8840
				&& playerEquipment[playerChest] == 8839
				&& playerEquipment[playerHands] == 8842;
	}

	public boolean fullVoidMelee() {
		return playerEquipment[playerHat] == 11665
				&& playerEquipment[playerLegs] == 8840
				&& playerEquipment[playerChest] == 8839
				&& playerEquipment[playerHands] == 8842;
	}

	public int[][] barrowsNpcs = { { 2030, 0 }, // verac
			{ 2029, 0 }, // toarg
			{ 2028, 0 }, // karil
			{ 2027, 0 }, // guthan
			{ 2026, 0 }, // dharok
			{ 2025, 0 } // ahrim
	};	
	public int[] barrowsMonsterNpcs = { 1678, 1679, 1680, 1681,1682,1683,1684,1685,1686,1687,1688};
		public int[][] CollLog = { {6260, 0},
        {6247, 0},
        {6222, 0},
        {6203, 0},
        {2025, 0},
        {2026, 0},
        {2027, 0},
        {2028, 0},
        {2029, 0},
        {2030, 0},
        {50, 0},
        {1160, 0},
        {3200, 0},
        {3340, 0},
        {8133, 0},
        {2881, 0},
        {2882, 0},
        {2883, 0}
    };
	public int barrowsKillCount;
	public int BarrowsKC, BandosKC;
	public int BarrowsRewardPotential;
	public int reduceSpellId;
	public final int[] REDUCE_SPELL_TIME = { 250000, 250000, 250000, 500000,
			500000, 500000 }; // how long does the other player stay immune to
								// the spell
	public long[] reduceSpellDelay = new long[6];
	public final int[] REDUCE_SPELLS = { 1153, 1157, 1161, 1542, 1543, 1562 };
	public boolean[] canUseReducingSpell = { true, true, true, true, true, true };

	public int slayerTask, taskAmount, slayerPoints;
	public boolean[] extend = new boolean[20];
	public int[] BlockID = new int[20];
	public boolean[] alreadyBlocked = new boolean[20];
	public int prayerId = -1;
	public int headIcon = -1;
	public int bountyIcon = 0;
	public long stopPrayerDelay, prayerDelay;
	public boolean usingPrayer;
	/*public final int[] PRAYER_DRAIN_RATE = { 500, 500, 500, 500, 500, 500, 500,
			500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 500,
			500, 500, 500, 500, 500, 500, 500, 500 };*/
	public final int[] PRAYER_LEVEL_REQUIRED = { 1, 4, 7, 8, 9, 10, 13, 16, 19,
			22, 25, 26, 27, 28, 31, 34, 37, 40, 43, 44, 45, 46, 49, 52, 60, 70 };
	public final int[] PRAYER = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
			14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25 };
	public final String[] PRAYER_NAME = { "Thick Skin", "Burst of Strength",
			"Clarity of Thought", "Sharp Eye", "Mystic Will", "Rock Skin",
			"Superhuman Strength", "Improved Reflexes", "Rapid Restore",
			"Rapid Heal", "Protect Item", "Hawk Eye", "Mystic Lore",
			"Steel Skin", "Ultimate Strength", "Incredible Reflexes",
			"Protect from Magic", "Protect from Missiles",
			"Protect from Melee", "Eagle Eye", "Mystic Might", "Retribution",
			"Redemption", "Smite", "Chivalry", "Piety" };
	public final int[] PRAYER_GLOW = { 83, 84, 85, 601, 602, 86, 87, 88, 89,
			90, 91, 603, 604, 92, 93, 94, 95, 96, 97, 605, 606, 98, 99, 100,
			607, 608 };
	public final int[] PRAYER_HEAD_ICONS = { -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1, 2, 1, 0, -1, -1, 3, 5, 4, -1, -1 };
	// {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,3,2,1,4,6,5};

	public boolean[] prayerActive = { false, false, false, false, false, false,
			false, false, false, false, false, false, false, false, false,
			false, false, false, false, false, false, false, false, false,
			false, false };

			
	public int duelTimer, duelTeleX, duelTeleY, duelSlot, duelSpaceReq,
			duelOption, duelingWith, duelStatus;
	public int headIconPk = -1, headIconHints;
	public boolean duelRequested;
	public boolean[] duelRule = new boolean[22];
	public final int[] DUEL_RULE_ID = { 1, 2, 16, 32, 64, 128, 256, 512, 1024,
			4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 2097152,
			8388608, 16777216, 67108864, 134217728 };

	public boolean doubleHit, usingSpecial, npcDroppingItems, usingRangeWeapon,
			usingBow, usingMagic, castingMagic;
	public int specMaxHitIncrease, freezeDelay, freezeTimer = -6, killerId,
			playerIndex, oldPlayerIndex, lastWeaponUsed, projectileStage,
			crystalBowArrowCount, playerMagicBook, teleGfx, teleEndAnimation,
			teleHeight, teleX, teleY, rangeItemUsed, killingNpcIndex,
			totalDamageDealt, oldNpcIndex, fightMode, attackTimer, npcIndex,
			npcClickIndex, npcType, castingSpellId, oldSpellId, spellId,
			hitDelay;
	public boolean magicFailed, oldMagicFailed;
	public int bowSpecShot, clickNpcType, clickObjectType, objectId, objectX,
			objectY, objectXOffset, objectYOffset, objectDistance;
	public int pItemX, pItemY, pItemId;
	public boolean isMoving, walkingToItem;
	public boolean isShopping, updateShop;
	public int myShopId;
	public int tradeStatus, tradeWith;
	public boolean forcedChatUpdateRequired, inDuel, tradeAccepted, goodTrade,
			inTrade, tradeRequested, tradeResetNeeded, tradeConfirmed,
			tradeConfirmed2, canOffer, acceptTrade, acceptedTrade;
	public int attackAnim, animationRequest = -1, animationWaitCycles;
	public int[] playerBonus = new int[12];
	public boolean isRunning2 = true;
	public boolean takeAsNote;
	public int combatLevel;
	public boolean saveFile = false;
	public boolean toggle = false;
	public int playerAppearance[] = new int[13];
	public int apset;
	public int actionID;
	public int wearItemTimer, wearId, wearSlot, interfaceId;
	public int XremoveSlot, XinterfaceID, XremoveID, Xamount;
	public int respawnLocation = 0;
	public boolean attackOptions = true;
	/*Achievement diary*/
	public boolean usingCloak = false;
	public int ArdyDiaryEasy = 0, ArdyDiaryMed = 0, ArdyDiaryHard = 0, ArdyDiaryElite = 0;
	/*					*/
	//
	
	//hunter
	public boolean success, success2, success3, success4, success5 = false;
	public int implingCatches = 0;
	/*Music Areas*/ 
	public boolean MusicOn = false;
	public boolean RegionMusicOn = true;
	public int lastSong = -1;
	public boolean MeleeTutorClaimed = false, MagicTutorClaimed = false, RangedTutorClaimed = false;
	public long LastRangedTutorClaimed = 0, LastMagicTutorClaimed = 0, LastMeleeTutorClaimed = 0;
	/**Zulrah Item charges**/
	public int BlowpipeCharges = 0, BlowpipeDarts = 0, DartType = 0, SerpHelmCharges = 0,ToxicStaffCharges = 0, TridentCharges = 0, ArcLightCharges = 0;
	public boolean addingCharges = false, addingDarts = false;
	/***********************/
	public boolean tempBoolean;
	public boolean GodwarsRope = false;
	public int[] price = new int[28];
	public int[] priceN = new int[28];
	public int total, playerBankPin, recoveryDelay = 3, attemptsRemaining = 3,
			lastPinSettings = -1, setPinDate = -1, changePinDate = -1,
			deletePinDate = -1, firstPin, secondPin, thirdPin, fourthPin,
			bankPin1, bankPin2, bankPin3, bankPin4, pinDeleteDateRequested;
	public boolean isChecking;
		public boolean hasBankPin, enterdBankpin, firstPinEnter, requestPinDelete,
			secondPinEnter, thirdPinEnter, fourthPinEnter, hasBankpin,
			isBanking;
	public int tutorial = 15;
	public boolean usingGlory = false;
	public int[] mining = new int[3];
	public int miningTimer = 0;
	public boolean fishing = false;
	public int smeltType; // 1 = bronze, 2 = iron, 3 = steel, 4 = gold, 5 =
							// mith, 6 = addy, 7 = rune
	public int smeltAmount;
	public int smeltTimer = 0;
	public boolean smeltInterface;
	public boolean patchCleared;
	public int[] farm = new int[2];
	public int TrawlerStatus = 0;
	public boolean TrawlerInPort = true;
	public boolean antiFirePot = false;
	public int homeTele = 0;
	public int homeTeleWaitTimer = 0;
	public long LasthomeTele = 0;
	/**
	 * Castle Wars
	 */
	public int castleWarsTeam;
	public boolean inCwGame;
	public boolean inCwWait;

	/**
	 * Fight Pits
	 */
	public boolean inPits = false;
	public int pitsStatus = 0;

	/**
	 * SouthWest, NorthEast, SouthWest, NorthEast
	 */

	public boolean isInTut() {
		if (absX >= 2625 && absX <= 2687 && absY >= 4670 && absY <= 4735) {
			return true;
		}
		return false;
	}

	public boolean inBarrows() {
		if (absX > 3520 && absX < 3598 && absY > 9653 && absY < 9750) {
			return true;
		}
		return false;
	}

	public boolean inArea(int x, int y, int x1, int y1) {
		if (absX > x && absX < x1 && absY < y && absY > y1) {
			return true;
		}
		return false;
	}

	public boolean inWild() {
		//if (inCw()) {
			//return true;
		//}
		if (absX > 2941 && absX < 3392 && absY > 3518 && absY < 3966 || absX > 2941 && absX < 3392 && absY > 9918 && absY < 10366) {
			if (!wildernessWarning) {
				resetWalkingQueue();
				wildernessWarning = true;
				c.getPA().sendFrame126("WARNING!", 6940);
				c.getPA().showInterface(1908);
			}
			return true;
		}
		return false;
	}
	
	public boolean arenas() {
		if (absX > 3331 && absX < 3391 && absY > 3242 && absY < 3260) {
			return true;
		}
		return false;
	}

	public int getArcLightCharge() {
		return ArcLightCharges;
	}

	public void setArcLightCharge(int chargeArc) {
		this.ArcLightCharges = chargeArc;
	}

	public int getToxicBlowpipeCharge() {
		return BlowpipeCharges;
	}

	public void setToxicBlowpipeCharge(int charge) {
		this.BlowpipeCharges = charge;
	}

	public int getToxicBlowpipeAmmo() {
		return DartType;
	}

	public int getToxicBlowpipeAmmoAmount() {
		return BlowpipeDarts;
	}

	public void setToxicBlowpipeAmmoAmount(int amount) {
		this.BlowpipeDarts = amount;
	}

	public void setToxicBlowpipeAmmo(int ammo) {
		this.DartType = ammo;
	}

	public int getSerpentineHelmCharge() {
		return this.SerpHelmCharges;
	}

	public void setSerpentineHelmCharge(int charge) {
		this.SerpHelmCharges = charge;
	}

	public int getTridentCharge() {
		return TridentCharges;
	}

	public void setTridentCharge(int tridentCharge) {
		this.TridentCharges = tridentCharge;
	}

	public int getToxicTridentCharge() {
		return TridentCharges;
	}

	public void setToxicTridentCharge(int toxicTridentCharge) {
		this.TridentCharges = toxicTridentCharge;
	}
	public boolean inDuelArena() {
		if ((absX > 3322 && absX < 3394 && absY > 3195 && absY < 3291)
				|| (absX > 3311 && absX < 3323 && absY > 3223 && absY < 3248)) {
			return true;
		}
		return false;
	}

			public boolean inMulti() {
				if((absX >= 3136 && absX <= 3327 && absY >= 3519 && absY <= 3607) || 
				(absX >= 3190 && absX <= 3327 && absY >= 3648 && absY <= 3839) ||  
				(absX >= 3200 && absX <= 3390 && absY >= 3840 && absY <= 3967) || 
				(absX >= 2992 && absX <= 3007 && absY >= 3912 && absY <= 3967) || 
				(absX >= 2946 && absX <= 2959 && absY >= 3816 && absY <= 3831) || 
				(absX >= 3008 && absX <= 3199 && absY >= 3856 && absY <= 3903) || 
				(absX >= 3008 && absX <= 3071 && absY >= 3600 && absY <= 3711) || 
				(absX >= 3072 && absX <= 3327 && absY >= 3608 && absY <= 3647) ||
				(absX >= 2624 && absX <= 2690 && absY >= 2550 && absY <= 2619) ||
				(absX >= 2371 && absX <= 2422 && absY >= 5062 && absY <= 5117) ||
				(absX >= 2896 && absX <= 2927 && absY >= 3595 && absY <= 3630) ||
				(absX >= 2892 && absX <= 2932 && absY >= 4435 && absY <= 4464) ||
				(absX >= 2256 && absX <= 2287 && absY >= 4680 && absY <= 4711) ||
				(absX >= 2862 && absX <= 2876 && absY >= 5351 && absY <= 5369) ||
				(absX >= 2918 && absX <= 2936 && absY <= 5331 && absY >= 5318) ||
				(absX >= 2842 && absX <= 2889 && absY <= 5296 && absY >= 5258) ||
				(absX >= 2907 && absX <= 2889 && absY <= 5276 && absY >= 5258) ||
				(absX <= 2943 && absX >= 2815 && absY <= 5375 && absY >= 5246) ||
				(absX <= 2959 && absX >= 2914 && absY <= 4406 && absY >= 4357) ||
				(absX <= 2434 && absX >= 2365 && absY <= 3138 && absY >= 3069) ||
				inBandosGWD()) {
					return true;
				}
				return false;
			}
	public boolean inZammyGWD() {		
		if(absX <= 2918 && absX >= 2936 && absY >= 5331 && absY <= 5318) {
			return true;
		}
		return false;
	};
	public boolean inArmadylGWD() {		
		if(absX <= 2842 && absX >= 2824 && absY >= 5296 && absY <= 5308) {
			return true;
		}
		return false;
	}
	public boolean inBandosGWD() {		
		if(absX >= 2864 && absX <= 2876 && absY >= 5351 && absY <= 5369) {
			return true;
		}
		return false;
	}
	public boolean inSaraGWD() {		
		if(absX <= 2907 && absX >= 2889 && absY <= 5276 && absY >= 5258) {
			return true;
		}
		return false;
	}
	public boolean inGodWars() {		
		if(absX <= 2953 && absX >= 2816 && absY <= 5368 && absY >= 5248) {
			return true;
		}
		return false;
	}
	public boolean inFightCaves() {
		return absX >= 2360 && absX <= 2445 && absY >= 5045 && absY <= 5125;
	}

	public boolean inPirateHouse() {
		return absX >= 3038 && absX <= 3044 && absY >= 3949 && absY <= 3959;
	}

	public String connectedFrom = "";
	public String globalMessage = "";

	public abstract void initialize();

	public abstract void update();

	public int playerId = -1;
	public String playerName = null;
	public String playerName2 = null;
	public String playerPass = null;
	public int playerRights;
	public PlayerHandler handler = null;
	public int playerItems[] = new int[28];
	public int playerItemsN[] = new int[28];
	public int playerLootItems[] = new int[28];
	public int playerLootItemsN[] = new int[28];
	public int playerLogItems[] = new int[43];
	public int playerLogItemsAmt[] = new int[43];

	public int CollectionLog = 0;
	public int bankItems[] = new int[Config.BANK_SIZE];
	public int bankItemsN[] = new int[Config.BANK_SIZE];
	public boolean bankNotes = false;


	public int[] SLAYER_HELMETS = { 11864, 11865, 19639, 19641, 19643, 19645, 19647, 19649, 21888, 21890, 21264, 21266 };
	public int[] IMBUED_SLAYER_HELMETS = { 11865, 19641, 19645, 19649, 21890, 21266 };

	public int[] GRACEFUL = { 11850, 11852, 11854, 11856, 11858, 11860, 13579, 13581, 13583, 13585, 13587, 13589, 13591,
			13593, 13595, 13597, 13599, 13601, 13603, 13605, 13607, 13609, 13611, 13613, 13615, 13617, 13619, 13621,
			13623, 13625, 13627, 13629, 13631, 13633, 13635, 13637, 13667, 13669, 13671, 13673, 13675, 13677, 21061,
			21064, 21067, 21070, 21073, 21076 };

			public int timer = 10;
	public int playerStandIndex = 0x328;
	public int playerTurnIndex = 0x337;
	public int playerWalkIndex = 0x333;
	public int playerTurn180Index = 0x334;
	public int playerTurn90CWIndex = 0x335;
	public int playerTurn90CCWIndex = 0x336;
	public int playerRunIndex = 0x338;

	public int playerHat = 0;
	public int playerCape = 1;
	public int playerAmulet = 2;
	public int playerWeapon = 3;
	public int playerChest = 4;
	public int playerShield = 5;
	public int playerLegs = 7;
	public int playerHands = 9;
	public int playerFeet = 10;
	public int playerRing = 12;
	public int playerArrows = 13;

	public int playerAttack = 0;
	public int playerDefence = 1;
	public int playerStrength = 2;
	public int playerHitpoints = 3;
	public int playerRanged = 4;
	public int playerPrayer = 5;
	public int playerMagic = 6;
	public int playerCooking = 7;
	public int playerWoodcutting = 8;
	public int playerFletching = 9;
	public int playerFishing = 10;
	public int playerFiremaking = 11;
	public int playerCrafting = 12;
	public int playerSmithing = 13;
	public int playerMining = 14;
	public int playerHerblore = 15;
	public int playerAgility = 16;
	public int playerThieving = 17;
	public int playerSlayer = 18;
	public int playerFarming = 19;
	public int playerRunecrafting = 20;
	public int playerHunter = 21;
	public int playerConstruction = 22;

	public int[] playerEquipment = new int[14];
	public int[] playerEquipmentN = new int[14];
	public int[] playerLevel = new int[25];
	public int[] playerXP = new int[25];

	public void updateshop(int i) {
		Client p = (Client) PlayerHandler.players[playerId];
		p.getShops().resetShop(i);
	}

	public void println_debug(String str) {
		System.out.println("[player-" + playerId + "]: " + str);
	}

	public void println(String str) {
		System.out.println("[player-" + playerId + "]: " + str);
	}

			public void setMale() {	
      			playerAppearance[0] = 0; // gender
      			playerAppearance[1] = 0;
      			playerAppearance[2] = 18;
      			playerAppearance[3] = 26;
      			playerAppearance[4] = 33;
      			playerAppearance[5] = 36;
      			playerAppearance[6] = 42; // feet
      			playerAppearance[7] = 10; // beard
      			playerAppearance[8] = 0; // hair colour
      			playerAppearance[9] = 0; // torso colour
      			playerAppearance[10] = 0; // legs colour
      			playerAppearance[11] = 0; // feet colour
      			playerAppearance[12] = 0;
			}
			public void setFemale() {	
      			playerAppearance[0] = 1; // gender
      			playerAppearance[1] = 47;//hair
      			playerAppearance[2] = 56;//torso
      			playerAppearance[3] = 61;//arms
      			playerAppearance[4] = 67;//hands
      			playerAppearance[5] = 71;//legs
      			playerAppearance[6] = 79; // feet
      			playerAppearance[7] = 255; // beard
      			playerAppearance[8] = 0; // hair colour
      			playerAppearance[9] = 1; // torso colour
      			playerAppearance[10] = 1; // legs colour
      			playerAppearance[11] = 0; // feet colour
      			playerAppearance[12] = 0;
			}
	public Player(int _playerId, String name) {
		super(_playerId, name);
		playerId = _playerId;
		playerRights = 0;

		for (int i = 0; i < playerItems.length; i++) {
			playerItems[i] = 0;
		}		
		for (int i = 0; i < playerLootItems.length; i++) {
			playerItems[i] = 0;
		}
		for (int i = 0; i < playerItemsN.length; i++) {
			playerItemsN[i] = 0;
		}
		for (int i = 0; i < playerLootItemsN.length; i++) {
			playerItemsN[i] = 0;
		}

		for (int i = 0; i < playerLevel.length; i++) {
			if (i == 3) {
				playerLevel[i] = 10;
			} else {
				playerLevel[i] = 1;
			}
		}

		for (int i = 0; i < playerXP.length; i++) {
			if (i == 3) {
				playerXP[i] = 1300;
			} else {
				playerXP[i] = 0;
			}
		}
		for (int i = 0; i < Config.BANK_SIZE; i++) {
			bankItems[i] = 0;
		}

		for (int i = 0; i < Config.BANK_SIZE; i++) {
			bankItemsN[i] = 0;
		}

				//setMale();
		playerAppearance[0] = 0; // gender
		playerAppearance[1] = 7; // head
		playerAppearance[2] = 25;// Torso
		playerAppearance[3] = 29; // arms
		playerAppearance[4] = 35; // hands
		playerAppearance[5] = 39; // legs
		playerAppearance[6] = 44; // feet
		playerAppearance[7] = 14; // beard
		playerAppearance[8] = 7; // hair colour
		playerAppearance[9] = 8; // torso colour
		playerAppearance[10] = 9; // legs colour
		playerAppearance[11] = 5; // feet colour
		playerAppearance[12] = 0; // skin colour

		apset = 0;
		actionID = 0;

		playerEquipment[playerHat] = -1;
		playerEquipment[playerCape] = -1;
		playerEquipment[playerAmulet] = -1;
		playerEquipment[playerChest] = -1;
		playerEquipment[playerShield] = -1;
		playerEquipment[playerLegs] = -1;
		playerEquipment[playerHands] = -1;
		playerEquipment[playerFeet] = -1;
		playerEquipment[playerRing] = -1;
		playerEquipment[playerArrows] = -1;
		playerEquipment[playerWeapon] = -1;


		teleportToX = Config.START_LOCATION_X;
		teleportToY = Config.START_LOCATION_Y;
		heightLevel = 0;

		absX = absY = -1;
		mapRegionX = mapRegionY = -1;
		currentX = currentY = 0;
		resetWalkingQueue();
	}

	void destruct() {
		playerListSize = 0;
		for (int i = 0; i < maxPlayerListSize; i++)
			playerList[i] = null;
		absX = absY = -1;
		mapRegionX = mapRegionY = -1;
		currentX = currentY = 0;
		resetWalkingQueue();
	}

	public static final int maxPlayerListSize = Config.MAX_PLAYERS;
	public Player playerList[] = new Player[maxPlayerListSize];
	public int playerListSize = 0;

	public byte playerInListBitmap[] = new byte[(Config.MAX_PLAYERS + 7) >> 3];

	public static final int maxNPCListSize = NPCHandler.maxNPCs;
	public NPC npcList[] = new NPC[maxNPCListSize];
	public int npcListSize = 0;

	public byte npcInListBitmap[] = new byte[(NPCHandler.maxNPCs + 7) >> 3];

	public boolean withinDistance(Player otherPlr) {
		if (heightLevel != otherPlr.heightLevel)
			return false;
		int deltaX = otherPlr.absX - absX, deltaY = otherPlr.absY - absY;
		return deltaX <= 15 && deltaX >= -16 && deltaY <= 15 && deltaY >= -16;
	}

	public boolean withinDistance(NPC npc) {
		if (heightLevel != npc.heightLevel)
			return false;
		if (npc.needRespawn == true)
			return false;
		int deltaX = npc.absX - absX, deltaY = npc.absY - absY;
		return deltaX <= 15 && deltaX >= -16 && deltaY <= 15 && deltaY >= -16;
	}

	public int distanceToPoint(int pointX, int pointY) {
		return (int) Math.sqrt(Math.pow(absX - pointX, 2)
				+ Math.pow(absY - pointY, 2));
	}

	public int mapRegionX, mapRegionY;
	public int absX, absY;
	public int currentX, currentY;
	public int lastX, lastY, lastHeight;

	public int heightLevel;
	public int playerSE = 0x328;
	public int playerSEW = 0x333;
	public int playerSER = 0x334;

	public boolean updateRequired = true;

	public final int walkingQueueSize = 50;
	public int walkingQueueX[] = new int[walkingQueueSize],
			walkingQueueY[] = new int[walkingQueueSize];
	public int wQueueReadPtr = 0;
	public int wQueueWritePtr = 0;
	public boolean isRunning = true;
	public int teleportToX = -1, teleportToY = -1;

	public void resetWalkingQueue() {
		wQueueReadPtr = wQueueWritePtr = 0;

		for (int i = 0; i < walkingQueueSize; i++) {
			walkingQueueX[i] = currentX;
			walkingQueueY[i] = currentY;
		}
	}

	public void addToWalkingQueue(int x, int y) {
		// if (VirtualWorld.I(heightLevel, absX, absY, x, y, 0)) {
		int next = (wQueueWritePtr + 1) % walkingQueueSize;
		if (next == wQueueWritePtr)
			return;
		walkingQueueX[wQueueWritePtr] = x;
		walkingQueueY[wQueueWritePtr] = y;
		wQueueWritePtr = next;
		// }
	}

	public boolean goodDistance(int objectX, int objectY, int playerX,
			int playerY, int distance) {
		for (int i = 0; i <= distance; i++) {
			for (int j = 0; j <= distance; j++) {
				if ((objectX + i) == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				} else if ((objectX - i) == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				} else if (objectX == playerX
						&& ((objectY + j) == playerY
								|| (objectY - j) == playerY || objectY == playerY)) {
					return true;
				}
			}
		}
		return false;
	}

	public int getNextWalkingDirection() {
				Client c = (Client) PlayerHandler.players[this.playerId];
		if (wQueueReadPtr == wQueueWritePtr)
			return -1;
		int dir;
		do {
			dir = Misc.direction(currentX, currentY,
					walkingQueueX[wQueueReadPtr], walkingQueueY[wQueueReadPtr]);
			if (dir == -1) {
				wQueueReadPtr = (wQueueReadPtr + 1) % walkingQueueSize;
			} else if ((dir & 1) != 0) {
				println_debug("Invalid waypoint in walking queue!");
				resetWalkingQueue();
				return -1;
			}
		} while ((dir == -1) && (wQueueReadPtr != wQueueWritePtr));
		if (dir == -1)
			return -1;
		dir >>= 1;
		currentX += Misc.directionDeltaX[dir];
		currentY += Misc.directionDeltaY[dir];
		absX += Misc.directionDeltaX[dir];
		absY += Misc.directionDeltaY[dir];
			c.updateWalkEntities();
		return dir;
	}

	public boolean didTeleport = false;
	public boolean mapRegionDidChange = false;
	public int dir1 = -1, dir2 = -1;
	public boolean createItems = false;
	public int poimiX = 0, poimiY = 0;

	public void getNextPlayerMovement() {
		getMovementQueue().process();
	}

	public void updateThisPlayerMovement(Buffer str) {
		if (mapRegionDidChange) {
			str.createFrame(73);
			str.writeWordA(mapRegionX + 6);
			str.writeWord(mapRegionY + 6);
		}

			str.createFrameVarSizeWord(81);
			str.initBitAccess();
		if (didTeleport) {
			str.writeBits(1, 1);
			str.writeBits(2, 3);
			str.writeBits(2, heightLevel);
			str.writeBits(1, 1);
			str.writeBits(1, (updateRequired) ? 1 : 0);
			str.writeBits(7, currentY);
			str.writeBits(7, currentX);
			return;
		}

		if (dir1 == -1) {
			isMoving = false;
			if (updateRequired) {
				str.writeBits(1, 1);
				str.writeBits(2, 0);
			} else {
				str.writeBits(1, 0);
			}
			if (DirectionCount < 50) {
				DirectionCount++;
			}
		} else {
			DirectionCount = 0;
			str.writeBits(1, 1);

			if (dir2 == -1) {
				isMoving = true;
				str.writeBits(2, 1);
				str.writeBits(3, Misc.xlateDirectionToClient[dir1]);
				str.writeBits(1, updateRequired ? 1 : 0);
			} else {
				isMoving = true;
				str.writeBits(2, 2);
				str.writeBits(3, Misc.xlateDirectionToClient[dir1]);
				str.writeBits(3, Misc.xlateDirectionToClient[dir2]);
				str.writeBits(1, updateRequired ? 1 : 0);
			}
		}
	}
	public boolean stopPlayer(boolean stop) {
		return (stop ? stopPlayerPacket == true : stopPlayerPacket == false);
	}
	public void updatePlayerMovement(Buffer str) {
		if (dir1 == -1) {
			if (updateRequired || isChatTextUpdateRequired()) {

				str.writeBits(1, 1);
				str.writeBits(2, 0);
			} else
				str.writeBits(1, 0);
		} else if (dir2 == -1) {

			str.writeBits(1, 1);
			str.writeBits(2, 1);
			str.writeBits(3, Misc.xlateDirectionToClient[dir1]);
			str.writeBits(1, (updateRequired || isChatTextUpdateRequired()) ? 1
					: 0);
		} else {

			str.writeBits(1, 1);
			str.writeBits(2, 2);
			str.writeBits(3, Misc.xlateDirectionToClient[dir1]);
			str.writeBits(3, Misc.xlateDirectionToClient[dir2]);
			str.writeBits(1, (updateRequired || isChatTextUpdateRequired()) ? 1
					: 0);
		}
	}

	public byte cachedPropertiesBitmap[] = new byte[(Config.MAX_PLAYERS + 7) >> 3];

			public int[] keepItems = new int[4];
			public int[] keepItemsN = new int[4];
			public int WillKeepAmt1,WillKeepAmt2,WillKeepAmt3,WillKeepAmt4,WillKeepItem1,WillKeepItem2,WillKeepItem3,WillKeepItem4,WillKeepItem1Slot,WillKeepItem2Slot,WillKeepItem3Slot,WillKeepItem4Slot,EquipStatus;
			
	    public int getCarriedWealth() { 
				int toReturn = 0;         
					for (int i = 0; i < c.playerEquipment.length; i++) {             
						if (c.playerEquipment[i] > 0 && Server.itemHandler.ItemList[c.playerEquipment[i]] != null)
							toReturn += (Server.itemHandler.ItemList[c.playerEquipment[i]].ShopValue * c.playerEquipmentN[i]);         
						}
					for (int i = 0; i < c.playerItems.length; i++) {             
						if (c.playerItems[i] > 0 && Server.itemHandler.ItemList[c.playerItems[i]] != null)                 
							toReturn += (Server.itemHandler.ItemList[c.playerItems[i]].ShopValue * c.playerItemsN[i]);         
					}         
					return toReturn;               
			}
			
			public int getLootBagWealth() { 
				int toReturn = 0;  
					for (int i = 0; i < c.playerLootItems.length; i++) {             
						if (c.playerLootItems[i] > 0 && Server.itemHandler.ItemList[c.playerLootItems[i]] != null)                 
							toReturn += c.getShops().getItemShopValue(c.playerLootItems[i]) * c.playerLootItemsN[i];         
					}         
					return toReturn;               
			}
		    public int getRiskedWealth() { 
				int toReturn = 0;         
				for (int i = 0; i < c.playerEquipment.length; i++) {             
					if (c.playerEquipment[i] > 0 && Server.itemHandler.ItemList[c.playerEquipment[i]] != null)
						toReturn += (Server.itemHandler.ItemList[c.playerEquipment[i]].ShopValue * c.playerEquipmentN[i]);         
					}
				for (int i = 0; i < c.playerItems.length; i++) {             
					if (c.playerItems[i] > 0 && Server.itemHandler.ItemList[c.playerItems[i]] != null)                 
						toReturn += (Server.itemHandler.ItemList[c.playerItems[i]].ShopValue * c.playerItemsN[i]);         
				}         
				return toReturn-(c.getShops().getItemShopValue(c.itemKeptId[0])+c.getShops().getItemShopValue(c.itemKeptId[1])+c.getShops().getItemShopValue(c.itemKeptId[2])+c.getShops().getItemShopValue(c.itemKeptId[3]));               
			
			}
			public void ResetKeepItems(){
				WillKeepAmt1 = -1;
				WillKeepItem1 = -1;
				WillKeepAmt2 = -1;
				WillKeepItem2 = -1;
				WillKeepAmt3 = -1;
				WillKeepItem3 = -1;
				WillKeepAmt4 = -1;
				WillKeepItem4 = -1;
			}
			public void StartBestItemScan(Client c){
				if(c.isSkulled && !c.prayerActive[10]){
					ItemKeptInfo(c, 0);
					return;
				}
				FindItemKeptInfo(c);	
				ResetKeepItems();
				BestItem1(c);
			}

			public void FindItemKeptInfo(Client c){
				if(isSkulled && c.prayerActive[10])
					ItemKeptInfo(c, 1);
				else if(!isSkulled && !c.prayerActive[10])
					ItemKeptInfo(c, 3);
				else if(!isSkulled && c.prayerActive[10])
					ItemKeptInfo(c, 4);	
			}
			
		Client c = (Client) this;
			public void ItemKeptInfo(Client c,int Lose){
				for(int i = 34568; i < 34588; i++){
					c.getPA().sendFrame126("",i);
				}
				c.getPA().sendFrame126("Item's Kept on Death", 34403);
				c.getPA().sendFrame126("Items you will keep on death:",34404);
				c.getPA().sendFrame126("Items you will lose on death:",34405);
				c.getPA().sendFrame126("Information:",34406);
				c.getPA().sendFrame126("Max items kept on death:",34407);
				c.getPA().sendFrame126("~ "+Lose+" ~",34408);
				c.getPA().sendFrame126("The normal amount of",34568);
				c.getPA().sendFrame126("items kept is three.",34569);
				c.getPA().sendFrame126("Carried wealth:",34409);
				c.getPA().sendFrame126(""+Misc.insertCommasToNumber(Integer.toString(getCarriedWealth())),34410);
				c.getPA().sendFrame126("Risked wealth:",34411);
				c.getPA().sendFrame126(""+Misc.insertCommasToNumber(Integer.toString(getRiskedWealth())),34412);
				switch (Lose){
					case 0:
					default:
						c.getPA().sendFrame126("Items you will keep on death:",34404);
						c.getPA().sendFrame126("Items you will lose on death:",34405);
						c.getPA().sendFrame126("You're marked with a",34571);
						c.getPA().sendFrame126("@red@skull. @lre@This reduces the",34572);
						c.getPA().sendFrame126("items you keep from",34573);
						c.getPA().sendFrame126("three to zero!",34574);		
						break;			
			case 1:
					c.getPA().sendFrame126("Items you will keep on death:",34404);
				c.getPA().sendFrame126("Items you will lose on death:",34405);
				c.getPA().sendFrame126("You're marked with a",34571);
				c.getPA().sendFrame126("@red@skull. @lre@This reduces the",34572);
				c.getPA().sendFrame126("items you keep from",34573);
				c.getPA().sendFrame126("three to zero!",34574);	
				c.getPA().sendFrame126("However, you also have",34575);
				c.getPA().sendFrame126("the @red@Protect @lre@Items prayer",34576);
				c.getPA().sendFrame126("active, which saves you",34577);
				c.getPA().sendFrame126("one extra item!",34578);
			break;
			case 3:
					c.getPA().sendFrame126("Items you will keep on death(if not skulled):",34404);
				c.getPA().sendFrame126("Items you will lose on death(if not skulled):",34405);
				c.getPA().sendFrame126("You have no factors",34571);
				c.getPA().sendFrame126("affecting the items you",34572);
				c.getPA().sendFrame126("keep.",34573);
			break;
			case 4:
						c.getPA().sendFrame126("Items you will keep on death(if not skulled):",34404);
				c.getPA().sendFrame126("Items you will lose on death(if not skulled):",34405);
				c.getPA().sendFrame126("You have the @red@Protect",34571);
				c.getPA().sendFrame126("@red@Item @lre@prayer active,",34572);
				c.getPA().sendFrame126("which saves you one",34573);
				c.getPA().sendFrame126("extra item!",34574);
			break;
			}
		}

		public void BestItem1(Client c){
			int BestValue = 0;
			int NextValue = 0;
			int ItemsContained = 0;
			WillKeepItem1 = 0;
			WillKeepItem1Slot = 0;
			for(int ITEM = 0; ITEM < 28; ITEM++){
				if(playerItems[ITEM] > 0){
				ItemsContained += 1;
					NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerItems[ITEM]-1));
					if(NextValue > BestValue){
						BestValue = NextValue;
						WillKeepItem1 = playerItems[ITEM]-1;
						WillKeepItem1Slot = ITEM;
						if(playerItemsN[ITEM] > 2 && !c.prayerActive[10]){
						WillKeepAmt1 = 3;
						} else if(playerItemsN[ITEM] > 3 && c.prayerActive[10]){
						WillKeepAmt1 = 4;
						} else {
						WillKeepAmt1 = playerItemsN[ITEM]; 
						}
					}
				}
			}
			for(int EQUIP = 0; EQUIP < 14; EQUIP++){
				if(playerEquipment[EQUIP] > 0){
				ItemsContained += 1;
				NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerEquipment[EQUIP]));
					if(NextValue > BestValue){
						BestValue = NextValue;
						WillKeepItem1 = playerEquipment[EQUIP];
						WillKeepItem1Slot = EQUIP+28;
						if(playerEquipmentN[EQUIP] > 2 && !c.prayerActive[10]){
						WillKeepAmt1 = 3;
						} else if(playerEquipmentN[EQUIP] > 3 && c.prayerActive[10]){
						WillKeepAmt1 = 4;
						} else {
						WillKeepAmt1 = playerEquipmentN[EQUIP]; 
						}
					}
				}
			}
			if(!isSkulled && ItemsContained > 1 && (WillKeepAmt1 < 3 || (c.prayerActive[10] && WillKeepAmt1 < 4))){
			BestItem2(c, ItemsContained);
			}
		}

		public void BestItem2(Client c, int ItemsContained){
			int BestValue = 0;
			int NextValue = 0;
			WillKeepItem2 = 0;
			WillKeepItem2Slot = 0;
			for(int ITEM = 0; ITEM < 28; ITEM++){
				if(playerItems[ITEM] > 0){
					NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerItems[ITEM]-1));
					if(NextValue > BestValue && !(ITEM == WillKeepItem1Slot && playerItems[ITEM]-1 == WillKeepItem1)){
						BestValue = NextValue;
						WillKeepItem2 = playerItems[ITEM]-1;
						WillKeepItem2Slot = ITEM;
						if(playerItemsN[ITEM] > 2-WillKeepAmt1 && !c.prayerActive[10]){
						WillKeepAmt2 = 3-WillKeepAmt1;
						} else if(playerItemsN[ITEM] > 3-WillKeepAmt1 && c.prayerActive[10]){
						WillKeepAmt2 = 4-WillKeepAmt1;
						} else {
						WillKeepAmt2 = playerItemsN[ITEM]; 
						}
					}
				}
			}
			for(int EQUIP = 0; EQUIP < 14; EQUIP++){
				if(playerEquipment[EQUIP] > 0){
				NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerEquipment[EQUIP]));
					if(NextValue > BestValue && !(EQUIP+28 == WillKeepItem1Slot && playerEquipment[EQUIP] == WillKeepItem1)){
						BestValue = NextValue;
						WillKeepItem2 = playerEquipment[EQUIP];
						WillKeepItem2Slot = EQUIP+28;
						if(playerEquipmentN[EQUIP] > 2-WillKeepAmt1 && !c.prayerActive[10]){
						WillKeepAmt2 = 3-WillKeepAmt1;
						} else if(playerEquipmentN[EQUIP] > 3-WillKeepAmt1 && c.prayerActive[10]){
						WillKeepAmt2 = 4-WillKeepAmt1;
						} else {
						WillKeepAmt2 = playerEquipmentN[EQUIP]; 
						}
					}
				}
			}
			if(!isSkulled && ItemsContained > 2 && (WillKeepAmt1+WillKeepAmt2 < 3 || (c.prayerActive[10] && WillKeepAmt1+WillKeepAmt2 < 4))){
			BestItem3(c, ItemsContained);
			}
		}

		public void BestItem3(Client c, int ItemsContained){
			int BestValue = 0;
			int NextValue = 0;
			WillKeepItem3 = 0;
			WillKeepItem3Slot = 0;
			for(int ITEM = 0; ITEM < 28; ITEM++){
				if(playerItems[ITEM] > 0){
					NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerItems[ITEM]-1));
					if(NextValue > BestValue && !(ITEM == WillKeepItem1Slot && playerItems[ITEM]-1 == WillKeepItem1) && !(ITEM == WillKeepItem2Slot && playerItems[ITEM]-1 == WillKeepItem2)){
						BestValue = NextValue;
						WillKeepItem3 = playerItems[ITEM]-1;
						WillKeepItem3Slot = ITEM;
						if(playerItemsN[ITEM] > 2-(WillKeepAmt1+WillKeepAmt2) && !c.prayerActive[10]){
						WillKeepAmt3 = 3-(WillKeepAmt1+WillKeepAmt2);
						} else if(playerItemsN[ITEM] > 3-(WillKeepAmt1+WillKeepAmt2) && c.prayerActive[10]){
						WillKeepAmt3 = 4-(WillKeepAmt1+WillKeepAmt2);
						} else {
						WillKeepAmt3 = playerItemsN[ITEM]; 
						}
					}
				}
			}
			for(int EQUIP = 0; EQUIP < 14; EQUIP++){
				if(playerEquipment[EQUIP] > 0){
				NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerEquipment[EQUIP]));
					if(NextValue > BestValue && !(EQUIP+28 == WillKeepItem1Slot && playerEquipment[EQUIP] == WillKeepItem1) && !(EQUIP+28 == WillKeepItem2Slot && playerEquipment[EQUIP] == WillKeepItem2)){
						BestValue = NextValue;
						WillKeepItem3 = playerEquipment[EQUIP];
						WillKeepItem3Slot = EQUIP+28;
						if(playerEquipmentN[EQUIP] > 2-(WillKeepAmt1+WillKeepAmt2) && !c.prayerActive[10]){
						WillKeepAmt3 = 3-(WillKeepAmt1+WillKeepAmt2);
						} else if(playerEquipmentN[EQUIP] > 3-WillKeepAmt1 && c.prayerActive[10]){
						WillKeepAmt3 = 4-(WillKeepAmt1+WillKeepAmt2);
						} else {
						WillKeepAmt3 = playerEquipmentN[EQUIP]; 
						}
					}
				}
			}
			if(!isSkulled && ItemsContained > 3 && c.prayerActive[10] && ((WillKeepAmt1+WillKeepAmt2+WillKeepAmt3) < 4)){
			BestItem4(c);
			}
		}

		public void BestItem4(Client c){
			int BestValue = 0;
			int NextValue = 0;
			WillKeepItem4 = 0;
			WillKeepItem4Slot = 0;
			for(int ITEM = 0; ITEM < 28; ITEM++){
				if(playerItems[ITEM] > 0){
					NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerItems[ITEM]-1));
					if(NextValue > BestValue && !(ITEM == WillKeepItem1Slot && playerItems[ITEM]-1 == WillKeepItem1) && !(ITEM == WillKeepItem2Slot && playerItems[ITEM]-1 == WillKeepItem2) && !(ITEM == WillKeepItem3Slot && playerItems[ITEM]-1 == WillKeepItem3)){
						BestValue = NextValue;
						WillKeepItem4 = playerItems[ITEM]-1;
						WillKeepItem4Slot = ITEM;
					}
				}
			}
			for(int EQUIP = 0; EQUIP < 14; EQUIP++){
				if(playerEquipment[EQUIP] > 0){
				NextValue = (int) Math.floor(c.getShops().getItemShopValue(playerEquipment[EQUIP]));
					if(NextValue > BestValue && !(EQUIP+28 == WillKeepItem1Slot && playerEquipment[EQUIP] == WillKeepItem1) && !(EQUIP+28 == WillKeepItem2Slot && playerEquipment[EQUIP] == WillKeepItem2) && !(EQUIP+28 == WillKeepItem3Slot && playerEquipment[EQUIP] == WillKeepItem3)){
						BestValue = NextValue;
						WillKeepItem4 = playerEquipment[EQUIP];
						WillKeepItem4Slot = EQUIP+28;
					}
				}
			}
		}

	public void addNewNPC(NPC npc, Buffer str, Buffer updateBlock) {
		int id = npc.npcId;
		npcInListBitmap[id >> 3] |= 1 << (id & 7);
		npcList[npcListSize++] = npc;

		str.writeBits(14, id);

		int z = npc.absY - absY;
		if (z < 0)
			z += 32;
		str.writeBits(5, z);
		z = npc.absX - absX;
		if (z < 0)
			z += 32;
		str.writeBits(5, z);

		str.writeBits(1, 0);
		str.writeBits(16, npc.npcType);

		boolean savedUpdateRequired = npc.updateRequired;
		npc.updateRequired = true;
		npc.appendNPCUpdateBlock(updateBlock);
		npc.updateRequired = savedUpdateRequired;
		str.writeBits(1, 1);
	}

	public void addNewPlayer(Player plr, Buffer str, Buffer updateBlock) {
		int id = plr.playerId;
		playerInListBitmap[id >> 3] |= 1 << (id & 7);
		playerList[playerListSize++] = plr;
		str.writeBits(11, id);
		str.writeBits(1, 1);
		boolean savedFlag = plr.isAppearanceUpdateRequired();
		boolean savedUpdateRequired = plr.updateRequired;
		plr.setAppearanceUpdateRequired(true);
		plr.updateRequired = true;
		plr.appendPlayerUpdateBlock(updateBlock);
		plr.setAppearanceUpdateRequired(savedFlag);
		plr.updateRequired = savedUpdateRequired;
		str.writeBits(1, 1);
		int z = plr.absY - absY;
		if (z < 0)
			z += 32;
		str.writeBits(5, z);
		z = plr.absX - absX;
		if (z < 0)
			z += 32;
		str.writeBits(5, z);
	}

	public int DirectionCount = 0;
	private boolean appearanceUpdateRequired = true;
	protected int hitDiff2;
	private int hitDiff = 0;
	protected boolean hitUpdateRequired2;
	private boolean hitUpdateRequired = false;
	public boolean isDead = false;

	protected static Buffer playerProps;
	static {
		playerProps = new Buffer(new byte[100]);
	}

	protected void appendPlayerAppearance(Buffer str) {
		playerProps.currentOffset = 0;

		playerProps.writeByte(playerAppearance[0]);

		playerProps.writeByte(headIcon);
		playerProps.writeByte(headIconPk);
		// playerProps.writeByte(headIconHints);
		// playerProps.writeByte(bountyIcon);
		if(!isNpc) {

		if (playerEquipment[playerHat] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerHat]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerCape] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerCape]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerAmulet] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerAmulet]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerWeapon] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerWeapon]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerChest] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerChest]);
		} else {
			playerProps.writeWord(0x100 + playerAppearance[2]);
		}

		if (playerEquipment[playerShield] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerShield]);
		} else {
			playerProps.writeByte(0);
		}

		if (!Item.isFullBody(playerEquipment[playerChest])) {
			playerProps.writeWord(0x100 + playerAppearance[3]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerLegs] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerLegs]);
		} else {
			playerProps.writeWord(0x100 + playerAppearance[5]);
		}

		if (!Item.isFullHelm(playerEquipment[playerHat])
				&& !Item.isFullMask(playerEquipment[playerHat])) {
			playerProps.writeWord(0x100 + playerAppearance[1]);
		} else {
			playerProps.writeByte(0);
		}

		if (playerEquipment[playerHands] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerHands]);
		} else {
			playerProps.writeWord(0x100 + playerAppearance[4]);
		}

		if (playerEquipment[playerFeet] > 1) {
			playerProps.writeWord(0x200 + playerEquipment[playerFeet]);
		} else {
			playerProps.writeWord(0x100 + playerAppearance[6]);
		}

		if (playerAppearance[0] != 1
				&& !Item.isFullMask(playerEquipment[playerHat])) {
			playerProps.writeWord(0x100 + playerAppearance[7]);
		} else {
			playerProps.writeByte(0);
		}
		} else {//send npc data
			playerProps.writeWord(-1);//Tells client that were being a npc
			playerProps.writeWord(npcId2);//send NpcID
		}
		playerProps.writeByte(playerAppearance[8]);
		playerProps.writeByte(playerAppearance[9]);
		playerProps.writeByte(playerAppearance[10]);
		playerProps.writeByte(playerAppearance[11]);
		playerProps.writeByte(playerAppearance[12]);
		playerProps.writeWord(playerStandIndex); // standAnimIndex
		playerProps.writeWord(playerTurnIndex); // standTurnAnimIndex
		playerProps.writeWord(playerWalkIndex); // walkAnimIndex
		playerProps.writeWord(playerTurn180Index); // turn180AnimIndex
		playerProps.writeWord(playerTurn90CWIndex); // turn90CWAnimIndex
		playerProps.writeWord(playerTurn90CCWIndex); // turn90CCWAnimIndex
		playerProps.writeWord(playerRunIndex); // runAnimIndex
		playerProps.writeQWord(Misc.playerNameToInt64(playerName));
		combatLevel = calculateCombatLevel();
		playerProps.writeByte(combatLevel); // combat level
		playerProps.writeWord(0);
		str.writeByteC(playerProps.currentOffset);
		str.writeBytes(playerProps.buffer, playerProps.currentOffset, 0);
	}

	public int calculateCombatLevel() {
		int j = getLevelForXP(playerXP[playerAttack]);
		int k = getLevelForXP(playerXP[playerDefence]);
		int l = getLevelForXP(playerXP[playerStrength]);
		int i1 = getLevelForXP(playerXP[playerHitpoints]);
		int j1 = getLevelForXP(playerXP[playerPrayer]);
		int k1 = getLevelForXP(playerXP[playerRanged]);
		int l1 = getLevelForXP(playerXP[playerMagic]);
		int combatLevel = (int) (((k + i1) + Math.floor(j1 / 2)) * 0.24798D) + 1;
		double d = (j + l) * 0.32500000000000001D;
		double d1 = Math.floor(k1 * 1.5D) * 0.32500000000000001D;
		double d2 = Math.floor(l1 * 1.5D) * 0.32500000000000001D;
		if (d >= d1 && d >= d2) {
			combatLevel += d;
		} else if (d1 >= d && d1 >= d2) {
			combatLevel += d1;
		} else if (d2 >= d && d2 >= d1) {
			combatLevel += d2;
		}
		return combatLevel;
	}

	public int getLevelForXP(int exp) {
		if (exp > 13034430) {
			return 99;
		} else {
			int points = 0;
			for (int lvl = 1; lvl <= 99; ++lvl) {
				points = (int) ((double) points + Math.floor((double) lvl
						+ 300.0D * Math.pow(2.0D, (double) lvl / 7.0D)));
				int var5 = (int) Math.floor((double) (points / 4));
				if (var5 >= exp) {
					return lvl;
				}
			}

			return 99;
		}
	}

	private boolean chatTextUpdateRequired = false;
	private byte chatText[] = new byte[4096];
	private byte chatTextSize = 0;
	private int chatTextColor = 0;
	private int chatTextEffects = 0;

	protected void appendPlayerChatText(Buffer str) {
		str.writeWordBigEndian(((getChatTextColor() & 0xFF) << 8)
				+ (getChatTextEffects() & 0xFF));
		str.writeByte(playerRights);
		str.writeByteC(getChatTextSize());
		str.writeBytes_reverse(getChatText(), getChatTextSize(), 0);
	}

	public void forcedChat(String text) {
		forcedText = text;
		forcedChatUpdateRequired = true;
		updateRequired = true;
		setAppearanceUpdateRequired(true);
	}

	public String forcedText = "null";

	public void appendForcedChat(Buffer str) {
		str.writeString(forcedText);
	}

	/**
	 * Graphics
	 **/

	public int mask100var1 = 0;
	public int mask100var2 = 0;
	protected boolean mask100update = false;

	public void appendMask100Update(Buffer str) {
		str.writeWordBigEndian(mask100var1);
		str.writeDWord(mask100var2);
	}

	public void gfx100(int gfx) {
		mask100var1 = gfx;
		mask100var2 = 6553600;
		mask100update = true;
		updateRequired = true;
	}

	public void gfx0(int gfx) {
		updateRequired = true;
		mask100var2 = 65536;
		mask100var1 = gfx;
		mask100update = true;
	}

	public boolean wearing2h() {
		Client c = (Client) this;
		String s = c.getItems().getItemName(c.playerEquipment[c.playerWeapon]);
		if (s.contains("2h"))
			return true;
		if (s.contains("bulwark") || s.contains("elder maul") || s.contains("stunning hammer"))
			return true;
		if (s.contains("godsword") || s.contains("k'ril"))
			return true;

		return false;
	}
	/**
	 * Animations
	 **/
	public void startAnimation(int animId) {
		//if (wearing2h() && animId == 829)
			//return;
		animationRequest = animId;
		animationWaitCycles = 0;
		updateRequired = true;
	}

	public void startAnimation(int animId, int time) {
		animationRequest = animId;
		animationWaitCycles = time;
		updateRequired = true;
	}

	public void appendAnimationRequest(Buffer str) {
		str.writeWordBigEndian((animationRequest == -1) ? 65535
				: animationRequest);
		str.writeByteC(animationWaitCycles);
	}

	/**
	 * Face Update
	 **/

	protected boolean faceUpdateRequired = false;
	public int face = -1;
	public int FocusPointX = -1, FocusPointY = -1;

	public void faceUpdate(int index) {
		face = index;
		faceUpdateRequired = true;
		updateRequired = true;
	}

	public void appendFaceUpdate(Buffer str) {
		str.writeWordBigEndian(face);
	}

	public void turnPlayerTo(int pointX, int pointY) {
		FocusPointX = 2 * pointX + 1;
		FocusPointY = 2 * pointY + 1;
		updateRequired = true;
	}

	private void appendSetFocusDestination(Buffer str) {
		str.writeWordBigEndianA(FocusPointX);
		str.writeWordBigEndian(FocusPointY);
	}

	/**
	 * Hit Update
	 **/

	protected void appendHitUpdate(Buffer str) {
		str.writeByte(getHitDiff()); // What the perseon got 'hit' for
		if (poisonMask == 1) {
			str.writeByteA(2);
		} else if (getHitDiff() > 0) {
			str.writeByteA(1); // 0: red hitting - 1: blue hitting
		} else {
			str.writeByteA(0); // 0: red hitting - 1: blue hitting
		}
		if (playerLevel[3] <= 0) {
			playerLevel[3] = 0;
			isDead = true;
		}
		str.writeByteC(playerLevel[3]); // Their current hp, for HP bar
		str.writeByte(getLevelForXP(playerXP[3]));
	}

	protected void appendHitUpdate2(Buffer str) {
		str.writeByte(hitDiff2); // What the perseon got 'hit' for
		if (poisonMask == 2) {
			str.writeByteS(2);
			poisonMask = -1;
		} else if (hitDiff2 > 0) {
			str.writeByteS(1); // 0: red hitting - 1: blue hitting
		} else {
			str.writeByteS(0); // 0: red hitting - 1: blue hitting
		}
		if (playerLevel[3] <= 0) {
			playerLevel[3] = 0;
			isDead = true;
		}
		str.writeByte(playerLevel[3]); // Their current hp, for HP bar
		str.writeByteC(getLevelForXP(playerXP[3])); // Their max hp, for HP
	}
	/**
	 * 0 North 1 East 2 South 3 West
	 */
	 public int x1 = -1, y1 = -1, x2 = -1, y2 = -1 , speed1 = -1,
			speed2 = -1, direction = -1;
	public int xOffsetWalk, yOffsetWalk;
	
	public void setForceMovement(int xOffset, int yOffset, int speedOne, int speedTwo, String directionSet,
			int animation) {
		//if (isForceMovementActive() || forceMovement) {
		//	return;
		//}
		//forceMovementActive = true;
		isRunning2 = false;
		stopMovement();
		xOffsetWalk = xOffset - c.getX();
		yOffsetWalk = yOffset - c.getY();
		playerStandIndex = 0x328;
		playerWalkIndex = 0x333;
		playerRunIndex = 0x338;
		playerTurn180Index = 0x334;
		playerTurn90CWIndex = 0x335;
		playerTurn90CCWIndex = 0x336;
		playerTurnIndex = 0x337;
		playerWalkIndex = animation;
		playerRunIndex = animation;
		//setAppearanceUpdateRequired(true);
            c.getNextPlayerMovement();
			c.getPA().walkTo(xOffsetWalk , yOffsetWalk);
			c.getPA().requestUpdates();
			c.postProcessing();
	}
	public void appendPlayerUpdateBlock(Buffer str) {
		if (!updateRequired && !isChatTextUpdateRequired())
			return; // nothing required
		int updateMask = 0;
		if (mask100update) {
			updateMask |= 0x100;
		}
		if (animationRequest != -1) {
			updateMask |= 8;
		}
		if (forcedChatUpdateRequired) {
			updateMask |= 4;
		}
		if (isChatTextUpdateRequired()) {
			updateMask |= 0x80;
		}
		if (isAppearanceUpdateRequired()) {
			updateMask |= 0x10;
		}
		if (faceUpdateRequired) {
			updateMask |= 1;
		}
		if (FocusPointX != -1) {
			updateMask |= 2;
		}
		if (isHitUpdateRequired()) {
			updateMask |= 0x20;
		}

		if (hitUpdateRequired2) {
			updateMask |= 0x200;
		}

		if (updateMask >= 0x100) {
			updateMask |= 0x40;
			str.writeByte(updateMask & 0xFF);
			str.writeByte(updateMask >> 8);
		} else {
			str.writeByte(updateMask);
		}

		// now writing the various update blocks itself - note that their
		// order crucial
		if (mask100update) {
			appendMask100Update(str);
		}
		if (animationRequest != -1) {
			appendAnimationRequest(str);
		}
		if (forcedChatUpdateRequired) {
			appendForcedChat(str);
		}
		if (isChatTextUpdateRequired()) {
			appendPlayerChatText(str);
		}
		if (faceUpdateRequired) {
			appendFaceUpdate(str);
		}
		if (isAppearanceUpdateRequired()) {
			appendPlayerAppearance(str);
		}
		if (FocusPointX != -1) {
			appendSetFocusDestination(str);
		}
		if (isHitUpdateRequired()) {
			appendHitUpdate(str);
		}
		if (hitUpdateRequired2) {
			appendHitUpdate2(str);
		}
	}

	public void clearUpdateFlags() {
		updateRequired = false;
		setChatTextUpdateRequired(false);
		setAppearanceUpdateRequired(false);
		setHitUpdateRequired(false);
		hitUpdateRequired2 = false;
		forcedChatUpdateRequired = false;
		mask100update = false;
		animationRequest = -1;
		FocusPointX = -1;
		FocusPointY = -1;
		poisonMask = -1;
		faceUpdateRequired = false;
		face = 65535;
	}

	public void stopMovement() {
		/*if (teleportToX <= 0 && teleportToY <= 0) {
			teleportToX = absX;
			teleportToY = absY;
		}
		newWalkCmdSteps = 0;
		getNewWalkCmdX()[0] = getNewWalkCmdY()[0] = travelBackX[0] = travelBackY[0] = 0;
		getNextPlayerMovement();*/
		getMovementQueue().reset();
		getMovementQueue().resetFollowing();
	}

	private int newWalkCmdX[] = new int[walkingQueueSize];
	private int newWalkCmdY[] = new int[walkingQueueSize];
	public int newWalkCmdSteps = 0;
	private boolean newWalkCmdIsRunning = false;
	protected int travelBackX[] = new int[walkingQueueSize];
	protected int travelBackY[] = new int[walkingQueueSize];
	protected int numTravelBackSteps = 0;

	public void preProcessing() {
		newWalkCmdSteps = 0;
	}

	public abstract void process();

	public abstract boolean processQueuedPackets();

	public void postProcessing() {
		if (this.newWalkCmdSteps > 0) {
			int firstX = this.getNewWalkCmdX()[0];
			int firstY = this.getNewWalkCmdY()[0];
			boolean found = false;
			this.numTravelBackSteps = 0;
			int ptr = this.wQueueReadPtr;
			int dir = Misc.direction(this.currentX, this.currentY, firstX,
					firstY);
			if (dir != -1 && (dir & 1) != 0) {
				do {
					int var13 = dir;
					--ptr;
					if (ptr < 0) {
						ptr = 49;
					}

					this.travelBackX[this.numTravelBackSteps] = this.walkingQueueX[ptr];
					this.travelBackY[this.numTravelBackSteps++] = this.walkingQueueY[ptr];
					dir = Misc.direction(this.walkingQueueX[ptr],
							this.walkingQueueY[ptr], firstX, firstY);
					if (var13 != dir) {
						found = true;
						break;
					}
				} while (ptr != this.wQueueWritePtr);
			} else {
				found = true;
			}

			if (found) {
				this.wQueueWritePtr = this.wQueueReadPtr;
				this.addToWalkingQueue(this.currentX, this.currentY);
				int i;
				if (dir != -1 && (dir & 1) != 0) {
					for (i = 0; i < this.numTravelBackSteps - 1; ++i) {
						this.addToWalkingQueue(this.travelBackX[i],
								this.travelBackY[i]);
					}

					i = this.travelBackX[this.numTravelBackSteps - 1];
					int wayPointY2 = this.travelBackY[this.numTravelBackSteps - 1];
					int wayPointX1;
					int wayPointY1;
					if (this.numTravelBackSteps == 1) {
						wayPointX1 = this.currentX;
						wayPointY1 = this.currentY;
					} else {
						wayPointX1 = this.travelBackX[this.numTravelBackSteps - 2];
						wayPointY1 = this.travelBackY[this.numTravelBackSteps - 2];
					}

					dir = Misc.direction(wayPointX1, wayPointY1, i, wayPointY2);
					if (dir != -1 && (dir & 1) == 0) {
						dir >>= 1;
						found = false;
						int x = wayPointX1;
						int y = wayPointY1;

						while (x != i || y != wayPointY2) {
							x += Misc.directionDeltaX[dir];
							y += Misc.directionDeltaY[dir];
							if ((Misc.direction(x, y, firstX, firstY) & 1) == 0) {
								found = true;
								break;
							}
						}

						if (!found) {
							this.println_debug("Fatal: Internal error: unable to determine connection vertex!  wp1=("
									+ wayPointX1
									+ ", "
									+ wayPointY1
									+ "), wp2=("
									+ i
									+ ", "
									+ wayPointY2
									+ "), "
									+ "first=("
									+ firstX
									+ ", "
									+ firstY + ")");
						} else {
							this.addToWalkingQueue(wayPointX1, wayPointY1);
						}
					} else {
						this.println_debug("Fatal: The walking queue is corrupt! wp1=("
								+ wayPointX1
								+ ", "
								+ wayPointY1
								+ "), "
								+ "wp2=(" + i + ", " + wayPointY2 + ")");
					}
				} else {
					for (i = 0; i < this.numTravelBackSteps; ++i) {
						this.addToWalkingQueue(this.travelBackX[i],
								this.travelBackY[i]);
					}
				}

				for (i = 0; i < this.newWalkCmdSteps; ++i) {
					this.addToWalkingQueue(this.getNewWalkCmdX()[i],
							this.getNewWalkCmdY()[i]);
				}
			}

			this.isRunning = this.isNewWalkCmdIsRunning() || this.isRunning2;
		}
	}

	public int getMapRegionX() {
		return mapRegionX;
	}

	public int getMapRegionY() {
		return mapRegionY;
	}

	public int getLocalX() {
		return getX() - 8 * getMapRegionX();
	}

	public int getLocalY() {
		return getY() - 8 * getMapRegionY();
	}
	public int getX() {
		return absX;
	}

	public int getY() {
		return absY;
	}

	public int getH() {
		return heightLevel;
	}

	public void setX(int i){
		c.teleportToX = i;
	}
	public void setY(int i){
		c.teleportToY = i;
	}
	public void setHeight(int i){
		c.heightLevel = i;
	}
	
	public int getId() {
		return playerId;
	}

	public boolean inPcBoat() {
		return absX >= 2660 && absX <= 2663 && absY >= 2638 && absY <= 2643;
	}

	public boolean inPcGame() {
		return absX >= 2624 && absX <= 2690 && absY >= 2550 && absY <= 2619;
	}

	public void setHitDiff(int hitDiff) {
		this.hitDiff = hitDiff;
	}

	public void setHitDiff2(int hitDiff2) {
		this.hitDiff2 = hitDiff2;
	}

	public int getHitDiff() {
		return hitDiff;
	}

	public void setHitUpdateRequired(boolean hitUpdateRequired) {
		this.hitUpdateRequired = hitUpdateRequired;
	}

	public void setHitUpdateRequired2(boolean hitUpdateRequired2) {
		this.hitUpdateRequired2 = hitUpdateRequired2;
	}

	public boolean isHitUpdateRequired() {
		return hitUpdateRequired;
	}

	public boolean getHitUpdateRequired() {
		return hitUpdateRequired;
	}

	public boolean getHitUpdateRequired2() {
		return hitUpdateRequired2;
	}

	public void setAppearanceUpdateRequired(boolean appearanceUpdateRequired) {
		this.appearanceUpdateRequired = appearanceUpdateRequired;
	}

	public boolean isAppearanceUpdateRequired() {
		return appearanceUpdateRequired;
	}

	public void setChatTextEffects(int chatTextEffects) {
		this.chatTextEffects = chatTextEffects;
	}

	public int getChatTextEffects() {
		return chatTextEffects;
	}

	public void setChatTextSize(byte chatTextSize) {
		this.chatTextSize = chatTextSize;
	}

	public byte getChatTextSize() {
		return chatTextSize;
	}

	public void setChatTextUpdateRequired(boolean chatTextUpdateRequired) {
		this.chatTextUpdateRequired = chatTextUpdateRequired;
	}

	public boolean isChatTextUpdateRequired() {
		return chatTextUpdateRequired;
	}

	public void setChatText(byte chatText[]) {
		this.chatText = chatText;
	}

	public byte[] getChatText() {
		return chatText;
	}

	public void setChatTextColor(int chatTextColor) {
		this.chatTextColor = chatTextColor;
	}

	public int getChatTextColor() {
		return chatTextColor;
	}

	public void setNewWalkCmdX(int newWalkCmdX[]) {
		this.newWalkCmdX = newWalkCmdX;
	}

	public int[] getNewWalkCmdX() {
		return newWalkCmdX;
	}

	public void setNewWalkCmdY(int newWalkCmdY[]) {
		this.newWalkCmdY = newWalkCmdY;
	}

	public int[] getNewWalkCmdY() {
		return newWalkCmdY;
	}

	public void setNewWalkCmdIsRunning(boolean newWalkCmdIsRunning) {
		this.newWalkCmdIsRunning = newWalkCmdIsRunning;
	}

	public boolean isNewWalkCmdIsRunning() {
		return newWalkCmdIsRunning;
	}

	public void setInStreamDecryption(ISAACRandomGen inStreamDecryption) {
	}

	public void setOutStreamDecryption(ISAACRandomGen outStreamDecryption) {
	}

	public boolean samePlayer() {
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (j == playerId)
				continue;
			if (PlayerHandler.players[j] != null) {
				if (PlayerHandler.players[j].playerName
						.equalsIgnoreCase(playerName)) {
					disconnected = true;
					return true;
				}
			}
		}
		return false;
	}

	public void putInCombat(int attacker) {
		underAttackBy = attacker;
		logoutDelay = System.currentTimeMillis();
		singleCombatDelay = System.currentTimeMillis();
	}

	public void dealDamage(int damage) {
		if (teleTimer <= 0)
			playerLevel[3] -= damage;
		else {
			if (hitUpdateRequired)
				hitUpdateRequired = false;
			if (hitUpdateRequired2)
				hitUpdateRequired2 = false;
		}

	}

	public int[] damageTaken = new int[Config.MAX_PLAYERS];

	public void handleHitMask(int damage) {
		if (!hitUpdateRequired) {
			hitUpdateRequired = true;
			hitDiff = damage;
		} else if (!hitUpdateRequired2) {
			hitUpdateRequired2 = true;
			hitDiff2 = damage;
		}
		updateRequired = true;
	}

}