package server.model.players;

import server.util.Misc;
import server.Config;
import server.model.npcs.NPCHandler;
import server.model.players.quests.*;
public class DialogueHandler {

	private Client c;

	public DialogueHandler(Client client) {
		this.c = client;
	}
	/**
	 *
	 * Chat Animations
	 *
	 **/
	 	public enum Anim {
			REALLY_SAD(9760),
			SAD(9765),
			DEPRESSED(9770),
			WORRIED(9775),
			SCARED(9780),
			MEAN_FACE(9785),
			MEAN_HEAD_BANG(9790),
			EVIL(9795),
			WHAT_THE_CRAP(9800),
			CALM(9810),
			CALM_NO_TALK(9805),
			CALM_TALK(9810),
			TOUGH(9815),
			SNOBBY(9820),
			SNOBBY_HEAD_MOVE(9825),
			CONFUSED(9830),
			DRUNK_HAPPY_TIRED(9835),
			TALKING_ALOT(9845),
			HAPPY_TALKING(9850),
			BAD_ASS(9855),
			THINKING(9860),
			COOL_YES(9864),
			LAUGH_EXCITED(9851),
			SECRELTY_TALKING(9838);

			private final int animationId;

			Anim(int animationId) {
				this.animationId = animationId;
			}

			public int getAnimationId() {
				return animationId;
			}
		}
	/**
	 * Handles all talking
	 * 
	 * @param dialogue
	 *            The dialogue you want to use
	 * @param npcId
	 *            The npc id that the chat will focus on during the chat
	 */
	public void sendDialogues(int dialogue, int npcId) {
		if(npcId != -1)
			c.talkingNpc = npcId;
		switch (dialogue) {
		case 0:
			c.talkingNpc = -1;
			c.getPA().removeAllWindows();
			c.nextChat = 0;
			break;
		case 1:
			sendPlayerChat1("Hello, how's it going?", Anim.CALM.getAnimationId());
			if(Misc.random(4) == 1)
			c.nextChat = 2;
			else
			c.nextChat = 3;
		break;
		case 2:
			sendNpcChat2("Not too bad, ", "But Im a little worried about the increase of goblins these days", c.talkingNpc, "Man", Anim.CALM.getAnimationId());
			c.nextChat = 0;
		break;
		case 3:
			sendNpcChat1("How can I help you?", c.talkingNpc, "Man", Anim.CALM.getAnimationId());
			c.nextChat = 4;
		break;
		case 4:
			sendOption3("Do you want to trade?", "I'm in search of a quest.", "I'm in search of enemies to kill.");
			//c.nextChat = 1504;
			c.dialogueAction = 4;
		break;
			
		//Silk Trader dialogue
		case 16:
			sendNpcChat1("Do you want to buy any fine silks?", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
			c.nextChat = 17;
			break;
				case 17:
					sendOption2("How much are they?", "No. Silk doesn't suit me.");
					//Family Crest Dialogue
					//sendOption3("How much are they?", "No. Silk doesn't suit me.", "I'm in search of a man named Avan Fitzharmon");
					c.dialogueAction = 17;
					break;
					case 18:
						sendPlayerChat1("How much are they?", Anim.CALM.getAnimationId());
						c.nextChat = 19;
						break;
						case 19:
							sendNpcChat1("3 gp.", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
							c.nextChat = 20;
							break;
							case 20:
								sendOption2("No. That's too much for me.", "Okay, that sounds good.");
								c.dialogueAction = 20;
								break;
								case 21:
									sendPlayerChat1("No. That's too much for me", Anim.CALM.getAnimationId());
									c.nextChat = 22;
									break;
									case 22:
										sendNpcChat1("2 gp and that's as low as I'll go.", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
										c.nextChat = 23;
										break;
									case 23:
										sendNpcChat2("I'm not selling it for any less", "You'll probably go and sell it in Varrock for a profit, anyway.", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
										c.nextChat = 24;
										break;
										case 24:
											sendOption2("2 gp sounds good.", "No, really. I don't want it.");
											c.dialogueAction = 24;
											break;
											case 25:
												sendPlayerChat1("Oh dear. I don't have enough money.", Anim.CONFUSED.getAnimationId());
												c.nextChat = 26;
												break;
												case 26:
													sendNpcChat1("Well, come back when you do have some money!", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
													c.nextChat = 0;
													break;
											case 27:
												sendPlayerChat1("No, really. I don't want it.", Anim.CONFUSED.getAnimationId());
												c.nextChat = 28;
												break;
												case 28:
													sendNpcChat1("Okay, but that's the best price you're going to get.", c.talkingNpc, "Silk Trader", Anim.CALM.getAnimationId());
													c.nextChat = 0;
												break;
							case 29:
								sendPlayerChat1("Okay, that sounds good.", Anim.CALM.getAnimationId());
								c.nextChat = 30;
								break;	
								case 30:
									if(c.getItems().playerHasItem(995, 2)){
										c.getItems().deleteItem(995, c.getItems().getItemSlot(995), 2);
										c.getItems().addItem(950, 1);
									c.nextChat = 0;
									c.dialogueAction = 0;
									c.getPA().closeAllWindows();
									} else
									c.nextChat = 25;
								break;
							case 31:
								sendPlayerChat1("No. Silk doesn't suit me.", Anim.CALM.getAnimationId());
								c.nextChat = 0;
							break;
       case 101:
		sendPlayerChat1("Good day to you Sir.", Anim.CALM.getAnimationId());
		c.nextChat = 102;
		break;
		case 102:
			sendNpcChat1("Well hello my brave adventurer.", c.talkingNpc, "Murphy", Anim.CALM_TALK.getAnimationId());
			c.nextChat = 103;
			break;
		case 103:
			sendPlayerChat1("What are you up to?", Anim.CALM.getAnimationId());
			c.nextChat = 104;
			break;
		case 104:
			sendNpcChat1("Getting ready to go fishing of course. There's no time to waste!", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 105;
			break;
		case 105:
			sendNpcChat3("I've got all the supplies I need from the shop","at the end of the pier. They sell good rope, hammers and axes","although their bailing buckets aren't too effective.", c.talkingNpc, "Murphy", Anim.SNOBBY.getAnimationId());
			c.nextChat = 106;
			break;
		case 106:
			sendOption2("What fish do you catch?", "Your boat doesn't look too safe.");
			c.dialogueAction = 106;
			break;
		case 107:
			sendPlayerChat1("What fish do you catch?", Anim.CALM.getAnimationId());
			c.nextChat = 108;
			break;
		case 108:
			sendNpcChat3("I get all sorts, anything that lies on the sea bed,","you never know what you're going to get until"," you pull up the net!", c.talkingNpc, "Murphy", Anim.CALM_TALK.getAnimationId());
			c.nextChat = 106;
			break;
		case 109:
			sendPlayerChat1("Your boat doesn't look too safe.", Anim.WORRIED.getAnimationId());
			c.nextChat = 110;
			break;
		case 110:
			sendNpcChat1("That's because it's not, the darn thing's full of holes.", c.talkingNpc, "Murphy", Anim.DEPRESSED.getAnimationId());
			c.nextChat = 111;
			break;
		case 111:
			sendPlayerChat1("Oh, so I suppose you can't go out for a while?", Anim.CALM.getAnimationId());
			c.nextChat = 112;
			break;
		case 112:
			sendNpcChat3("Oh no, I don't let a few holes stop an experienced"," sailor like me. I could sail these seas in a barrel,"," I'll be going out soon enough.", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 113;
			break;
		case 113:
			sendPlayerChat1("Could I help?", Anim.CALM.getAnimationId());
			c.nextChat = 114;
			break;
		case 114:
			sendNpcChat3("Well of course you can! I'll warn you though,"," the seas are merciless and without fishing experience"," you won't catch much.", c.talkingNpc, "Murphy", Anim.SNOBBY.getAnimationId());
			c.nextChat = 115;
			break;
		case 115:
			sendNpcChat2("You need a fishing level of 15 or above ","to catch any fish on the trawler.", c.talkingNpc, "Murphy", Anim.WORRIED.getAnimationId());
			c.nextChat = 116;
			break;
		case 116:
			sendNpcChat2("On occasions the net rips,", "so you'll need some rope to repair it.", c.talkingNpc, "Murphy", Anim.DEPRESSED.getAnimationId());
			c.nextChat = 117;
			break;
		case 117:
			sendNpcChat2("Repairing the net is difficult in the harsh conditions"," so you'll find it easier with a higher crafting level.", c.talkingNpc, "Murphy", Anim.DEPRESSED.getAnimationId());
			c.nextChat = 118;
			break;
		case 118:
			sendPlayerChat1("Right...ok.", Anim.CALM.getAnimationId());
			c.nextChat = 119;
			break;
		case 119:
			sendNpcChat1("There's also a slight problem with leaks.", c.talkingNpc, "Murphy", Anim.WORRIED.getAnimationId());
			c.nextChat = 120;
			break;
		case 120:
			sendPlayerChat1("Leaks?!", Anim.SAD.getAnimationId());
			c.nextChat = 121;
			break;
		case 121:
			sendNpcChat1("Nothing some swamp paste won't fix...", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 122;
			break;
		case 122:
			sendPlayerChat1("Swamp paste?", Anim.CONFUSED.getAnimationId());
			c.nextChat = 123;
			break;
		case 123:
			sendNpcChat1("Also, there's the small matter of the Kraken.", c.talkingNpc, "Murphy", Anim.WHAT_THE_CRAP.getAnimationId());
			c.nextChat = 124;
			break;
		case 124:
			sendPlayerChat1("You have got to be kidding me?", Anim.WHAT_THE_CRAP.getAnimationId());
			c.nextChat = 125;
			break;
		case 125:
			sendNpcChat2("Occupational hazard. I usually whack it with an axe"," a few times and fix the damage with a hammer once it's gone.", c.talkingNpc, "Murphy", Anim.WORRIED.getAnimationId());
			c.nextChat = 126;
			break;
		case 126:
			sendNpcChat1("Oh, and one more thing... I hope you're a good swimmer?", c.talkingNpc, "Murphy", Anim.SCARED.getAnimationId());
			c.nextChat = 127;
			break;
		case 127:
			sendOption2("Actually, I think I'll leave it.", "I'll be fine, let's go.");
			c.dialogueAction = 127;
			break;
		case 128:
			sendPlayerChat1("Actually, I think I'll leave it.", Anim.CALM.getAnimationId());
			c.nextChat = 129;
			break;
		case 129:
			sendNpcChat1("Bloomin' land lovers!!!", c.talkingNpc, "Murphy", Anim.SAD.getAnimationId());
			c.nextChat = 0;
			break;
		case 130:
			sendPlayerChat1("I'll be fine, let's go.", Anim.HAPPY_TALKING.getAnimationId());
			// Handle options based on whether the trawler is at port or at sea
			if (c.TrawlerStatus == 0 && c.TrawlerInPort) {
				c.nextChat = 131;
			} else {
				c.nextChat = 132;
			}
			break;
		case 131:
			sendNpcChat2("Aye aye! Meet me on board the trawler."," I just need to get a few things together.", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			break;
		case 132:
			sendNpcChat1("Aye aye! Meet me on board the trawler.", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 133;
			break;
		case 133:
			sendNpcChat2("Oh hang on. I'm already on a fishing trip with"," someone. You'll have to try back in a few minutes.", c.talkingNpc, "Murphy", Anim.SNOBBY.getAnimationId());
			c.nextChat = 134;
			break;
		case 134:
			sendPlayerChat1("How can you be here and on board the boat?!", Anim.WHAT_THE_CRAP.getAnimationId());
			c.nextChat = 135;
			break;
		case 135:
			sendNpcChat1("That's Game Magic, [lass/son].", c.talkingNpc, "Murphy", Anim.WHAT_THE_CRAP.getAnimationId());
			c.nextChat = 136;
			break;
		case 136:
			sendPlayerChat1("What?!", Anim.CONFUSED.getAnimationId());
			c.nextChat = 137;
			break;
		case 137:
			sendNpcChat1("Never mind. Just try back later OK?", c.talkingNpc, "Murphy", Anim.CALM.getAnimationId());
			c.nextChat = 0;
			break;
		case 138:
			sendPlayerChat1("What's swamp paste?", Anim.CONFUSED.getAnimationId());
			c.nextChat = 139;
			break;
		case 139:
			sendNpcChat2("Swamp tar mixed with flour"," which is then heated over a fire.", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 140;
			break;
		case 140:
			sendPlayerChat1("Where can I find swamp tar?", Anim.CONFUSED.getAnimationId());
			c.nextChat = 141;
			break;
		case 141:
			sendNpcChat2("Unfortunately the only supply of swamp tar"," is in the swamps below Lumbridge.", c.talkingNpc, "Murphy", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 0;
			break;
		case 500:
			sendNpcChat1("You already have some air runes.", c.talkingNpc, "Magic combat tutor", Anim.THINKING.getAnimationId());
			c.nextChat = 0;
			break;
		case 501:
			sendNpcChat2("You already have a training sword and shield.","Save some for the other adventurers.", c.talkingNpc, "Melee combat tutor", Anim.THINKING.getAnimationId());
			c.nextChat = 502;
			break;
		case 502:
			sendNpcChat2("Greetings adventurer, I am the Melee combat tutor.","Is there anything I can do for you?", c.talkingNpc, "Melee combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 505;
			break;
		case 503:
			sendNpcChat1("Here is a training bow and arrows, use them well.", c.talkingNpc, "Ranged combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 0;
			break;
		case 504:
			sendNpcChat1("Here is 30 air and mind runes, use them well.", c.talkingNpc, "Magic combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 0;
			break;
		case 505:
			sendOption5("Tell me about melee combat.", "Tell me about different weapon types I can use.", "Tell me about skillcapes", "I'd like a training sword and shield.", "Goodbye.");
			c.dialogueAction = 505;
			break;
		case 506:
			sendPlayerChat1("Tell me about melee combat.", Anim.CALM_TALK.getAnimationId());
			c.nextChat = 507;
			break;
		case 507:
			sendNpcChat2("Well adventurer, the first thing you will need is a", "sword and a shield appropriate for your level.", c.talkingNpc, "Melee combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.setSidebarInterface(4, 1644);
			c.nextChat = 508;
			break;
		case 508:
			sendNpcChat4("Make sure to equip your sword and shield.","Click on them in your inventory they will disappear", "from your inventory and move to your worn items.", "You can see your worn items in the worn items tab here", c.talkingNpc, "Melee combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.setSidebarInterface(0, 2423);
			c.nextChat = 509;
			break;
		case 509:
			sendNpcChat2("When you are wielding your sword you will then be able","to see the correct options in the combat interface.", c.talkingNpc, "Melee combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 510;
			break;
		case 510:
			sendNpcChat3("There are four different melee styles.", "Accurate, aggressive, defensive and controlled.", "Not all weapons will have all four styles though.", c.talkingNpc, "Melee combat tutor", Anim.HAPPY_TALKING.getAnimationId());
			c.nextChat = 511;
			break;
		case 511:
			sendPlayerChat1("Interesting, what does each style do?", Anim.THINKING.getAnimationId());
			c.nextChat = 0;
			break;

			/** Bank Settings **/
			case 1013:
				sendNpcChat1("Good day. How may I help you?", c.talkingNpc, "Banker", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 1014;
				break;
			case 1014:// bank open done, this place done, settings done, to do
				// delete pin
				sendOption3("I'd like to access my bank account, please.", "I'd like to check my my P I N settings.", "What is this place?");
				c.dialogueAction = 251;
				break;
			/** What is this place? **/
			case 1015:
				sendPlayerChat1("What is this place?", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 1016;
				break;
			case 1016:
				sendNpcChat2("This is the bank of " + Config.SERVER_NAME + ".", "We have many branches in many towns.", c.talkingNpc, "Banker", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 0;
				break;
			/**
			 * Note on P I N. In order to check your "Pin Settings. You must have
			 * enter your Bank Pin first
			 **/
			/** I don't know option for Bank Pin **/
			case 1017:
				sendStartInfo("Since you don't know your P I N, it will be deleted in @red@3 days@bla@. If you", "wish to cancel this change, you may do so by entering your P I N", "correctly next time you attempt to use your bank.", "", "");
				c.nextChat = 0;
				break;
			case 3000: // first part. Entering the tutorial island
				c.getPA().chatbox(6180); // displays
				// client.getPacketDispatcher().chatbox
				// client.getPlayerAssistant().tutorialIslandInterface(0, 0); //
				// progress bar + tutorial int
				c.getPA().drawHeadicon(1, 945, 0, 0);//drawHeadicon(int i, int j, int k, int l)
				chatboxText("To start the tutorial use your left mouse button to click on the",
						"Runescape guide in this room. He is indicated by a flashing",
						"yellow arrow above his head. If you can't see him, use your",
						"keyboard's arrow keys to rotate the view.",
						"@blu@Getting started");
				c.getPA().chatbox(6179); // displays
				// client.getPacketDispatcher().chatbox
				c.tutorialProgress = 0;
				c.canWalkTutorial = true;
				c.nextChat = 0;
				break;
			/*
			 * RS guide section
			 */
			case 3001: // RS GUIDE
				sendNpcChat2("Greetings! I see you are a new arrival to the land. My","job is to welcome all new visitors. So welcome!",
						c.talkingNpc, "Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3002;
				break;
			case 3002: // 2
				sendNpcChat2("You have already learned the first thing needed to",
						"succeed in this world: talking to other people!",
						c.talkingNpc, "Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3003;
				break;

			case 3003: // 3
				sendNpcChat3(
						"You will find many inhabitants of this world have useful",
						"things to say to you. By clicking on them with your",
						"mouse you can talk to them.", c.talkingNpc,
						"Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3004;
				break;
			case 3004:
				sendNpcChat4(
						"I would also suggest reading through some of the",
						"supporting information on the website. There you can",
						"find the Knowledge Base, which contains all the",
						"additional information you're ever likely to need. It also",
						c.talkingNpc, "Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3005;
				break;
			case 3005:
				sendNpcChat2("contains maps and helpful tips to help you on your",
						"journey.", c.talkingNpc, "Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3006;
				break;

			case 3006:// show tab wrentch
				clearChatBoxText(c); // call this every time there is new
				// client.getPacketDispatcher().chatboxtext
				// coming up
				sendNpcChat2(
						"You will notice a flashing icon of a wrench, please click",
						"on this to continue the tutorial.", c.talkingNpc,
						"Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.setSidebarInterface(11, 904); // wrench
				// tab
				c.getPA().flashSideBarIcon(-11);
				c.nextChat = 3007;
				break;

			case 3007: // Player controls
				c.getPA().closeAllWindows();
				chatboxText("Please click on the flashing wrench icon found at the bottom",
						"right of your screen. This will display your player controls.",
						"", "", "Player controls");
				c.nextChat = 0;
				break;
			case 3008: // Glad your making progress
				sendNpcChat1("I'm glad you're making progress!", c.talkingNpc,
						"Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3009;
			break;

			case 3009:
				sendNpcChat2("To continue the tutorial go through that door over",
						"there and speak to your first instructor!",
						c.talkingNpc, "Runescape Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3010;
			break;
			case 3010:
				c.tutorialProgress = 2;
				c.getPA().chatbox(6180);
				c.getPA().closeAllWindows();
				chatboxText(
						
						"You can interact with many items of scenery by simply clicking",
						"on them. Right clicking will also give more options. Feel free to",
						"try it with the things in this room, then click on the door",
						"indicated with the yellow arrow to go through to the next instructor.",
						"Interacting with scenery");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3098, 3107, c.getH(),
						2);
				c.nextChat = 0;
			break;

			case 3011: // door handling
				c.getPA().closeAllWindows();
				chatboxText(
						
						"Follow the path to find the next instructor. Clicking on the",
						"ground will walk you to that point. Talk to the Survival Expert by",
						"the pond to the continue the tutorial. Remember you can rotate",
						"the view by pressing the arrow keys.", "Moving around");
				//c.getPA().createPlayerHints(1, 2);
				c.getPA().drawHeadicon(1, 943, 0, 0);//drawHeadicon(int i, int j, int k, int l)
				// client.getPacketDispatcher().tutorialIslandInterface(5, 2);
				// // progress bar + tutorial int
				c.nextChat = 0;
				break;
						/*
			 * Survival Expert. Second part.
			 */
			case 3012: // Survival Expert
				sendNpcChat4(
						"Hello there, newcomer. My name is Brynna. My job is",
						"to teach you a few survival tips and tricks. First off",
						"we're going to start with the most basic survival skill of",
						"all: making a fire.", c.talkingNpc, "Survival Expert", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3013;
				break;

			case 3013: // giving bronze and tinder
				sendItemChat(590, 150, "",
						"The Survival Guide gives you a @blu@tinderbox @bla@and a",
						"@blu@bronze axe!");
				c.getItems().addItem(590, 1);
				c.getItems().addItem(1351, 1);
				if(!c.getItems().playerHasItem(1351, 1)){
					c.getItems().addItem(1351, 1);
				} 
				if(!c.getItems().playerHasItem(590, 1)){
					c.getItems().addItem(590, 1);
				}
				c.nextChat = 0;
				chatboxText("Click on the flashing backpack icons to the right hand side of",
						"the main window to view your inventory. Your inventory is a list",
						"of everything you have on your backpack.", "",
						"Viewing the items that you were given");
				c.setSidebarInterface(3, 3213);// sends
				// interface
				c.getPA().flashSideBarIcon(-3); // flashes
				// inventory
				c.tutorialProgress = 3;
				break;
			case 3014: // finished cutting tree
				sendItemChat(1511, 150, "", "You got some logs");
				c.getPA().removeHintIcon(c);
				c.nextChat = 3015;
				break;
			case 3015: // firemaking time
				c.getPA().closeAllWindows();
				chatboxText("Well done! You managed to cut some logs from the tree! Next,",
						"use the tinderbox in your inventory to light the logs.",
						"First click on the tinderbox to use it.",
						"Then click on the logs in your inventory to light them.",
						"Making a fire");
				// client.getPacketDispatcher().createArrow(1, 2); // sends to
				// Survival Expert
				c.tutorialProgress = 4;
				break;

			case 3016: // firemaking done skill tab flashing now.
				// client.getPA().closeAllWindows();
				chatboxText("Click on the flashing bar graph icon near the inventory button",
						"to see your skill stats.", "", "",
						"You gained some experience.");
				c.getPA().flashSideBarIcon(-2); // flashes
				// skill
				c.setSidebarInterface(2, 27101); // sets
				// the
				// skill
				// tab
				c.nextChat = 3017;
				break;

			case 3017: // survival expert part 2
				sendNpcChat3("Well done! Next we need to get some food in our",
						"bellies. We'll need something to cook. There are shrimp",
						"in the pond there so let's catch and cook some.",
						c.talkingNpc, "Survival Expert", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3018;

				break;

			case 3018:
				sendItemChat(303, 150, "",
						"The Survival Guide gives you a @blu@net!");
				c.getItems().addItem(303, 1);
				c.nextChat = 0;
				chatboxText("Click on the sparkling fishing spot indicated by the flashing",
						"arrow. Remember, you can check your inventory by clicking the",
						"backpack icon.", "", "Catch some Shrimp");
				c.getPA().createObjectHints(3101, 3092, c.getH(),
						2);
				c.tutorialProgress = 6;
				break;

			case 3019: // Cooking the shrimp
				c.getPA().chatbox(6180);
				chatboxText("Now you have caught some shrimp let's cook it. First light a",
						"fire, chop down a tree and then use the tinderbox on the logs.",
						"If you've lost your axe or tinderbox, Brynna will give you",
						"another.", "Cooking your shrimp.");
				c.getPA().chatbox(6179);
				break;		

			/*
			 * cooking tutor
			 */
			case 3020: // tutorial PROGRESS = 7
				// client.getPacketDispatcher().tutorialIslandInterface(15,4);
				// // 15 percent
				c.getPA().chatbox(6180);
				chatboxText("Talk to the chef indicated. He will teach you the more advanced",
						"aspects of Cooking such as combining ingredients. He will also",
						"teach you about your music player menu as well.", "",
						"Find your next instructor");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3078, 3084, c.getH(), 2);
				break;

			case 3021: // start of dialogue.
				sendNpcChat3(
						"Ah! Welcome newcomer. I am the Master Chef Leo. It",
						"is here I will teach you how to cook food truly fit for a",
						"king.", c.talkingNpc, "Master Chef", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3022;
				break;

			case 3022:
				sendPlayerChat2("I already know how to cook. Brynna taught me just", "now.", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3023;
				break;
			case 3023:
				sendNpcChat3("Hahahahahaha! You call THAT cooking? Some shrimp",
						"on an open log fire? Oh no, no, no. I am going to",
						"teach you the fine art of cooking bread.",
						c.talkingNpc, "Master Chef", Anim.LAUGH_EXCITED.getAnimationId());
				c.nextChat = 3024;
				break;
			case 3024:
				sendNpcChat2("And no fine meal is complete without good music, so",
						"we'll cover that while you're here too.",
						c.talkingNpc, "Master Chef", Anim.HAPPY_TALKING.getAnimationId());
				c.nextChat = 3025;
				break;

			case 3025:
				sendItemChat(1933, 150, 
						"",
						"The Cooking Guide gives you a @blu@bucket of water@bla@ and a",
						"@blu@pot of flour!");
				if(c.getItems().playerHasItem(1931, 1)){
					c.getItems().deleteItem(1931, 1);
					c.getItems().addItem(1933, 1);
				} 
				if(c.getItems().playerHasItem(1925, 1)){
					c.getItems().deleteItem(1925, 1);
					c.getItems().addItem(1929, 1);
				} else {
					c.getItems().addItem(1929, 1);
					c.getItems().addItem(1933, 1);
				}
				c.nextChat = 0;
				chatboxText("This is the base for many of the meals. To make dough we must",
						"mix flour and water. First right click the bucket of water and",
						"select use, then left click on the pot of flour.", "",
						"Making dough");
				c.getPA().removeHintIcon(c);
				c.tutorialProgress = 8;

				break;
			case 3026: // cooking dough
				c.getPA().chatbox(6180);
				chatboxText(
						
						"Now you have made dough, you can cook it. To cook the dough",
						"use it with the range shown by the arrow. If you lose your",
						"dough, talk to Leo - he will give you more ingredients.",
						"", "Cooking dough");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3075, 3081, c.getH(), 2);

				c.nextChat = 0;
				break;	
				case 3037: // new tutorial prog
				c.getPA().chatbox(6180);
				chatboxText(
						
						"Well done! Your first loaf of bread. As you gain experience in",
						"Cooking you will be able to make other things like pies, cakes",
						"and even kebabs. Now you've got the hang of cooking, let's",
						"move on. Click on the flashing icon in the bottom right.",
						"Cooking dough");
				c.getPA().chatbox(6179);
				c.getPA().removeHintIcon(c);
				// client.getPacketDispatcher().tutorialIslandInterface(20, 5);
				c.setSidebarInterface(13, 50020); // sets
				// music
				c.getPA().flashSideBarIcon(-13);
				c.tutorialProgress = 9;
				c.nextChat = 0;
				break;

			case 3038: // Emotes
				c.getPA().chatbox(6180);
				chatboxText(
						"",
						"Now, how about showing some feelings? You will see a flashing",
						"icon in the shape of a person. Click on that to access your",
						"emotes.", "Emotes");
				c.getPA().chatbox(6179);
				c.getPA().removeHintIcon(c);
				// client.getPacketDispatcher().tutorialIslandInterface(25, 6);
				// // 25 percent now
				c.setSidebarInterface(12, 147); // run
				// tab
				c.getPA().flashSideBarIcon(-12);
				c.nextChat = 0;
				break;
			case 3039: // running
				c.tutorialProgress = 11;
				c.getPA().chatbox(6180);
				chatboxText(
						"It's only a short distance to the next guide.",
						"Why not try running there? Start by opening the player",
						"settings, that's the flashing icon of a wrench.", "",
						"Running");
				c.getPA().chatbox(6179);
				c.getPA().flashSideBarIcon(-11);
				c.getPA().createObjectHints(3086, 3126, c.getH(),2);
				c.nextChat = 0;
				break;
			case 3040:
				c.getPA().chatbox(6180);
				chatboxText(
						"In this menu you will see many options. At the bottom in the",
						"middle is a button with the symbol of a running shoe. You can",
						"turn this button on or off to select run or walk. Give it a go,",
						"click on the run button now.", "Running");
				c.getPA().chatbox(6179);
				c.nextChat = 0;
				break;
			case 3041: // clicked on run
				c.getPA().chatbox(6180);
				chatboxText(
						"Now that you have the run button turned on, follow the path",
						"until you come to the end. You may notice that the numbers on",
						"the button goes down. This is your run energy. If your run",
						"energy reaches zero, you'll stop running.",
						"Run to the next guide");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3086, 3125, c.getH(),2);
				c.nextChat = 0;
				break;
				/**
			 * Quest Guide
			 */
			case 3042: // entering the quest GUIDE
				c.getPA().createPlayerHints(1, 4); // sends to
				// quest
				// guide
				// client.getPacketDispatcher().tutorialIslandInterface(35, 8);//30 or 35 percent
				c.getPA().chatbox(6180);
				chatboxText("Talk with the Quest Guide.", "",
						"He will tell you all about quests.", "", "");
				c.getPA().chatbox(6179);
				c.tutorialProgress = 12;
				//PassDoor.passThroughDoor(player, 3019, 2, 3, 0, 0, -1, 0);
				c.nextChat = 0;
				break;

			case 3043: // quest guide dialogue START
				sendNpcChat2(
						"Ah. Welcome, adventurer. I'm here to tell you all about",
						"quests. Let's start by opening the quest side panel.",
						c.talkingNpc, "Quest Guide", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3044;
				break;

			case 3044: // Send quest tab
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText("Open the Quest Journal.", "",
						"Click on the flashing icon next to your inventory.", "",
						"");
				c.getPA().chatbox(6179);
				c.setSidebarInterface(14, 638); // quest
				c.getPA().flashSideBarIcon(-14);
				c.nextChat = 0;
				break;

			case 3045: // quest guide 2 prog 13
				sendNpcChat3(
						"Now you have the journal open. I'll tell you a bit about",
						"it. At the moment all the quests shown in red which",
						"means you have not started them yet.", c.talkingNpc,
						"Quest Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3046;

				break;

			case 3046:
				sendNpcChat4(
						"When you start a quest it will change colour to yellow",
						"and to green when you've finished. This is so you can",
						"easily see what's complete, what's started, and what's left",
						"to begin.", c.talkingNpc, "Quest Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3047;
				break;

			case 3047:
				sendNpcChat3(
						"The start of quests are easy to find. Look out for the",
						"star icons on the minimap, just like the one you should",
						"see marking my house.", c.talkingNpc, "Quest Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3048;
				break;

			case 3048:
				sendNpcChat4(
						"The quests themselves can vary greatly from collecting",
						"beads to hunting down dragons. Generally quests are",
						"started by talking to a non-player character like me,",
						"and will involve a series of tasks.", c.talkingNpc,
						"Quest Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3049;
				break;

			case 3049: // last
				sendNpcChat4(
						"There's not a lot more I can tell you about questing.",
						"You have to experience the thrill of it yourself to fully",
						"understand. You may find some adventure in the caves",
						"under my house.", c.talkingNpc, "Quest Guide", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3050;
				break;

			case 3050: // moving on. Cave time biaches
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"",
						"It's time to enter some caves. Click on the ladder to go down to",
						"the next area.", "", "Moving on");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3088, 3119, c.getH(),
						2);
				c.nextChat = 0;
				c.tutorialProgress = 14;
				break;
			// end
			/*
			 * Start of Mining/Smithing
			 */
			case 3051:
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"Next let's get you a weapon or more to the point, you can",
						"make your first weapon yourself. Don't panic, the Mining",
						"Instructor will help you. Talk to him and he'll tell you all about it.",
						"", "Mining and Smithing");
				c.getPA().chatbox(6179);
				// client.getPacketDispatcher().tutorialIslandInterface(40,9);
				c.getPA().createPlayerHints(1, 5);
				c.nextChat = 0;
				break;

			case 3052:// mining tutor start
				sendNpcChat4("Hi there. You must be new around here. So what do I",
						"call you? Newcomer seems so impersonal and if we're",
						"going to be working together, I'd rather call you by",
						"name.", c.talkingNpc, "Mining Instructor", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3053;
				break;

			case 3053:// mining tutor start
				sendPlayerChat1("You can call me "
						+ c.playerName + ".", Anim.HAPPY_TALKING.getAnimationId());
				c.nextChat = 3054;
				break;

			case 3054:// mining tutor start
				sendNpcChat2("Ok then, " + c.playerName + "."
								+ " My name is Dezzick and I'm a",
						"miner by trade. Let's prospect some of those rocks.",
						c.talkingNpc, "Mining Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3055;
				break;

			case 3055: // prospecting
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"To prospect a mineable rock, just right click it and select the",
						"'prospect rock' option. This will tell you the type of ore you can",
						"mine from it. Try it now on one of the rocks indicated.",
						"", "Prospecting");
				c.getPA().chatbox(6179);
				// client.getPacketDispatcher().tutorialIslandInterface(40,9);
				c.getPA().createObjectHints(3076, 9504, c.getH(),
						2);
				c.nextChat = 0;
				c.tutorialProgress = 15;
				break;
			case 3056: // done prospecting
				sendPlayerChat2(
						"I prospected both types of rocks! One set contains tin",
						"and the other has copper ore inside.", Anim.HAPPY_TALKING.getAnimationId());
				c.nextChat = 3057;
				break;

			case 3057:
				sendNpcChat2(
						"Absolutely right, " + c.playerName
								+ "." + " These two ore types",
						"can be smelted together to make bronze.",
						c.talkingNpc, "Mining Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3058;
				break;

			case 3058:
				sendNpcChat3(
						"So now you know what ore is in the rocks over there,",
						"why don't you have a go at mining some tin and",
						"copper? here, you'll need this to start with.",
						c.talkingNpc, "Mining Instructor", Anim.TALKING_ALOT.getAnimationId());
				c.nextChat = 3060;
				break;
			case 3060:
				sendItemChat(1265, 150, "",
						"Dezzick gives you a @blu@bronze pickaxe!");
				c.getItems().addItem(1265, 1);
				c.nextChat = 0;
				chatboxText(
						
						"It's quite simple really. All you need to do is right click on the",
						"rock and select 'mine'. You can only mine when you have a",
						"pickaxe. So give a try: first mine one tin ore.", "",
						"Mining");
				c.getPA().createObjectHints(3076, 9504, c.getH(),
						2); // sends
				// hint
				// to
				// ore
				c.tutorialProgress = 17;
				break;

			case 3061: // furnace time
				c.tutorialProgress = 19;
				c.nextChat = 0;
				chatboxText(
						
						"You should now have both some copper and tin ore. So let's",
						"smelt them to make a bronze bar. To do this, right click on",
						"either tin or copper ore and select use, then left click on the",
						"furnace. Try it now.", "Smelting");
				break;
			case 3062: // smelting
				c.tutorialProgress = 20;
				c.nextChat = 0;
				c.getPA().chatbox(6180);
				chatboxText("", "Speak to the Mining Instructor and he'll show you how to make", "it into a weapon.", "", "You've made a bronze bar!");
				c.getPA().chatbox(6179);
				c.getPA().createPlayerHints(1, 5);
				break;

			case 3063:
				c.nextChat = 3064;
				sendPlayerChat1("How do I make a weapon out of this?", Anim.CONFUSED.getAnimationId());
				break;

			case 3064:
				sendNpcChat2("Okay, I'll show you how to make a dagger out of it.",
						"You'll be needing this...", c.talkingNpc,
						"Mining Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3065;
				break;

			case 3065: // giving you the hammer
				sendItemChat(2347, 150, "", "Dezzick gives you a @blu@hammer!");
				c.getItems().addItem(2347, 1);
				c.nextChat = 0;
				chatboxText("To smith you'll need a hammer - like the one you were given by", "Dezzick - access to an anvil like the one with the arrow over it", "and enough metal bars to make what you are trying to smith.", "", "Smithing a dagger");
				c.getPA().createObjectHints(3082, 9499, c.getH(), 2); // send
				// hint
				// to
				// furnace
				break;

			case 3066:
				chatboxText("So let's move on. Go through the gates shown by the arrow.", "Remember you may need to move the camera to see your,", "surroundings. Speak to the guide for a recap at any time.", "", "You've finished in this area");
				c.tutorialProgress = 21;
				c.getPA().createObjectHints(3094, 9503, c.getH(), 2); // send
				// hint
				// to
				// furnace
				break;
/*
			 * start of melee
			 */
			case 3067:// Melee instructor c.tutorialProgress = 22
				sendPlayerChat1("Hi! My name is "
						+ c.playerName + ".", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3068;
				break;

			case 3068:
				sendNpcChat2("Do I look like I care? To me you're just another",
						"newcomer who thinks they're ready to fight.",
						c.talkingNpc, "Combat Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3069;
				break;

			case 3069:
				sendNpcChat1("I am Vannaka, the greatest swordsman alive.",
						c.talkingNpc, "Combat Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3070;
				break;

			case 3070:
				sendNpcChat1("Let's get started by teaching you to wield a weapon",
						c.talkingNpc, "Combat Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3071;
				break;

			case 3071: // send wear interface
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"",
						"You now have access to a new interface. Click on the flashing",
						"icon of a man the one to the right of your backpack icon.",
						"", "Wielding weapons");
				c.getPA().chatbox(6179);
				c.setSidebarInterface(4, 1644);// worn
				c.getPA().flashSideBarIcon(-4);
				c.nextChat = 0;
				break;

			case 3072:
				sendNpcChat2(
						"Very good, but that little butter knife isn't going to",
						"protect you much. Here, take these.", c.talkingNpc,
						"Combat Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3073;
				break;

			case 3073:
				sendItemChat(1171, 150,
						"",// Gives me sword and shield
						"The Combat Guide gives you a @blu@bronze sword@bla@ and a",
						"@blu@wooden shield!");
				c.getItems().addItem(1171, 1);
				c.getItems().addItem(1277, 1);
				c.nextChat = 0;
				chatboxText(
						
						"In your worn inventory panel, right click on the dagger and",
						"select the remove option from the drop down list. After you've",
						"unequipped the dagger, wield the sword and shield. As you",
						"pass the mouse over an item you will see its name.",
						"Unequipping items");
				c.getPA().removeHintIcon(c);
				break;

			case 3074:
				sendPlayerChat1("I did it! I killed a giant rat!", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3075;
				break;

			case 3075:
				sendNpcChat3("I saw, " + c.playerName + "."
								+ " You seem better at this than I",
						"thought. Now that you have grasped basic swordplay",
						"let's move on.", c.talkingNpc, "Combat Instructor", Anim.CALM_TALK.getAnimationId());

				c.nextChat = 3076;
				break;

			case 3076:
				sendNpcChat4(
						"Let's try some ranged attacking, with this you can kill",
						"foes from a distance. Also, foes unable to reach you are",
						"as good as dead. You'll be able to attack the rats",
						"without entering the pit.", c.talkingNpc,
						"Combat Instructor", Anim.CALM_TALK.getAnimationId());

				c.nextChat = 3077;
				break;

			case 3077: // gives me bow and arrow
				sendItemChat(841, 150,
						"",
						"The Combat Guide gives you some @blu@bronze arrows@bla@ and",
						"a @blu@shortbow!");
				c.getItems().addItem(841, 1);
				c.getItems().addItem(882, 50);
				c.nextChat = 0;
				chatboxText(
						
						"Now you have a bow and some arrows. Before you can use",
						"them you'll need to equip them. Remember: to attack, right",
						"click on the monster and select attack.", "",
						"Rat ranging");
				c.ratdied2 = true;
				c.getPA().drawHeadicon(1, 13, 0, 0); // draws
				// headicon
				// to
				// rat
				break;
			// end of mining/smithing
			/*
			 * FINISH . Last parts, Finacial,prayer,magic
			 */

			case 3078: // fresh
				c.getPA().chatbox(6180);
				chatboxText(
						
						"Follow the path and you will come to the front of the building.",
						"This is the Bank of " + Config.SERVER_NAME
								+ ", where you can store all your",
						"most valued items. To open your bank box just right click on an",
						"open booth indicated and select 'use'.", "Banking");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3122, 3124, c.getH(),
						2);
				break;

			case 3079: // fiancial dude start
				sendPlayerChat1("Hello. Who are you?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3080;

				break;

			case 3080:
				sendNpcChat2(
						"I'm the Financial Advisor. I'm here to tell people how to",
						"make money.", c.talkingNpc, "Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3081;
				break;

			case 3081:
				sendPlayerChat1("Okay. How can I make money then?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3082;
				break;

			case 3082:
				sendNpcChat1("How you can make money? Quite.", c.talkingNpc,
						"Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3083;
				break;

			case 3083:
				sendNpcChat3(
						"Well there are three basic ways of making money here:",
						"combat, quests, and trading. I will talk you through each",
						"of them very quickly.", c.talkingNpc,
						"Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3084;
				break;

			case 3084:
				sendNpcChat3(
						"Let's start with combat as it is probably still fresh in",
						"your mind. Many enemies, both human and monster,",
						"will drop items when they die.", c.talkingNpc,
						"Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3085;
				break;

			case 3085:
				sendNpcChat3(
						"Now, the next way to earn money quickly is by quests.",
						"Many people on " + Config.SERVER_NAME
								+ " have things they need",
						"doing, which they will reward you for.",
						c.talkingNpc, "Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3086;
				break;

			case 3086:
				sendNpcChat3(
						"By getting a high level in skills such as Cooking, Mining,",
						"Smithing or Fishing, you can create or catch your own",
						"items and sell them for pure profit.", c.talkingNpc,
						"Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3087;
				break;

			case 3087:
				sendNpcChat2(
						"Well that about covers it. Come back if you'd like to go",
						"over this again.", c.talkingNpc, "Financial Advisor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3088;
				break;

			case 3088: // end
				c.getPA().closeAllWindows();
				c.tutorialProgress = 28;
				c.getPA().chatbox(6180);
				chatboxText("", "Continue through the next door.", "", "",
						"");
				c.getPA().chatbox(6179);
				c.getPA().createObjectHints(3129, 3124, c.getH(),
						2);
				c.getPA().createPlayerHints(1, 8);
				c.nextChat = 0;
				break;
			// end of FINANCIAL

			/*
			 * Section Prayer
			 */

			case 3089: // start of dialogue
				sendPlayerChat1("Good day, brother, my name's "
						+ c.playerName + ".", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3090;
				break;

			case 3090:
				sendNpcChat2("Hello, " + c.playerName + "."
								+ " I'm Brother Brace. I'm here to",
						"tell you all about Prayer.", c.talkingNpc,
						"Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3091;

				break;
			case 3091:
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText("",
						"Click on the flashing icon to open the Prayer menu.", "",
						"", "Your Prayer menu");
				c.getPA().chatbox(6179);
				c.setSidebarInterface(5, 5608);
				c.getPA().flashSideBarIcon(-5);
				c.tutorialProgress = 29;
				c.nextChat = 0;
				break;

			case 3092:
				sendNpcChat3("This is your Prayer list. Prayers can help a lot in",
						"combat. Click on the prayer you wish to use to activate",
						"it and click it again to deactivate it.",
						c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3093;

				break;
			case 3093:
				sendNpcChat3("Active prayers will drain your Prayer Points which",
						"you can recharge by finding an altar or other holy spot",
						"and praying there.", c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3094;
				break;

			case 3094:
				sendNpcChat3("As you noticed, most enemies will drop bones when",
						"defeated. Burying bones by clicking them in your",
						"inventory will gain you Prayer experience.",
						c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3095;
				break;

			case 3095:
				sendNpcChat2(
						"I'm also the community officer 'round here, so it's my",
						"job to tell you about your friends and ignore list.",
						c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3096;
				break;

			case 3096:
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"You should now see another new icon. Click on the flashing",
						"icon to open your friends list.", "", "", "Friends list");
				c.getPA().chatbox(6179);
				c.setSidebarInterface(8, 5065);
				c.getPA().flashSideBarIcon(-8);
				c.tutorialProgress = 30;
				c.nextChat = 0;
				break;

			case 3097: // long dialogue START
				// client.getPacketDispatcher().tutorialIslandInterface(75, 16);
				sendNpcChat4("Good. Now you have both menus open, I'll tell you a",
						"little about each. You can add people to either list by",
						"clicking the add button then typing their name into the",
						"box that appears.", c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3098;
				break;

			case 3098:
				sendNpcChat4(
						"You remove people from the lists in the same way. If",
						"you add someone to your ignore list they will not be",
						"able to talk to you or send any form of message to",
						"you.", c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3099;

				break;
			case 3099:
				sendNpcChat4(
						"Your friends list shows the online status of your",
						"friends. Friends in the red are offline, friends in green are",
						"online and on the same server and friends in yellow",
						"are online but on a different server.", c.talkingNpc,
						"Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3100;
				break;

			case 3100:
				sendPlayerChat1("Are there rules on in-game behaviour?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3101;
				break;
			case 3101:
				sendNpcChat3("Yes, you should read the rules of conduct on the",
						"website to make sure you do nothing to get yourself",
						"banned.", c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3102;
				break;
			case 3102:
				sendNpcChat3("But in general, always try to be courteous to other",
						"players - remember the people in the game are real",
						"people with real feelings.", c.talkingNpc,
						"Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3103;
				break;
			case 3103:
				sendNpcChat2(
						"If you go 'round being abusive or causing trouble your",
						"character could end up being the one in trouble.",
						c.talkingNpc, "Brother Brace", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3104;
				break;
			case 3104: // last one
				sendPlayerChat1("Okay thanks. I'll bear that in mind.", Anim.CALM_TALK.getAnimationId());
				c.getPA().chatbox(6180);
				chatboxText(
						
						"You're almost finished on tutorial island. Pass through the",
						"door to find the path leading to your final instructor.",
						"", "", "Your final instructor!");
				c.getPA().removeHintIcon(c);
				c.tutorialProgress = 32;
				c.getPA().chatbox(6179);
				c.getPA().createPlayerHints(1, 9);
				c.nextChat = 0;
				break;
			// END BROTHER BRACE PRAYER

			/*
			 * Start magic instructor
			 */

			case 3105:
				sendPlayerChat1("Hello.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3106;
				break;

			case 3106:
				sendNpcChat3("Good day, newcomer. My name is Terrova. I'm here",
						"to tell you about Magic. Let's start by opening your",
						"spell list.", c.talkingNpc, "Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3107;
				break;

			case 3107:
				// sendItemChat(client, "", "", 0, 50);
				c.getPA().closeAllWindows();
				c.getPA().chatbox(6180);
				chatboxText(
						
						"",
						"Open up the Magic menu by clicking on the flashing icon next",
						"to the Prayer button you just learned about.", "",
						"Open up your final menu");
				c.getPA().chatbox(6179);
				c.nextChat = 0;
				c.setSidebarInterface(6, 1151); // modern
				c.getPA().flashSideBarIcon(-6);
				break;

			case 3108:
				sendNpcChat3(
						"Good. This is a list of your spells. Currently you can",
						"only cast one offensive spell called Wind Strike. Let's",
						"try it out on one of those chickens.", c.talkingNpc,
						"Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3109;
				break;

			case 3109:
				sendItemChat(556, 300,
						"",
						"Terrova gives you five @blu@air runes@bla@ and @blu@five mind runes!");
				c.getItems().addItem(558, 5);
				c.getItems().addItem(556, 5);
				c.nextChat = 0;
				chatboxText(
						
						"Now you have runes you should see the Wind Strike icon at the",
						"top left corner of the Magic interface - second in from the",
						"left. Walk over to the caged chickens, click the Wind Strike icon",
						"and then select one of the chicken to cast it on.",
						"Cast Wind Strke at a chicken");
				// sendStatement("Now you have runes you should see the Wind Strike icon at the",
				// "top left corner of the Magic interface - second in from the",
				// "left. Walk over to the caged chickens, click the Wind Strike icon",
				// "and then select one of the chicken to cast it on.");
				c.getPA().drawHeadicon(1, 20, 0, 0); // draws
				// headicon
				// to
				// chicken
				break;

			case 3110:
				sendNpcChat2("Well you're all finished here now. I'll give you a",
						"reasonable number of runes when you leave.",
						c.talkingNpc, "Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3111;
				break;

			case 3111:
				sendOption2("Mainland", "Stay here");
				c.dialogueAction = 3111;
				c.nextChat = 0;
				break;

			case 3112:// Mainland
				c.tutorialProgress = 35;
				sendNpcChat4(
						"When you get to the mainland you will find yourself in",
						"the town of Lumbridge. If you want some ideas on",
						"where to go next talk to my friend the Lumbridge",
						"Guide. You can't miss him; he's holding a big staff with",
						c.talkingNpc, "Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3113;
				break;
			case 3113:
				sendNpcChat4(
						"a question mark on the end. He also has a white beard",
						"and carries a rucksack full of scrolls. There are also",
						"many tutors willing to teach you about the many skills",
						"you could learn.", c.talkingNpc, "Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3114;
				break;

			case 3114:
				sendNpcChat3(
						"If all else fails, visit the " + Config.SERVER_NAME
								+ " website for a whole",
						"chestload of information on quests, skills, and minigames",
						"as well as a very good starter's guide.",
						c.talkingNpc, "Magic Instructor", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3115;
				break;

			case 3115:
				c.tutorialProgress = 36;
				c.getItems().deleteAllItems();
				c.getPA().startTeleport2(Config.LUMBY_X, Config.LUMBY_Y, 0);
				sendStatement(
						"",
						"Teleporting to the main land.",
						"",
						"");
				c.nextChat = 3116;
				c.canWalkTutorial = true;
				break;
			case 3116:
				c.getPA().addStarter();
				c.sendSidebars();
				sendStatement(
						"Welcome to Lumbridge! To get more help, simply click on the",
						"Lumbridge Guide or one of the Tutors - these can be found by",
						"looking for the question mark icon on your mini-map. If you find",
						"you are lost at any time, look for a signpost.");
				c.nextChat = -1;
				c.canWalkTutorial = true;
				c.closeTutorialInterface = true;
				break;
				
			case 3118:
				sendNpcChat2("Hello " + c.playerName + ".",
						"Are you interested in buying any beer?",
						c.talkingNpc,
						NPCHandler.getNpcListName(c.talkingNpc), Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3119;
				break;

			case 3119:
				sendOption2("Yes please.", "No Thanks.");
				c.dialogueAction = 152;
				break;

			case 3120:
				sendPlayerChat1("No thanks.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;

			case 3121:
				sendPlayerChat1("Yes please.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3122;
				break;

			case 3122:
				sendOption4("Asgarnain Ale", "Wizard's Mind Bomb", "Dwarven Stout",
						"Never Mind");
				c.dialogueAction = 153;
				break;

			case 3123:
				if (c.getItems().playerHasItem(995, 3)) {
					sendPlayerChat1("Asgarnian Ale please.", Anim.CALM_TALK.getAnimationId());
					c.getItems().deleteItem(995, 3);
					c.getItems().addItem(1905, 1);
					c.nextChat = 0;
				} else {
					sendNpcChat1("You don't have enough coins to buy that.",
							c.talkingNpc,
							NPCHandler.getNpcListName(c.talkingNpc), Anim.CALM_TALK.getAnimationId());
				}
				break;

			case 3124:
				sendPlayerChat1("Wizard's Mind Bomb please.", Anim.CALM_TALK.getAnimationId());
				c.getItems().deleteItem(995, 3);
				c.getItems().addItem(1907, 1);
				c.nextChat = 0;
				break;

			case 3125:
				sendPlayerChat1("Dwarven Stout please.", Anim.CALM_TALK.getAnimationId());
				c.getItems().deleteItem(995, 3);
				c.getItems().addItem(1913, 1);
				c.nextChat = 0;
				break;

			case 3126:
				sendPlayerChat1("Never mind.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 14: // lumby guide
				sendNpcChat1(
						"Greetings, welcome to " + Config.SERVER_NAME + ".",
						c.talkingNpc, "Lumbridge Guide", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 150://bob
				sendOption2("I would like to view your shop",
						"I would like to fix my gear");
				c.dialogueAction = 91;
				break;
				/*
				* Generic Bartenders
				*/
			case 199:
				sendNpcChat1("Hello would you like to buy a beer for 2 gp?",
						c.talkingNpc, "Bartender", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 200;
				break;

			case 200:
				if (c.getItems().playerHasItem(995, 2)) {
					sendPlayerChat1("Yes I would love a beer.", Anim.CALM_TALK.getAnimationId());
					c.getItems().deleteItem(995, 2);
					c.getItems().addItem(1917, 1);
					c.nextChat = 0;
				} else {
					sendPlayerChat1("I don't have enough coins to buy a beer.", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 0;
				}
				break;
				
			case 50:
				sendNpcChat1("What am I to do?", c.talkingNpc, "Cook", Anim.WORRIED.getAnimationId());
				c.nextChat = 51;
				break;
			case 51:
				sendOption4("What's wrong?", "Can you cook me a cake?",
						"You don't look very happy.", "Nice hat.");
				c.dialogueAction = 52;
				break;
			case 52:
				sendPlayerChat1("What's wrong?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 54;
				break;
			case 54:
				sendNpcChat3(
						"Oh dear, oh dear, oh dear, I'm in a terrible terrible",
						"mess! It's the Duke's birthday today, and I should be",
						"making him a lovely big birthday cake!",
						c.talkingNpc, "Cook", Anim.WORRIED.getAnimationId());
				c.nextChat = 55;
				break;
			case 55:
				sendNpcChat4(
						"I've forgotten to buy the ingredients. I'll never get",
						"them in time now. He'll sack me! What will I do? I have",
						"four children and a goat to look after. Would you help",
						"me? Please?", c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 56;
				break;
			case 56:
				sendOption2("I'm always happy to help a cook in distress.",
						"I can't right now, Maybe later.");
				c.dialogueAction = 57;
				break;
			case 57:
				sendPlayerChat1("Yes, I'll help you.", Anim.CALM_TALK.getAnimationId());// 9157
				c.nextChat = 60;
				break;
			case 58:
				sendPlayerChat1("I can't right now, Maybe later.", Anim.CALM_TALK.getAnimationId());// 9158
				c.nextChat = 59;
				break;
			case 59:
				sendNpcChat1("Oh please! Hurry then!", c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 60:
				sendNpcChat2("Oh thank you, thank you. I need milk, an egg, and",
						"flour. I'd be very grateful if you can get them for me.",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.cookAss = 1;
				QuestAssistant.sendStages(c);
				c.nextChat = 61;
				break;
			case 61:
				sendPlayerChat1("So where do I find these ingredients then?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 62;
				break;
			case 62:
				sendNpcChat3("You can find flour in any of the shops here.",
						"You can find eggs by killing chickens.",
						"You can find milk by using a bucket on a cow",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 63:
				sendNpcChat1("I don't have time for your jibber-jabber!",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 64:
				sendNpcChat1("Does it look like I have the time?",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 65:
				sendPlayerChat1("You don't look so happy.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 54;
				break;
			case 66:
				sendNpcChat1(
						"How are you getting on with finding the ingredients?",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 67;
				break;
			case 67:
				if (c.getItems().playerHasItem(1944, 1)
						&& c.getItems().playerHasItem(1927, 1)
						&& c.getItems().playerHasItem(1933, 1)) {
					sendPlayerChat1("Here's all the items!", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 68;
				} else {
					sendPlayerChat1("I don't have all the items yet.", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 59;
				}
				break;
			case 68:
				c.getItems().deleteItem(1944, 1);
				c.getItems().deleteItem(1927, 1);
				c.getItems().deleteItem(1933, 1);
				c.cookAss = 2;
				sendNpcChat2("You brought me everything I need! I'm saved!",
						"Thank you!", c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 69;
				break;
			case 69:
				sendPlayerChat1("So do I get to go to the Duke's Party?", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 70;
				break;
			case 70:
				sendNpcChat2(
						"I'm afraid not, only the big cheeses get to dine with the",
						"Duke.", c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 72;
				break;
			case 72:
				sendPlayerChat2(
						"Well, maybe one day I'll be important enough to sit on",
						"the Duke's table", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 74;
				break;
			case 74:
				sendNpcChat1("Maybe, but I won't be holding my breath.",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 75;
				break;
			case 75:
				QuestRewards.cookReward(c);
				c.nextChat = 0;
				break;
			case 76:
				sendNpcChat1("Thanks for helping me out friend!",
						c.talkingNpc, "Cook", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
				/**
			 * CANNNON
			 * @author Andrew
			 */
			case 3500:
				/*if (c.lostCannon) {
					sendNpcChat2("Hello, " + c.playerName + ".", "I see that you lost your cannon.", c.talkingNpc, "Nulodion", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3501;
				} else {
					sendNpcChat1("" + c.playerName + " you do not have anything to collect currently.", c.talkingNpc, "Nulodion", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 0;
				}*/
				break;

			case 3501:
				/*if (c.lostCannon) {
					if (c.getItems().freeSlots() >= 4) {
						sendNpcChat1("Here is your cannon, try not to lose it again.", c.talkingNpc, "Nulodion", Anim.CALM_TALK.getAnimationId());
						for (int i = 0; i < 4; i++) {
						//c.getItems().addItem(c.getCannon().ITEM_PARTS[i], 1);
						}
						c.lostCannon = false;
						c.nextChat = 0;
					} else {
						sendNpcChat1("You need at least 4 free inventory spots.", c.talkingNpc, "Nulodion", Anim.CALM_TALK.getAnimationId());
						c.nextChat = 0;
					}
				} else {
					sendNpcChat1("" + c.playerName + " you do not have a cannon to collect currently.", c.talkingNpc, "Nulodion", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 0;
				}*/
				break;
			case 3502:
				sendNpcChat2(
						"I am the leader of the White Knights of Falador.",
						"Why do you seek my audience?",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3522;
				break;
			case 3503:
				sendOption2(
						"I seek a Quest!",
						"I don't, I'm just looking around.");
				c.dialogueAction = 1000;
				break;
					case 3533:
						sendPlayerChat1("I Seek a Quest!", Anim.CALM_TALK.getAnimationId());
						c.nextChat = 3504;
						break;
					case 3531:
							sendPlayerChat1("I don't, I'm just looking around.", Anim.CALM_TALK.getAnimationId());
							c.nextChat = 3530;
						break;
					case 3532:
						sendNpcChat1("Ok. Please don't break anything.",
								c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
						c.nextChat = 0;
						break;
			case 3504:
				sendNpcChat2("Well, I need some spy work doing but it's quite dangerous. ",
						"It will involve going into the Black Knights'Fortress.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3505;
				break;
			case 3505:
				sendOption2("I laugh in the face of danger!", "I go and cower in a corner at the fist sign of danger!");
				c.dialogueAction = 3505;
				break;
			case 3506:
				sendPlayerChat1("I laugh in the face on danger!", Anim.CALM_TALK.getAnimationId());// 9158
				c.nextChat = 3507;
				break;
			case 3507:
				sendNpcChat2("Well that's good.",
						"Don't get to overconfident though."
						, c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3508;
				break;
			case 3508:
				sendNpcChat2("You've come along at just the right time actually.",
						"All of my knights are already known to the Black Knights."
						, c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3509;
				break;
			case 3509:
				sendNpcChat1("Subtley isn't exactly our strong point.", c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 3510:
					sendPlayerChat2("Can't you just take your White Knights' armour off?", "They wouldn't recognise you then!", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3511;
				break;
			case 3511:
				sendNpcChat2("I am afraid our charter prevents us using espionage in any form,","that is the domain of the Temple Knights.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3512;
				break;
			case 3512:
					sendPlayerChat2("Temple Knights?", "Who are they?", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3513;
				break;
			case 3513:
				sendNpcChat2("That information is classified.","I am forbidden to share it with outsiders.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3514;
				break;
			case 3514:
					sendPlayerChat2("So...", "what do you need doing?", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3514;
				break;
			case 3515:
				sendNpcChat3("Well, the Black Knights have started making strange threats to us;","demanding large amounts of money and land, and threatening","to invade Falador if we don't pay them.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3516;
				break;
			case 3516:
				sendNpcChat1("Now, NORMALLY this wouldn't be a problem...",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3517;
				break;
			case 3517:
				sendNpcChat1("But they claim to have a powerful new secret weapon.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3518;
				break;
			case 3518:
				sendNpcChat3("Your mission, should you decide to accept it,", "is to infiltrate their fortress, find out what","their secret weapon is, and then sabotage it.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3519;
				break;
			case 3519:
				sendOption2_withTitle("Yes!", "No.", "Start the Black Knights' Fortress quest?");
				c.dialogueAction = 3519;
				break;
					case 3520:
							sendPlayerChat1("Ok, I'll do my best", Anim.CALM_TALK.getAnimationId());
							c.blackKnight = 1;
							QuestAssistant.sendStages(c);
							c.nextChat = 3521;
						break;
					case 3523:
							sendPlayerChat1("No, I'm not ready to do that.", Anim.CALM_TALK.getAnimationId());
							c.nextChat = 3524;
						break;
					case 3524:
						sendNpcChat1("Come see me again if you change your mind",
								c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
						c.nextChat = 0;
						break;
			case 3521:
				sendNpcChat3("Good luck!","Let me know how you get on. Here's the Dossier","for the case, I've already given you the details.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3522;
				break;
			case 3522:
			if(c.getItems().freeSlots() < 1){
				sendNpcChat2("Oh. You don't appear to have any room for the","dossier in your inventory. Come back when you do.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
			} else {
				if (!c.getItems().playerHasItem(9589, 1))
					c.getItems().addItem(9589, 1);
			}
				c.nextChat = -1;
				break;
			case 3525:
					sendPlayerChat1("I go an cower in a corner at the first sign of danger!", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3526;
				break;
			case 3526:
				sendNpcChat1("Err....",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3527;
				break;
			case 3527:
				sendNpcChat1("Well.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3528;
				break;
			case 3528:
				sendNpcChat1("I... suppose spy work DOES involve a little hiding in corners.",
						c.talkingNpc, "Sir Amik Varze", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 3529;
				break;
			case 3529:
					sendOption2("Oh. I suppose I'll give it a go then.", "No, I'm not ready to do that.");
					c.dialogueAction = 3529;
				break;
			case 3530:
					sendPlayerChat1("Oh. I suppose I'll give it a go then.", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 3508;
				break;
			/*case 3510:
				if (c.getItemAssistant().playerHasItem(291, 30)) {
					sendPlayerChat("Here's all the items!");
					c.blackKnight = 2;
					c.nextChat = 3511;
				} else {
					sendPlayerChat("I don't have all the items yet.");
					c.nextChat = 0;
				}
				break;
			case 3511:
				sendNpcChat1("Thank you very much " + Misc.capitalize(c.playerName) + "!",
						c.talkingNpc, "Sir Amik Varze");
				c.nextChat = 3512;
				break;
			case 3512:
				c.getItemAssistant().deleteItem(291, 30);
				sendNpcChat2("You brought me everything I need!",
						"Thank you!", c.talkingNpc, "Sir Amik Varze");
				c.nextChat = 3513;
				break;
			case 3513:
				sendNpcChat1("One last thing" + c.playerName + ", here is your reward.",
						c.talkingNpc, "Sir Amik Varze");
				QuestRewards.blackKnightReward(player);
				c.nextChat = 0;
				break;*/
				
				/*
				 *
				 * Elemental workshop dialogue
				 *
				 */
				 
			case 84:
				sendNpcChat1("How are you getting on finding all my supplies",
						c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 85;
				break;
			case 85:
				if (c.getItems().playerHasItem(434, 6)
						&& c.getItems().playerHasItem(436, 4)
						&& c.getItems().playerHasItem(440, 2)) {
					sendPlayerChat1("Here's all the items!", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 86;
				} else {
					sendPlayerChat1("I haven't found all the items yet.", Anim.CALM_TALK.getAnimationId());
					c.nextChat = 88;
				}
				break;
			case 86:
				c.getItems().deleteItem(434, 6);
				c.getItems().deleteItem(436, 4);
				c.getItems().deleteItem(440, 2);
				c.doricQuest = 2;
				sendNpcChat2("You brought me everything I need.", "Thank You!",
						c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 87;
				break;
			case 87:
				QuestRewards.doricFinish(c);
				c.nextChat = 0;
				break;
			case 88:
				sendNpcChat1("Hurry Then!", c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 89:
				sendNpcChat1(
						"Hello traveler, what brings you to my humble smithy?",
						c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 90;
				break;
			case 90:
				sendOption2("Mind your own buisness, Shortstuff!",
						"I wanted to use your anivils.");
				c.dialogueAction = 55;
				break;
			case 91:
				sendNpcChat1("Mind your own buisness, Shortstuff!?",
						c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 92:
				sendNpcChat1("So you want to use my anvils?", c.talkingNpc,
						"Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 98;
				break;
			case 98:
				sendPlayerChat1("Yes, I would like to use your anvils.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 93;
				break;
			case 93:
				sendNpcChat4("My anvils get enough work with my own use.",
						"I make pickaxes, and it takes a lot of hard work.",
						"If you could get me some more materials,",
						"then i could let use them.", c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 94;
				break;
			case 94:
				sendOption2("Yes i will get you the materials.",
						"No, hitting rocks is boring.");
				c.dialogueAction = 56;
				break;
			case 95:
				sendPlayerChat1("No, hitting rocks is boring.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
			case 96:
				sendPlayerChat1("Yes i will get you the materials.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 97;
				break;
			case 97:
				NPCChat(c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId(), 
						"Clay is what i use more than anything, to make casts.",
						"Could you get me 6 clay, 4 copper, and 2 iron, please?",
						"I could give a nice little reward",
						"Take my pickaxe with you just incase you need it.");
				c.getItems().addItem(1265, 1);
				c.nextChat = 99;
				break;
			case 99:
				sendPlayerChat1("Certainly, I'll be right back!", Anim.CALM_TALK.getAnimationId());
				c.doricQuest = 1;
				QuestAssistant.sendStages(c);
				c.nextChat = 0;
				break;
			case 100:
				NPCChat(c.talkingNpc, "Doric", Anim.CALM_TALK.getAnimationId(), "Thanks for the help!");
				c.nextChat = 0;
				break;
			case 3550:
				sendItemChat(2886, 300, "", "You find a book titled 'The Elemental Shield'.");
				c.getItems().addItem(2886, 1);
				c.nextChat = 0;
				break;
			case 3551:
				sendPlayerChat2("Now to explore this area thoroughly, to find what", "forgotten secrets it contains.", Anim.CALM_TALK.getAnimationId());
				c.nextChat = 0;
				break;
				/**Aubury and Rune Mysteries**/
				case 4000:
					NPCChat(c.talkingNpc, "Aubury", Anim.CALM_TALK.getAnimationId(), "Do you want to buy some runes?");
					c.nextChat = 4001;
					break;
				case 4001:
					sendOption3("Can you tell me about your cape?", "Yes please!", "Oh, it's a rune shop. No thank you, then.");
					c.dialogueAction = 4001;
					break;
			/**First Options**/
				/**option 1**/
					case 4002:sendPlayerChat1("Can you tell me about your cape?", Anim.CALM_TALK.getAnimationId());
						c.nextChat = 4005;
						break;
					case 4005:
						NPCChat(c.talkingNpc, "Aubury", Anim.CALM_TALK.getAnimationId(), "Certainly! Skillcapes are a symbol of achievement","Only people who have mastered a skill and reached level 99","can get their hands on them and gain the benefits they carry.");
						c.nextChat = 4006;
						break;
					case 4006:
						sendOption2("I'd like to view your store please.", "No thank you.");
						c.dialogueAction = 4001;
						break;
				/**end option 1**/
				/**option 2**/
					case 4003://option 2 open shop then end
						sendPlayerChat1("Yes please!", Anim.CALM_TALK.getAnimationId());
						c.getShops().openShop(25);
						c.nextChat = 0;
						break;
				/**end option 2**/
				/**option 3**/
					case 4004:
						PLAYERChat(Anim.CALM_TALK.getAnimationId(), "No thank you.");
						c.nextChat = 4008;
						break;
					case 4008:
						NPCChat(c.talkingNpc, "Aubury", Anim.CALM_TALK.getAnimationId(),"Well, if you find someone who does want runes,","please send them my way.");
						c.nextChat = 0;
						c.dialogueAction = 0;
						break;
				/**end of option 3**/
			/**Start Rune Mysteries**/
				case 4010:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "Greetings. Welcome to my castle.");
					c.nextChat = 4011;
					break;
					case 4011:
						sendOption2("Have any quests for me?", "Where can I find money?");
						c.dialogueAction = 4011;
						break;
					case 4013:
						PLAYERChat(Anim.CALM_TALK.getAnimationId(), "Where can I find money?");
						c.nextChat = 0;
						break;
					
					case 4012:
						PLAYERChat(Anim.CALM_TALK.getAnimationId(), "Have any quests for me?");
						c.nextChat = 4014;
						break;
				case 4014:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "Well, I wouldn't describe it as a quest,", "but there is something I could use some help with.");
					c.nextChat = 4015;
					break;
					case 4015:
						PLAYERChat(Anim.CONFUSED.getAnimationId(), "What is it?");
						c.nextChat = 4016;
						break;
				case 4016:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "We were recently sorting through some of the things stored", "down in the cellar, and we found this old talisman.");
					c.nextChat = 4017;
					break;
			case 4017:
				sendItemChat(1438, 300, "", "The Duke shows you a talisman.");
				c.nextChat = 4018;
				break;
				case 4018:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "The Order of Wizard over at the Wizards' Tower", "have been on the hunt for magical artefacts recently.");
					c.nextChat = 4019;
					break;
				case 4019:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "I wonder if this might be just the kind of thing they're after.");
					c.nextChat = 4020;
					break;
				case 4020:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "Would you be willing to take it to them for me?");
					c.nextChat = 4021;
					break;
					case 4021:
						sendOption2_withTitle("Yes", "No", "Start Rune Mysteries?");
						c.dialogueAction = 4021;
						break;
					case 4022:
						PLAYERChat(Anim.CONFUSED.getAnimationId(), "Sure, no problem.");
						c.nextChat = 4023;
						break;
				case 4023:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "Thank you very much.");
					c.nextChat = 4024;
					break;
				case 4024:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "You'll find the Wizards' Tower south west of here,", "across the bridge from Draynor Village.");
					c.nextChat = 4025;
					break;
				case 4025:
					NPCChat(c.talkingNpc, "Duke Horacio", Anim.CALM_TALK.getAnimationId(), "When you arrive, look for Sedridor.", "He is the Archmage of the wizards there.");
					c.nextChat = 4026;
					break;
				case 4026:
					sendItemChat(1438, 300, "", "The Duke hands you the talisman.");
					c.nextChat = 4027;
					break;
				case 4027:
					c.getItems().addItem(1438, 1);
					c.runeMist = Config.STARTQUEST;
					QuestAssistant.sendStages(c);
					c.nextChat = 0;
					c.dialogueAction = 0;
					c.getPA().closeAllWindows();
					break;
		}
	}		public void sendStatement(String... line) {
		switch (line.length) {
			case 1:
				c.getPA().sendFrame126(line[0], 357);
				c.getPA().sendFrame126("Click here to continue", 358);
				c.getPA().sendFrame164(356);
			break;
			case 2:
				c.getPA().sendFrame126(line[0], 360);
				c.getPA().sendFrame126(line[1], 361);
				c.getPA().sendFrame126("Click here to continue", 362);
				c.getPA().sendFrame164(359);
			break;
			case 3:
				c.getPA().sendFrame126(line[0], 364);
				c.getPA().sendFrame126(line[1], 365);
				c.getPA().sendFrame126(line[2], 366);
				c.getPA().sendFrame126("Click here to continue", 367);
				c.getPA().sendFrame164(363);
			break;
			case 4:
				c.getPA().sendFrame126(line[0], 369);
				c.getPA().sendFrame126(line[1], 370);
				c.getPA().sendFrame126(line[2], 371);
				c.getPA().sendFrame126(line[3], 372);
				c.getPA().sendFrame126("Click here to continue", 373);
				c.getPA().sendFrame164(368);
			break;
		}
	}
	public void sendItemChat(int item, int zoom, String header, String... line) {
		switch (line.length) {
			case 1:
				c.getPA().sendFrame246(4883, zoom, item);
				c.getPA().sendFrame126(header, 4884);
				c.getPA().sendFrame126(line[0], 4885);
				c.getPA().sendFrame164(4882);
			break;
			case 2:
				c.getPA().sendFrame246(4888, zoom, item);
				c.getPA().sendFrame126(header, 4889);
				c.getPA().sendFrame126(line[0], 4890);
				c.getPA().sendFrame126(line[1], 4891);
				c.getPA().sendFrame164(4887);
			break;
			case 3:
				c.getPA().sendFrame246(4894, zoom, item);
				c.getPA().sendFrame126(header, 4895);
				c.getPA().sendFrame126(line[0], 4896);
				c.getPA().sendFrame126(line[1], 4897);
				c.getPA().sendFrame126(line[2], 4898);
				c.getPA().sendFrame164(4893);
			break;
			case 4:
				c.getPA().sendFrame246(4901, zoom, item);
				c.getPA().sendFrame126(header, 4902);
				c.getPA().sendFrame126(line[0], 4903);
				c.getPA().sendFrame126(line[1], 4904);
				c.getPA().sendFrame126(line[2], 4905);
				c.getPA().sendFrame126(line[3], 4906);
				c.getPA().sendFrame164(4900);
			break;
		}
	}
	public void sendStatement2(String... line) {
		switch (line.length) {
			case 1:
				c.getPA().sendFrame126(line[0], 357);
				c.getPA().sendFrame126("Click here to continue", 358);
				c.getPA().sendFrame164(356);
			break;
			case 2:
				c.getPA().sendFrame126(line[0], 360);
				c.getPA().sendFrame126(line[1], 361);
				c.getPA().sendFrame126("Click here to continue", 362);
				c.getPA().sendFrame164(359);
			break;
			case 3:
				c.getPA().sendFrame126(line[0], 364);
				c.getPA().sendFrame126(line[1], 365);
				c.getPA().sendFrame126(line[2], 366);
				c.getPA().sendFrame126("Click here to continue", 367);
				c.getPA().sendFrame164(363);
			break;
			case 4:
				c.getPA().sendFrame126(line[0], 369);
				c.getPA().sendFrame126(line[1], 370);
				c.getPA().sendFrame126(line[2], 371);
				c.getPA().sendFrame126(line[3], 372);
				c.getPA().sendFrame126("Click here to continue", 373);
				c.getPA().sendFrame164(368);
			break;
		}
	}		
	public void chatboxText(String text, String text1, String text2,
			String text3, String title) {
		c.getPA().sendFrame126(title, 6180);
		c.getPA().sendFrame126(text, 6181);
		c.getPA().sendFrame126(text1, 6182);
		c.getPA().sendFrame126(text2, 6183);
		c.getPA().sendFrame126(text3, 6184);
	}
	public void clearChatBoxText(Client c) {
		c.getPA().sendFrame126("", 6180);
		c.getPA().sendFrame126("", 6181);
		c.getPA().sendFrame126("", 6182);
		c.getPA().sendFrame126("", 6183);
		c.getPA().sendFrame126("", 6184);
	}


	/*
	 * Information Box
	 */

	public void sendStartInfo(String text, String text1, String text2,
			String text3, String title) {
		c.getPA().sendFrame126(title, 6180);
		c.getPA().sendFrame126(text, 6181);
		c.getPA().sendFrame126(text1, 6182);
		c.getPA().sendFrame126(text2, 6183);
		c.getPA().sendFrame126(text3, 6184);
		c.getPA().sendFrame164(6179);
	}
	public void sendDestroy(String s, String s1, int itemID) {
		c.getPA().sendFrame126(s, 44711);
		c.getPA().sendFrame126(s1, 44707);
		c.getPA().sendFrame164(44700);
		c.getPA().sendFrame34a(44710, itemID, 0, 1);
	}	
	public String sendDestroyDialogue(int itemID) {
		if(itemID == 11941)
			return "You will have to buy another from a slayer master.";
		if(itemID >= 9096 && itemID <= 9104)
			return "The Oneiromancer might be able to help you get another.";
		
		return "You can receive a replacement from Diango.";
	}
	/*
	 * Options
	 */

	public void sendOption2(String s, String s1) {
		c.getPA().sendFrame126("Select an Option", 2460);
		c.getPA().sendFrame126(s, 2461);
		c.getPA().sendFrame126(s1, 2462);
		c.getPA().sendFrame164(2459);
	}
	public void sendOption2_withTitle(String s, String s1, String title) {
		c.getPA().sendFrame126(title, 2460);
		c.getPA().sendFrame126(s, 2461);
		c.getPA().sendFrame126(s1, 2462);
		c.getPA().sendFrame164(2459);
	}

	public void sendOption3(String s, String s1, String s2) {
		c.getPA().sendFrame126("Select an Option", 2470);
		c.getPA().sendFrame126(s, 2471);
		c.getPA().sendFrame126(s1, 2472);
		c.getPA().sendFrame126(s2, 2473);
		c.getPA().sendFrame164(2469);
	}

	public void sendOption4(String s, String s1, String s2, String s3) {
		c.getPA().sendFrame126("Select an Option", 2481);
		c.getPA().sendFrame126(s, 2482);
		c.getPA().sendFrame126(s1, 2483);
		c.getPA().sendFrame126(s2, 2484);
		c.getPA().sendFrame126(s3, 2485);
		c.getPA().sendFrame164(2480);
	}

	public void sendOption5(String s, String s1, String s2, String s3, String s4) {
		c.getPA().sendFrame126("Select an Option", 2493);
		c.getPA().sendFrame126(s, 2494);
		c.getPA().sendFrame126(s1, 2495);
		c.getPA().sendFrame126(s2, 2496);
		c.getPA().sendFrame126(s3, 2497);
		c.getPA().sendFrame126(s4, 2498);
		c.getPA().sendFrame164(2492);
	}

	/*
	 * Statements
	 */
	public void sendStatement(String header, String one) {
		c.getPA().sendFrame246(4883, 0, -1);
		c.getPA().sendFrame126(header, 4884);
		c.getPA().sendFrame126(one, 4885);
		c.getPA().sendFrame164(4882);
	}
	public void sendStatement(String s) { // 1 line click here to continue chat
											// box interface
		c.getPA().sendFrame126(s, 357);
		c.getPA().sendFrame126("Click here to continue", 358);
		c.getPA().sendFrame164(356);
	}

	/*
	 * Npc Chatting
	 */

			public void NPCChat(int ChatNpc, String name, int animation, String... line) {
				switch (line.length) {
					case 1:
						c.getPA().sendFrame200(4883, animation);
						c.getPA().sendFrame126(name, 4884);
						c.getPA().sendFrame126(line[0], 4885);
						c.getPA().sendFrame75(ChatNpc, 4883);
						c.getPA().sendFrame164(4882);
					break;
					case 2:
						c.getPA().sendFrame200(4888, animation);
						c.getPA().sendFrame126(name, 4889);
						c.getPA().sendFrame126(line[0], 4890);
						c.getPA().sendFrame126(line[1], 4891);
						c.getPA().sendFrame75(ChatNpc, 4888);
						c.getPA().sendFrame164(4887);
					break;
					case 3:
						c.getPA().sendFrame200(4894, animation);	//Was 591
						c.getPA().sendFrame126(name, 4895);
						c.getPA().sendFrame126(line[0], 4896);
						c.getPA().sendFrame126(line[1], 4897);
						c.getPA().sendFrame126(line[2], 4898);
						c.getPA().sendFrame75(ChatNpc, 4894);
						c.getPA().sendFrame164(4893);
					break;
					case 4:
						c.getPA().sendFrame200(4901, animation);
						c.getPA().sendFrame126(name, 4902);
						c.getPA().sendFrame126(line[0], 4903);
						c.getPA().sendFrame126(line[1], 4904);
						c.getPA().sendFrame126(line[2], 4905);
						c.getPA().sendFrame126(line[3], 4906);
						c.getPA().sendFrame75(ChatNpc, 4901);
						c.getPA().sendFrame164(4900);
					break;
				}
			}
			public void PLAYERChat(int animation, String... line) {
				switch (line.length) {
						case 1:
							c.getPA().sendFrame200(969, animation);
							c.getPA().sendFrame126(c.playerName, 970);
							c.getPA().sendFrame126(line[0], 971);
							c.getPA().sendFrame185(969);
							c.getPA().sendFrame164(968);
						break;
						case 2:
							c.getPA().sendFrame200(974, animation);
							c.getPA().sendFrame126(c.playerName, 975);
							c.getPA().sendFrame126(line[0], 976);
							c.getPA().sendFrame126(line[1], 977);
							c.getPA().sendFrame185(974);
							c.getPA().sendFrame164(973);
						break;
						case 3:
							c.getPA().sendFrame200(980, animation);
							c.getPA().sendFrame126(c.playerName, 981);
							c.getPA().sendFrame126(line[0], 982);
							c.getPA().sendFrame126(line[1], 983);
							c.getPA().sendFrame126(line[2], 984);
							c.getPA().sendFrame185(980);
							c.getPA().sendFrame164(979);
						break;
						case 4:
							c.getPA().sendFrame200(987, animation);
							c.getPA().sendFrame126(c.playerName, 988);
							c.getPA().sendFrame126(line[0], 989);
							c.getPA().sendFrame126(line[1], 990);
							c.getPA().sendFrame126(line[2], 991);
							c.getPA().sendFrame126(line[3], 992);
							c.getPA().sendFrame185(987);
							c.getPA().sendFrame164(986);
						break;
				}
			}
		public void sendNpcChat1(String s, int ChatNpc, String name, int animation) {
			c.getPA().sendFrame200(4883, animation);
			c.getPA().sendFrame126(name, 4884);
			c.getPA().sendFrame126(s, 4885);
			c.getPA().sendFrame75(ChatNpc, 4883);
			c.getPA().sendFrame164(4882);
		}
		public void sendNpcChat2(String s, String s1, int ChatNpc, String name, int animation) {
			c.getPA().sendFrame200(4888, animation);
			c.getPA().sendFrame126(name, 4889);
			c.getPA().sendFrame126(s, 4890);
			c.getPA().sendFrame126(s1, 4891);
			c.getPA().sendFrame75(ChatNpc, 4888);
			c.getPA().sendFrame164(4887);
		}
	
		public void sendNpcChat3(String s, String s1, String s2, int ChatNpc, String name, int animation) {
			c.getPA().sendFrame200(4894, animation);	//Was 591
			c.getPA().sendFrame126(name, 4895);
			c.getPA().sendFrame126(s, 4896);
			c.getPA().sendFrame126(s1, 4897);
			c.getPA().sendFrame126(s2, 4898);
			c.getPA().sendFrame75(ChatNpc, 4894);
			c.getPA().sendFrame164(4893);
		}
	
	
		private void sendNpcChat4(String s, String s1, String s2, String s3, int ChatNpc, String name, int animation) {
			c.getPA().sendFrame200(4901, animation);
			c.getPA().sendFrame126(name, 4902);
			c.getPA().sendFrame126(s, 4903);
			c.getPA().sendFrame126(s1, 4904);
			c.getPA().sendFrame126(s2, 4905);
			c.getPA().sendFrame126(s3, 4906);
			c.getPA().sendFrame75(ChatNpc, 4901);
			c.getPA().sendFrame164(4900);
		}
	//endregion

	/*
	 * Player Chating Back
	 */
	 
	//region send player chat methods
	public void sendPlayerChat1(String s, int animationId) {
		c.getPA().sendFrame200(969, animationId);
		c.getPA().sendFrame126(c.playerName, 970);
		c.getPA().sendFrame126(s, 971);
		c.getPA().sendFrame185(969);
		c.getPA().sendFrame164(968);
	}

	public void sendPlayerChat2(String s, String s1, int animationId) {
		c.getPA().sendFrame200(974, animationId);
		c.getPA().sendFrame126(c.playerName, 975);
		c.getPA().sendFrame126(s, 976);
		c.getPA().sendFrame126(s1, 977);
		c.getPA().sendFrame185(974);
		c.getPA().sendFrame164(973);
	}

	public void sendPlayerChat3(String s, String s1, String s2, int animationId) {
		c.getPA().sendFrame200(980, animationId);
		c.getPA().sendFrame126(c.playerName, 981);
		c.getPA().sendFrame126(s, 982);
		c.getPA().sendFrame126(s1, 983);
		c.getPA().sendFrame126(s2, 984);
		c.getPA().sendFrame185(980);
		c.getPA().sendFrame164(979);
	}

	public void sendPlayerChat4(String s, String s1, String s2, String s3, int animationId) {
		c.getPA().sendFrame200(987, animationId);
		c.getPA().sendFrame126(c.playerName, 988);
		c.getPA().sendFrame126(s, 989);
		c.getPA().sendFrame126(s1, 990);
		c.getPA().sendFrame126(s2, 991);
		c.getPA().sendFrame126(s3, 992);
		c.getPA().sendFrame185(987);
		c.getPA().sendFrame164(986);
	}
	//endregion
	 	//region send item chat methods
	public void sendItemChat1(String header, String one, int item, int zoom) {
		c.getPA().sendFrame246(4883, zoom, item);
		c.getPA().sendFrame126(header, 4884);
		c.getPA().sendFrame126(one, 4885);
		c.getPA().sendFrame164(4882);
	}

	public void sendItemChat2(String header, String one, String two, int item,
			int zoom) {
		c.getPA().sendFrame246(4888, zoom, item);
		c.getPA().sendFrame126(header, 4889);
		c.getPA().sendFrame126(one, 4890);
		c.getPA().sendFrame126(two, 4891);
		c.getPA().sendFrame164(4887);
	}

	public void sendItemChat3(String header, String one, String two,
			String three, int item, int zoom) {
		c.getPA().sendFrame246(4894, zoom, item);
		c.getPA().sendFrame126(header, 4895);
		c.getPA().sendFrame126(one, 4896);
		c.getPA().sendFrame126(two, 4897);
		c.getPA().sendFrame126(three, 4898);
		c.getPA().sendFrame164(4893);
	}

	public void sendItemChat4(String header, String one, String two,
			String three, String four, int item, int zoom) {
		c.getPA().sendFrame246(4901, zoom, item);
		c.getPA().sendFrame126(header, 4902);
		c.getPA().sendFrame126(one, 4903);
		c.getPA().sendFrame126(two, 4904);
		c.getPA().sendFrame126(three, 4905);
		c.getPA().sendFrame126(four, 4906);
		c.getPA().sendFrame164(4900);
	}
	//endregion
}
