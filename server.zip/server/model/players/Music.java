package server.model.players;

import server.event.CycleEvent;
import server.event.CycleEventHandler;
import server.event.CycleEventContainer;
import java.util.ArrayList;
import java.util.List;
import server.util.Misc;
import server.world.Boundary;
import server.model.players.Client;

public class Music {

    public static List<Integer> unlockedSongIds = new ArrayList<>();
    public static List<String> unlockedSongNames = new ArrayList<>();
    public static List<Integer> favoriteSongIds = new ArrayList<>();
    public static List<String> favoriteSongNames = new ArrayList<>();
	public Music(Client c) {
		this.player = c;
	}
	Client player;
						public static void addToFavorites(int songId, String songName) {
							// Check if the song is not already in favorites to avoid duplicates
							if (!favoriteSongIds.contains(songId)) {
								favoriteSongIds.add(songId);
								favoriteSongNames.add(songName);
							}
						}
						public static void addToUnlocked(Client c, int songId) {
							// Check if the song is not already in favorites to avoid duplicates
							if (!unlockedSongIds.contains(songId)) {
								String songName = Music.CITY_MUSIC.getSongNameById(songId);

								// Add some logging to check the values
								System.out.println("Song ID: " + songId);
								System.out.println("Song Name: " + songName);

								if (songName != null) {
									String formattedName = CITY_MUSIC.formatSongName(songName);
									unlockedSongIds.add(songId);
									unlockedSongNames.add(songName);
									c.sendMessage("You have unlocked the track: @red@" + formattedName);
								} else {
									c.sendMessage("Failed to unlock the track with ID: " + songId);
								}
							}
						}

						public void refreshUnlocked(int songId) {
							// Check if the song is not already in favorites to avoid duplicates
							if (!unlockedSongIds.contains(songId)) {
								unlockedSongIds.add(songId);
								String songName = Music.CITY_MUSIC.getSongNameById(songId);
								String formattedName = CITY_MUSIC.formatSongName(songName);
								unlockedSongNames.add(songName);
								//c.sendMessage("You have unlocked the track: @red@" + formattedName);
							}
						}
						public static void removeFromFavorites(String songNameToRemove) {
							// Check if the songName is in the favoriteSongNames list
							if (favoriteSongNames.contains(songNameToRemove)) {
								int index = favoriteSongNames.indexOf(songNameToRemove);
								favoriteSongNames.remove(index);
								favoriteSongIds.remove(index);
							}
						}
						public static void setText(Client c, int totaltoupdate){
							c.getPA().sendFrame126("" + (c.onPlaylist ? "Favorite" : "All") + " Music:", 19945);
							c.getPA().sendFrame126("" + (c.onPlaylist ? "Favorited" : "Unlocked") + ":", 50022);
							//c.getPA().sendFrame126(""+ favoriteSongNames.size()+ "", 50023);
							for (int i = totaltoupdate; i < 373; i++) {
								c.getPA().sendFrame126("", 50473 + i);
							}
						}
public static void refreshPlaylist(Client c, boolean onPlaylist) {
    int configId = 800;
    int config = 795;
    int totalSize = CITY_MUSIC.values().length;
    int currentSongId = 0; // Replace with your method to get the song ID
    String songName = null;
    String formatSongName = null;
    
    if (c.onPlaylist) {
        if (favoriteSongIds.size() != 0) {
            setText(c, favoriteSongIds.size());
            c.getPA().sendFrame126("" + favoriteSongNames.size() + "", 50023);
            for (int i = 0; i < favoriteSongIds.size(); i++) {
                int cityMusicIndex = favoriteSongIds.get(i);
                CITY_MUSIC cityMusic = CITY_MUSIC.values()[cityMusicIndex];
                
                if (isSongInPlaylist(cityMusicIndex, c)) {
                    c.getPA().sendFrame36(configId + i, 1); // Display - sprite for songs in the playlist
                } else {
                    c.getPA().sendFrame36(configId + i, 0); // Display + sprite for songs not in the playlist
                } 
                
                if (cityMusic != null) {
                    formatSongName = CITY_MUSIC.formatSongName(cityMusic.getName());
                    if (formatSongName != null)
                        c.getPA().sendFrame126("@gre@" + formatSongName, 50473 + i);
                }
            }
        } else {
            for (int i = 0; i < 373; i++) {
                c.getPA().sendFrame126("", 50473 + i);
            }
            c.sendMessage("You have no favorites.");
        }
    } else {
        c.getPA().sendFrame126("" + unlockedSongIds.size() + "/" + totalSize, 50023);
        setText(c, unlockedSongIds.size());
        for (int i = 0; i < 373; i++) {
            int cityMusicIndex = i;
            CITY_MUSIC cityMusic = CITY_MUSIC.values()[cityMusicIndex];
            
            if (cityMusic != null) {
                songName = Music.CITY_MUSIC.getSongNameById(cityMusic.getMusic());
                formatSongName = Music.CITY_MUSIC.formatSongName(cityMusic.getName());
                
                if (isSongUnlocked(cityMusicIndex)) {
                    c.getPA().sendFrame126("@gre@" + formatSongName, 50473 + i);
                } else {
                    c.getPA().sendFrame126("" + formatSongName, 50473 + i);
					c.getPA().sendFrame36(268, 2);
                }
                
                if (favoriteSongIds.contains(cityMusicIndex)) {
                    c.getPA().sendFrame36(configId + (i - 5), 1); // Display - sprite for songs in the playlist
                } else {
                    c.getPA().sendFrame36(configId + (i - 5), 0); // Display + sprite for songs not in the playlist
                }
            }
        }
    }
}

	public static void refreshConfigs(Client c, int config) {
		int currentSongId = 0; // Replace with your method to get the song ID
		String songName = null;
		String formatSongName = null;
		if(c.onPlaylist){
			if (favoriteSongIds.size() != 0) {
				for (int i = 0; i < favoriteSongIds.size(); i++) {
					songName = favoriteSongNames.get(i);
					formatSongName = CITY_MUSIC.formatSongName(songName);
					currentSongId = favoriteSongIds.get(i); // Replace with your method to get the song ID
					if (isSongInPlaylist(currentSongId, c)) {
						c.getPA().sendFrame36(config, 1); // Display - sprite for songs in the playlist
					} else {
						c.getPA().sendFrame36(config, 0);
					}
				}
			}
		} else {
			for (int i = 5; i < 373; i++) {
				songName = Music.CITY_MUSIC.getSongNameById(i);
				formatSongName = Music.CITY_MUSIC.formatSongName(songName);
				if (!favoriteSongIds.contains(i)) {
					c.getPA().sendFrame36(config, 0); // Display - sprite for songs in the playlist
				} else {
					c.getPA().sendFrame36(config, 1); // Display + sprite for songs not in the playlist
				}
				
			}
		}
	}
		public static int[][] regions = {
										/*Inside tracks*/ 			/*Outside tracks*/
			//songID, songID2, songID3, songid1, songid2, songid3
			{5, 124, 195, 84, 100, 133, 344},//varrock
			{15, 106, 366, 182, 200, 215, 344},//falador
			{138, 139, 24, 117, 88, 370, 138},//lumbridge
			{44, 106, 366, 182, 200, 215, 344},//Camelot
			{224, 106, 366, 182, 200, 215, 344},//seers village
			{32, 106, 366, 182, 200, 215, 344},//Ardougne market
			{34, 106, 366, 182, 200, 215, 344},//Yanille
			{45, 106, 366, 182, 200, 215, 344},//CastleWars
			{6, 106, 366, 182, 200, 215, 344},//Alkharid
			{3312, 3325, 3224, 3246, 89, 106, 366, 182, 200, 215, 344},//Duel arena
			{178, 106, 366, 182, 200, 215, 344},//Fremmy lighthouse
			{82, 106, 366, 182, 200, 215, 344},//Draynor)
			{30, 106, 366, 182, 200, 215, 344},//Barbarian village
			{30, 106, 366, 182, 200, 215, 344},//Stronghold of security
			{254, 106, 366, 182, 200, 215, 344},//Safety first dungeon top floor
			{218, 106, 366, 182, 200, 215, 344},//Taverly
			{223, 106, 366, 182, 200, 215, 344},//Burth
			{116, 106, 366, 182, 200, 215, 344},//Catherby
			{128, 106, 366, 182, 200, 215, 344},//Tree Gnome Village
			{125, 106, 366, 182, 200, 215, 344},//Tree Gnome Maze
			{167, 106, 366, 182, 200, 215, 344},//Karamja
			{40, 106, 366, 182, 200, 215, 344},//relleka
			{40, 106, 366, 182, 200, 215, 344},//ARDOUGNE_ZOO
			{32, 106, 366, 182, 200, 215, 344},//ardy market
			{32, 106, 366, 182, 200, 215, 344}//EDGEVILLE
		};
public static void RegionMusicLocations(Client c) {
    int songId = -1; // Initialize songId to an invalid value

    for (int i = 0; i < regions.length; i++) {
        // Check if the player is within the boundary of the current region
        Boundary currentBoundary = getBoundaryForRegion(i);
        if (Boundary.isIn(c, currentBoundary) && !c.MusicOn && c.RegionMusicOn) {
            // Logic to select a song based on the region
            int[] regionSongs = regions[i];
            int randomIndex = 4 + Misc.random(2);
            songId = regionSongs[randomIndex];

            if (songId != -1)
                addToUnlocked(c, songId);

            if (!isSongPlaying(c)) {
				songStartTime = System.currentTimeMillis();
                playSong(c, songId, false, true);
            }
            // Break out of the loop as soon as a matching region is found
            break;
        }
    }

    // Handle music playback based on the priority region
    if (!c.MusicOn && c.RegionMusicOn && !isSongPlaying(c)) {
        if (songId == -1) {
            // No matching region found, use a default song ID or handle as needed
            c.getPA().musicManager("PLAY", 234);
        }
    } else if (c.MusicOn && !c.RegionMusicOn) {
        c.getPA().musicManager("PLAY", c.currentSong);
    } else if (!c.MusicOn && !c.RegionMusicOn) {
        c.getPA().musicManager("STOP", -1);
    }
}
 // Helper method to get the boundary for a given region index
    public static Boundary getBoundaryForRegion(int regionIndex) {
        switch (regionIndex) {
            case 0: // Varrock
                return Boundary.VARROCK;
            case 1: // Falador
                return Boundary.FALADOR;
            case 2: // Lumbridge
                return Boundary.LUMBRIDGE;
            case 3: // Camelot
                return Boundary.CAMELOT; // Assuming Wizards' Tower is used for Camelot
            case 4: // Seers Village
                return Boundary.SEERS; // Assuming Varrock is used for Seers Village
            case 5: // Ardougne Market
                return Boundary.ARDOUGNE_ZOO; // Assuming Ardougne Zoo is used for Ardougne Market
            //case 6: // Yanille
                // Comment out as Yanille is not explicitly defined in the Boundary class
                // return YANILLE;
            //    return null;
            //case 7: // Castle Wars
                // Comment out as Castle Wars is not explicitly defined in the Boundary class
                // return CASTLE_WARS;
            //    return null;
            case 8: // Al Kharid
                return Boundary.AL_KHARID;
            case 9: // Duel Arena
                return Boundary.IN_DUEL_AREA[0];
           // case 10: // Fremennik Lighthouse
                // Comment out as Fremennik Lighthouse is not explicitly defined in the Boundary class
                // return FREMENNIK_LIGHTHOUSE;
               // return null;
            case 11: // Draynor
                return Boundary.DRAYNOR;
            case 12: // Barbarian Village
                return Boundary.BARB;
           /* case 13: // Stronghold of Security
                return null; // Adjust as needed
            case 14: // Safety First Dungeon Top Floor
                return null; // Adjust as needed
            case 15: // Taverly
                return null; // Adjust as needed
            case 16: // Burthorpe
                return null; // Adjust as needed*/
            case 17: // Catherby
                return Boundary.CATHERBY;
            //case 18: // Tree Gnome Village
               // return null; // Adjust as needed
           // case 19: // Tree Gnome Maze
              //  return null; // Adjust as needed
            case 20: // Karamja
                return Boundary.KARAMAJA[0]; // Assuming the first boundary in KARAMAJA is used for Karamja
            //case 21: // Rellekka
               // return null; // Adjust as needed
            default:
                // Return a default boundary or handle as needed
                return Boundary.F2P;
        }
    }
		// Add these fields to your class
		private static final int SONG_DURATION_SECONDS = 90; // Duration of each song in seconds
		public static long songStartTime = 0;

		// Modify the isSongPlaying method to use the duration information from the enum
		public static boolean isSongPlaying(Client c) {
				CITY_MUSIC currentSong = CITY_MUSIC.values()[c.currentSong];
			if (c.currentSong >= 1 && c.currentSong < CITY_MUSIC.values().length) {
				currentSong = CITY_MUSIC.values()[c.currentSong];

				// Calculate the elapsed time since the song started
				long elapsedTime = System.currentTimeMillis() - songStartTime;

				// Check if the elapsed time is less than the song duration
				return elapsedTime < currentSong.getDurationSeconds() * 1000; // Convert seconds to milliseconds
			}

			// Default to false if the track ID is out of bounds
			return false;
		}

		// Add this field to your class
		private static final long[] SONG_DURATIONS = {
				0,  // Placeholder for track 0 (assuming track IDs start from 1)
				0,  // Placeholder for track 0 (assuming track IDs start from 1)
				0,  // Placeholder for track 0 (assuming track IDs start from 1)
				0,  // Placeholder for track 0 (assuming track IDs start from 1)
				0,  // Placeholder for track 0 (assuming track IDs start from 1)
				161, // Track 1 duration in milliseconds (2 minutes and 23 seconds)
				198000, // Track 2 duration in milliseconds (3 minutes and 18 seconds)
				380000, // Track 3 duration in milliseconds (6 minutes and 20 seconds)
				// ... Add durations for other tracks
		};
	public static boolean isSongUnlocked(int songId) {
		return unlockedSongIds.contains(songId);
	}
public static void playSong(Client c, int cityMusicIndex, boolean musicOn, boolean regionMusic) {
    CITY_MUSIC[] cityMusics = CITY_MUSIC.values();

    if (cityMusicIndex >= 0 && cityMusicIndex < cityMusics.length) {
        CITY_MUSIC cityMusic = cityMusics[cityMusicIndex];
        String formatSongName = CITY_MUSIC.formatSongName(cityMusic.getName());

        if (isSongUnlocked(cityMusic.getMusic()) || c.playerRights >= 3) {
            c.MusicOn = musicOn;
            c.RegionMusicOn = regionMusic;
            c.getPA().musicManager("PLAY", cityMusic.getMusic()); // Play the song
            c.currentSong = cityMusic.getMusic();
            c.getPA().sendFrame126("Current Song: " + formatSongName, 5450);
        } else {
            c.MusicOn = false;
            //c.sendMessage("You have not unlocked " + formatSongName + ".");
        }
    } else {
        // Handle the case where the cityMusicIndex is out of bounds
        c.MusicOn = false;
        c.sendMessage("Invalid song index.");
    }
}


// Add a method to check if a song is in the playlist
private static boolean isSongInPlaylist(int songId, Client c) {
    // Implement the logic to check if the song is in the playlist
    // You can use the favoriteSongIds list for this check
    return favoriteSongIds.contains(songId);
}
		public static enum CITY_MUSIC {
			SEVENTH_REALM(4, 120),
			ADVENTURE(5, 141),
			AL_KHARID(6, 198),
			ALONE(7, 207),
			AMBIENT_JUNGLE(8, 226),
			ANYWHERE(9, 217),
			ARABIAN(10, 216),
			ARABIAN_2(11, 184),
			ARABIAN_3(12, 145),
			ARABIQUE(13, 204),
			ARMY_OF_DARKNESS(14, 155),
			ARRIVAL(15, 99),
			ARTISTRY(16, 217),
			ATTACK_1(17, 128),
			ATTACK_2(18, 148),
			ATTACK_3(19, 170),
			ATTACK_4(20, 149),
			ATTACK_5(21, 125),
			ATTACK_6(22, 152),
			ATTENTION(23, 172),
			AUTUMN_VOYAGE(24, 136),
			AYE_CAR_RUM_BA(25, 257),
			AZTEC(26, 210),
			BACKGROUND(27, 242),
			BALLAD_OF_ENCHANTMENT(28, 207),
			BANDIT_CAMP(29, 180),
			BARBARIANISM(30, 273),
			BARKING_MAD(31, 177),
			BAROQUE(32, 128),
			BEYOND(33, 166),
			BIG_CHORDS(34, 148),
			BLISTERING_BARNACLES(35, 237),
			BODY_PARTS(36, 288),
			BONE_DANCE(37, 185),
			BONE_DRY(38, 328),
			BOOK_OF_SPELLS(39, 330),
			BORDERLAND(40, 184),
			BREEZE(41, 205),
			BREW_HO_HO(42, 258),
			BUBBLE_AND_SQUEAK(43, 190),
			CAMELOT(44, 193),
			CASTLEWARS(45, 187),
			CATCH_ME_IF_YOU_CAN(46, 247),
			CAVE_BACKGROUND(47, 197),
			CAVE_OF_BEASTS(48, 207),
			CAVE_OF_THE_GOBLINS(49, 193),
			CAVERN(50, 187),
			CELLAR_SONG(51, 247),
			CHAIN_OF_COMMAND(52, 204),
			CHAMBER(53, 193),
			CHEFSURPRISE(54, 187),
			CHICKENED_OUT(55, 197),
			CHOMPY_HUNT(56, 184),
			CITY_OF_THE_DEAD(57, 205),
			CLAUSTROPHOBIA(58, 226),
			CLOSE_QUARTERS(59, 198),
			COMPETITION(60, 207),
			CONTEST(61, 184),
			CORPORAL_PUNISHMENT(62, 145),
			COURAGE(63, 172),
			CRYSTAL_CASTLE(64, 99),
			CRYSTAL_CAVE(65, 217),
			CRYSTAL_SWORD(66, 216),
			CURSED(67, 184),
			DAGANNOTH_DAWN(68, 205),
			DANCE_OF_THE_UNDEAD(69, 258),
			DANGEROUS(70, 190),
			DANGEROUS_ROAD(71, 149),
			DANGEROUS_WAY(72, 172),
			DARK(73, 136),
			DAVY_JONES_LOCKER(74, 217),
			DEAD_CAN_DANCE(75, 216),
			DEAD_QUIET(76, 184),
			DEADLANDS(77, 205),
			DEEP_WILDERNESS(78, 226),
			DEEPDOWN(79, 198),
			DESERT_HEAT(80, 207),
			DESERT_VOYAGE(81, 184),
			DIANGOS_LITTLE_HELPERS(82, 145),
			DISTANT_LAND(83, 204),
			DOORWAYS(84, 155),
			DOWN_BELOW(85, 99),
			DOWN_TO_EARTH(86, 217),
			DRAGONTHEE_ISLAND(87, 216),
			DREAM(88, 184),
			DUEL_ARENA(89, 205),
			DUNJUN(90, 226),
			DYNASTY(91, 198),
			EGYPT(92, 207),
			ELVEN_MIST(93, 184),
			EMOTION(94, 205),
			EMPEROR(95, 226),
			ETCETERIA(96, 198),
			EVERLASTING_FIRE(97, 207),
			EVERYWHERE(98, 184),
			EVIL_BOBS_ISLAND(99, 205),
			EXPANSE(100, 226),
			EXPECTING(101, 198),
			EXPEDITION(102, 207),
			EXPOSED(103, 184),
			FAERIE(104, 205),
			FAITHLESS(105, 226),
			FANFARE(106, 198),
			FANFARE_2(107, 207),
			FANFARE_3(108, 184),
			FOREVER(384, 219),
			FANGS_FOR_THE_MEMORY(109, 205),
			FARAWAY(110, 226),
			FEAR_AND_LOATHING(111, 198),
			FENKENSTRAINS_REFRAIN(112, 207),
			FIGHT_OR_FLIGHT(113, 184),
			FIND_MY_WAY(114, 205),
			FIRE_AND_BRIMSTONE(115, 226),
			FISHING(116, 198),
			FLUTE_SALAD(117, 207),
			FORBIDDEN(118, 184),
			FROGLAND(119, 205),
			FROSTBITE(120, 226),
			FRUITS_DE_MER(121, 198),
			FUNNY_BUNNIES(122, 207),
			GAOL(123, 184),
			GARDEN(124, 205),
			GNOME(125, 226),
			GNOME_KING(126, 198),
			GNOME_THEME(127, 207),
			GNOME_VILLAGE(128, 184),
			GNOME_VILLAGE_2(129, 205),
			GNOME_BALL(130, 226),
			GOBLIN_GAME(131, 198),
			GOLDEN_TOUCH(132, 207),
			GREATNESS(133, 184),
			GRIP_OF_THE_TALON(134, 205),
			GROTTO(135, 226),
			GROUNDSCAPE(136, 198),
			GRUMPY(137, 207),
			HARMONY(138, 184),
			HARMONY_2(139, 205),
			HAUNTED_MINE(140, 226),
			HAVE_A_BLAST(141, 198),
			HEART_AND_MIND(142, 207),
			HELLS_BELLS(143, 184),
			HERMIT(144, 205),
			HIGH_SEAS(145, 226),
			HORIZON(146, 198),
			HYPNOTIZED(147, 207),
			IBAN(148, 184),
			ICE_MELODY(149, 205),
			IN_BETWEEN(150, 226),
			IN_THE_BRINE(151, 198),
			IN_THE_CLINK(152, 207),
			IN_THE_MANOR(153, 184),
			IN_THE_PITS(154, 205),
			INCANTATION(155, 226),
			INSECT_QUEEN(156, 198),
			INSPIRATION(157, 207),
			INTO_THE_ABYSS(158, 184),
			INTREPID(159, 205),
			ISLAND_LIFE(160, 226),
			JOLLY_R(161, 198),
			JUNGLE_ISLAND(162, 207),
			JUNGLE_TROUBLES(163, 184),
			JUNGLY_1(164, 205),
			JUNGLY_2(165, 226),
			JUNGLY_3(166, 198),
			KARAMJA_JAM(167, 207),
			KINGDOM(168, 184),
			KNIGHTLY(169, 205),
			LA_MORT(170, 226),
			LAIR(171, 198),
			LAMENT(172, 207),
			LAND_OF_THE_DWARVES(173, 184),
			LANDLUBBER(174, 205),
			LASTING(175, 226),
			LEGEND(176, 198),
			LEGION(177, 207),
			LIGHTHOUSE(178, 184),
			LIGHTNESS(179, 205),
			LONESOME(180, 226),
			LONG_AGO(181, 198),
			LONG_WAY_HOME(182, 207),
			LOST_SOUL(183, 184),
			LULLABY(184, 205),
			MAD_EADGER(185, 226),
			MAGE_ARENA(186, 198),
			MAGIC_DANCE(187, 207),
			MAGICAL_JOURNEY(188, 184),
			MARCH(189, 205),
			MAROONED(190, 226),
			MARZIPAN(191, 198),
			MASQUERADE(192, 207),
			MASTERMINDLESS(193, 184),
			MAUSOLEUM(194, 205),
			MEDIEVAL(195, 226),
			MELLOW(196, 198),
			MELODRAMA(197, 207),
			MERIDIAN(198, 184),
			METHOD_OF_MADNESS(199, 205),
			MILES_AWAY(200, 226),
			MIND_OVER_MATTER(201, 198),
			MIRACLE_DANCE(202, 207),
			MIRAGE(203, 184),
			MISCELLANIA(204, 205),
			MONARCH_WALTZ(205, 226),
			MONKEY_MADNESS(206, 198),
			MONSTER_MELEE(207, 207),
			MOODY(208, 184),
			MORYTANIA(209, 205),
			MUDSKIPPER_MELODY(210, 226),
			NARNODES_THEME(211, 198),
			NATURAL(212, 207),
			NEWBIE_MELODY(213, 184),
			NEVERLAND(214, 205),
			NIGHTFALL(215, 226),
			NIGHTWALK(216, 198),
			NO_WAY_OUT(217, 207),
			NOMAD(218, 184),
			NULL_AND_VOID(219, 205),
			ORIENTAL(220, 226),
			OUT_OF_THE_DEEP(221, 198),
			OVER_TO_NARDAH(222, 207),
			OVERPASS(223, 184),
			OVERTURE(224, 205),
			PARADE(225, 226),
			PATH_OF_PERIL(226, 198),
			PATHWAYS(227, 207),
			PEST_CONTROL(228, 184),
			PHARAOHS_TOMB(229, 205),
			PHASMATYS(230, 226),
			PHEASANT_PEASANT(231, 198),
			PRIRATES_OF_PERIL(233, 207),
			PRINCIPALITY(232, 184),
			QUEST(234, 205),
			RAT_A_TAT_TAT(235, 226),
			RAT_HUNT(236, 198),
			READY_FOR_BATTLE(237, 207),
			REGAL(238, 184),
			REGGAE(239, 205),
			REGGAE_2(240, 226),
			RELLEKKA(241, 198),
			RIGHT_ON_TRACK(242, 207),
			RIGHTEOUSNESS(243, 184),
			RIVERSIDE(244, 205),
			ROLL_THE_BONES(245, 226),
			ROMANCING_THE_CRONE(246, 198),
			ROMPER_CHOMPER(247, 207),
			ROYALE(248, 184),
			RUNE_ESSENCE(249, 205),
			SAD_MEADOW(250, 226),
			SAGA(251, 198),
			SARCOPHAGUS(252, 207),
			SARIMS_VERMIN(253, 184),
			SCAPE_CAVE(254, 205),
			SCAPE_SAD(255, 226),
			SCAPE_SOFT(256, 198),
			SCAPE_WILD(257, 207),
			SCAPE_MAIN(0, 193),
			SCAPE_ORIGINAL(1, 187),
			SCAPE_SANTA(2, 247),
			SCAPE_SCARED(3, 197),
			SCARAB(258, 207),
			SEA_SHANTY(259, 184),
			SEA_SHANTY_2(260, 205),
			SERENADE(261, 226),
			SERENE(262, 198),
			SETTLEMENT(263, 207),
			SHADOWLAND(264, 184),
			SHINE(265, 205),
			SHINING(266, 226),
			SHIPWRECKED(267, 198),
			SHOWDOWN(268, 207),
			SOJOURN(269, 184),
			SOUNDSCAPE(270, 205),
			SPHINX(271, 226),
			SPIRIT(272, 198),
			SPIRITS_OF_THE_ELID(273, 207),
			SPLENDOUR(274, 184),
			SPOOKY(275, 205),
			SPOOKY_2(276, 170),
			SPOOKY_JUNGLE(277, 190),
			STAGNANT(278, 197),
			STARLIGHT(279, 184),
			START(280, 193),
			STILL_NIGHT(281, 177),
			STILLNESS(282, 172),
			STRANDED(283, 213),
			STRANGE_PLACE(284, 142),
			STRATOSPHERE(285, 175),
			STROM_BREW(286, 180),
			SUBTERANEA(287, 178),
			SUNBURN(288, 150),
			SUPERSTITION(289, 164),
			SUSPICIOUS(290, 160),
			TALE_OF_KALEDAGRIM(291, 220),
			TALKING_FOREST(292, 176),
			TEARS_OF_GUTHIX(293, 148),
			TECHNOLOGY(294, 186),
			TEMPLE(295, 155),
			TEMPLE_OF_LIGHT(296, 170),
			THE_CELLAR_DWELLERS(297, 164),
			THE_CHOSEN(298, 148),
			THE_DESERT(299, 178),
			THE_DESOLATE_ISLE(300, 185),
			THE_ENCHANTER(301, 240),
			THE_FAR_SIDE(302, 200),
			THE_GEINE(303, 146),
			THE_GOLEM(304, 185),
			THE_LOST_MELODY(305, 170),
			THE_LOST_TRIBE(306, 160),
			THE_MAD_MOLE(307, 140),
			THE_MONSTERS_BELOW(308, 162),
			THE_NAVIGATOR(309, 138),
			THE_NOBLE_RODENT(310, 140),
			THE_OTHER_SIDE(311, 154),
			THE_POWER_OF_TEARS(312, 150),
			THE_QUIZMASTER(313, 190),
			THE_ROGUES_DEN(314, 175),
			THE_SHADOW(315, 185),
			THE_SLAYER(316, 180),
			THE_TERRIBLE_TOWER(317, 148),
			THE_TOWER(318, 154),
			THEME(319, 128),
			THRONE_OF_THE_DEMON(320, 162),
			TIME_OUT(321, 170),
			TIME_TO_MINE(322, 160),
			TIPTOE(323, 172),
			TITLE_FIGHT(324, 167),
			TOMORROW(325, 166),
			TOO_MANY_COOKS(326, 148),
			TRAWLER(327, 170),
			TRAWLER_MINOR(328, 178),
			TREE_SPIRITS(329, 156),
			TREMBLE(330, 150),
			TRIBAL(331, 160),
			TRIBAL_2(332, 148),
			TRIBAL_BACKGROUND(333, 170),
			TRINITY(334, 184),
			TROUBLED(335, 146),
			TWILIGHT(336, 152),
			TZHAAR(337, 176),
			UNDERCURRENT(338, 195),
			UNDERGROUND(339, 172),
			UNDERGROUND_PASS(340, 160),
			UNDERSTANDING(341, 186),
			UNKNOWN_LAND(342, 150),
			UPCOMING(343, 188),
			WANDER(344, 166),
			WARRIOR(345, 160),
			WATERFALL(346, 148),
			WATERLOGGED(347, 156),
			WAYWARD(348, 172),
			WELL_OF_VOYAGE(349, 160),
			VENTURE(350, 160),
			VENTURE_2(351, 160),
			WILD_SIDE(352, 166),
			WILDERNESS(353, 146),
			WILDERNESS_2(354, 150),
			WILDERNESS_3(355, 155),
			WILDWOOD(356, 176),
			VILLAGE(357, 146),
			VISION(358, 152),
			WITCHING(359, 170),
			WOE_OF_THE_WYVERN(360, 140),
			WOLFMOUNTAIN(361, 160),
			WONDER(362, 150),
			WONDEROUS(363, 148),
			WOODLAND(364, 165),
			VOODOO_CULT(365, 150),
			WORKSHOP(366, 140),
			VOYAGE(367, 155),
			WRATH_AND_RUIN(368, 160),
			XENOPHOBE(369, 160),
			YESTERYEAR(370, 154),
			ZEALOT(371, 176),
			ZORGE_DANCE(372, 165);

			int music;
			int durationSeconds;

			CITY_MUSIC(int music, int durationSeconds) {
				this.music = music;
				this.durationSeconds = durationSeconds;
			}
			public static String getSongNameById(int songId) {
				for (CITY_MUSIC song : CITY_MUSIC.values()) {
					if (song.getMusic() == songId) {
						return song.getName();
					}
				}
				return null; // Handle the case where the song ID is not found
			}
				public static String formatSongName(String name) {
					// Remove underscores and capitalize the words
					String[] words = name.split("_");
					StringBuilder formattedName = new StringBuilder();
					for (int i = 0; i < words.length; i++) {
						String word = words[i];
						formattedName.append(word.substring(0, 1).toUpperCase())
									 .append(word.substring(1).toLowerCase());

						// Add space between words, except for the last word
						if (i < words.length - 1) {
							formattedName.append(" ");
						}
					}
					return formattedName.toString();
				}
			public int getMusic() {
				return music;
			}
			
			public String getName() {
				return this.name(); // Use the enum name as the song name
			}
			 public int getDurationSeconds() {
				return durationSeconds;
			}
			 public static CITY_MUSIC getByActionButtonId(int actionButtonId) {
					for (CITY_MUSIC cityMusic : values()) {
						if (cityMusic.getMusic() == (actionButtonId - 197036)) {
							return cityMusic;
						}
					}
					return null; // Handle the case where the actionButtonId doesn't match any CITY_MUSIC
				}
			// If you need to set the duration dynamically
			public void setDurationSeconds(int durationSeconds) {
				this.durationSeconds = durationSeconds;
			}
		}


}