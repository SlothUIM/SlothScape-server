package server.model.items;

import server.model.players.Client;
import server.model.players.skills.farming.*;
import server.model.players.skills.*;
import server.model.players.quests.*;
import server.model.players.skills.cooking.*;
import server.util.Misc;
import server.Config;
import server.model.npcs.*;
import server.model.objects.Object;
import server.world.Boundary;
import server.event.CycleEvent;
import server.event.CycleEventContainer;
import server.event.CycleEventHandler;

/**
 * 
 * @author Ryan / Lmctruck30
 * 
 */

public class UseItem {

	public static void ItemonObject(Client c, int objectID, int objectX,
			int objectY, int itemId) {
		final int goodPosXType1 = objectX - 5;
		final int goodPosXType2 = objectX + 5;
		final int goodPosYType1 = objectY - 5;
		final int goodPosYType2 = objectY + 5;
		if (c.absX >= goodPosXType1 && c.absX <= goodPosXType2 && c.absY >= goodPosYType1 && c.absY <= goodPosYType2) {
			c.turnPlayerTo(objectX, objectY);
		} else {
			c.getPA().playerWalk(objectX, objectY);
		}
		if (!c.getItems().playerHasItem(itemId, 1))
			return;
			if (c.getRunecrafting().isTalisman(itemId))
				c.getRunecrafting().TalismanOnAltar(itemId, objectID);
			
		if (Farming.prepareCrop(c, itemId, objectID, objectX, objectY)) {
			return;
		}
		switch (objectID) {
			case 26115:
			if(c.EleWorkShop > 1 && c.getItems().playerHasItem(2887) && c.absY == objectY){
					c.getPA().object(-1, objectX, objectY, 0, 0);
					c.getPA().object(objectID, objectX, objectY+1, 2, 0);
					c.getPA().walkTo(0, 1);
				CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
						@Override
						public void execute(CycleEventContainer container) {
								container.stop();
						}

						@Override
						public void stop() {

						c.getPA().object(-1, objectX, objectY+1, 0, 0);
						c.getPA().object(objectID, objectX, objectY, 1, 0);
						}

					}, 2);
			}
			break;
			/*case 2452:
			if (c.getRunecrafting().isTalisman(itemId))
				c.getRunecrafting().TalismanOnAltar(itemId, objectID);
			break;*/
			case 3402:
				if(c.getItems().playerHasItem(2893, 1) && c.getItems().playerHasItem(2347, 1)){
					c.getItems().deleteItem(2893, 1);
                        c.startAnimation(898);
					c.sendMessage("Following the instructions in the book you make an elemental shield.");
					CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
                        @Override
                        public void execute(CycleEventContainer container) {
                            container.stop();
                        }

                        @Override
                        public void stop() {
							c.EleWorkshopWater_stage = 215;
							c.EleWorkShop = 16;
							c.getItems().addItem(2890, 1);
							QuestRewards.EleWorkshopReward(c);
                        }
                    }, 3);
				}
			break;
			case 3410:
				switch(itemId){ 
					case 2889:
						if(c.getItems().playerHasItem(2888, 1)){
							c.getItems().deleteItem(2889, 1);
							c.getItems().addItem(2888, 1);
							c.startAnimation(899);
							c.EleWorkshopWater_stage = 215;
							c.sendMessage("You empty the lava into the furnace.");
							c.getPA().sendConfig(299, 215 << 3);
						}
					break;
					case 2892:
					case 453:
						if(c.getItems().playerHasItem(453, 4) && c.getItems().playerHasItem(2892, 1) && c.EleWorkshopWater_stage == 215){
							c.sendMessage("You place the elemental ore and four heaps of coal into the furnace.");
							c.startAnimation(899);
							c.getItems().deleteItem(453, 4);
							c.getItems().deleteItem(2892, 1);
							CycleEventHandler.getSingleton().addEvent(c, new CycleEvent() {
								@Override
								public void execute(CycleEventContainer container) {
									container.stop();
								}

								@Override
								public void stop() {
									c.EleWorkshopWater_stage = 12;
									c.getItems().addItem(2893, 1);
									c.sendMessage("You retrieve a bar of elemental metal.");
								}
							}, 2);
						}
					break;
				}
			break;
			case 18519:
				switch(itemId){ 
					case 2888:
						if(c.getItems().playerHasItem(2888, 1)){
							c.getItems().deleteItem(2888, 1);
							c.getItems().addItem(2889, 1);
							c.sendMessage("You fill the bowl with hot lava.");
						}
					break;
				}
			break;
		case 12269:
		case 2732:
		case 114:
		case 2727:
		case 385:
		case 14919:
		case 2728:
		case 9682:
			if (c.absX == 3014 && c.absY > 3235 && c.absY < 3238
					|| c.absX == 3012 && c.absY == 3239 || c.absX == 3020
					&& c.absY > 3236 && c.absY < 3239 || c.absX > 2805
					&& c.absX < 2813 || c.absY > 3437 && c.absY < 3442) {
				return;
			}
			if (c.tutorialProgress < 36 || Boundary.isIn(c, Boundary.TUTORIAL)) {
				CookingTutorialIsland.cookThisFood(c, itemId, objectID);
			} else {
				c.getCooking().startCooking(c, itemId, objectID);
				//c.getCooking().itemOnObject(itemId);
			}
			break;
		case 2783:
			c.getSmithingInt().showSmithInterface(itemId);
			break;	
			case 29728:
				//c.getPA().object(29727, c.objectX, c.objectY, 0, 0);
					new Object(29729, c.objectX, c.objectY, c.heightLevel, 0,
							10, 29728, 15);
				break;
		case 409:
			if (c.getPrayer().isBone(itemId))
				c.getPrayer().bonesOnAltar(itemId);
			break;
		default:
			if (c.playerRights == 3)
				Misc.println("Player At Object id: " + objectID
						+ " with Item id: " + itemId);
			break;
		}

	}

	public static void ItemonItem(Client c, int itemUsed, int useWith) {
		if (c.tutorialProgress < 36) {
			if (itemUsed == 1929 && useWith == 1933 || itemUsed == 1933 && useWith == 1929) {
				c.getItems().deleteItem(1929, 1);
				c.getItems().deleteItem(1933, 1);
				c.getItems().addItem(2307, 1);
				c.getItems().addItem(1925, 1);
				c.getItems().addItem(1931, 1);
				if (c.tutorialProgress == 8) {
					c.getDH().sendDialogues(3026, -1);
				}
			}
		}
				if (useWith == 11941 || useWith == 11942) {
					if(c.oneClickDeposit){
						int slotToUpdate = -1; // Initialize with an invalid value

						// Check if the item is already present in any slot
						for (int ITEM = 0; ITEM < 28; ITEM++) {
							if (c.playerLootItems[ITEM] == (itemUsed + 1)) {
								slotToUpdate = ITEM; // Store the slot index to update
								break;
							}
						}

						if (slotToUpdate != -1) {
							// Item already present in a slot
							if (c.getItems().isStackable(c.playerLootItems[slotToUpdate] - 1)) {
								// Item is stackable, increment the quantity
								c.playerLootItemsN[slotToUpdate]++;
							} else {
								// Item is not stackable, find an empty slot
								for (int ITEM = 0; ITEM < 28; ITEM++) {
									if (c.playerLootItems[ITEM] == 0) {
										slotToUpdate = ITEM; // Store the slot index to update
										break;
									}
								}

								if (slotToUpdate != -1) {
									c.playerLootItems[slotToUpdate] = itemUsed + 1;
									c.playerLootItemsN[slotToUpdate] = 1;
								} else {
									// Handle the case when there are no empty slots available
									// Display an error message or take appropriate action
								}
							}
						} else {
							// Item not present in any slot, find an empty slot
							for (int ITEM = 0; ITEM < 28; ITEM++) {
								if (c.playerLootItems[ITEM] == 0) {
									slotToUpdate = ITEM; // Store the slot index to update
									break;
								}
							}

							if (slotToUpdate != -1) {
								c.playerLootItems[slotToUpdate] = itemUsed + 1;
								c.playerLootItemsN[slotToUpdate] = 1;
							} else {
								// Handle the case when there are no empty slots available
								// Display an error message or take appropriate action
							}
						}
						// Delete the used item
						if(c.getItems().playerHasItem(itemUsed, 1)) {
							if (c.getItems().isStackable(itemUsed))
								c.getItems().deleteItem(itemUsed, c.getItems().getItemSlot(itemUsed), c.getItems().getItemAmount(itemUsed));
							else
								c.getItems().deleteItem(itemUsed, c.getItems().getItemSlot(itemUsed), 1);
						}
					} else {
						c.xRemoveId = itemUsed;
						c.xRemoveSlot = c.getItems().getItemSlot(itemUsed);
						c.getDH().sendOption4("Add 1", "Add 5", "Add 10", "Add X");
						c.dialogueAction = 420;
					}
					
				}
		
		int firemakingItems[] = {590, 7329, 7330, 7331};
		for (int i = 0; i < firemakingItems.length; i++) {
			if (itemUsed == firemakingItems[i] || useWith == firemakingItems[i] && c.isFiremaking == false) {
				Firemaking.attemptFire(c, itemUsed, useWith, c.absX, c.absY, false);
			} else if (itemUsed == firemakingItems[i] || useWith == firemakingItems[i] && c.isFiremaking) {
				c.sendMessage("You can't do that, you are already firemaking.");
			}
		}

		if (itemUsed == 227 || useWith == 227)
			c.getHerblore().handlePotMaking(itemUsed, useWith);
		
		if (itemUsed == 12934 && (useWith == 12924 || useWith == 12926)){
				c.addingCharges = true;
				c.xRemoveId = itemUsed;
				c.getOutStream().createFrame(27);
			
		}
		if (itemUsed <= 811 && itemUsed >= 806 && (useWith == 12924 || useWith == 12926)){
				c.addingDarts = true;
				c.xRemoveId = itemUsed;
				c.getOutStream().createFrame(27);
			
		}
		if ((itemUsed <= 566 && itemUsed >= 554) || (itemUsed <= 4699 && itemUsed >= 4694) && useWith == 12791){

				c.addingToRP = true;
				c.xRemoveId = itemUsed;
				c.getOutStream().createFrame(27);
			
		}
		if ((itemUsed == 946 && useWith == 2886 || itemUsed == 2886 && useWith == 946)){
			if (c.EleWorkShop >= 1 && !c.getItems().playerHasItem(2887)){
					c.sendMessage("You make a small cut in the spine of the book.");
					c.getItems().deleteItem(2886, 1);
					c.getItems().addItem(9715, 1);
					c.getItems().addItem(2887, 1);
					if (c.EleWorkShop == 2)
						c.EleWorkShop = 3;
					c.sendMessage("Inside you find a small, old, battered key.");
			} else {
				c.sendMessage("Now why would I do that?");
				return;
			}
		}
		if (itemUsed == 9075 && useWith == 12791){

				c.addingToRP = true;
				c.xRemoveId = itemUsed;
				c.getOutStream().createFrame(27);
			
		}
		
		if (c.getItems().getItemName(itemUsed).contains("(")
				&& c.getItems().getItemName(useWith).contains("("))
			c.getPotMixing().mixPotion2(itemUsed, useWith);
		if (itemUsed == 1733 || useWith == 1733)
			c.getCrafting().handleLeather(itemUsed, useWith);
		if (itemUsed == 1755 || useWith == 1755)
			c.getCrafting().handleChisel(itemUsed, useWith);
		if (itemUsed == 946 || useWith == 946)
			c.getFletching().handleLog(itemUsed, useWith);
		
		if (itemUsed == 1777 || useWith == 1777){
			
			if (itemUsed == 50 || useWith == 50 || itemUsed == 48 || useWith == 48)
			c.getFletching().handleString(itemUsed, useWith, 0);
			if (itemUsed == 54 || useWith == 54 || itemUsed == 56 || useWith == 56)
			c.getFletching().handleString(itemUsed, useWith, 1);
			if (itemUsed == 60 || useWith == 60 || itemUsed == 58 || useWith == 58)
			c.getFletching().handleString(itemUsed, useWith, 2);
			if (itemUsed == 64 || useWith == 64 || itemUsed == 62 || useWith == 62)
			c.getFletching().handleString(itemUsed, useWith, 3);
			if (itemUsed == 68 || useWith == 68 || itemUsed == 66 || useWith == 66)
			c.getFletching().handleString(itemUsed, useWith, 4);
			if (itemUsed == 72 || useWith == 72 || itemUsed == 70 || useWith == 70)
			c.getFletching().handleString(itemUsed, useWith, 5);
		}
		if (itemUsed == 53 || useWith == 53 || itemUsed == 52 || useWith == 52)
			c.getFletching().makeArrows(itemUsed, useWith);
		if ((itemUsed == 1540 && useWith == 11286)
				|| (itemUsed == 11286 && useWith == 1540)) {
			if (c.playerLevel[c.playerSmithing] >= 95) {
				c.getItems()
						.deleteItem(1540, c.getItems().getItemSlot(1540), 1);
				c.getItems().deleteItem(11286, c.getItems().getItemSlot(11286),
						1);
				c.getItems().addItem(11284, 1);
				c.sendMessage("You combine the two materials to create a dragonfire shield.");
				c.getPA().addSkillXP(500 * Config.SMITHING_EXPERIENCE,
						c.playerSmithing);
			} else {
				c.sendMessage("You need a smithing level of 95 to create a dragonfire shield.");
			}
		}
		if (itemUsed == 9142 && useWith == 9190 || itemUsed == 9190
				&& useWith == 9142) {
			if (c.playerLevel[c.playerFletching] >= 58) {
				int boltsMade = c.getItems().getItemAmount(itemUsed) > c
						.getItems().getItemAmount(useWith) ? c.getItems()
						.getItemAmount(useWith) : c.getItems().getItemAmount(
						itemUsed);
				c.getItems().deleteItem(useWith,
						c.getItems().getItemSlot(useWith), boltsMade);
				c.getItems().deleteItem(itemUsed,
						c.getItems().getItemSlot(itemUsed), boltsMade);
				c.getItems().addItem(9241, boltsMade);
				c.getPA().addSkillXP(
						boltsMade * 6 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 58 to fletch this item.");
			}
		}
		if (itemUsed == 9143 && useWith == 9191 || itemUsed == 9191
				&& useWith == 9143) {
			if (c.playerLevel[c.playerFletching] >= 63) {
				int boltsMade = c.getItems().getItemAmount(itemUsed) > c
						.getItems().getItemAmount(useWith) ? c.getItems()
						.getItemAmount(useWith) : c.getItems().getItemAmount(
						itemUsed);
				c.getItems().deleteItem(useWith,
						c.getItems().getItemSlot(useWith), boltsMade);
				c.getItems().deleteItem(itemUsed,
						c.getItems().getItemSlot(itemUsed), boltsMade);
				c.getItems().addItem(9242, boltsMade);
				c.getPA().addSkillXP(
						boltsMade * 7 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 63 to fletch this item.");
			}
		}
		if (itemUsed == 9143 && useWith == 9192 || itemUsed == 9192
				&& useWith == 9143) {
			if (c.playerLevel[c.playerFletching] >= 65) {
				int boltsMade = c.getItems().getItemAmount(itemUsed) > c
						.getItems().getItemAmount(useWith) ? c.getItems()
						.getItemAmount(useWith) : c.getItems().getItemAmount(
						itemUsed);
				c.getItems().deleteItem(useWith,
						c.getItems().getItemSlot(useWith), boltsMade);
				c.getItems().deleteItem(itemUsed,
						c.getItems().getItemSlot(itemUsed), boltsMade);
				c.getItems().addItem(9243, boltsMade);
				c.getPA().addSkillXP(
						boltsMade * 7 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 65 to fletch this item.");
			}
		}
		if (itemUsed == 9144 && useWith == 9193 || itemUsed == 9193
				&& useWith == 9144) {
			if (c.playerLevel[c.playerFletching] >= 71) {
				int boltsMade = c.getItems().getItemAmount(itemUsed) > c
						.getItems().getItemAmount(useWith) ? c.getItems()
						.getItemAmount(useWith) : c.getItems().getItemAmount(
						itemUsed);
				c.getItems().deleteItem(useWith,
						c.getItems().getItemSlot(useWith), boltsMade);
				c.getItems().deleteItem(itemUsed,
						c.getItems().getItemSlot(itemUsed), boltsMade);
				c.getItems().addItem(9244, boltsMade);
				c.getPA().addSkillXP(
						boltsMade * 10 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 71 to fletch this item.");
			}
		}
		if (itemUsed == 9144 && useWith == 9194 || itemUsed == 9194
				&& useWith == 9144) {
			if (c.playerLevel[c.playerFletching] >= 58) {
				int boltsMade = c.getItems().getItemAmount(itemUsed) > c
						.getItems().getItemAmount(useWith) ? c.getItems()
						.getItemAmount(useWith) : c.getItems().getItemAmount(
						itemUsed);
				c.getItems().deleteItem(useWith,
						c.getItems().getItemSlot(useWith), boltsMade);
				c.getItems().deleteItem(itemUsed,
						c.getItems().getItemSlot(itemUsed), boltsMade);
				c.getItems().addItem(9245, boltsMade);
				c.getPA().addSkillXP(
						boltsMade * 13 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 58 to fletch this item.");
			}
		}
		if (itemUsed == 1601 && useWith == 1755 || itemUsed == 1755
				&& useWith == 1601) {
			if (c.playerLevel[c.playerFletching] >= 63) {
				c.getItems()
						.deleteItem(1601, c.getItems().getItemSlot(1601), 1);
				c.getItems().addItem(9192, 15);
				c.getPA().addSkillXP(8 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 63 to fletch this item.");
			}
		}
		if (itemUsed == 1607 && useWith == 1755 || itemUsed == 1755
				&& useWith == 1607) {
			if (c.playerLevel[c.playerFletching] >= 65) {
				c.getItems()
						.deleteItem(1607, c.getItems().getItemSlot(1607), 1);
				c.getItems().addItem(9189, 15);
				c.getPA().addSkillXP(8 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 65 to fletch this item.");
			}
		}
		if (itemUsed == 1605 && useWith == 1755 || itemUsed == 1755
				&& useWith == 1605) {
			if (c.playerLevel[c.playerFletching] >= 71) {
				c.getItems()
						.deleteItem(1605, c.getItems().getItemSlot(1605), 1);
				c.getItems().addItem(9190, 15);
				c.getPA().addSkillXP(8 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 71 to fletch this item.");
			}
		}
		if (itemUsed == 1603 && useWith == 1755 || itemUsed == 1755
				&& useWith == 1603) {
			if (c.playerLevel[c.playerFletching] >= 73) {
				c.getItems()
						.deleteItem(1603, c.getItems().getItemSlot(1603), 1);
				c.getItems().addItem(9191, 15);
				c.getPA().addSkillXP(8 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 73 to fletch this item.");
			}
		}
		if (itemUsed == 1615 && useWith == 1755 || itemUsed == 1755
				&& useWith == 1615) {
			if (c.playerLevel[c.playerFletching] >= 73) {
				c.getItems()
						.deleteItem(1615, c.getItems().getItemSlot(1615), 1);
				c.getItems().addItem(9193, 15);
				c.getPA().addSkillXP(8 * Config.FLETCHING_EXPERIENCE,
						c.playerFletching);
			} else {
				c.sendMessage("You need a fletching level of 73 to fletch this item.");
			}
		}
		if (itemUsed >= 11710 && itemUsed <= 11714 && useWith >= 11710
				&& useWith <= 11714) {
			if (c.getItems().hasAllShards()) {
				c.getItems().makeBlade();
			}
		}
		if (itemUsed == 2368 && useWith == 2366 || itemUsed == 2366
				&& useWith == 2368) {
			c.getItems().deleteItem(2368, c.getItems().getItemSlot(2368), 1);
			c.getItems().deleteItem(2366, c.getItems().getItemSlot(2366), 1);
			c.getItems().addItem(1187, 1);
		}

		if (c.getItems().isHilt(itemUsed) || c.getItems().isHilt(useWith)) {
			int hilt = c.getItems().isHilt(itemUsed) ? itemUsed : useWith;
			int blade = c.getItems().isHilt(itemUsed) ? useWith : itemUsed;
			if (blade == 11690) {
				c.getItems().makeGodsword(hilt);
			}
		}

		switch (itemUsed) {
			case 4151:
				if(useWith == 12004){
					c.getItems().deleteItem(4151, c.getItems().getItemSlot(4151), 1);
					c.getItems().deleteItem(12004, c.getItems().getItemSlot(12004), 1);
					c.getItems().addItem(12006, 1);
				}
			break;
			case 12004:
				if(useWith == 4151){
					c.getItems().deleteItem(4151, c.getItems().getItemSlot(4151), 1);
					c.getItems().deleteItem(12004, c.getItems().getItemSlot(12004), 1);
					c.getItems().addItem(12006, 1);
				}
			break;

		default:
			if (c.playerRights == 3)
				Misc.println("Player used Item id: " + itemUsed
						+ " with Item id: " + useWith);
			break;
		}
	}

	public static void ItemonNpc(Client c, int itemId, int npcId, int slot) {
		switch(npcId){
		case 3021:
			if (c.getFarmingTools().noteItem(itemId)) {
				return;
			}
			
			break;
			//case 43:
				//NPCHandler.npcs[npcId].shearSheep(c, 1735, 1737, 893, 43, 42, 50);
				//break;
		}
		switch (itemId) {

		default:
			if (c.playerRights == 3)
				Misc.println("Player used Item id: " + itemId
						+ " with Npc id: " + npcId + " With Slot : " + slot);
			break;
		}

	}

}
