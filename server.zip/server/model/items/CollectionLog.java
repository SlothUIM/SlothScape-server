package server.model.items;

import server.Config;
import server.Server;
import server.model.players.Client;
import server.model.players.Player;
import server.model.players.PlayerHandler;
import server.model.npcs.NPCHandler;
import server.model.players.PlayerAssistant;
import server.util.Misc;

public class CollectionLog {

	private Client c;
		public CollectionLog(Client client){
			this.c = client;
		}
			
		public int getItemFromSlot(int slot) {
			return (c.playerLogItems[slot]);
		}
		public int getItemAmt(int slot) {
			return (c.playerLogItemsAmt[slot]);
		}
		public int getAllLogsTotal() {
			return EasyClueCollectionLog.length+MediumClueCollectionLog.length+HardClueCollectionLog.length+EliteClueCollectionLog.length+MasterRareClueCollectionLog.length
			+SharedClueCollectionLog.length+MiscCollectionLog.length+PetCollectionLog.length+CreatureCreationCollectionLog.length+RandomEventCollectionLog.length+fightCavesCollectionLog.length
			+CyclopesCollectionLog.length+DGKCollectionLog.length+callistoCollectionLog.length+corpCollectionLog.length+sireCollectionLog.length+barrowsCollectionLog.length+bandosCollectionLog.length;
		
		}
		public int getCollectionTotalAmount(String bossName) {
    int[][] bossCollectionLog = null;

    // Determine the collection log array based on the boss name
    switch (bossName) {
        case "BeginnerClue":
            bossCollectionLog = BeginnerCollectionLog;
            break;
        case "EasyClue":
            bossCollectionLog = EasyClueCollectionLog;
            break;
        case "MediumClue":
            bossCollectionLog = MediumClueCollectionLog;
            break;
        case "HardClue":
            bossCollectionLog = HardClueCollectionLog;
            break;
        case "EliteClue":
            bossCollectionLog = EliteClueCollectionLog;
            break;
        case "MasterRareClue":
            bossCollectionLog = MasterRareClueCollectionLog;
            break;
        case "SharedClue":
            bossCollectionLog = SharedClueCollectionLog;
            break;
        case "Misc":
            bossCollectionLog = MiscCollectionLog;
            break;
        case "pets":
            bossCollectionLog = PetCollectionLog;
            break;
        case "creation":
            bossCollectionLog = CreatureCreationCollectionLog;
            break;
        case "RandomEvent":
            bossCollectionLog = RandomEventCollectionLog;
            break;
        case "fightCaves":
            bossCollectionLog = fightCavesCollectionLog;
            break;
        case "Cyclopes":
            bossCollectionLog = CyclopesCollectionLog;
            break;
        case "DGK":
            bossCollectionLog = DGKCollectionLog;
            break;
        case "Callisto":
            bossCollectionLog = callistoCollectionLog;
            break;
        case "Corp":
            bossCollectionLog = corpCollectionLog;
            break;
        case "Sire":
            bossCollectionLog = sireCollectionLog;
            break;
        case "Barrows":
            bossCollectionLog = barrowsCollectionLog;
            break;
        case "General Graardor":
            bossCollectionLog = bandosCollectionLog;
            break;
        case "Commander Zilyana":
            bossCollectionLog = saraCollectionLog;
            break;
        case "K'ril tsutsaroth":
            bossCollectionLog = zammyCollectionLog;
            break;
        case "Kree'arra":
            bossCollectionLog = armadylCollectionLog;
            break;
        case "King Black Dragon":
            bossCollectionLog = KBDCollectionLog;
            break;
        case "Kraken":
            bossCollectionLog = krakenCollectionLog;
            break;
        // Add more cases for other bosses as needed

        default:
            // Boss name does not match any collection log
            return -1;
    }

     int uniqueItemCount = 0;

    // Count the number of unique items with an amount greater than 0 in the collection log array
    for (int i = 0; i < bossCollectionLog.length; i++) {
        int amount = bossCollectionLog[i][2];
        if (amount > 0) {
            uniqueItemCount++;
        }
    }

    return uniqueItemCount;
}
				public String[] BossLogName = { 
						"Abyssal Sire", "Barrows Chests", "Bryophyta", "Callisto", "Cerberus", "Chaos Elemental", 
						"Chaos Fanatic", "Commander Zilyana", "Corporeal Beast", "Dagannoth Kings", "The Fight Caves", 
						"General Graardor", "Giant Mole", "Kalphite Queen", "King Black Dragon", "Kraken", "Kree'arra", 
						"K'ril Tsutsaroth", "Zulrah"}; 
						
			public void openLog(int log) {
				c.CollLogOpen = log;
				if(log == 0) {
					for(int slot = 0; slot < BossLogName.length; slot++) {
						c.getPA().sendFrame126(BossLogName[slot] , 35714+slot);
							for(int i = 35733; i < 35813; i++)
								c.getPA().sendFrame126("" , i);
					}
					/*c.getPA().sendFrame126("Barrows Chests" , 35715);
					c.getPA().sendFrame126("Bryophyta" , 35716);
					c.getPA().sendFrame126("Callisto" , 35717);
					c.getPA().sendFrame126("Cerberus" , 35718);
					c.getPA().sendFrame126("Chaos Elemental" , 35719);
					c.getPA().sendFrame126("Chaos Fanatic" , 35720);
					c.getPA().sendFrame126("Commander Zilyana" , 35721);
					c.getPA().sendFrame126("Corporeal Beast" , 35722);
					c.getPA().sendFrame126("Dagannoth Kings" , 35723);
					c.getPA().sendFrame126("The Fight Caves" , 35724);
					if(c.getCollectionLog().getCollectionTotalAmount("General Graardor") == 7)
						c.getPA().sendFrame126("@gre@General Graardor" , 35725);
					else
						c.getPA().sendFrame126("General Graardor" , 35725);
					c.getPA().sendFrame126("Giant Mole" , 35726);
					c.getPA().sendFrame126("Kalphite Queen" , 35727);
					c.getPA().sendFrame126("King Black Dragon" , 35728);
					c.getPA().sendFrame126("Kraken" , 35729);
					c.getPA().sendFrame126("Kree'arra" , 35730);
					c.getPA().sendFrame126("K'ril Tsutsaroth" , 35731);
					c.getPA().sendFrame126("Zulrah" , 35732);*/
				} if(log == 1) {
					c.getPA().sendFrame126("Chambers of Xeric" , 35714);
					c.getPA().sendFrame126("Theatre of Blood" , 35715);
					c.getPA().sendFrame126("Tombs of Amascut" , 35716);
					for(int i = 35717; i < 35813; i++)
					c.getPA().sendFrame126("" , i);
				} else if(log == 2) {
					c.getPA().sendFrame126("Beginner Treasure Trails" , 35714);
					if(c.getCollectionLog().getCollectionTotalAmount("EasyClue") == 61)
						c.getPA().sendFrame126("@gre@Easy Treasure Trails" , 35715);
					else
						c.getPA().sendFrame126("Easy Treasure Trails" , 35715);
					c.getPA().sendFrame126("Medium Treasure Trails" , 35716);
					c.getPA().sendFrame126("Hard Treasure Trails" , 35717);
					c.getPA().sendFrame126("Elite Treasure Trails" , 35718);
					c.getPA().sendFrame126("Master Treasure Trails" , 35719);
					c.getPA().sendFrame126("Hard Treasure Trails(Rare)" , 35720);
					c.getPA().sendFrame126("Elite Treasure Trails(Rare)" , 35721);
					c.getPA().sendFrame126("Master Treasure Trails(Rare)" , 35722);
					c.getPA().sendFrame126("Shared Treasure Trails Rewards" , 35723);
					for(int i = 35724; i < 35813; i++)
					c.getPA().sendFrame126("" , i);
				} else if(log == 4) {
					c.getPA().sendFrame126("Aerial Fishing" , 35714);
					c.getPA().sendFrame126("All pets" , 35715);
					c.getPA().sendFrame126("Champion's Challenge" , 35716);
					c.getPA().sendFrame126("Chaos Druids" , 35717);
					c.getPA().sendFrame126("Chompy Bird Hunting" , 35718);
					c.getPA().sendFrame126("Creature Creation" , 35719);
					c.getPA().sendFrame126("Cyclopes" , 35720);
					c.getPA().sendFrame126("Miscellaneous" , 35721);
					c.getPA().sendFrame126("Random Events" , 35722);
					for(int i = 35723; i < 35813; i++)
					c.getPA().sendFrame126("" , i);
				}
			}
public int getCollectionLogItemAmount(int[][] bossCollectionLog, int itemId) {
    for (int i = 0; i < bossCollectionLog.length; i++) {
        int itemID = bossCollectionLog[i][0];
        int amount = bossCollectionLog[i][2];

        if (itemID == itemId) {
            return amount; // Return the amount if item ID matches
        }
    }

    return 0; // Return 0 if item ID is not found in the collection log
}
		public int[][] sireCollectionLog = {
			{13262, 0, 0},
			{13273, 1, 0},
			{8264, 2, 0},
			{13274, 3, 0},
			{13275, 4, 0},
			{13276, 5, 0},
			{13277, 6, 0},
			{13265, 7, 0},
			{4151, 8, 0}
			// Add more Barrows items...
		};			
		public int[][] CreatureCreationCollectionLog = {
			{10859, 0, 0},
			{10877, 1, 0},
			{10878, 2, 0},
			{10879, 3, 0},
			{10880, 4, 0},
			{10881, 5, 0},
			{10882, 6, 0}
        // Add more Barrows items...
		};	
		public int[][] RandomEventCollectionLog = {
			{6654, 0, 0},
			{6655, 1, 0},
			{6656, 2, 0},
			
			{6180, 3, 0},
			{6181, 4, 0},
			{6182, 5, 0},
			
			{7594, 6, 0},
			{7592, 7, 0},
			{7593, 8, 0},
			{7595, 9, 0},
			{7596, 10, 0},
			
			{3057, 11, 0},
			{3058, 12, 0},
			{3059, 13, 0},
			{3060, 14, 0},
			{3061, 15, 0},
			{6183, 16, 0},
			
			{6345, 17, 0},
			{6341, 18, 0},
			{6343, 19, 0},
			{6347, 20, 0},
			{6349, 21, 0}
		
        // Add more Barrows items...
		};				
		public int[][] ChompyCollectionLog = {
        {2978, 0, 0},
        {2979, 1, 0},
        {2980, 2, 0},
        {2981, 3, 0},
        {2982, 4, 0},
        {2983, 5, 0},
        {2984, 6, 0},
        {2985, 7, 0},
        {2986, 8, 0},
        {2987, 9, 0},
        {2988, 10, 0},
        {2989, 11, 0},
        {2990, 12, 0},
        {2991, 13, 0},
        {2992, 14, 0},
        {2993, 15, 0},
        {2994, 16, 0},
        {2995, 17, 0}
        // Add more items...
		};		
		public int[][] eleCollectionLog = {
        {11995, 0, 0},
        {11920, 1, 0},
        {7158, 2, 0}
        // Add more items...
		};	
		public int[][] fanaticCollectionLog = {
        {11995, 0, 0},
        {12806, 1, 0},
        {12807, 2, 0}
        // Add more items...
		};			
		public int[][] corpCollectionLog = {
        {12816, 0, 0},
        {12819, 1, 0},
        {12821, 2, 0},
        {12823, 3, 0},
        {12833, 4, 0},
        {12829, 5, 0}
        // Add more items...
		};				
		public int[][] CyclopesCollectionLog = {
        {8844, 0, 0},
        {8845, 1, 0},
        {8846, 2, 0},
        {8847, 3, 0},
        {8848, 4, 0},
        {8849, 5, 0},
        {8850, 6, 0},
        {12954, 7, 0}
        // Add more items...
		};	
		public int[][] barrowsCollectionLog = {
        {4732, 0, 0},
        {4708, 1, 0},
        {4716, 2, 0},
        {4724, 3, 0},
        {4745, 4, 0},
        {4753, 5, 0},
        {4736, 6, 0},
        {4712, 7, 0},
        {4720, 8, 0},
        {4728, 9, 0},
        {4749, 10, 0},
        {4757, 11, 0},
        {4738, 12, 0},
        {4714, 13, 0},
        {4722, 14, 0},
        {4730, 15, 0},
        {4751, 16, 0},
        {4759, 17, 0},
        {4734, 18, 0},
        {4710, 19, 0},
        {4718, 20, 0},
        {4726, 21, 0},
        {4747, 22, 0},
        {4755, 23, 0},
        {4740, 24, 0}
        // Add more items...
    };		
	public int[][] bandosCollectionLog = {
        {12650, 0, 0},
        {11832, 1, 0},
        {11834, 2, 0},
        {11836, 3, 0},
        {11812, 4, 0},
        {11818, 5, 0},
        {11820, 6, 0},
        {11822, 7, 0}
        // Add more items...
    };		
	public int[][] saraCollectionLog = {
		
        {12651, 0, 0},
		{11785, 1, 0},
        {11814, 2, 0},
        {11838, 3, 0},
        {13256, 4, 0},
        {11818, 5, 0},
        {11820, 6, 0},
        {11822, 7, 0}
        // Add more items...
    };		
	public int[][] zammyCollectionLog = {
		
        {12652, 0, 0},
		{11791, 1, 0},
        {11824, 2, 0},
        {11787, 3, 0},
        {11816, 4, 0},
        {11818, 5, 0},
        {11820, 6, 0},
        {11822, 7, 0}
        // Add more items...
    };	
	public int[][] armadylCollectionLog = {
		
        {12649, 0, 0},
		{11826, 1, 0},
        {11828, 2, 0},
        {11830, 3, 0},
        {11810, 4, 0},
        {11818, 5, 0},
        {11820, 6, 0},
        {11822, 7, 0}
        // Add more items...
    };	
	public int[][] krakenCollectionLog = {
		
        {12655, 0, 0},
		{12004, 1, 0},
        {11905, 2, 0},
        {12007, 3, 0}
        // Add more items...
    };	
	public int[][] KBDCollectionLog = {
		
        {12653, 0, 0},
		{7980, 1, 0},
        {11920, 2, 0},
        {11286, 3, 0}
        // Add more items...
    };	
	public int[][] callistoCollectionLog = {
        {13178, 0, 0},
        {12603, 1, 0},
        {11920, 2, 0},
        {7158, 3, 0}
        // Add more items...
    };	
	public int[][] cerberusCollectionLog = {
        {13247, 0, 0},
        {13227, 1, 0},
        {13229, 2, 0},
        {13231, 3, 0},
        {13245, 4, 0},
        {13233, 5, 0},
        {13249, 6, 0}
        // Add more items...
    };	
	public int[][] fightCavesCollectionLog = {
        {13225, 0, 0},
        {6570, 1, 0},
        {6571, 2, 0}
        // Add more items...
    };	
	public int[][] DGKCollectionLog = {
        {12644, 0, 0},
        {12643, 1, 0},
        {12645, 2, 0},
        {6737, 3, 0},
        {6733, 4, 0},
        {6731, 5, 0},
        {6735, 6, 0},
        {6739, 7, 0},
        {6724, 8, 0},
        {6726, 9, 0}
        // Add more  items...
    };	
	public int[][] bryophytaCollectionLog = {
        {14653, 0, 0}
        // Add more  items...
    };	
	public int[][] MiscCollectionLog = {
        {13576, 0, 0},
        {7991, 1, 0},
        {7993, 2, 0},
        {7989, 3, 0},
        {10976, 4, 0},
        {10977, 5, 0},
        {9044, 6, 0},
        {11338, 7, 0},
        {11335, 8, 0},
        {2366, 9, 0},
        {1249, 10, 0},
        {19707, 11, 0},
        {11015, 12, 0},
        {11017, 13, 0},
        {11018, 14, 0},
        {11016, 15, 0},
		
        {9007, 16, 0},
        {9008, 17, 0},
        {9010, 18, 0},
        {9011, 19, 0},
        {7536, 20, 0},
        {7538, 21, 0},
        {6571, 22, 0}
        // Add more Barrows items...
    };		
	public int[][] PetCollectionLog = {
        {13262, 0, 0},
        {13178, 1, 0},
        {13247, 2, 0},
        {11995, 3, 0},
        {12651, 4, 0},
        {12643, 5, 0},
        {12644, 6, 0},
        {12645, 7, 0},
        {13225, 8, 0},
        {12650, 9, 0},
        {12646, 10, 0},
        {12647, 11, 0},
        {12653, 12, 0},
        {12655, 13, 0},
        {12649, 14, 0},
        {12652, 15, 0},
        {12648, 16, 0},
        {12921, 17, 0}
        // Add more Barrows items...
    };	
	//clue scroll Collection Log Items and amounts
	public int[][] BeginnerCollectionLog = {
        {10836, 0, 0},
        {10837, 1, 0},
        {10838, 2, 0},
        {10839, 3, 0},
        {10840, 4, 0},
        {12297, 5, 0}
        // Add more Barrows items...
		};	
	public int[][] EasyClueCollectionLog = {
        {2587, 0, 0},
        {2583, 1, 0},
        {2585, 2, 0},
        {3472, 3, 0},
        {2589, 4, 0},
        {2595, 5, 0},
        {2591, 6, 0},
        {2593, 7, 0},
        {3473, 8, 0},
        {2597, 9, 0},
        {10665, 10, 0},
        {10668, 11, 0},
        {10671, 12, 0},
        {10674, 13, 0},
        {10677, 14, 0},
        {10699, 15, 0},
        {10700, 16, 0},
        {10701, 17, 0},
        {10702, 18, 0},
        {10703, 19, 0},
		
        {12221, 20, 0},
        {12215, 21, 0},
        {12217, 22, 0},
        {12219, 23, 0},
        {12223, 24, 0},
		
        {12211, 25, 0},
        {12205, 26, 0},
        {12207, 27, 0},
        {12209, 28, 0},
        {12213, 29, 0},
		
        {12231, 30, 0},
        {12225, 31, 0},
        {12227, 32, 0},
        {12229, 33, 0},
        {12233, 34, 0},
		
        {12241, 35, 0},
        {12235, 36, 0},
        {12237, 37, 0},
        {12239, 38, 0},
        {12243, 39, 0},
		
        {7362, 40, 0},
        {7366, 41, 0},
        {7364, 42, 0},
        {7368, 43, 0},
        {7394, 44, 0},
        {7390, 45, 0},
        {7386, 46, 0},
        {7396, 47, 0},
        {7392, 48, 0},
        {7388, 49, 0},
        {10458, 50, 0},
        {10464, 51, 0},
        {10462, 52, 0},
        {10466, 53, 0},
        {10460, 54, 0},
        {10468, 55, 0},
        {10316, 56, 0},
        {10318, 57, 0},
        {10320, 58, 0},
        {10322, 59, 0},
        {10324, 60, 0},
        {2631, 61, 0},
        {2633, 62, 0},
        {2635, 63, 0},
        {2637, 64, 0},
        {12247, 65, 0},
        {10392, 66, 0},
        {10398, 67, 0},
        {10394, 68, 0},
        {10396, 69, 0},
        {10404, 70, 0},
        {10424, 71, 0},
        {10406, 72, 0},
        {10426, 73, 0},
        {10412, 74, 0},
        {10432, 75, 0},
        {10414, 76, 0},
        {10434, 77, 0},
        {10408, 78, 0},
        {10428, 79, 0},
        {10410, 80, 0},
        {10430, 81, 0},
        {10366, 82, 0},
        {12297, 83, 0},
        {10280, 84, 0}
        // Add more Barrows items...
    };	
	public int[][] MediumClueCollectionLog = {
        {2577, 0, 0},
        {2579, 1, 0},
        {12598, 2, 0},
		
        {2605, 3, 0},
        {2599, 4, 0},
        {2601, 5, 0},
        {3474, 6, 0},
        {2603, 7, 0},
		
        {2613, 8, 0},
        {2607, 9, 0},
        {2609, 10, 0},
        {3475, 11, 0},
        {2611, 12, 0},
		
		
        {10666, 13, 0},
        {10669, 14, 0},
        {10672, 15, 0},
        {10675, 16, 0},
        {10678, 17, 0},
		
        {10709, 18, 0},
		{10710, 19, 0},
        {10711, 20, 0},
        {10712, 21, 0},
        {10713, 22, 0},
		
        {12293, 23, 0},
		{12287, 24, 0},
        {12289, 25, 0},
        {12295, 26, 0},
        {12291, 27, 0},
		
        {12283, 28, 0},
        {12277, 29, 0},
        {12279, 30, 0},
        {12285, 31, 0},
        {12281, 32, 0},
		
        {7370, 33, 0},
        {7372, 34, 0},
        {7378, 35, 0},
        {7380, 36, 0},
		
        {10452, 37, 0},
        {10446, 38, 0},
		
        {10454, 39, 0},
        {10448, 40, 0},
		
        {10456, 41, 0},
        {10450, 42, 0},
		
        {7319, 43, 0},
        {7323, 44, 0},
        {7321, 45, 0},
        {7327, 46, 0},
        {7325, 47, 0},
        {12309, 48, 0},
        {12311, 49, 0},
        {12313, 50, 0},
		
        {2645, 51, 0},
        {2647, 52, 0},
        {2649, 53, 0},
        {12299, 54, 0},
        {12301, 55, 0},
        {12303, 56, 0},
        {12305, 57, 0},
        {12307, 58, 0},
		
        {10416, 59, 0},
        {10436, 60, 0},
        {10418, 61, 0},
        {10438, 62, 0},
		
        {10400, 63, 0},
        {10420, 64, 0},
        {10402, 65, 0},
        {10422, 66, 0},
		
        {10364, 67, 0},
        {10282, 68, 0}
        // Add more Barrows items...
    };		
	public int[][] HardClueCollectionLog = {
        {2581, 0, 0},
		
        {2627, 1, 0},//full helm
        {2623, 2, 0},//platebody
        {2625, 3, 0},//platelegs
        {3477, 4, 0},//plateskirt
        {2629, 5, 0},//kiteshield
		
        {2619, 6, 0},//full helm
        {2615, 7, 0},//platebody
        {2617, 8, 0},//platelegs
        {3478, 9, 0},//plateskirt
        {2621, 10, 0},//kiteshield
		
        {2657, 11, 0},//full helm
        {2653, 12, 0},//platebody
        {2655, 13, 0},//platelegs
        {3478, 14, 0},//plateskirt
        {2659, 15, 0},//kiteshield
		
        {2673, 16, 0},//full helm
        {2669, 17, 0},//platebody
        {2671, 18, 0},//platelegs
        {3480, 19, 0},//plateskirt
        {2675, 20, 0},//kiteshield
		
        {2665, 21, 0},//full helm
        {2661, 22, 0},//platebody
        {2663, 23, 0},//platelegs
        {3479, 24, 0},//plateskirt
        {2667, 25, 0},//kiteshield
		
        {10667, 26, 0},//h1
        {10670, 27, 0},//h2
        {10673, 28, 0},//h3
        {10676, 29, 0},//h4
        {10679, 30, 0},//h5
		
        {10286, 31, 0},//h1
        {10288, 32, 0},//h2
        {10290, 33, 0},//h3
        {10292, 34, 0},//h4
        {10294, 35, 0},//h5
		
		//sara dhide
        {10390, 36, 0},//coif
        {10386, 37, 0},//body
        {10388, 38, 0},//legs
        {10384, 39, 0},//vambs
		//guthix dhide
        {10382, 40, 0},//coif
        {10378, 41, 0},//body
        {10380, 42, 0},//legs
        {10376, 43, 0},//vambs
		
		//zam dhide
        {10374, 44, 0},//coif
        {10370, 45, 0},//body
        {10372, 46, 0},//legs
        {10368, 47, 0},//vambs
		
		//red dhide(t)
        {12331, 48, 0},//body
        {12333, 49, 0},//chaps
		
		//red dhide(g)
        {12327, 50, 0},//body
        {12329, 51, 0},//chaps
		
		//blue dhide(t)
        {7376, 52, 0},//body
        {7384, 53, 0},//chaps
		//blue dhide(g)
        {7374, 54, 0},//body
        {7382, 55, 0},//chaps
		//enchanged
        {7400, 56, 0},//hat
        {7399, 57, 0},//top
        {7398, 58, 0},//bottoms
		//stoles
        {10470, 59, 0},//sara
        {10472, 60, 0},//guthix
        {10474, 61, 0},//zamorak
		//croziers
        {10440, 62, 0},//sara
        {10442, 63, 0},//guthix
        {10444, 64, 0},//zamorak
		//pirates hat
        {2651, 65, 0},//sara
		//cavs
        {12323, 66, 0},//red
        {12321, 67, 0},//white
        {12325, 68, 0},//blue
        {2639, 69, 0},//tan
        {2641, 70, 0},//dark
        {2643, 71, 0},//black
		
        {10354, 72, 0},//Amulet_of_glory(t4)
		
        {10284, 73, 0}//Magic_comp_bow
        // Add more Barrows items...
    };		
	public int[][] EliteClueCollectionLog = {
        {13101, 0, 0},
		
        {13107, 1, 0},//full helm
        {13109, 2, 0},//platebody
        {13111, 3, 0},//platelegs
        {13113, 4, 0},//plateskirt
		
        {12385, 5, 0},//kiteshield
        {12387, 6, 0},//kiteshield
        {12381, 7, 0},//kiteshield
        {12383, 8, 0},//kiteshield
		
        {13095, 9, 0},//kiteshield
        {13097, 10, 0},//kiteshield
        {13099, 11, 0},//kiteshield
        {13006, 12, 0},//kiteshield
        {13763, 13, 0}//kiteshield
        // Add more Barrows items...
    };	
	public int[][] MasterRareClueCollectionLog = {
        {12426, 0, 0},
        {12422, 1, 0},
        {12437, 2, 0},
        {12424, 3, 0},
        {10334, 4, 0},
		
        {10330, 5, 0},//full helm
        {10332, 6, 0},//platebody
        {10336, 7, 0},//platelegs
        {10342, 8, 0},//plateskirt
		
        {10338, 9, 0},//kiteshield
        {10340, 10, 0},//kiteshield
        {10344, 11, 0},//kiteshield
        {10350, 12, 0},//kiteshield
		
        {10348, 13, 0},//kiteshield
        {10346, 14, 0},//kiteshield
        {10352, 15, 0},//kiteshield
        {12389, 16, 0},//kiteshield
        {12391, 17, 0},//kiteshield
        {13578, 18, 0},//kiteshield
        {3486, 19, 0},//kiteshield
        {3481, 20, 0},//kiteshield
        {3483, 21, 0},//kiteshield
        {3485, 22, 0},//kiteshield
        {3488, 23, 0}//kiteshield
        // Add more Barrows items...
    };	
	public int[][] SharedClueCollectionLog = {
        {3827, 0, 0},
        {3831, 1, 0},
        {3835, 2, 0},
        {3828, 3, 0},
        {3832, 4, 0},
		
        {3836, 5, 0},//full helm
        {3829, 6, 0},//platebody
        {3833, 7, 0},//platelegs
        {3837, 8, 0},//plateskirt
		
        {3830, 9, 0},//kiteshield
        {3834, 10, 0},//kiteshield
        {3838, 11, 0},//kiteshield
		
        {12402, 12, 0},//kiteshield		
        {12403, 13, 0},//kiteshield
        {12404, 14, 0},//kiteshield
        {12405, 15, 0},//kiteshield
        {12406, 16, 0},//kiteshield
        {12407, 17, 0},//kiteshield
        {12408, 18, 0},//kiteshield
        {12409, 19, 0},//kiteshield
        {12410, 20, 0},//kiteshield
        {12411, 21, 0},//kiteshield
		
        {7329, 22, 0},//kiteshield
        {7330, 23, 0},//kiteshield
        {7331, 24, 0},//kiteshield
        {10326, 25, 0},//kiteshield
        {10327, 26, 0},//kiteshield
        {10476, 27, 0}
        // Add more Barrows items...
    };	


		public void openCollectionLog(int[][] bossCollectionLog) {
			for(int i = 0; i < 89; i++)
					c.getPA().sendFrame34a(35814, -1, i, 0);
			for (int i = 0; i < bossCollectionLog.length; i++) {
				int itemID = bossCollectionLog[i][0];
				int slot = bossCollectionLog[i][1];
				int currentAmt = bossCollectionLog[i][2];
				c.getPA().sendFrame34a(35814, itemID, slot, currentAmt);
			}
		}
		public void addBossLogItems(int[][] bossCollectionLog, int itemId, int itemAmt) {
			//for(int i = 25; i < 42; i++)
					//c.getPA().sendFrame34a(35814, -1, i, 0);
			for (int i = 0; i < bossCollectionLog.length; i++) {
				int itemID = bossCollectionLog[i][0];
				int slot = bossCollectionLog[i][1];
				int currentAmt = bossCollectionLog[i][2];
				int updatedAmt = currentAmt + itemAmt;
				if (itemID == itemId) { // Check if itemID matches the itemId parameter
					bossCollectionLog[i][2] = updatedAmt; // Update the item amount in the collection log array
					c.getPA().sendFrame34a(35814, itemID, slot, updatedAmt);
					break; // Exit the loop once the item is found and updated
        }		
			}
		}	
}