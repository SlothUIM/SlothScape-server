package server;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.text.DecimalFormat;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import server.tick.*;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import server.event.EventManager;
import server.event.CycleEventHandler;
import server.model.npcs.NPCHandler;
import server.model.npcs.NPCDrops;
import server.model.players.PlayerHandler;
import server.model.players.Player;
import server.model.players.Client;
import server.model.players.PlayerSave;
import server.event.EventHandler;
import server.model.minigames.*;
import server.net.ConnectionHandler;
import server.net.ConnectionThrottleFilter;
import server.util.SimpleTimer;
import server.util.log.Logger;
import server.world.ItemHandler;
import server.world.ObjectHandler;
import server.world.ObjectManager;
import server.world.ShopHandler;
import server.world.ClanChatHandler;
import server.world.map.ObjectDef;
import server.world.map.VarBit;
import server.clip.*;
import server.model.players.PriceChecker;
import server.model.objects.Doors;
import server.model.objects.DoubleDoors;
import java.util.concurrent.TimeUnit;
/**
 * Server.java
 * 
 * @author Sanity
 * @author Graham
 * @author Blake
 * @author Ryan Lmctruck30
 * 
 */

public class Server {
	public static Server getServer() {
		return singleton;
	}
	private Server() {
	}
	private static Server singleton = new Server();
	private static long minutesCounter;
	
	private static BufferedReader minuteFile;
	private static void startMinutesCounter() {
		try {
			minuteFile = new BufferedReader(new FileReader(
					"./data/minutes.log"));
			minutesCounter = Long.parseLong(minuteFile.readLine());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void setMinutesCounter(long minutesCounter) {
		try {
			BufferedWriter minuteCounter = new BufferedWriter(new FileWriter(
					"./data/minutes.log"));
			minuteCounter.write(Long.toString(minutesCounter));
			minuteCounter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static long getMinutesCounter() {
		long d = TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis()
				- minutesCounter);
		return d;
	}
	private static final Scheduler scheduler2 = new Scheduler();


	public static Scheduler getScheduler() {
		return scheduler2;
	}

	public static void schedule(Tick tick) {
		getScheduler().schedule(tick);
	}
	public static boolean sleeping;
	//public static final int cycleRate;
	public static boolean UpdateServer = false;
	public static long lastMassSave = System.currentTimeMillis();
	private static IoAcceptor acceptor;
	private static ConnectionHandler connectionHandler;
	private static ConnectionThrottleFilter throttleFilter;
	private static SimpleTimer engineTimer, debugTimer;
	private static long cycleTime, cycles, totalCycleTime, sleepTime;
	private static DecimalFormat debugPercentFormat;
	public static boolean shutdownServer = false;
	public static int garbageCollectDelay = 40;
	public static boolean shutdownClientHandler;
	public static int serverlistenerPort;
	public static ItemHandler itemHandler = new ItemHandler();
	public static PlayerHandler playerHandler = new PlayerHandler();
	public static NPCHandler npcHandler = new NPCHandler();
	public static ShopHandler shopHandler = new ShopHandler();
	public static ObjectHandler objectHandler = new ObjectHandler();
	public static ObjectManager objectManager = new ObjectManager();
	public static CastleWars castleWars = new CastleWars();
	public static FightPits fightPits = new FightPits();
	public static PestControl pestControl = new PestControl();
	public static NPCDrops npcDrops = new NPCDrops();
	public static ClanChatHandler clanChat = new ClanChatHandler();
	public static FightCaves fightCaves = new FightCaves();
	
	private static EventHandler eventHandler = new EventHandler();
	// public static WorldMap worldMap = new WorldMap();
	// private static final WorkerThread engine = new WorkerThread();

	private final static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	static {
			serverlistenerPort = 43594;
		//cycleRate = 600;
		shutdownServer = false;
		//engineTimer = new SimpleTimer();
		//debugTimer = new SimpleTimer();
		//sleepTime = 0;
		//debugPercentFormat = new DecimalFormat("0.0#%");
	}

	// height,absX,absY,toAbsX,toAbsY,type
	/*
	 * public static final boolean checkPos(int height,int absX,int absY,int
	 * toAbsX,int toAbsY,int type) { return
	 * I.I(height,absX,absY,toAbsX,toAbsY,type); }
	 */
	 
	public static void main(java.lang.String args[])
			throws NullPointerException, IOException {
		/**
		 * Starting Up Server
		 */

		System.setOut(new Logger(System.out));
		System.setErr(new Logger(System.err));
		System.out.println("Launching...");

		/**
		 * Accepting Connections
		 */
		acceptor = new SocketAcceptor();
		connectionHandler = new ConnectionHandler();

		SocketAcceptorConfig sac = new SocketAcceptorConfig();
		sac.getSessionConfig().setTcpNoDelay(false);
		sac.setReuseAddress(true);
		sac.setBacklog(100);

		throttleFilter = new ConnectionThrottleFilter(Config.CONNECTION_DELAY);
		sac.getFilterChain().addFirst("throttleFilter", throttleFilter);
		acceptor.bind(new InetSocketAddress(serverlistenerPort),
				connectionHandler, sac);

		/**
		 * Initialise Handlers
		 */
				ObjectDef.loadConfig();
				VarBit.unpackConfig();
				Doors.getSingleton().load();
				DoubleDoors.getSingleton().load();
				RegionFactory.load();
				PriceChecker.loadcache();
				npcHandler.init();
				EventManager.initialize();
				Connection.initialize();
				startMinutesCounter();
				setMinutesCounter(minutesCounter);
		/**
		 * Server Successfully Loaded
		 */
		System.out.println("Server listening on port " + serverlistenerPort);
		scheduler.scheduleAtFixedRate(SERVER_TASKS, 0, Config.CYCLE_TIME, TimeUnit.MILLISECONDS);
		
		
		try {
			while (!scheduler.awaitTermination(60, TimeUnit.SECONDS)) {
				// TODO
				// Cleanup?
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		acceptor = null;
		connectionHandler = null;
		sac = null;
		System.exit(0);
	}
	private static Throwable lastThrowable = null;
	private static final Runnable SERVER_TASKS = () -> {
		try {
			
			//World.getWorld().tick();
			//Highpkarena.process();
			//Lowpkarena.process();
			//XericLobby.process();
			CycleEventHandler.getSingleton().process();
			itemHandler.process();
			itemHandler.createglobalitems();
			playerHandler.process();
			npcHandler.process();
			shopHandler.process();
			objectManager.process();
			fightPits.process();
			pestControl.process();
			eventHandler.process();
		if (System.currentTimeMillis() - lastMassSave > 300000) {
					for (Player p : PlayerHandler.players) {
						if (p == null)
							continue;
						PlayerSave.saveGame((Client) p);
						System.out.println("Saved game for " + p.playerName
								+ ".");
						lastMassSave = System.currentTimeMillis();
					}

				}
		} catch (Throwable t) {
			if(lastThrowable == null || !lastThrowable.getMessage().equalsIgnoreCase(t.getMessage())) {
				lastThrowable = t;
				t.printStackTrace();
			}
			System.out.println("A fatal exception has been thrown!");
					for (Player p : PlayerHandler.players) {
						if (p == null)
							continue;
						PlayerSave.saveGame((Client) p);
						System.out.println("Saved game for " + p.playerName + ".");
					}
					scheduler.shutdown(); // Kills the tickloop thread if Exception is thrown.
			//log.warn("Server tasks threw an error! {}", t.getMessage());
			//PlayerHandler.nonNullStream().forEach(PlayerSave::save);
		}
	};
	public static void processAllPackets() {
		for (int j = 0; j < PlayerHandler.players.length; j++) {
			if (PlayerHandler.players[j] != null) {
				while (PlayerHandler.players[j].processQueuedPackets())
					;
			}
		}
	}

	public static boolean playerExecuted = false;

	private static void debug() {
		if (debugTimer.elapsed() > 360 * 1000 || playerExecuted) {
			long averageCycleTime = totalCycleTime / cycles;
			System.out
					.println("Average Cycle Time: " + averageCycleTime + "ms");
			double engineLoad = ((double) averageCycleTime / (double) Config.CYCLE_TIME);
			System.out
					.println("Players online: " + PlayerHandler.playerCount
							+ ", engine load: "
							+ debugPercentFormat.format(engineLoad));
			totalCycleTime = 0;
			cycles = 0;
			System.gc();
			System.runFinalization();
			debugTimer.reset();
			playerExecuted = false;
		}
	}

	public static long getSleepTimer() {
		return sleepTime;
	}

}
