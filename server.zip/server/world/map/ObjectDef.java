package server.world.map;
import server.model.players.Client;

public final class ObjectDef {

	public static ObjectDef getObjectDef(int i) {
		if (i > indices.length)
			i = indices.length - 2;
		for (int j = 0; j < 20; j++)
			if (cache[j].type == i)
				return cache[j];
		cacheIndex = (cacheIndex + 1) % 20;
		ObjectDef object = cache[cacheIndex];
		cacheStream.setOffset(indices[i]);
		object.type = i;
		object.setDefaults();
			object.readValues(cacheStream);
			
			/*if(i > 0)
			object.description += " [ModelID: " + object.models + "] ";*/
		switch(i)
		{
		}
		return object;
	}

	private void setDefaults() {
		models = null;
		modelTypes = null;
		name = null;
		description = null;
		modifiedModelColors = null;
		originalModelColors = null;
		sizeX = 1;
		sizeY = 1;
		unwalkable = true;
		aBoolean757 = true;
		hasActions = false;
		adjustToTerrain = false;
		aBoolean764 = false;
		animationId = -1;
		anInt775 = 16;
		actions = null;
		mapFunctionId = -1;
		mapSceneId = -1;
		solidObject = true;
		plane = 0;
		aBoolean736 = false;
		configId_1 = -1;
		configId = -1;
		childrenIDs = null;
	}

	private static ByteStream cacheStream;
	private static int[] indices;
	public static void loadConfig() {
		cacheStream = new ByteStream(getBuffer("loc.dat"));
		ByteStream index = new ByteStream(getBuffer("loc.idx"));
		int totalObjects = index.getUShort();
		indices = new int[totalObjects+20000];
		int i = 2;
		for (int j = 0; j < totalObjects; j++) {
			indices[j] = i;
			i += index.getUShort();
		}
		
		cache = new ObjectDef[20];
		for (int k = 0; k < 20; k++)
			cache[k] = new ObjectDef();
		System.out.println("[ObjectDef] DONE LOADING OBJECT CONFIGURATION Loaded objects: "+totalObjects);
	}
	public static int varbitID = 0;
	public static int varbitShift = 0;
	public static int varbitShift2 = 0;
	public ObjectDef method580() {
		int i = -1;
		try {
			if (configId_1 != -1) {
				VarBit varBit = VarBit.cache[configId_1];
				varbitID = varBit.setting;
				varbitShift2 = varBit.low;
				varbitShift = varBit.high;
				int i1 = Client.anIntArray1232[varbitShift - varbitShift2];
				i = Client.variousSettings[varbitID] >> varbitShift2 & i1;
				System.out.println("configID: " + varbitID + ", bitShift : " + varbitShift2 + ", low: " + varbitShift + ", mask: " + i1);
			    } else if (configId != -1)
				i = Client.variousSettings[configId];
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int var;
		
		if (i >= 0 && i < childrenIDs.length) {
			var = childrenIDs[i];
		} else 
			var = childrenIDs[childrenIDs.length - 1];
		
		return var != -1 ? getObjectDef(var) : null;
	}
	public int[] solidObjects = { 1902, 1903, 1904, 1905, 1906, 1907, 1908,
			1909, 1910, 1911, 1912, 1536, 1535, 1537, 1538, 5139, 5140, 5141,
			5142, 5143, 5144, 5145, 5146, 5147, 5148, 5149, 5150, 1534, 1533,
			1532, 1531, 1530, 1631, 1624, 733, 1658, 1659, 1631, 1620, 14723,
			14724, 14726, 14622, 14625, 14627, 11668, 11667, 14543, 14749,
			14561, 14750, 14752, 14751, 1547, 1548, 1415, 1508, 1506, 1507,
			1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518, 1519,
			1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1505,
			1504, 3155, 3154, 3152, 10748, 9153, 9154, 9473, 1602, 1603, 1601,
			1600, 9544, 9563, 9547, 2724, 6966, 6965, 9587, 9588, 9626, 9627,
			9596, 9598, 11712, 11713, 11773, 11776, 11652, 11818, 11716, 11721,
			14409, 11715, 11714, 11825, 11409, 11826, 11819, 14411, 14410,
			11719, 11717, 14402, 11828, 11772, 11775, 11686, 12278, 1853,
			11611, 11610, 11609, 11608, 11607, 11561, 11562, 11563, 11564,
			11558, 11616, 11617, 11625, 11624, 12990, 12991, 5634, 1769, 1770,
			135, 134, 11536, 11512, 11529, 11513, 11521, 11520, 11519, 11518,
			11517, 11516, 11514, 11509, 11538, 11537, 11470, 11471, 136, 11528,
			11529, 11530, 11531, 1854, 1000, 9265, 9264, 1591, 11708, 11709,
			11851, 26821 ,26820,26814,24161, 28869, 28867, 28868, 27887};

	public void setSolid(int type) {
		solidObject = false;
		for (int i = 0; i < solidObjects.length; i++) {
			if (type == solidObjects[i]) {
				unwalkable = true;
				solidObject = true;
				continue;
			}
		}

	}

	public static byte[] getBuffer(String s) {
		try {
			java.io.File f = new java.io.File("./Data/world/object/" + s);
			if (!f.exists())
				return null;
			byte[] buffer = new byte[(int) f.length()];
			java.io.DataInputStream dis = new java.io.DataInputStream(
					new java.io.FileInputStream(f));
			dis.readFully(buffer);
			dis.close();
			return buffer;
		} catch (Exception e) {
		}
		return null;
	}


	
	
	private void readValues(ByteStream stream)
	{
		
        while(true) {
				int type;
					type = stream.getUByte();
					if(type == 0)
						break;
					if(type == 1)
					{
						int len = stream.getUByte();
						if(len > 0)
						{
							if(models == null)
							{
								modelTypes = new int[len];
								models = new int[len];
								for(int k1 = 0; k1 < len; k1++)
								{
									models[k1] = stream.getUShort();
									modelTypes[k1] = stream.getUByte();
								}
							} else
							{
								stream.setOffset(stream.getOffset() +(len*3));
							}
						}
					} else if(type == 2) {
							name = stream.readString();
					} else if(type == 3)
								stream.readString();
					else if(type == 5) {
						int len = stream.getUByte();
						if(len > 0) {
							if(models == null || lowMem)
							{
								modelTypes = null;
								models = new int[len];
								for(int l1 = 0; l1 < len; l1++)
									models[l1] = stream.getUShort();
							} else
							{
								stream.setOffset(stream.getOffset() +(len*2));
							}
						}
					} else if(type == 14)
						sizeX = stream.getUByte();
					else if(type == 15)
						sizeY = stream.getUByte();
					else if(type == 17)
						unwalkable = false;
					else if(type == 18)
						aBoolean757 = false;
					else if(type == 19)
						hasActions = (stream.getUByte() == 1);
					else if(type == 21)
						adjustToTerrain = true;
					else if(type == 22) {
					} else if(type == 23)
						aBoolean764 = true;
					else if(type == 24)
					{
						animationId = stream.getUShort();
						if(animationId == 65535)
							animationId = -1;
					} else if(type == 28)
						anInt775 = stream.getUByte();
					else if(type == 29)
						stream.getByte();
					else if(type == 39)
						stream.getByte();
					else if(type >= 30 && type < 39) {
						if(actions == null)
							actions = new String[10];
						actions[type - 30] = stream.readString();
						hasActions = true;
						if(actions[type - 30].equalsIgnoreCase("hidden"))
							actions[type - 30] = null;
					} else if(type == 40) {
						int i1 = stream.getUByte();
						modifiedModelColors = new int[i1];
						originalModelColors = new int[i1];
						for(int i2 = 0; i2 < i1; i2++)
						{
							modifiedModelColors[i2] = stream.getUShort();
							originalModelColors[i2] = stream.getUShort();
						}

					} else if (type == 41) {
						int i1 = stream.getUByte();
						originalTexture = new short[i1];
						modifiedTexture = new short[i1];
						for (int i2 = 0; i2 < i1; i2++) {
							originalTexture[i2] = (short) stream.getUShort();
							modifiedTexture[i2] = (short) stream.getUShort();
						}
				}else if(type == 60)
						mapFunctionId = stream.getUShort();
					else if(type == 62) {
					} else if(type == 64)
						solidObject = false;
					else if(type == 65)
						stream.getUShort();
					else if(type == 66)
						stream.getUShort();
					else if(type == 67)
						stream.getUShort();
					else if(type == 68)
						mapSceneId = stream.getUShort();
					else if(type == 69)
						plane = stream.getUByte();
					else if(type == 70)
						stream.getShort();
					else if(type == 71)
						stream.getShort();
					else if(type == 72)
						stream.getShort();
					else if(type == 73)
						aBoolean736 = true;
					else if(type == 74) {
					} else if(type == 75){
						stream.getUByte();
					} else if(type == 77 || type == 92){
						configId_1 = stream.getUShort();
						if(configId_1 == 65535)
							configId_1 = -1;
						configId = stream.getUShort();
						if(configId == 65535)
							configId = -1;
						
							int var3 = -1;
							if(type == 92) {
									var3 = stream.getUShort();
								if(var3 == 65535)
									var3 = -1;
							}
						int j1 = stream.getUByte();
						childrenIDs = new int[j1 + 2];
						for(int j2 = 0; j2 <= j1; j2++) {
							childrenIDs[j2] = stream.getUShort();
							if(childrenIDs[j2] == 65535)
								childrenIDs[j2] = -1;
						}
						childrenIDs[j1 + 1] = var3;
					}
				else if (type == 78) {
					stream.getUShort(); // ambient sound id
					stream.getUByte();
				} 
				else if (type == 79) {
					stream.setOffset(stream.getOffset() +5);
					int len = stream.getByte();
					stream.setOffset(stream.getOffset() +(len*2));
				}
				else if (type == 81) {
					stream.getUByte();
				}
				else if (type == 82) {
					int mapFunction2 = stream.getUShort();

				
				} else if (type == 249) {
	            }
			} 
	}
	public static int getObjectId(long id) {
		return (int) (id >>> 32) & 0x7fffffff;
	}
	private ObjectDef() {
		type = -1;
	}

	public boolean hasActions() {
		return hasActions;
	}

	public boolean hasName() {
		return name != null && name.length() > 1;
	}

	public boolean solid() {
		return solidObject;
	}

	public int xLength() {
		return sizeX;
	}

	public int yLength() {
		return sizeY;
	}

	public boolean isUnshootable() {
		return aBoolean757;
	}
	public boolean unwalkable() {
		return unwalkable;
	}

	public boolean aBoolean736;
	public String name;
	public int sizeX;
	public int mapFunctionId;
	private int[] originalModelColors;
	private int[] modifiedModelColors;
	private short[] originalTexture;
	private short[] modifiedTexture;
	public int configId;
	public static boolean lowMem;
	public int type;
	public boolean aBoolean757;
	public int mapSceneId;
	public int childrenIDs[];
	public int sizeY;
	public boolean adjustToTerrain;
	public boolean aBoolean764;
	public boolean unwalkable;
	public int plane;
	private static int cacheIndex;
	public int[] models;
	public int configId_1;
	public int anInt775;
	private int[] modelTypes;
	public byte description[];
	public boolean hasActions;
	public boolean solidObject;
	public int animationId;
	private static ObjectDef[] cache;
	public String actions[];

}
