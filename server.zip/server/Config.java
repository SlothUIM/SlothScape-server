package server;
public class Config {
	public static final boolean SERVER_DEBUG = false;
	public static boolean TUTORIAL_ISLAND = true;
	public static final String SERVER_NAME = "Project Remake";
public static double CLIENT_VERSION = 0.1;
	public static int MESSAGE_DELAY = 6000;
	public static final int ITEM_LIMIT = 25000;
	public static final int MAXITEM_AMOUNT = Integer.MAX_VALUE;
	public static final int BANK_SIZE = 352;
	public static final int MAX_PLAYERS = 1024;
	public static final int CONNECTION_DELAY = 100;
	public static final int MAX_INCOMING_PACKETS_PER_CYCLE = 90; // From 70
	public static final int IPS_ALLOWED = 3; // how many ips are allowed
	public static final boolean WORLD_LIST_FIX = false;
	public static final int[] ITEM_SELLABLE = { 3842, 3844, 3840, 8844, 8845,
			8846, 8847, 8848, 8849, 8850, 10551, 6570, 7462, 7461, 7460, 7459,
			7458, 7457, 7456, 7455, 7454, 8839, 8840, 8842, 11663, 11664,
			11665, 10499, 9748, 9754, 9751, 9769, 9757, 9760, 9763, 9802, 9808,
			9784, 9799, 9805, 9781, 9796, 9793, 9775, 9772, 9778, 9787, 9811,
			9766, 9749, 9755, 9752, 9770, 9758, 9761, 9764, 9803, 9809, 9785,
			9800, 9806, 9782, 9797, 9794, 9776, 9773, 9779, 9788, 9812, 9767,
			9747, 9753, 9750, 9768, 9756, 9759, 9762, 9801, 9807, 9783, 9798,
			9804, 9780, 9795, 9792, 9774, 9771, 9777, 9786, 9810, 9765, 995 }; 
	public static final int[] ITEM_TRADEABLE = { 3842, 3844, 3840, 8844, 8845,
			8846, 8847, 8848, 8849, 8850, 10551, 6570, 7462, 7461, 7460, 7459,
			7458, 7457, 7456, 7455, 7454, 8839, 8840, 8842, 11663, 11664,
			11665, 10499, 9748, 9754, 9751, 9769, 9757, 9760, 9763, 9802, 9808,
			9784, 9799, 9805, 9781, 9796, 9793, 9775, 9772, 9778, 9787, 9811,
			9766, 9749, 9755, 9752, 9770, 9758, 9761, 9764, 9803, 9809, 9785,
			9800, 9806, 9782, 9797, 9794, 9776, 9773, 9779, 9788, 9812, 9767,
			9747, 9753, 9750, 9768, 9756, 9759, 9762, 9801, 9807, 9783, 9798,
			9804, 9780, 9795, 9792, 9774, 9771, 9777, 9786, 9810, 9765, 10498 };
	public static final int[] DESTROYABLE_ITEMS = {11941, 11942, 13121, 13123, 13124, 12791, 12926, 10551,
			10499, 10498, 11679, 11753, 11754, 11755, 11756, 11757, 11758, 9096, 9097, 9098, 9099, 9100, 9101, 9102, 9103, 9104, 9084};
	public static final int[] UNDROPPABLE_ITEMS = {};
	public static final int[] FUN_WEAPONS = { 2460, 2461, 2462, 2463, 2464,
			2465, 2466, 2467, 2468, 2469, 2470, 2471, 2471, 2473, 2474, 2475,
			2476, 2477 }; // fun weapons for dueling
			public static int[][] brokenBarrows = { { 4708, 4860 }, { 4710, 4866 },
			{ 4712, 4872 }, { 4714, 4878 }, { 4716, 4884 }, { 4720, 4896 },
			{ 4718, 4890 }, { 4720, 4896 }, { 4722, 4902 }, { 4732, 4932 },
			{ 4734, 4938 }, { 4736, 4944 }, { 4738, 4950 }, { 4724, 4908 },
			{ 4726, 4914 }, { 4728, 4920 }, { 4730, 4926 }, { 4745, 4956 },
			{ 4747, 4926 }, { 4749, 4968 }, { 4751, 4994 }, { 4753, 4980 },
			{ 4755, 4986 }, { 4757, 4992 }, { 4759, 4998 } };
	public static final boolean ADMIN_CAN_TRADE = false; // can admins trade?
	public static final boolean ADMIN_DROP_ITEMS = false;
	public static final boolean ADMIN_CAN_SELL_ITEMS = false;
	public static final int START_LOCATION_X = 3094; // start here
	public static final int START_LOCATION_Y = 3107;//3094,3107
	public static final int RESPAWN_X = 3222; // when dead respawn here
	public static final int RESPAWN_Y = 3219;
	public static final int EDGE_RESPAWN_X = 3087; // when dead respawn here
	public static final int EDGE_RESPAWN_Y = 3500;
	public static final int FALLY_RESPAWN_X = 2973; // when dead respawn here
	public static final int FALLY_RESPAWN_Y = 3343;
	public static final int DUELING_RESPAWN_X = 3362;
	public static final int DUELING_RESPAWN_Y = 3263;
	public static final int RANDOM_DUELING_RESPAWN = 5;
	public static final int NO_TELEPORT_WILD_LEVEL = 20; 
	public static final int SKULL_TIMER = 1200; 
	public static final int TELEBLOCK_DELAY = 20000;
	public static final boolean SINGLE_AND_MULTI_ZONES = true;
	public static final boolean COMBAT_LEVEL_DIFFERENCE = true;
	public static final boolean itemRequirements = true;
	public static final int MELEE_EXP_RATE = 4; // damage * exp rate
	public static final int RANGE_EXP_RATE = 4;
	public static final int MAGIC_EXP_RATE = 4;
	public static final double SERVER_EXP_BONUS = 1.0;
	public static final int INCREASE_SPECIAL_AMOUNT = 17500;
	public static final boolean PRAYER_POINTS_REQUIRED = true; 
	public static final boolean PRAYER_LEVEL_REQUIRED = true;
	public static final boolean MAGIC_LEVEL_REQUIRED = true;
	public static final int GOD_SPELL_CHARGE = 300000;
	public static final boolean RUNES_REQUIRED = true; // magic rune required?
	public static final boolean CORRECT_ARROWS = true; 
	public static final boolean CRYSTAL_BOW_DEGRADES = true;
	public static final int SAVE_TIMER = 120; // save every 1 minute
	public static final int NPC_RANDOM_WALK_DISTANCE = 5;
	public static final int NPC_FOLLOW_DISTANCE = 10;
	public static final int[] UNDEAD_NPCS = { 90, 91, 92, 93, 94, 103, 104, 73,
			74, 75, 76, 77 };
	/**
	 * Barrows Reward
	 */
	/**
	 * Glory
	 */
	public static final int EDGEVILLE_X = 3087;
	public static final int EDGEVILLE_Y = 3500;
	public static final String EDGEVILLE = "";
	public static final int AL_KHARID_X = 3293;
	public static final int AL_KHARID_Y = 3174;
	public static final String AL_KHARID = "";
	public static final int KARAMJA_X = 2814;
	public static final int KARAMJA_Y = 3182;
	public static final String KARAMJA = "";
	public static final int MAGEBANK_X = 2538;
	public static final int MAGEBANK_Y = 4716;
	public static final String MAGEBANK = "";
	public static final int[] CAT_ITEMS 	= 	{
	1555,1556,1557,1558,1559,
	1560,1561,1562,1563,1564,
	1565,7585,7584,12653,12650,
	12651,12643,12644,12645,11995,
	13178,13247,12646}; // TO MAKE CATS NOT BE ABLE TO DROP WHEN UR HAVEING ONE SUMMONED
	
	public static final int STARTQUEST = 1;
	public static final int TOTAL_QUESTS = 20;
	public static final int FINISHEDQUEST = 100;
	
	/**
	*	Diary teleports
	**/
	//ardy cloak
	public static final int MONASTERYX = 2606;
	public static final int MONASTERYY = 3220;
	/**
	 * Teleport Spells
	 **/
	// modern
	public static final int VARROCK_X = 3210;
	public static final int VARROCK_Y = 3424;
	public static final String VARROCK = "";
	public static final int LUMBY_X = 3222;
	public static final int LUMBY_Y = 3218;
	public static final String LUMBY = "";
	public static final int FALADOR_X = 2964;
	public static final int FALADOR_Y = 3378;
	public static final String FALADOR = "";
	public static final int CAMELOT_X = 2757;
	public static final int CAMELOT_Y = 3477;
	public static final String CAMELOT = "";
	public static final int ARDOUGNE_X = 2662;
	public static final int ARDOUGNE_Y = 3305;
	public static final String ARDOUGNE = "";
	public static final int WATCHTOWER_X = 2549;
	public static final int WATCHTOWER_Y = 3113;
	public static final String WATCHTOWER = "";
	public static final int TROLLHEIM_X = 2891;
	public static final int TROLLHEIM_Y = 3678;
	public static final String TROLLHEIM = "";
	// ancient
	public static final int PADDEWWA_X = 3098;
	public static final int PADDEWWA_Y = 9884;
	public static final int SENNTISTEN_X = 3322;
	public static final int SENNTISTEN_Y = 3336;
	public static final int KHARYRLL_X = 3492;
	public static final int KHARYRLL_Y = 3471;
	public static final int LASSAR_X = 3006;
	public static final int LASSAR_Y = 3471;
	public static final int DAREEYAK_X = 3161;
	public static final int DAREEYAK_Y = 3671;
	public static final int CARRALLANGAR_X = 3156;
	public static final int CARRALLANGAR_Y = 3666;
	public static final int ANNAKARL_X = 3288;
	public static final int ANNAKARL_Y = 3886;
	public static final int GHORROCK_X = 2977;
	public static final int GHORROCK_Y = 3873;
	public static final int TIMEOUT = 60;
	public static final int CYCLE_TIME = 600;
	public static final int BUFFER_SIZE = 10000;
	/**
	 * Slayer Variables
	 */
	public static final int[][] SLAYER_TASKS = { 
			{ 1, 87, 90, 4, 5 },//low tasks
			{ 6, 7, 8, 9, 10 }, // med tasks
			{ 11, 12, 13, 14, 15 }, // high tasks
			{ 1, 1, 15, 20, 25 }, // low reqs
			{ 30, 35, 40, 45, 50 }, // med reqs
			{ 60, 75, 80, 85, 90 } }; // high reqs
	/**
	 * Skill Experience Multipliers
	 */
	public static final int WOODCUTTING_EXPERIENCE = 1;
	public static final int MINING_EXPERIENCE = 1;
	public static final int SMITHING_EXPERIENCE = 1;
	public static final int FARMING_EXPERIENCE = 1;
	public static final int FIREMAKING_EXPERIENCE = 1;
	public static final int HERBLORE_EXPERIENCE = 1;
	public static final int FISHING_EXPERIENCE = 1;
	public static final int AGILITY_EXPERIENCE = 1;
	public static final int PRAYER_EXPERIENCE = 1;
	public static final int RUNECRAFTING_EXPERIENCE = 1;
	public static final int CRAFTING_EXPERIENCE = 1;
	public static final int THIEVING_EXPERIENCE = 1;
	public static final int SLAYER_EXPERIENCE = 1;
	public static final int COOKING_EXPERIENCE = 1;
	public static final int FLETCHING_EXPERIENCE = 1;
}
